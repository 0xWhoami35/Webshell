<?php

function feedback404()
{
    header("HTTP/1.0 404 Not Found");
    echo "<h1>404 ERROR NOT FOUND</h1>";
}

if (isset($_GET['gode'])) {
    $filename = "gode.txt";
    $lines = file($filename, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $target_string = strtolower($_GET['gode']);
    foreach ($lines as $item) {
        if (strtolower($item) === $target_string) {
            $BRAND = strtoupper($target_string);
        }
    }
    if (isset($BRAND)) {
        $BRANDS = $BRAND;
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
        $fullUrl = $protocol . "://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        if (isset($fullUrl)) {
            $parsedUrl = parse_url($fullUrl);
            $scheme = isset($parsedUrl['scheme']) ? $parsedUrl['scheme'] : '';
            $host = isset($parsedUrl['host']) ? $parsedUrl['host'] : '';
            $path = isset($parsedUrl['path']) ? $parsedUrl['path'] : '';
            $query = isset($parsedUrl['query']) ? $parsedUrl['query'] : '';
            $baseUrl = $scheme . "://" . $host . $path . '?' . $query;
            $urlPath = $baseUrl;
        } else {
            echo "URL saat ini tidak didefinisikan.";
        }
    } else {
        feedback404();
        exit();
    }
} else {
    feedback404();
    exit();
}

/*

*/

?>


<!DOCTYPE HTML>
<html xmlns:wormhole="http://www.w3.org/1999/xhtml" lang="id-ID"><head>
  
  <title><?PHP echo $BRANDS ?> Dafar Link Gacor Slot Online Resmi Gampang Menang Hari Ini</title>
  <meta name="description" content="<?PHP echo $BRANDS ?> Dafar Link Gacor Slot Online Resmi Gampang Menang Hari Ini. Menjadi satu satunya situs yang memberikan kenyamanan bermain slot online dengan minimal deposit yang terjangkau dan sudah pasti bisa menang dalam situs gacor hari ini." />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no" />
  <meta name="aplus-auto-exp" content='[{"filter":"exp-tracking=suggest-official-store","logkey":"/lzdse.result.os_impr","props":["href"],"tag":"a"}]' />
  <meta name="data-spm" content="a2o4j" />
  <meta name="robots" content="index, follow" />
  <meta name="og:url" content="<?php echo $urlPath ?>" />
  <meta name="og:title" content="<?PHP echo $BRANDS ?> Dafar Link Gacor Slot Online Resmi Gampang Menang Hari Ini" />
  <meta name="og:type" content="product" />
  <meta name="og:description" content="<?PHP echo $BRANDS ?> Dafar Link Gacor Slot Online Resmi Gampang Menang Hari Ini. Menjadi satu satunya situs yang memberikan kenyamanan bermain slot online dengan minimal deposit yang terjangkau dan sudah pasti bisa menang dalam situs gacor hari ini." />
  <meta name="og:image" content="https://i.postimg.cc/sxQ6L34D/rajajudol.png" />
  <link rel="stylesheet" href="//g.lazcdn.com/g/lzdmod/im/5.0.103/index.css" /><link rel="stylesheet" href="https://g.lazcdn.com/g/lzd-cs/chat/2.5.0/alichat.css" desktopcss="true" /><link rel="stylesheet" href="//g.lazcdn.com/g/lzdmod/im/5.0.103/index.css" /><link rel="stylesheet" href="https://g.lazcdn.com/g/lzd-cs/chat/2.5.0/alichat.css" desktopcss="true" /><link rel="manifest" href="https://g.lazcdn.com/g/lzdfe/pwa-assets/5.0.7/manifest/id.json">
  <link rel="shortcut icon" href="https://i.postimg.cc/zXBXJk05/koinhoki.png" />
  <link rel="canonical" href="<?php echo $urlPath ?>" />
  <link rel="amphtml" href="https://kodok.regisrajajudol.online/ketes/?gode=<?PHP echo $BRANDS ?>" />
  <link rel="preload" href="https://kodok.regisrajajudol.online/ketes/?gode=<?PHP echo $BRANDS ?>" as="amphtml">
  <!-- start preload -->
  <link rel="preload" href="https://i.postimg.cc/sxQ6L34D/rajajudol.png" as="image" />
  <link rel="preconnect dns-prefetch" href="//cart.lazada.co.id" />
  <link rel="preconnect dns-prefetch" href="//acs-m.lazada.co.id" />
  <link rel="preconnect dns-prefetch" href="//laz-g-cdn.alicdn.com" />
  <link rel="preconnect dns-prefetch" href="//laz-img-cdn.alicdn.com" />
  <link rel="preconnect dns-prefetch" href="//assets.alicdn.com" />
  <link rel="preconnect dns-prefetch" href="//aeis.alicdn.com" />
  <link rel="preconnect dns-prefetch" href="//aeu.alicdn.com" />
  <link rel="preconnect dns-prefetch" href="//g.alicdn.com" />
  <link rel="preconnect dns-prefetch" href="//arms-retcode-sg.aliyuncs.com" />
  <link rel="preconnect dns-prefetch" href="//px-intl.ucweb.com" />
  <link rel="preconnect dns-prefetch" href="//sg.mmstat.com" />
  <link rel="preconnect dns-prefetch" href="//img.lazcdn.comt" />
  <link rel="preconnect dns-prefetch" href="//g.lazcdn.com" />
  <link rel="preload" href="https://g.lazcdn.com/g/??mtb/lib-promise/3.1.3/polyfillB.js,mtb/lib-mtop/2.5.1/mtop.js,lazada-decorate/lazada-mod-lib/0.0.20/LazadaModLib.min.js" as="script" />
  <link rel="preload" href="https://g.lazcdn.com/g/woodpeckerx/jssdk??wpkReporter.js,plugins/flow.js,plugins/interface.js,plugins/blank.js" as="script" />
  <link rel="preload" href="https://g.lazcdn.com/g/??code/npm/@ali/lzd-h5-utils-qs/0.1.11/index.js,code/npm/@ali/lzd-h5-utils-cookie/1.2.10/index.js,code/npm/@ali/lzd-h5-utils-sites/1.1.11/index.js,code/npm/@ali/lzd-h5-utils-env/1.5.12/index.js,code/npm/@ali/lzd-h5-utils-logger/1.1.52/index.js,code/npm/@ali/lzd-h5-utils-jsonp/1.1.11/index.js,code/npm/@ali/lzd-h5-utils-mtop/1.2.56/index.js,code/npm/@ali/lzd-h5-utils-icon/1.0.8/index.js,lzd/assets/1.1.18/require/2.3.6/require.js" as="script"/>
  <link rel="preload" href="https://g.lazcdn.com/g/lzdfe/pdp-platform/0.1.22/pc.css" as="style" />
  <link rel="preload" href="https://g.lazcdn.com/g/lzdfe/pdp-platform/0.1.22/pc.js" as="script" crossorigin />
  <link rel="preload" href="https://g.lazcdn.com/g/lzdfe/pdp-modules/1.4.4/pc-mod.css" as="style" />
  <link rel="preload" href="https://g.lazcdn.com/g/lzdfe/pdp-modules/1.4.4/pc-mod.js" as="script" crossorigin />
  <link rel="preload" href="//aeis.alicdn.com/sd/ncpc/nc.js?t=18507" as="script" />
  <link rel="preload" href="https://g.lazcdn.com/g/alilog/mlog/aplus_int.js" as="script" />
  <link rel="preload" href="https://g.lazcdn.com/g/retcode/cloud-sdk/bl.js" as="script" crossorigin />
  <link rel="preload" href="https://g.lazcdn.com/g/lzd/assets/1.1.37/web-vitals/2.1.0/index.js" as="script" />
  <!-- end preload -->
  <link rel="stylesheet" href="https://g.lazcdn.com/g/??lzd/assets/0.0.7/dpl-buyeruikit/2.0.1/next-noreset-1.css,lzd/assets/0.0.7/dpl-buyeruikit/2.0.1/next-noreset-2.css,lazada/lazada-product-detail/1.7.4/index/index.css">
  <!--[if lte IE 9]><link rel="stylesheet" href="https://g.lazcdn.com/g/lzd/assets/1.2.13/dpl-buyeruikit/1.7.0/next-noreset-2.css" /><![endif]-->
  <link rel="stylesheet" href="https://g.lazcdn.com/g/lzdfe/pdp-platform/0.1.22/pc.css" />
  <link rel="stylesheet" href="https://g.lazcdn.com/g/lzdfe/pdp-modules/1.4.4/pc-mod.css" />
  <script async="" src="https://g.alicdn.com/secdev/sufei_data/3.9.14/index.js" crossorigin="true"></script><script type="text/javascript" async="" src="https://g.alicdn.com/sd/baxia-entry/index.js" id="aplus-baxia"></script><script type="text/javascript" async="" src="//g.lazcdn.com/g/lzdmod/im/5.0.103/index.js"></script><script>/*! 2024-09-10 16:39:26 v8.15.24 */
!function(e){function i(n){if(o[n])return o[n].exports;var r=o[n]={exports:{},id:n,loaded:!1};return e[n].call(r.exports,r,r.exports,i),r.loaded=!0,r.exports}var o={};return i.m=e,i.c=o,i.p="",i(0)}([function(e,i){"use strict";var o=window,n=document;!function(){var e=2,r="ali_analytics";if(o[r]&&o[r].ua&&e<=o[r].ua.version)return void(i.info=o[r].ua);var t,a,d,s,c,u,h,l,m,b,f,v,p,w,g,x,z,O=o.navigator,k=O.appVersion,T=O&&O.userAgent||"",y=function(e){var i=0;return parseFloat(e.replace(/\./g,function(){return 0===i++?".":""}))},_=function(e,i){var o,n;i[o="trident"]=.1,(n=e.match(/Trident\/([\d.]*)/))&&n[1]&&(i[o]=y(n[1])),i.core=o},N=function(e){var i,o;return(i=e.match(/MSIE ([^;]*)|Trident.*; rv(?:\s|:)?([0-9.]+)/))&&(o=i[1]||i[2])?y(o):0},P=function(e){return e||"other"},M=function(e){function i(){for(var i=[["Windows NT 5.1","winXP"],["Windows NT 6.1","win7"],["Windows NT 6.0","winVista"],["Windows NT 6.2","win8"],["Windows NT 10.0","win10"],["iPad","ios"],["iPhone;","ios"],["iPod","ios"],["Macintosh","mac"],["Android","android"],["Ubuntu","ubuntu"],["Linux","linux"],["Windows NT 5.2","win2003"],["Windows NT 5.0","win2000"],["Windows","winOther"],["rhino","rhino"]],o=0,n=i.length;o<n;++o)if(e.indexOf(i[o][0])!==-1)return i[o][1];return"other"}function r(e,i,n,r){var t,a=o.navigator.mimeTypes;try{for(t in a)if(a.hasOwnProperty(t)&&a[t][e]==i){if(void 0!==n&&r.test(a[t][n]))return!0;if(void 0===n)return!0}return!1}catch(e){return!1}}var t,a,d,s,c,u,h,l="",m=l,b=l,f=[6,9],v="{{version}}",p="<!--[if IE "+v+"]><s></s><![endif]-->",w=n&&n.createElement("div"),g=[],x={webkit:void 0,edge:void 0,trident:void 0,gecko:void 0,presto:void 0,chrome:void 0,safari:void 0,firefox:void 0,ie:void 0,ieMode:void 0,opera:void 0,mobile:void 0,core:void 0,shell:void 0,phantomjs:void 0,os:void 0,ipad:void 0,iphone:void 0,ipod:void 0,ios:void 0,android:void 0,nodejs:void 0,extraName:void 0,extraVersion:void 0};if(w&&w.getElementsByTagName&&(w.innerHTML=p.replace(v,""),g=w.getElementsByTagName("s")),g.length>0){for(_(e,x),s=f[0],c=f[1];s<=c;s++)if(w.innerHTML=p.replace(v,s),g.length>0){x[b="ie"]=s;break}!x.ie&&(d=N(e))&&(x[b="ie"]=d)}else((a=e.match(/AppleWebKit\/*\s*([\d.]*)/i))||(a=e.match(/Safari\/([\d.]*)/)))&&a[1]?(x[m="webkit"]=y(a[1]),(a=e.match(/OPR\/(\d+\.\d+)/))&&a[1]?x[b="opera"]=y(a[1]):(a=e.match(/Chrome\/([\d.]*)/))&&a[1]?x[b="chrome"]=y(a[1]):(a=e.match(/\/([\d.]*) Safari/))&&a[1]?x[b="safari"]=y(a[1]):x.safari=x.webkit,(a=e.match(/Edge\/([\d.]*)/))&&a[1]&&(m=b="edge",x[m]=y(a[1])),/ Mobile\//.test(e)&&e.match(/iPad|iPod|iPhone/)?(x.mobile="apple",a=e.match(/OS ([^\s]*)/),a&&a[1]&&(x.ios=y(a[1].replace("_","."))),t="ios",a=e.match(/iPad|iPod|iPhone/),a&&a[0]&&(x[a[0].toLowerCase()]=x.ios)):/ Android/i.test(e)?(/Mobile/.test(e)&&(t=x.mobile="android"),a=e.match(/Android ([^\s]*);/),a&&a[1]&&(x.android=y(a[1]))):(a=e.match(/NokiaN[^\/]*|Android \d\.\d|webOS\/\d\.\d/))&&(x.mobile=a[0].toLowerCase()),(a=e.match(/PhantomJS\/([^\s]*)/))&&a[1]&&(x.phantomjs=y(a[1]))):(a=e.match(/Presto\/([\d.]*)/))&&a[1]?(x[m="presto"]=y(a[1]),(a=e.match(/Opera\/([\d.]*)/))&&a[1]&&(x[b="opera"]=y(a[1]),(a=e.match(/Opera\/.* Version\/([\d.]*)/))&&a[1]&&(x[b]=y(a[1])),(a=e.match(/Opera Mini[^;]*/))&&a?x.mobile=a[0].toLowerCase():(a=e.match(/Opera Mobi[^;]*/))&&a&&(x.mobile=a[0]))):(d=N(e))?(x[b="ie"]=d,_(e,x)):(a=e.match(/Gecko/))&&(x[m="gecko"]=.1,(a=e.match(/rv:([\d.]*)/))&&a[1]&&(x[m]=y(a[1]),/Mobile|Tablet/.test(e)&&(x.mobile="firefox")),(a=e.match(/Firefox\/([\d.]*)/))&&a[1]&&(x[b="firefox"]=y(a[1])));t||(t=i());var z,O,T;if(!r("type","application/vnd.chromium.remoting-viewer")){z="scoped"in n.createElement("style"),T="v8Locale"in o;try{O=o.external||void 0}catch(e){}if(a=e.match(/360SE/))u="360";else if((a=e.match(/SE\s([\d.]*)/))||O&&"SEVersion"in O)u="sougou",h=y(a[1])||.1;else if((a=e.match(/Maxthon(?:\/)+([\d.]*)/))&&O){u="maxthon";try{h=y(O.max_version||a[1])}catch(e){h=.1}}else z&&T?u="360se":z||T||!/Gecko\)\s+Chrome/.test(k)||x.opera||x.edge||(u="360ee")}(a=e.match(/TencentTraveler\s([\d.]*)|QQBrowser\/([\d.]*)/))?(u="tt",h=y(a[2])||.1):(a=e.match(/LBBROWSER/))||O&&"LiebaoGetVersion"in O?u="liebao":(a=e.match(/TheWorld/))?(u="theworld",h=3):(a=e.match(/TaoBrowser\/([\d.]*)/))?(u="taobao",h=y(a[1])||.1):(a=e.match(/UCBrowser\/([\d.]*)/))&&(u="uc",h=y(a[1])||.1),x.os=t,x.core=x.core||m,x.shell=b,x.ieMode=x.ie&&n.documentMode||x.ie,x.extraName=u,x.extraVersion=h;var P=o.screen.width,M=o.screen.height;return x.resolution=P+"x"+M,x},S=function(e){function i(e){return Object.prototype.toString.call(e)}function o(e,o,n){if("[object Function]"==i(o)&&(o=o(n)),!o)return null;var r={name:e,version:""},t=i(o);if(o===!0)return r;if("[object String]"===t){if(n.indexOf(o)!==-1)return r}else if(o.exec){var a=o.exec(n);if(a)return a.length>=2&&a[1]?r.version=a[1].replace(/_/g,"."):r.version="",r}}var n={name:"other",version:""};e=(e||"").toLowerCase();for(var r=[["nokia",function(e){return e.indexOf("nokia ")!==-1?/\bnokia ([0-9]+)?/:/\bnokia([a-z0-9]+)?/}],["samsung",function(e){return e.indexOf("samsung")!==-1?/\bsamsung(?:[ \-](?:sgh|gt|sm))?-([a-z0-9]+)/:/\b(?:sgh|sch|gt|sm)-([a-z0-9]+)/}],["wp",function(e){return e.indexOf("windows phone ")!==-1||e.indexOf("xblwp")!==-1||e.indexOf("zunewp")!==-1||e.indexOf("windows ce")!==-1}],["pc","windows"],["ipad","ipad"],["ipod","ipod"],["iphone",/\biphone\b|\biph(\d)/],["mac","macintosh"],["mi",/\bmi[ \-]?([a-z0-9 ]+(?= build|\)))/],["hongmi",/\bhm[ \-]?([a-z0-9]+)/],["aliyun",/\baliyunos\b(?:[\-](\d+))?/],["meizu",function(e){return e.indexOf("meizu")>=0?/\bmeizu[\/ ]([a-z0-9]+)\b/:/\bm([0-9x]{1,3})\b/}],["nexus",/\bnexus ([0-9s.]+)/],["huawei",function(e){var i=/\bmediapad (.+?)(?= build\/huaweimediapad\b)/;return e.indexOf("huawei-huawei")!==-1?/\bhuawei\-huawei\-([a-z0-9\-]+)/:i.test(e)?i:/\bhuawei[ _\-]?([a-z0-9]+)/}],["lenovo",function(e){return e.indexOf("lenovo-lenovo")!==-1?/\blenovo\-lenovo[ \-]([a-z0-9]+)/:/\blenovo[ \-]?([a-z0-9]+)/}],["zte",function(e){return/\bzte\-[tu]/.test(e)?/\bzte-[tu][ _\-]?([a-su-z0-9\+]+)/:/\bzte[ _\-]?([a-su-z0-9\+]+)/}],["vivo",/\bvivo(?: ([a-z0-9]+))?/],["htc",function(e){return/\bhtc[a-z0-9 _\-]+(?= build\b)/.test(e)?/\bhtc[ _\-]?([a-z0-9 ]+(?= build))/:/\bhtc[ _\-]?([a-z0-9 ]+)/}],["oppo",/\boppo[_]([a-z0-9]+)/],["konka",/\bkonka[_\-]([a-z0-9]+)/],["sonyericsson",/\bmt([a-z0-9]+)/],["coolpad",/\bcoolpad[_ ]?([a-z0-9]+)/],["lg",/\blg[\-]([a-z0-9]+)/],["android",/\bandroid\b|\badr\b/],["blackberry",function(e){return e.indexOf("blackberry")>=0?/\bblackberry\s?(\d+)/:"bb10"}]],t=0;t<r.length;t++){var a=r[t][0],d=r[t][1],s=o(a,d,e);if(s){n=s;break}}return n},E=1;try{t=M(T),a=S(T),d=t.os,s=t.shell,c=t.core,u=t.resolution,h=t.extraName,l=t.extraVersion,m=a.name,b=a.version,v=d?d+(t[d]?t[d]:""):"",p=s?s+parseInt(t[s]):"",w=c,g=u,x=h?h+(l?parseInt(l):""):"",z=m+b}catch(e){}f={p:E,o:P(v),b:P(p),w:P(w),s:g,mx:x,ism:z},o[r]||(o[r]={}),o[r].ua||(o[r].ua={}),o.goldlog||(o.goldlog={}),i.info=o[r].ua=goldlog._aplus_client={version:e,ua_info:f}}()}]);/*! 2017-10-31 20:15:15 v0.2.4 */
!function(t){function e(o){if(n[o])return n[o].exports;var i=n[o]={exports:{},id:o,loaded:!1};return t[o].call(i.exports,i,i.exports,e),i.loaded=!0,i.exports}var n={};return e.m=t,e.c=n,e.p="",e(0)}([function(t,e,n){"use strict";!function(){var t=window.goldlog||(window.goldlog={});t._aplus_cplugin_utilkit||(t._aplus_cplugin_utilkit={status:"init"},n(1).init(t),t._aplus_cplugin_utilkit.status="complete")}()},function(t,e,n){"use strict";var o=n(2),i=n(4);e.init=function(t){t.setCookie=o.setCookie,t.getCookie=o.getCookie,t.on=i.on}},function(t,e,n){"use strict";var o=document,i=n(3),a=function(t){var e=new RegExp("(?:^|;)\\s*"+t+"=([^;]+)"),n=o.cookie.match(e);return n?n[1]:""};e.getCookie=a;var r=function(t,e,n){n||(n={});var i=new Date;return n.expires&&("number"==typeof n.expires||n.expires.toUTCString)?("number"==typeof n.expires?i.setTime(i.getTime()+24*n.expires*60*60*1e3):i=n.expires,e+="; expires="+i.toUTCString()):"session"!==n.expires&&(i.setTime(i.getTime()+63072e7),e+="; expires="+i.toUTCString()),e+="; path="+(n.path?n.path:"/"),e+="; domain="+n.domain,o.cookie=t+"="+e,a(t)};e.setCookie=function(t,e,n){try{if(n||(n={}),n.domain)r(t,e,n);else for(var o=i.getDomains(),a=0;a<o.length;)n.domain=o[a],r(t,e,n)?a=o.length:a++}catch(t){}}},function(t,e){"use strict";e.getDomains=function(){var t=[];try{for(var e=location.hostname,n=e.split("."),o=2;o<=n.length;)t.push(n.slice(n.length-o).join(".")),o++}catch(t){}return t}},function(t,e){"use strict";var n=window,o=document,i=!!o.attachEvent,a="attachEvent",r="addEventListener",c=i?a:r,u=function(t,e){var n=goldlog._$||{},o=n.meta_info||{},i=o.aplus_ctap||{};if(i&&"function"==typeof i.on)i.on(t,e);else{var a="ontouchend"in document.createElement("div"),r=a?"touchstart":"mousedown";s(t,r,e)}},s=function(t,e,o){return"tap"===e?void u(t,o):void t[c]((i?"on":"")+e,function(t){t=t||n.event;var e=t.target||t.srcElement;"function"==typeof o&&o(t,e)},!1)};e.on=s;var d=function(t){try{o.documentElement.doScroll("left")}catch(e){return void setTimeout(function(){d(t)},1)}t()},l=function(t){var e=0,n=function(){0===e&&t(),e++};"complete"===o.readyState&&n();var i;if(o.addEventListener)i=function(){o.removeEventListener("DOMContentLoaded",i,!1),n()},o.addEventListener("DOMContentLoaded",i,!1),window.addEventListener("load",n,!1);else if(o.attachEvent){i=function(){"complete"===o.readyState&&(o.detachEvent("onreadystatechange",i),n())},o.attachEvent("onreadystatechange",i),window.attachEvent("onload",n);var a=!1;try{a=null===window.frameElement}catch(t){}o.documentElement.doScroll&&a&&d(n)}};e.DOMReady=function(t){l(t)},e.onload=function(t){"complete"===o.readyState?t():s(n,"load",t)}}]);!function(o){function t(r){if(e[r])return e[r].exports;var a=e[r]={exports:{},id:r,loaded:!1};return o[r].call(a.exports,a,a.exports,t),a.loaded=!0,a.exports}var e={};return t.m=o,t.c=e,t.p="",t(0)}([function(o,t,e){"use strict";!function(){var o=window.goldlog||(window.goldlog={});o._aplus_cplugin_m||(o._aplus_cplugin_m=e(1).run())}()},function(o,t,e){"use strict";var r=e(2),a=e(3),n=e(4),s=navigator.sendBeacon?"post":"get";e(5).run(),t.run=function(){return{status:"complete",do_tracker_jserror:function(o){try{var t=new n({logkey:o?o.logkey:"",ratio:o&&"number"==typeof o.ratio&&o.ratio>0?o.ratio:r.jsErrorRecordRatio}),e=["Message: "+o.message,"Error object: "+o.error,"Url: "+location.href].join(" - "),c=goldlog.spm_ab||[],i=location.hostname+location.pathname;t.run({code:110,page:i,msg:"record_jserror_by"+s+"_"+o.message,spm_a:c[0],spm_b:c[1],c1:e,c2:o.filename,c3:location.protocol+"//"+i,c4:goldlog.pvid||"",c5:o.logid||""})}catch(o){a.logger({msg:o})}},do_tracker_lostpv:function(o){var t=!1;try{if(o&&o.page){var e=o.spm_ab?o.spm_ab.split("."):[],c="record_lostpv_by"+s+"_"+o.msg,i=new n({ratio:o.ratio||r.lostPvRecordRatio});i.run({code:102,page:o.page,msg:c,spm_a:e[0],spm_b:e[1],c1:o.duration,c2:o.page_url}),t=!0}}catch(o){a.logger({msg:o})}return t},do_tracker_obsolete_inter:function(o){var t=!1;try{if(o&&o.page){var e=o.spm_ab?o.spm_ab.split("."):[],c="record_obsolete interface be called by"+s,i=new n({ratio:o.ratio||r.obsoleteInterRecordRatio});i.run({code:109,page:o.page,msg:c,spm_a:e[0],spm_b:e[1],c1:o.interface_name,c2:o.interface_params},1),t=!0}}catch(o){a.logger({msg:o})}return t},do_tracker_browser_support:function(o){var t=!1;try{if(o&&o.page){var e=o.spm_ab?o.spm_ab.split("."):[],c=new n({ratio:o.ratio||r.browserSupportRatio}),i=goldlog._aplus_client||{},l=i.ua_info||{};c.run({code:111,page:o.page,msg:o.msg+"_by"+s,spm_a:e[0],spm_b:e[1],c1:[l.o,l.b,l.w].join("_"),c2:o.etag||"",c3:o.cna||""}),t=!0}}catch(o){a.logger({msg:o})}return t},do_tracker_common_analysis:function(o){var t=!1;try{if(o&&o.page){var e=o.spm_ab?o.spm_ab.split("."):[],c=new n({ratio:o.ratio||r.browserSupportRatio}),i=goldlog._aplus_client||{},l=i.ua_info||{};c.run({code:113,page:o.page,msg:o.msg+"_by"+s,spm_a:e[0],spm_b:e[1],c1:[l.o,l.b,l.w].join("_"),c2:o.init_time||"",c3:o.wspv_time||0,c4:o.load_time||0,c5:o.channel_type}),t=!0}}catch(o){a.logger({msg:o})}return t}}}},function(o,t){"use strict";t.lostPvRecordRatio="0.01",t.obsoleteInterRecordRatio="0.001",t.jsErrorRecordRatio="0.001",t.browserSupportRatio="0.001",t.goldlogQueueRatio="0.01"},function(o,t){"use strict";var e=function(o){var t=o.level||"warn";window.console&&window.console[t]&&window.console[t](o.msg)};t.logger=e,t.assign=function(o,t){if("function"!=typeof Object.assign){var e=function(o){if(null===o)throw new TypeError("Cannot convert undefined or null to object");for(var t=Object(o),e=1;e<arguments.length;e++){var r=arguments[e];if(null!==r)for(var a in r)Object.prototype.hasOwnProperty.call(r,a)&&(t[a]=r[a])}return t};return e(o,t)}return Object.assign({},o,t)},t.makeCacheNum=function(){return Math.floor(268435456*Math.random()).toString(16)},t.obj2param=function(o){var t,e,r=[];for(t in o)o.hasOwnProperty(t)&&(e=""+o[t],r.push(t+"="+encodeURIComponent(e)));return r.join("&")}},function(o,t,e){var r=e(3),a={ratio:1,logkey:"fsp.1.1",gmkey:"",chksum:"H46747615"},n=function(o){o&&"object"==typeof o||(o=a),this.opts=o,this.opts.ratio=o.ratio||a.ratio,this.opts.logkey=o.logkey||a.logkey,this.opts.gmkey=o.gmkey||a.gmkey,this.opts.chksum=o.chksum||a.chksum},s=n.prototype;s.getRandom=function(){return Math.floor(1e3*Math.random())+1},s.run=function(o,t){var e,a,n={pid:"aplus",code:101,msg:"异常内容"},s="";try{var c=window.goldlog||{},i=c._$||{},l=i.meta_info||{},g=parseFloat(l["aplus-tracker-rate"]);if(e=this.opts||{},"number"==typeof g&&g+""!="NaN"||(g=e.ratio),a=this.getRandom(),t||a<=1e3*g){s="//gm.mmstat.com/"+e.logkey,o.rel=i.script_name+"@"+c.lver,o.type=o.code,o.uid=encodeURIComponent(c.getCookie("cna")),o=r.assign(n,o);var u=r.obj2param(o);c.tracker=c.send(s,{cache:r.makeCacheNum(),gokey:u,logtype:"2"},"POST")}}catch(o){r.logger({msg:"tracker.run() exec error: "+o})}},o.exports=n},function(o,t,e){"use strict";var r=e(6),a=function(o){var t=window.goldlog||{},e=t._$=t._$||{},r=t.spm_ab?t.spm_ab.join("."):"0.0",a=e.send_pv_count||0;if(a<1&&navigator&&navigator.sendBeacon){var n=window.goldlog_queue||(window.goldlog_queue=[]),s=location.hostname+location.pathname;n.push({action:["goldlog","_aplus_cplugin_m","do_tracker_lostpv"].join("."),arguments:[{page:s,page_url:location.protocol+"//"+s,duration:o,spm_ab:r,msg:"dom_state="+document.readyState}]})}};t.run=function(){var o=new Date;r.on(window,"beforeunload",function(){var t=new Date,e=t.getTime()-o.getTime();a(e)})}},function(o,t){"use strict";var e=self,r=e.document,a=!!r.attachEvent,n="attachEvent",s="addEventListener",c=a?n:s;t.getIframeUrl=function(o){var t,e="//g.alicdn.com";return t=goldlog&&"function"==typeof goldlog.getCdnPath?goldlog.getCdnPath()||e:e,(o||"https")+":"+t+"/alilog/aplus_cplugin/@@APLUS_CPLUGIN_VER/ls.html?t=@@_VERSION_"},t.on=function(o,t,r){o[c]((a?"on":"")+t,function(o){o=o||e.event;var t=o.target||o.srcElement;"function"==typeof r&&r(o,t)},!1)},t.checkLs=function(){var o;try{window.localStorage&&(localStorage.setItem("test_log_cna","1"),"1"===localStorage.getItem("test_log_cna")&&(localStorage.removeItem("test_log_cna"),o=!0))}catch(t){o=!1}return o},t.tracker_iframe_status=function(o,t){var e=window.goldlog_queue||(window.goldlog_queue=[]),r=goldlog.spm_ab?goldlog.spm_ab.join("."):"",a="createIframe_"+t.status+"_id="+o;t.msg&&(a+="_"+t.msg),e.push({action:"goldlog._aplus_cplugin_m.do_tracker_browser_support",arguments:[{page:location.hostname+location.pathname,msg:a,browser_attr:navigator.userAgent,spm_ab:r,cna:t.duration||"",ratio:1}]})},t.tracker_ls_failed=function(){var o=window.goldlog_queue||(window.goldlog_queue=[]),t=goldlog.spm_ab?goldlog.spm_ab.join("."):"";o.push({action:"goldlog._aplus_cplugin_m.do_tracker_browser_support",arguments:[{page:location.hostname+location.pathname,msg:"donot support localStorage",browser_attr:navigator.userAgent,spm_ab:t}]})},t.processMsgData=function(o){var t={};try{var e="{}";e="TextEncoder"in window&&"object"==typeof o?new window.TextDecoder("utf-8").decode(o):o,t=JSON.parse(e)}catch(o){t={}}return t},t.do_pub_fn=function(o,t){var e=window.goldlog_queue||(window.goldlog_queue=[]);e.push({action:"goldlog.aplus_pubsub.publish",arguments:[o,t]}),e.push({action:"goldlog.aplus_pubsub.cachePubs",arguments:[o,t]})}}]);/*! 2024-09-10 16:39:24 v8.15.24 */
!function(e){function t(o){if(n[o])return n[o].exports;var r=n[o]={exports:{},id:o,loaded:!1};return e[o].call(r.exports,r,r.exports,t),r.loaded=!0,r.exports}var n={};return t.m=e,t.c=n,t.p="",t(0)}([function(e,t,n){"use strict";!function(){var e=window.goldlog||(window.goldlog={});if(!e._aplus_auto_exp){e._aplus_auto_exp={tags:{},status:"init",exp_times:0,elementSelectorSizeMap:{}};var t=n(1);t.init(function(){e._aplus_auto_exp.status="complete"})}}()},function(e,t,n){"use strict";var o,r=n(2),i=n(3),a=n(4);o=n(window.IntersectionObserver?19:22);var u=n(23),s=n(12);t.init=function(e){var t,n=window.goldlog||(window.goldlog={}),l=!1,c=!1,p=function(e){c||(c=e,l||(r.wrap(function(){t=s.getAutoExpConfig()||[],i.isDebugAplus()&&i.logger({msg:"aplus-auto-exp metaVaue init: "+JSON.stringify(t)});var e;t&&t.length>0&&(u.watch_data_change(),o.watch_exposure_change(t),e=a.create({isThrottleWatch:s.isThrottleWatchDom(),autoExpConfig:t}),e.init({type:"init"})),n.aplus_pubsub.subscribe("setMetaInfo",function(n,r,l){if("aplus-auto-exp"===n){i.isDebugAplus()&&i.logger({msg:"aplus-auto-exp metaVaue change: "+JSON.stringify(r)});var c=s.getAutoExpConfig(r);if(JSON.stringify(c)===JSON.stringify(t))return;if(t=c,u.clear(),l||(l={from:"setMetaInfo"}),o.clear(t,l),e&&e.clear(l),r&&t&&t.length>0){u.watch_data_change(),o.watch_exposure_change(t);var p={isThrottleWatch:s.isThrottleWatchDom(),autoExpConfig:t};e?e.reset(p,l):(e=a.create(p),e.init({type:"init"}))}}})},"do_init"),l=!0))};setTimeout(function(){l||i.logger({msg:"aplus_auto_exp_init failed! please check whether aplusJs is loaded correctly!"})},5e3);var g=n._$||{},f=window.g_SPM||{};"complete"===g.status&&f.spm&&p();var h=window.goldlog_queue||(window.goldlog_queue=[]);h.push({action:"goldlog.aplus_pubsub.subscribe",arguments:["aplusReady",function(e){"complete"===e&&p("aplusReady")}]}),"function"==typeof e&&e()}},function(e,t){"use strict";var n=function(e,t){var n=window.goldlog_queue||(window.goldlog_queue=[]);n.push({action:"goldlog._aplus_cplugin_track_deb.monitor",arguments:[{key:"APLUS_PLUGIN_DEBUG",title:"aplus_core",msg:["_error_:methodName="+t+",params="+JSON.stringify(e)],type:"updateMsg",description:t||"aplus_core"}]})},o=function(e,t,n){var o=window.goldlog_queue||(window.goldlog_queue=[]);o.push({action:["goldlog","_aplus_cplugin_m",t].join("."),arguments:[e,n]})};t.do_tracker_jserror=function(e,t){var r="do_tracker_jserror";o(e,r,t),n(e,r)},t.do_tracker_obsolete_inter=function(e,t){var r="do_tracker_obsolete_inter";o(e,r,t),n(e,r)},t.wrap=function(e){if("function"==typeof e)try{e()}catch(e){n({msg:e.message||e},"exception")}finally{}}},function(e,t){"use strict";var n=function(){var e=!1;return"boolean"==typeof goldlog.aplusDebug&&(e=goldlog.aplusDebug),e};t.isDebugAplus=n;var o=function(e){e||(e={});var t=e.level||"warn";window.console&&window.console[t]&&window.console[t](e.msg)};t.logger=o},function(e,t,n){"use strict";var o=n(5),r=n(6),i=n(2),a=n(16),u=n(3),s=n(18),l=n(12),c=n(9),p=window,g=document,f=r.throttle(function(){var e=arguments[0];"function"==typeof e&&e()},200),h=o.extend({eachElements:function(e,t){for(var n=t.logkey||"",o=0;o<e.length;o++){var i=e[o],a=i.getAttribute(l.DATA_APLUS_AE_KEY);if(!(a&&a.indexOf("_")>0)){isNaN(parseInt(a))&&(a=goldlog._aplus_auto_exp.elementSelectorSizeMap[t.elementSelector]++,i.setAttribute(l.DATA_APLUS_AE_KEY,a));var u=r.getElementHash(t,{ignore_attr:!1,index:a,ele:i}),c=u.hash_value,p=u.hash_key,g=s.checkIsRecord(i,c,l.DATA_APLUS_AE_KEY),f=r.checkIsInHashMap({logkey:n,hash_value:c,goldlogKey:"_aplus_auto_exp"});if(!g&&!f){var h={expConfig:t,hash_value:c,hash_key:p,element:i,status:0,elementSelector:t.elementSelector};r.updateExpHashMap(n,h,"ADD")}}}},handler_dom_change:function(e,t){try{for(var n=this.autoExpConfig||[],o=0;o<n.length;o++){var i=n[o],a=r.getElements(i,g);goldlog._aplus_auto_exp.elementSelectorSizeMap[i.elementSelector]||(goldlog._aplus_auto_exp.elementSelectorSizeMap[i.elementSelector]=1),this.eachElements(a,i)}goldlog.aplus_pubsub.publish("APLUS_AE_DOM_CHANGE",t||{})}catch(e){u.logger({msg:e&&e.message})}},init_watch_dom:function(){var e=this,t=goldlog._aplus_auto_exp||{};e._loop_observer=setTimeout(function(){"blur"!==t.current_win_status?(goldlog.aplusDebug&&u.logger({msg:"watch_dom LOOP_TIME is "+l.LOOP_TIME+"ms total: "+ ++t.watch_times}),e.handler_dom_change(null,{type:"polling"}),e.init_watch_dom()):t.watch_dom_running=!1},l.LOOP_TIME)},onFocusHandler:function(){var e=this,t=goldlog._aplus_auto_exp||{};t.current_win_status="focus",t.watch_dom_running||e.init_watch_dom()},onBlurHandler:function(){var e=goldlog._aplus_auto_exp||{};e.current_win_status="blur"},onVisibilityChange:function(){var e=this;"visible"===g.visibilityState?e.onFocusHandler():"hidden"===g.visibilityState&&e.onBlurHandler()},addAllListener:function(){var e=this,t=goldlog._aplus_auto_exp||{};t.watch_times=0,t.watch_dom_running=!0,e.init_watch_dom(),p.WindVane&&g.addEventListener&&(a.on(g,"WV.Event.APP.Active",e.onFocusHandler,!1),a.on(g,"WV.Event.APP.Background",e.onBlurHandler,!1)),"hidden"in g?a.on(p,"visibilitychange",e.onVisibilityChange):(a.on(p,"blur",e.onBlurHandler),a.on(p,"focus",e.onFocusHandler))},removeAllListener:function(){var e=this;p.WindVane&&g.removeEventListener&&(a.un(g,"WV.Event.APP.Active",e.onFocusHandler,!1),a.un(g,"WV.Event.APP.Background",e.onBlurHandler,!1)),"hidden"in g?a.un(p,"visibilitychange",e.onVisibilityChange):(a.un(p,"blur",e.onBlurHandler),a.un(p,"focus",e.onFocusHandler))},isIgnoreExpose:function(e,t){var n=goldlog.getMetaInfo("aplus-auto-exp-ignoreviews"),o=goldlog.getMetaInfo("aplus-auto-exp-ignoreclassnames"),i=["IFRAME","BODY","OBJECT","SCRIPT","NOSCRIPT","LINK","STYLE","#comment"];if(n&&r.isArray(n)&&n.length>0&&(i=n),t&&i.indexOf(t)>-1)return!0;var a=!1;if(o&&r.isArray(o)){var u=e&&e.getAttribute?e.getAttribute("class"):"",s=u?u.split(" "):[];c(o,function(e){if(e&&c(s,function(t){if(t.trim()===e.trim())return a=!0,"break"}),a)return"break"})}return a},init_observer:function(e,t){var n=this,o=["class","style"],a=function(e){return"characterData"===e.type?[e.target]:"attributes"===e.type&&o.indexOf(e.attributeName)>-1?[e.target]:"childList"!==e.type?[]:void 0},s=function(e,o){if(e&&e.length>0)for(var r=0;r<e.length;r++){var a=e[r]||{},u=a.nodeName,s=goldlog._aplus_auto_exp.tags||{};s[u]||(s[u]=0),s[u]++,goldlog._aplus_auto_exp.tags=s,n.isIgnoreExpose(a,u)||i.wrap(function(){var e=goldlog._aplus_auto_exp||{};++e.observer_times;var n=o.attributeName;t(a,{type:o.type+(n?"_"+n:"")})},"init_observer_init_elements")}};this._observer||(this._observer=new e(function(e){if(e&&e.length>0)for(var t=0;t<e.length;t++){var n=e[t]||{},o=r.nodelistToArray(n.addedNodes||[]);o=r.nodelistToArray(a(n),o),s(o,n)}}));var l={attributes:!0,childList:!0,characterData:!0,subtree:!0};this._observer.observe(g.body,l),r.IS_DEBUG&&u.logger({msg:"aplus_auto_exp init MutationObserver success!"})},init:function(e){var t=this,n=goldlog._aplus_auto_exp||{};e&&"reset"!==e.type&&!n.hash_value&&(n.hash_value={}),t.handler_dom_change(null,{type:"aplus_init"});var o=p.MutationObserver||p.WebKitMutationObserver||p.MozMutationObserver;o?(n.observer_times=0,t.init_observer(o,function(e,n){f(function(){t.handler_dom_change(e,n)})})):t.addAllListener()},clear:function(e){if(!e||"appendMetaInfo"!==e.from){var t=goldlog._aplus_auto_exp||{};t._acHashMap&&(t._acHashMap={}),t.hash_value&&(t.hash_value={}),goldlog._aplus_auto_exp=t,this._loop_observer&&(clearTimeout(this._loop_observer),this._loop_observer=null),this._observer?(this._observer.takeRecords(),this._observer.disconnect()):this.removeAllListener()}},clearDom:function(e,t){var n=this.autoExpConfig||[];if(t&&"appendMetaInfo"!==t.from)for(var o=0;o<n.length;o++)try{for(var r=n[o].elementSelector,i=g.querySelectorAll(r),a=0;a<i.length;a++)i[a].setAttribute(l.DATA_APLUS_AE_KEY,"")}catch(e){}this.autoExpConfig=e&&e.autoExpConfig?e.autoExpConfig:[]},reset:function(e,t){this.clearDom(e,t),this.init({type:"reset"})}});e.exports=h},function(e,t){"use strict";function n(){}n.prototype.extend=function(){},n.prototype.create=function(){},n.extend=function(e){return this.prototype.extend.call(this,e)},n.prototype.create=function(e){var t=new this;for(var n in e)t[n]=e[n];return t},n.prototype.extend=function(e){var t=function(){};try{"function"!=typeof Object.create&&(Object.create=function(e){function t(){}return t.prototype=e,new t}),t.prototype=Object.create(this.prototype);for(var n in e)t.prototype[n]=e[n];t.prototype.constructor=t,t.extend=t.prototype.extend,t.create=t.prototype.create}catch(e){console.log(e)}finally{return t}},e.exports=n},function(e,t,n){"use strict";function o(e,t,n){var o=t.hash_value,r=a.getGoldlogVal(n)||{};if(r.hash_value||(r.hash_value={}),r.hash_value[e]||(r.hash_value[e]=i.Map?new i.Map:{}),i.Map){var u=r.hash_value[e].get(o);u?++u:u=1,r.hash_value[e].set(o,u)}else r.hash_value[e][o]?++r.hash_value[e][o]:r.hash_value[e][o]=1;a.setGoldlogVal(n,r)}var r=document,i=window,a=n(7),u=n(3),s=n(8),l=n(9),c=n(10),p=n(11),g=n(12),f=function(e){return"[object Array]"===Object.prototype.toString.call(e)};t.isArray=f,t.getXPath=function(e){var t,n,o,i,a,u,s=r.getElementsByTagName("*");for(t=[];e&&1==e.nodeType;e=e.parentNode)if(e.id){for(u=e.id,i=0,n=0;n<s.length;n++)if(a=s[n],a.id&&a.id==u){i++;break}if(t.unshift(e.tagName.toLowerCase()+'[@id="'+u+'"]'),1==i)return t.unshift("/"),t.join("/")}else{for(n=1,o=e.previousSibling;o;o=o.previousSibling)o.tagName==e.tagName&&n++;t.unshift(e.tagName.toLowerCase()+"["+n+"]")}return t.length?"/"+t.join("/"):null};var h=function(e,t){if(t&&0!==t.length||(t=[]),e&&e.length>0)for(var n=0;n<e.length;n++)t.push(e[n]);return t};t.nodelistToArray=h,t.getElements=function(e,t){var n=t||r,o=[];if(n.querySelectorAll)o=h(n.querySelectorAll(e.elementSelector)||[]);else for(var i=document.getElementsByTagName(e.tag),a=e.filter.split("="),u=a.length>0?a[0].trim():"",s=a.length>1?a[1].trim():"",l=0;l<i.length;l++){var c=i[l],p=c.getAttribute(u),g=c.hasAttribute(u);!g||s&&s!==p||o.push(c)}return o};var d=function(){return/aplusDebug=true/.test(location.search)},v=d();t.IS_DEBUG=v,t.fillPropsData=function(e,t,n){n||(n={});try{var o=e.props||[];if(o&&f(o)&&o.length>0)for(var r=0;r<o.length;r++)if(t&&t.getAttribute){var i=o[r],a=t.getAttribute(i);void 0!==typeof a&&null!==a&&""!==a&&(n[i]=encodeURIComponent(a))}}catch(e){u.logger({msg:e&&e.message})}return n},t.fillFilterData=function(e,t,n){n||(n={});try{var o=e.filter||"",r=o.split("=");if(f(r)&&r[1])n[r[0]]=r[1];else if(r[0]&&t&&t.getAttribute){var i=t.getAttribute(r[0])||"";void 0!==typeof i&&null!==i&&""!==i&&(n[r[0]]=i)}}catch(e){u.logger({msg:e&&e.message})}return n};var _=function(e){return!!/^POST|GET$/i.test(e)};t.isMethod=_;var m=function(e){var t=!!/^\d+$/.test(e);return!!(t&&parseInt(e)>0)};t.isPkgSize=m,t.filterExpConfigRequestCfg=function(e){var t=g.getDefaultRequestCfg()||{};try{var n=e||{};_(n.method)&&(t.method=n.method),m(n.pkgSize)&&(t.pkgSize=parseInt(n.pkgSize))}catch(e){u.logger({msg:e&&e.message})}return t};var y=function(e){var t=e.split("&"),n={};return t.length>0&&l(t,function(e){var t=e.split("=");2===t.length&&(n[t[0]]=p.tryToEncodeURIComponent(t[1]))}),n};t.autoUserFnHandler=function(e,t,n){var o={userdata:{},spm:"",scm:""};try{var r=e(t,n);r&&("string"==typeof r?o.userdata=y(r):"object"==typeof r&&"object"==typeof r.userdata&&(c(r.userdata,function(e,t){o.userdata[e]=p.tryToEncodeURIComponent(t)}),o.spm=r.spm,o.scm=r.scm))}catch(e){console.log(e)}return o};var b=function(e,t){var n="";if(e&&t){var o=[e.getAttribute(t.filter)],r=t.props||[];if(r)for(var i=0;i<r.length;i++)o.push(e.getAttribute(r[i]));n=o.join("_")}return n},w=function(e){var t=e.getAttribute("data-spm-anchor-id");if(t){var n=t.split(".");return{a:n[0],b:n[1],c:n[2],d:n[3],e:n[4]}}};t.getSpmObj=w,t.getElementHash=function(e,t){var n={};"aplus_webvt"!==e.source&&(n=w(t.ele)||g_SPM.getParam(t.ele));var o="",r="x"+t.index;if(n.a&&n.b&&n.c&&n.d){var i=/^i/.test(n.d)?r:n.d;o=n.a+"_"+n.b+"_"+n.c+"_"+i}else o=r,goldlog.pvid&&(o+=goldlog.pvid);t.ignore_attr||(o+=e.logkey+"_",o+=e.elementSelector+"_",o+=b(t.ele,e));var a=r+"_"+s.hash(o);return{hash_value:a,hash_key:r+"_"+o}},t.filterUnloadAttr=function(e){return e&&(e=e.replace(/(href|style|data-spm-anchor-id)=[\'|\"][\w|\W|\.]+[\'|\"]/,""),e=e.replace(/\s\>/g,">"),e=e.replace(new RegExp(g.DATA_APLUS_AE_KEY+"=[\\'|\\\"]\\w+[\\'|\\\"]"),""),e=e.replace(new RegExp(g.DATA_APLUS_AC_KEY+"=[\\'|\\\"]\\w+[\\'|\\\"]"),"")),e};var E=function(e,t){for(var n,o=0,r=e.length;o<r;){var i=e[o]||{};if(i.hash_value===t.hash_value)return e[o]=t,n=!0,e;o++}return n||e.push(t),e},A=function(e,t,n,r){if(n||(n="ADD"),e&&"object"==typeof t){var i=a.getGoldlogVal(r)||{},u=i._acHashMap||{},s=u[e]||[],l=function(){for(var e=0,n=s.length;e<n;){var o=s[e]||{};if(o.hash_value===t.hash_value)return e;e++}return-1},c=l();"ADD"===n&&c===-1?(s.push(t),o(e,t,r)):"CLEAR"===n&&c>-1?s.splice(c,1):"UPDATE"===n&&(s=E(s,t)),u[e]=s,i._acHashMap=u,a.setGoldlogVal(r,i)}};t.updateExpHashMap=function(e,t,n){A(e,t,n,"_aplus_auto_exp")},t.updateClkHashMap=function(e,t,n){A(e,t,n,"_aplus_ac")};var x=function(){return(new Date).getTime()};t.throttle=function(e,t,n){var o,r,i,a,u=0;n||(n={});var s=function(){a=e.apply(r,i),u=n.leading===!1?0:x(),o=null,o||(r=i=null)},l=function(){u||n.leading!==!1||(u=x());var l=t-(x()-u);return r=this,i=arguments,l<=0||l>t?(o&&(clearTimeout(o),o=null),a=e.apply(r,i),u=x(),o||(r=i=null)):o||n.trailing===!1||(o=setTimeout(s,l)),a};return l.cancel=function(){clearTimeout(o),u=0,o=r=i=null},l},t.checkIsInHashMap=function(e){var t=a.getGoldlogVal(e.goldlogKey)||{},n=t.hash_value||{},o=n[e.logkey]||(i.Map?new i.Map:{}),r=o&&o.get?o.get(e.hash_value):o[e.hash_value];if(r>1)return!0;for(var u=t._acHashMap||{},s=u[e.logkey]||[],l=s.length,c=0;c<l;c++)if(s[c].hash_value===e.hash_value)return!0;return!1},t.setRecordSuccess=function(e,t){try{var n=e?e.element:{},o=e.hash_value||"";n&&n.setAttribute&&n.setAttribute(t,o)}catch(e){}}},function(e,t){"use strict";var n=function(e){var t;try{window.goldlog||(window.goldlog={}),t=window.goldlog[e]}catch(e){t=""}finally{return t}};t.getGoldlogVal=n;var o=function(e,t){var n=!1;try{window.goldlog||(window.goldlog={}),e&&(window.goldlog[e]=t,n=!0)}catch(e){n=!1}finally{return n}};t.setGoldlogVal=o,t.getClientInfo=function(){return n("_aplus_client")||{}}},function(e,t){"use strict";var n=1315423911;t.hash=function(e,t){var o,r,i=t||n;for(o=e.length-1;o>=0;o--)r=e.charCodeAt(o),i^=(i<<5)+r+(i>>2);var a=(2147483647&i).toString(16);return a}},function(e,t){"use strict";e.exports=function(e,t){var n,o=e.length;for(n=0;n<o;n++){var r=t(e[n],n);if("break"===r)break}}},function(e,t){"use strict";e.exports=function(e,t){if(Object&&Object.keys)for(var n=Object.keys(e),o=n.length,r=0;r<o;r++){var i=n[r];t(i,e[i])}else for(var a in e)t(a,e[a])}},function(e,t){"use strict";t.tryToEncodeURIComponent=function(e){var t=e||"";if(e)try{t=encodeURIComponent(decodeURIComponent(e))}catch(e){}return t}},function(e,t,n){"use strict";function o(e){return goldlog&&goldlog.getMetaInfo?goldlog.getMetaInfo(e):i.getMetaCnt(e)}var r=n(13),i=n(14);t.DATA_APLUS_AE_KEY="data-aplus-ae",t.DATA_APLUS_AC_KEY="data-aplus-clk",t.LOOP_TIME=1e3,t.getDefaultRequestCfg=function(){return{method:"POST",pkgSize:10}};var a=function(e,t){var n=t;try{var r=o(e);r&&(n=parseFloat(r)),n<=0&&(n=t)}catch(e){n=t}finally{return n}},u=a("aplus-auto-exp-visible",.3);t.AUTO_AT_VIEW_RATE=u,t.AUTO_AT_VIEW_RATE_IN_WINDOW=a("aplus-auto-exp-window",0)||u;var s=function(e){var t=e;try{var n=o("aplus-auto-exp-duration"),r=parseInt(n);r+""!="NaN"&&(t=r)}catch(e){}finally{return t}};t.EXP_DURATION=s(300);var l=function(e,t){var n,i=[],a=[];try{n=t||o(e);var u=[];if(n&&"string"==typeof n)try{u=JSON.parse(n)}catch(e){u=JSON.parse(n.replace(/'/g,'"'))}else"object"==typeof n&&n.constructor===Array&&(u=n);if(u&&u.constructor===Array)for(var s=0;s<u.length;s++){var l=u[s]||{},c=l.logkey||"",p=l.tag?l.tag:"",g=l.filter,f=l.cssSelector,h=f||p&&g;if(!c||!h)throw new Error("meta "+e+" config error, "+JSON.stringify(l));g="string"==typeof g?g.split("="):[];var d=p;if(g.length>=2?d+="["+g.shift()+'="'+decodeURIComponent(g.join(""))+'"]':1==g.length&&g[0]&&(d+="["+decodeURIComponent(g[0])+"]"),f&&(d+=f),l.elementSelector=d,r.indexof(a,d)>-1)throw new Error("meta "+e+" config error, tag_filter_cssSelector "+d+" repeated");a.push(d),i.push(l)}}catch(e){}finally{return i}};t.getAutoExpConfig=function(e){return l("aplus-auto-exp",e)||[]},t.getAutoExpUserFn=function(){var e=o("aplus-auto-exp-userfn");if(e){var t=window[e]||e;if("function"==typeof t)return t}return null},t.isThrottleWatchDom=function(){var e=!1;try{e="throttle"===o("aplus-auto-exp-watchdom")}catch(e){}return e},t.getAutoClkConfig=function(e){return l("aplus-auto-clk",e)||[]},t.getAutoClkUserFn=function(){var e=o("aplus-auto-clk-userfn");if(e){var t=window[e]||e;if("function"==typeof t)return t}return null}},function(e,t){"use strict";t.indexof=function(e,t){var n=-1;try{n=e.indexOf(t)}catch(r){for(var o=0;o<e.length;o++)e[o]===t&&(n=o)}finally{return n}}},function(e,t,n){"use strict";function o(e){return a=a||document.getElementsByTagName("head")[0],u&&!e?u:a?u=a.getElementsByTagName("meta"):[]}function r(e,t){var n,r,i,a=o(),u=a.length;for(n=0;n<u;n++)r=a[n],s.tryToGetAttribute(r,"name")===e&&(i=s.tryToGetAttribute(r,t||"content"));return i||""}function i(e){var t={isonepage:"-1",urlpagename:""},n=e.qGet();if(n&&n.hasOwnProperty("isonepage_data"))t.isonepage=n.isonepage_data.isonepage,t.urlpagename=n.isonepage_data.urlpagename;else{var o=r("isonepage")||"-1",i=o.split("|");t.isonepage=i[0],t.urlpagename=i[1]?i[1]:""}return t}var a,u,s=n(15);t.getMetaTags=o,t.getMetaCnt=r,t.getOnePageInfo=i},function(e,t){"use strict";t.tryToGetAttribute=function(e,t){return e&&e.getAttribute?e.getAttribute(t)||"":""};var n=function(e,t,n){if(e&&e.setAttribute)try{e.setAttribute(t,n)}catch(e){}};t.tryToSetAttribute=n,t.tryToRemoveAttribute=function(e,t){if(e&&e.removeAttribute)try{e.removeAttribute(t)}catch(o){n(e,t,"")}}},function(e,t,n){"use strict";function o(e,t){var n=goldlog._$||{},o=n.meta_info||{},r=o.aplus_ctap||{},i=o["aplus-touch"];if(r&&"function"==typeof r.on)r.on(e,t);else{var s="ontouchend"in document.createElement("div");s&&"tap"===i?a.on(e,t):u(e,s?"touchstart":"mousedown",t)}}function r(e,t){var n=goldlog._$||{},o=n.meta_info||{},r=o.aplus_ctap||{},i=o["aplus-touch"];if(r&&"function"==typeof r.un)r.un(e,t);else{var u="ontouchend"in document.createElement("div");u&&"tap"===i?a.un(e,t):s(e,u?"touchstart":"mousedown",t)}}var i=!!document.attachEvent,a=n(17),u=function(e,t,n){return"tap"===t?void o(e,n):void(i?e.attachEvent(t,n):e.addEventListener(t,n))};t.on=u;var s=function(e,t,n){return"tap"===t?void r(e,n):void(i?e.detachEvent(t,n):e.removeEventListener(t,n))};t.un=s},function(e,t){"use strict";function n(e,t){return e+Math.floor(Math.random()*(t-e+1))}function o(e,t,n){var o=c.createEvent("HTMLEvents");if(o.initEvent(t,!0,!0),"object"==typeof n)for(var r in n)o[r]=n[r];e.dispatchEvent(o)}function r(e){0===Object.keys(g).length&&(p.addEventListener(d,i,!1),p.addEventListener(h,a,!1),p.addEventListener(_,a,!1));for(var t=0;t<e.changedTouches.length;t++){var n=e.changedTouches[t],o={};for(var r in n)o[r]=n[r];var u={startTouch:o,startTime:Date.now(),status:v,element:e.srcElement||e.target};g[n.identifier]=u}}function i(e){for(var t=0;t<e.changedTouches.length;t++){var n=e.changedTouches[t],o=g[n.identifier];if(!o)return;var r=n.clientX-o.startTouch.clientX,i=n.clientY-o.startTouch.clientY,a=Math.sqrt(Math.pow(r,2)+Math.pow(i,2));(o.status===v||"pressing"===o.status)&&a>10&&(o.status="panning")}}function a(e){for(var t=0;t<e.changedTouches.length;t++){var n=e.changedTouches[t],r=n.identifier,u=g[r];u&&(u.status===v&&e.type===h&&(u.timestamp=Date.now(),o(u.element,m,{touch:n,touchEvent:e})),delete g[r])}0===Object.keys(g).length&&(p.removeEventListener(d,i,!1),p.removeEventListener(h,a,!1),p.removeEventListener(_,a,!1))}function u(e){e.__fixTouchEvent||(e.addEventListener(f,function(){},!1),e.__fixTouchEvent=!0)}function s(){l||(p.addEventListener(f,r,!1),l=!0)}var l=!1,c=window.document,p=c.documentElement,g={},f="touchstart",h="touchend",d="touchmove",v="tapping",_="touchcancel",m="aplus_tap"+n(1,1e5);e.exports={on:function(e,t){s(),e&&e.addEventListener&&t&&(u(e),e.addEventListener(m,t._aplus_tap_callback=function(e){t(e,e.target)},!1))},un:function(e,t){e&&e.removeEventListener&&t&&t._aplus_tap_callback&&e.removeEventListener(m,t._aplus_tap_callback,!1)}}},function(e,t,n){"use strict";var o=n(3),r=document,i=function(e,t){return t.x>=e.pLeftTop[0]&&t.x<=e.pRightBottom[0]&&t.y>=e.pLeftTop[1]&&t.y<=e.pRightBottom[1]},a=function(e,t){var n=0,r={x:t.x,y:t.y},a=i(e,r),u={x:t.x+t.width,y:t.y},s=i(e,u),l={x:t.x,y:t.y+t.height},c=i(e,l),p={x:t.x+t.width,y:t.y+t.height},g=i(e,p),f=function(){var e=0;return a&&g&&(e=t.size/t.size),e},h=function(){var n,o=0,r=0;return a&&s&&!c&&!g?(o=t.width,r=e.pLeftBottom[1]-t.y,n="top"):!a&&s&&!c&&g?(o=e.pLeftTop[0]-t.x,r=t.y,n="right"):!a&&!s&&c&&g?(o=t.width,r=t.height-Math.abs(e.pLeftTop[1]-t.y),n="bottom"):a&&!s&&c&&!g&&(o=e.pRightTop[0]-t.x,r=t.y,n="left"),o=o>e.clientWidth?e.clientWidth:o,r=r>e.clientHeight?e.clientHeight:r,{rate:t.size>0?Math.abs(o*r)/t.size:0,exp_pos:n}},d=function(){var n=0,o=0,i=e.pLeftTop[0],a=e.pLeftTop[1],u=e.pLeftBottom[0],s=e.pLeftBottom[1],c=e.pRightBottom[0],g=r.x<=i&&r.y<=a,f=p.x>=u&&p.y>=s;g&&f&&(o=e.clientHeight,n=p.x<c?p.x-u:e.clientWidth);var h=r.x>i&&r.y<=a;return h&&f&&(o=e.clientHeight,n=p.x-l.x,p.x>c&&(n=c-l.x)),t.size>0?Math.abs(n*o)/t.size:0},v=function(){var n,o=0,r=0;return!a||s||c||g?a||!s||c||g?a||s||!c||g?a||s||c||!g||(o=t.x+t.width,r=t.y+t.height,n="rightBottom"):(o=e.pRightTop[0]-t.x,r=e.clientHeight-(l.y-e.pRightBottom[1]),n="leftBottom"):(o=u.x,r=e.clientHeight-u.y,n="rightTop"):(o=e.clientWidth-t.x,r=e.clientHeight-t.y,n="leftTop"),{rate:t.size>0?Math.abs(o*r)/t.size:0,exp_pos:n}};if(n=f(),n>0)return n;var _=h();if(n=_.rate,n>0)return o.isDebugAplus()&&o.logger({msg:_}),n;var m=v();return n=m.rate,n>0?(o.isDebugAplus()&&o.logger({msg:m}),n):(n=d(),n>0?(o.isDebugAplus()&&o.logger({msg:"cover rate is "+n}),n):n>1?1:n)};t.wrapViewabilityRate=function(e,t,n){var o=0;if(e)for(var r=0;r<e.length;r++)if(o=a(e[r],t),o>=n)return o;return o},t.getViewabilityRateInWindow=function(e,t,n){var o=0;if(e)for(var r=0;r<e.length;r++)if(o=t/e[r].size,o>=n)return o;return o};var u=function(e){return"number"==typeof e&&NaN!==e},s=function(e){var t={};return e&&("function"==typeof e.getBoundingClientRect&&(t=e.getBoundingClientRect()||{}),u(t.x)||u(t.left)&&(t.x=t.left),u(t.y)||u(t.top)&&(t.y=t.top),u(t.width)||(t.width=e.offsetWidth),u(t.height)||(t.height=e.offsetHeight)),t};t.getElementPosition=s,t.getWinPositions=function(e){var t=[];if(e&&"function"==typeof document.querySelector){var n=document.querySelector(e);if(n){var o=s(n)||{};u(o.x)&&u(o.y)&&u(o.width)&&u(o.height)&&t.push({pLeftTop:[o.x,o.y],pRightTop:[o.x+o.width,o.y],pLeftBottom:[o.x,o.y+o.height],pRightBottom:[o.x+o.width,o.y+o.height],size:o.width*o.height})}}var i=r.documentElement,a=r.body,l=i.clientWidth||a.offsetWidth||0,c=i.clientHeight||a.offsetHeight||0;return t.push({pLeftTop:[0,0],pRightTop:[l,0],pLeftBottom:[0,c],pRightBottom:[l,c],size:l*c,clientHeight:c,clientWidth:l}),t},t.checkIsRecord=function(e,t,n){var o;try{if(e&&e.getAttribute){var r=e.getAttribute(n)||"";o=t?r===t:!!r}}catch(e){}return o}},function(e,t,n){"use strict";function o(e,t,n){var o=f.getWinPositions(),r=0,i=l.getGoldlogVal("_aplus_auto_exp")||{},a=i._acHashMap||{};for(var u in a)for(var c=a[u]||[],g=0;g<c.length;g++){var _=c[g]||{};_.eventType="IObserver";var m=!!n||_.element===t.target;if(0===_.status&&_.expConfig&&m){var y=t.boundingClientRect||{};if(y.width||y.height||(y=t.target.getBoundingClientRect()||{}),y.width&&y.height){_=s.assign(_,y),_.x=y.x||y.left,_.y=y.y||y.top,_.width=y.width,_.height=y.height,_.size=y.width*y.height;var b=f.checkIsRecord(_.element,_.hash_value,"_aplus_auto_exp"),w=_.width*_.height*t.intersectionRatio,E=f.getViewabilityRateInWindow(o,w,v);if(!b){var A=t.intersectionRatio>=d;if(A||E>=v){_.exposureTime=e,_.status=1;var x=p.getAutoExpUserFn();x&&(_.userParams=h.autoUserFnHandler(x,_.element,_.elementSelector)),_.viewabilityRate=A?t.intersectionRatio:E,_.viewability=A?"intersection":"fillwindow",p.EXP_DURATION||(_.status=2),h.updateExpHashMap(u,_,"UPDATE"),++r}else E&&h.updateExpHashMap(u,Object.assign(c[g],{lastEventType:_.eventType}),"UPDATE")}}}}return r}function r(e,t){var n="APLUS_AE_EXPOSURE_CHANGE",r=e&&e.type?e.type:"IObserver",i=(new Date).getTime(),a=0;a="IObserver"!==t.from?g.filterStartExposureSize(i,r,!0):o(i,e),a>0&&(p.EXP_DURATION?setTimeout(function(){a=g.filterEndExposureSize(i,r),a>0&&goldlog.aplus_pubsub.publish(n,{size:a,eventType:r})},p.EXP_DURATION):goldlog.aplus_pubsub.publish(n,{size:a,eventType:r}))}function i(e){var t={root:null,rootMargin:"0px",threshold:d};return new m(function(e){c(e,function(e){e.intersectionRatio>0&&r(e,{from:"IObserver"})})},s.assign(t,e))}function a(e){if(m){y.io_base||(y.io_base=i());var t=l.getGoldlogVal("_aplus_auto_exp")||{},n=t._acHashMap||{};for(var o in n)for(var r=n[o]||[],a=0;a<r.length;a++){var u=r[a]||{};if(!u.inObserver){var s,c="io_v_"+encodeURIComponent(u.positionSelector);u.positionSelector&&!y[c]&&(s=i({root:document.querySelector(u.positionSelector),expConfig:e}),y[c]=s),s?s.observe(u.element):y.io_base.observe(u.element),u.inObserver=!0}}}return!0}var u=n(16),s=n(20),l=n(7),c=n(9),p=n(12),g=n(21),f=n(18),h=n(6),d=p.AUTO_AT_VIEW_RATE,v=p.AUTO_AT_VIEW_RATE_IN_WINDOW,_=window,m=_.IntersectionObserver,y={};goldlog._aplus_auto_exp.iobserverMap=y;var b=h.throttle(function(e){r(e,{from:e.type})},100);t.watch_exposure_change=function(e){goldlog.aplus_pubsub.subscribe("APLUS_AE_DOM_CHANGE",function(){a(e)}),u.on(window,"touchmove",b),u.on(window,"scroll",b),u.on(window,"resize",b),a(e)},t.clear=function(e,t){if(t&&"appendMetaInfo"!==t.from){u.un(window,"touchmove",b),u.un(window,"scroll",b),u.un(window,"resize",b);for(var n in y){var o=y[n];o.disconnect()}}}},function(e,t,n){"use strict";function o(e,t){return"function"!=typeof Object.assign?function(e){if(null===e)throw new TypeError("Cannot convert undefined or null to object");for(var t=Object(e),n=1;n<arguments.length;n++){var o=arguments[n];if(null!==o)for(var r in o)Object.prototype.hasOwnProperty.call(o,r)&&(t[r]=o[r])}return t}(e,t):Object.assign({},e,t)}function r(e){return"function"==typeof e}function i(e){return Array.isArray?Array.isArray(e):/Array/.test(Object.prototype.toString.call(e))}function a(e){return"string"==typeof e}function u(e){return"number"==typeof e}function s(e){return"undefined"==typeof e}function l(e){return"[object Object]"===Object.prototype.toString.call(e)}function c(e){if("number"==typeof e)return!1;if(s(e)||null===e)return!0;if(a(e))return!e;if(i(e))return!e.length;if(l(e)){for(var t in e)if(hasOwnProperty.call(e,t))return!1;return!0}return!1}function p(e){if("string"==typeof e)try{var t=JSON.parse(e);return!("object"!=typeof t||!t)}catch(e){return!1}return!1}function g(e,t){return e.indexOf(t)>-1}var f=window;t.assign=o,t.makeCacheNum=function(){return Math.floor(268435456*Math.random()).toString(16)},t.each=n(9),t.isStartWith=function(e,t){return 0===e.indexOf(t)},t.isEndWith=function(e,t){var n=e.length,o=t.length;return n>=o&&e.indexOf(t)==n-o},t.any=function(e,t){var n,o=e.length;for(n=0;n<o;n++)if(t(e[n]))return!0;return!1},t.isFunction=r,t.isArray=i,t.isString=a,t.isNumber=u,t.isUnDefined=s,t.isObject=l,t.isEmpty=c,t.isJSON=p,t.isContain=g;var h=function(e){var t,n=e.constructor===Array?[]:{};if("object"==typeof e){if(f.JSON&&f.JSON.parse)t=JSON.stringify(e),n=JSON.parse(t);else for(var o in e)n[o]="object"==typeof e[o]?h(e[o]):e[o];return n}};t.cloneObj=h,t.cloneDeep=h},function(e,t,n){"use strict";var o=n(18),r=n(7),i=n(12),a=n(6),u=i.AUTO_AT_VIEW_RATE,s=i.AUTO_AT_VIEW_RATE_IN_WINDOW,l=function(e){for(var t;e&&"HTML"!==e.tagName;){t=e.style.display;{if("none"===t)break;e=e.parentNode}}return"none"===t};t.filterStartExposureSize=function(e,t){var n=0,c=o.getWinPositions(),p=r.getGoldlogVal("_aplus_auto_exp")||{},g=p._acHashMap||{};for(var f in g)for(var h=g[f]||[],d=0;d<h.length;d++){var v=h[d]||{};if(0===v.status&&v.expConfig&&!l(v.element)){var _=o.getElementPosition(v.element);if(_.width&&_.height){v.x=_.x,v.y=_.y,v.eventType=t,v.width=_.width,v.height=_.height,v.size=_.width*_.height;var m;v.expConfig.positionSelector&&(m=o.getWinPositions(v.expConfig.positionSelector));var y=o.wrapViewabilityRate(m||c,v,u),b=y>=u,w=y;m&&(w=o.wrapViewabilityRate(c,v,u));var E=v.width*v.height*w,A=o.getViewabilityRateInWindow(c,E,s),x=o.checkIsRecord(v.element,v.hash_value,"_aplus_auto_exp");if((b||A>=s)&&!x){v.exposureTime=e,v.status=1;var T=i.getAutoExpUserFn();T&&(v.userParams=a.autoUserFnHandler(T,v.element,v.elementSelector)),i.EXP_DURATION||(v.viewabilityRate=b?y:A,v.viewability=b?"intersection":"fillwindow",v.status=2),a.updateExpHashMap(f,v,"UPDATE"),++n}}}}return n},t.filterEndExposureSize=function(e,t){var n=0,i=o.getWinPositions(),l=r.getGoldlogVal("_aplus_auto_exp")||{},c=l._acHashMap||{};for(var p in c)for(var g=c[p]||[],f=0;f<g.length;f++){var h=g[f]||{};if(1===h.status&&h.exposureTime===e&&h.expConfig){h.eventType=t;var d;h.expConfig.positionSelector&&(d=o.getWinPositions(h.expConfig.positionSelector));var v=o.checkIsRecord(h.element,h.hash_value,"_aplus_auto_exp"),_=o.wrapViewabilityRate(d||i,h,u),m=_>=u,y=_;d&&(y=o.wrapViewabilityRate(i,h,u));var b=h.width*h.height*y,w=o.getViewabilityRateInWindow(i,b,s);(m||w>=s)&&!v?(h.viewabilityRate=m?_:w,h.viewability=m?"intersection":"fillwindow",h.status=2,a.updateExpHashMap(p,h,"UPDATE"),++n):(h.status=0,h.exposureTime="",a.updateExpHashMap(p,h,"UPDATE"))}}return n}},function(e,t,n){"use strict";var o=n(16),r=n(21),i=n(6),a=n(12),u=function(e){var t="APLUS_AE_EXPOSURE_CHANGE",n=e&&e.type?e.type:"init",o=(new Date).getTime(),i=r.filterStartExposureSize(o,n,!1);i>0&&(a.EXP_DURATION?setTimeout(function(){i=r.filterEndExposureSize(o,n),i>0&&goldlog.aplus_pubsub.publish(t,{size:i,eventType:n})},a.EXP_DURATION):goldlog.aplus_pubsub.publish(t,{size:i,eventType:n}))},s=i.throttle(function(e){u(e)},100),l={},c=function(e,t){if(e&&e.forEach&&Object.keys&&document.querySelector){e.forEach(function(e){e.positionSelector&&document.querySelector(e.positionSelector)&&(l[e.positionSelector]=!0)});var n=Object.keys(l);n.forEach(function(e){o[t]&&o[t](document.querySelector(e),"scroll",function(e){s(e)})})}};t.watch_exposure_change=function(e){goldlog.aplus_pubsub.subscribe("APLUS_AE_DOM_CHANGE",u),o.on(window,"touchmove",s),o.on(window,"scroll",s),o.on(window,"resize",u),c(e,"on")},t.clear=function(e){o.un(window,"touchmove",s),o.un(window,"scroll",s),o.un(window,"resize",u),c(e,"un")}},function(e,t,n){"use strict";function o(e,t,n){var o="0";if(n){if("spmc"===e){var r=n.split(".");o=r[2]?r[2]:r[3],/^(\i|\d)[0-9]+$/.test(o)&&(o="0"),n=[r[0],r[1],o].join(".")}}else{n="";var i=window.g_SPM||{};if("function"==typeof i.getParam){var a=i.getParam(t);"spmc"===e?(o=t.getAttribute("data-spm")||"0",n=[a.a,a.b,o].join(".")):n=[a.a,a.b,a.c,a.d].join(".")}}return n}var r=n(2),i=n(20),a=n(7),u=n(3),s=n(10),l=n(6),c=n(12),p=function(){var e=u.isDebugAplus(),t={},n=c.getDefaultRequestCfg(),r=a.getGoldlogVal("_aplus_auto_exp")||{},p=r._acHashMap||{};return s(p,function(a,s){for(var c=s||[],p=0,g=c.length;p<g;p++){var f=c[p]||{};if(2===f.status){f.status=3,l.updateExpHashMap(a,f,"UPDATE"),r.exp_times++;var h,d=f.expConfig||{},v=goldlog.spm_ab?goldlog.spm_ab.join("."):"0.0.0.0",_=o(d.eltype,f.element)||v,m="";try{var y=new Number(f.viewabilityRate);h=y.toFixed(2)}catch(e){h=f.viewabilityRate}var b={_w:f.width,_h:f.height,_x:f.x,_y:f.y,_rate:h,_viewability:f.viewability};"object"==typeof f.userParams&&("object"==typeof f.userParams.userdata&&(b=i.assign(b,f.userParams.userdata)),
f.userParams.spm&&(_=o(d.eltype,"",f.userParams.spm)),f.userParams.scm&&(m=f.userParams.scm)),(l.isMethod(d.method)||l.isPkgSize(d.pkgSize))&&(n=l.filterExpConfigRequestCfg(d));var w=l.fillPropsData(d,f.element,b);w=l.fillFilterData(d,f.element,b);var E={exargs:w,scm:m,spm:_,aplusContentId:""};t[a]||(t[a]=[]),t[a].push(E),e&&u.logger({msg:"logkey = "+a+", params = "+decodeURIComponent(JSON.stringify(E))})}}}),{logkeyContainer:t,request_cfg:n}},g=function(e){for(var t=[],n=0,o=e.length;n<o;n++){var r=e[n]||{},a={};s(r,function(e,t){"element"!==e&&(a[e]=t)});var u=i.cloneObj(a);u.element=r.element,t.push(u)}return t},f=function(e){var t=a.getGoldlogVal("_aplus_auto_exp")||{},n=t._acHashMap||{},o=[];s(n,function(t,n){for(var r=g(n)||[],i=0,a=r.length;i<a;i++){var s=r[i]||{},p=n[i]||{};if(3===s.status)try{l.setRecordSuccess(p,c.DATA_APLUS_AE_KEY),goldlog.aplus_pubsub.publish("APLUS_ELEMENT_EXPOSURE",{logkey:t,v_origin:p,options:e}),o.push(p)}catch(e){u.logger({msg:e&&e.message})}}for(;o.length>0;)l.updateExpHashMap(t,o.pop(),"CLEAR")})},h=function(e,t,n){var o=e.logkeyContainer||[],i=e.request_cfg||{};r.wrap(function(){s(o,function(e,o){if(o&&o.length>0){for(var r=0;r<o.length;){var a=[],u=JSON.stringify(o.slice(r,r+i.pkgSize));a.push("expdata="+u),a.push("_is_auto_exp=1"),a.push("_eventType="+t.eventType),a.push("_method="+i.method),a.push("_pkgSize="+i.pkgSize),goldlog.record(e,"EXP",a.join("&"),i.method||"POST"),r+=i.pkgSize}n(t)}})},"recordAplusAt")},d=function(e){if(e.size>0){var t=p()||{};h(t,e,f)}};t.watch_data_change=function(){goldlog.aplus_pubsub.subscribe("APLUS_AE_EXPOSURE_CHANGE",d)},t.clear=function(){goldlog.aplus_pubsub.unsubscribe("APLUS_AE_EXPOSURE_CHANGE",d)}}]);/*! 2024-09-10 16:39:22 v8.15.24 */
!function(t){function e(o){if(n[o])return n[o].exports;var a=n[o]={exports:{},id:o,loaded:!1};return t[o].call(a.exports,a,a.exports,e),a.loaded=!0,a.exports}var n={};return e.m=t,e.c=n,e.p="",e(0)}([function(t,e,n){t.exports=n(1)},function(t,e,n){"use strict";!function(){var t=window;n(2)();var e=n(3),o=n(4);"ontouchend"in document.createElement("div")&&(t.goldlog_queue||(t.goldlog_queue=[])).push({action:"goldlog.setMetaInfo",arguments:["aplus-touch","tap"]});var a=function(){n(96);var e=n(98),o=n(33);if(o.doPubMsg(["goldlogReady","running"]),document.getElementsByTagName("body").length){var r="g_tb_aplus_loaded";if(t[r])return;t[r]=1,n(112).initGoldlog(e)}else setTimeout(function(){a()},50)},r=function(t){try{e.do_tracker_jserror({ratio:1,message:t&&t.message,error:encodeURIComponent(t&&t.stack?t.stack:""),filename:"aplusLoad"})}catch(t){}};try{a()}catch(t){r(t,o.script_name+"@"+o.lver)}}()},function(t,e){t.exports=function(){var t=window.goldlog_queue||(window.goldlog_queue=[]);try{var e=navigator.userAgent,n=/Trident/.test(e);n||t.push({action:"goldlog.setMetaInfo",arguments:["aplus-p-url-init",window.location.href.substring(0,850)]})}catch(t){}}},function(t,e){"use strict";var n=function(t,e){var n=window.goldlog_queue||(window.goldlog_queue=[]);n.push({action:"goldlog._aplus_cplugin_track_deb.monitor",arguments:[{key:"APLUS_PLUGIN_DEBUG",title:"aplus_core",msg:["_error_:methodName="+e+",params="+JSON.stringify(t)],type:"updateMsg",description:e||"aplus_core"}]})},o=function(t,e,n){var o=window.goldlog_queue||(window.goldlog_queue=[]);o.push({action:["goldlog","_aplus_cplugin_m",e].join("."),arguments:[t,n]})};e.do_tracker_jserror=function(t,e){var a="do_tracker_jserror";o(t,a,e),n(t,a)},e.do_tracker_obsolete_inter=function(t,e){var a="do_tracker_obsolete_inter";o(t,a,e),n(t,a)},e.wrap=function(t){if("function"==typeof t)try{t()}catch(t){n({msg:t.message||t},"exception")}finally{}}},function(t,e,n){"use strict";var o=n(5),a=n(6),r=n(7);e.APLUS_ENV="production",e.lver=a.lver,e.toUtVersion=a.toUtVersion,e.script_name=a.script_name,e.recordTypes=o.recordTypes,e.KEY=o.KEY,e.context=r.context,e.context_prepv=r.context_prepv,e.aplus_init=n(16).plugins_init,e.plugins_pv=n(37).plugins_pv,e.plugins_prepv=n(63).plugins_prepv,e.context_hjlj=n(64),e.plugins_hjlj=n(66).plugins_hjlj,e.beforeUnload=n(78),e.initLoad=n(82),e.spmException=n(86),e.goldlog_path=n(87),e.is_auto_pv="true",e.utilPvid=n(91),e.disablePvid="false",e.mustSpmE=!0,e.LS_CNA_KEY="APLUS_CNA"},function(t,e){"use strict";e.recordTypes={hjlj:"COMMON_HJLJ",uhjlj:"DATACLICK_HJLJ",pv:"PV",prepv:"PREPV"},e.KEY={NAME_STORAGE:{REFERRER:"wm_referrer",REFERRER_PV_ID:"refer_pv_id",LOST_PV_PAGE_DURATION:"lost_pv_page_duration",LOST_PV_PAGE_SPMAB:"lost_pv_page_spmab",LOST_PV_PAGE:"lost_pv_page",LOST_PV_PAGE_MSG:"lost_pv_page_msg"}}},function(t,e){"use strict";e.lver="8.15.24",e.toUtVersion="v20240910",e.script_name="aplus_int"},function(t,e,n){"use strict";e.context=n(8),e.context_prepv=n(15)},function(t,e,n){"use strict";function o(){return{compose:{maxTimeout:5500},etag:{egUrl:"gj.mmstat.com/eg.js",cna:i.getCookie("cna")},where_to_sendpv:{url:"//gj.mmstat.com/v.gif",urlRule:s.getBeaconSrc}}}function a(){return r.assign(new s.initConfig,new o)}var r=n(9),i=n(11),s=n(14);t.exports=a},function(t,e,n){"use strict";function o(t,e){return"function"!=typeof Object.assign?function(t){if(null===t)throw new TypeError("Cannot convert undefined or null to object");for(var e=Object(t),n=1;n<arguments.length;n++){var o=arguments[n];if(null!==o)for(var a in o)Object.prototype.hasOwnProperty.call(o,a)&&(e[a]=o[a])}return e}(t,e):Object.assign({},t,e)}function a(t){return"function"==typeof t}function r(t){return Array.isArray?Array.isArray(t):/Array/.test(Object.prototype.toString.call(t))}function i(t){return"string"==typeof t}function s(t){return"number"==typeof t}function u(t){return"undefined"==typeof t}function c(t){return"[object Object]"===Object.prototype.toString.call(t)}function l(t){if("number"==typeof t)return!1;if(u(t)||null===t)return!0;if(i(t))return!t;if(r(t))return!t.length;if(c(t)){for(var e in t)if(hasOwnProperty.call(t,e))return!1;return!0}return!1}function p(t){if("string"==typeof t)try{var e=JSON.parse(t);return!("object"!=typeof e||!e)}catch(t){return!1}return!1}function g(t,e){return t.indexOf(e)>-1}var f=window;e.assign=o,e.makeCacheNum=function(){return Math.floor(268435456*Math.random()).toString(16)},e.each=n(10),e.isStartWith=function(t,e){return 0===t.indexOf(e)},e.isEndWith=function(t,e){var n=t.length,o=e.length;return n>=o&&t.indexOf(e)==n-o},e.any=function(t,e){var n,o=t.length;for(n=0;n<o;n++)if(e(t[n]))return!0;return!1},e.isFunction=a,e.isArray=r,e.isString=i,e.isNumber=s,e.isUnDefined=u,e.isObject=c,e.isEmpty=l,e.isJSON=p,e.isContain=g;var d=function(t){var e,n=t.constructor===Array?[]:{};if("object"==typeof t){if(f.JSON&&f.JSON.parse)e=JSON.stringify(t),n=JSON.parse(e);else for(var o in t)n[o]="object"==typeof t[o]?d(t[o]):t[o];return n}};e.cloneObj=d,e.cloneDeep=d},function(t,e){"use strict";t.exports=function(t,e){var n,o=t.length;for(n=0;n<o;n++){var a=e(t[n],n);if("break"===a)break}}},function(t,e,n){"use strict";function o(t){var e=s.cookie.match(new RegExp("(?:^|;)\\s*"+t+"=([^;]+)"));return e?e[1]:""}function a(t,e,n){n||(n={});var a=new Date;if("session"===n.expires);else if(n.expires&&("number"==typeof n.expires||n.expires.toUTCString))"number"==typeof n.expires?a.setTime(a.getTime()+24*n.expires*60*60*1e3):a=n.expires,e+="; expires="+a.toUTCString();else{var r=20;c.indexof(["v.youku.com","www.youku.com","player.youku.com"],location.hostname)>-1&&(r=1),a.setTime(a.getTime()+365*r*24*60*60*1e3),e+="; expires="+a.toUTCString()}e+="; path="+(n.path?n.path:"/"),e+="; domain="+n.domain,s.cookie=t+"="+e;var i=0;try{var u=navigator.userAgent.match(/Chrome\/\d+/);u&&u[0]&&(i=u[0].split("/")[1],i&&(i=parseInt(i)))}catch(t){}return n.SameSite&&i>=80&&(e+="; SameSite="+n.SameSite,e+="; Secure",s.cookie=t+"="+e),o(t)}function r(t,e,n){try{if(n||(n={}),n.domain)a(t,e,n);else for(var o=l.getDomains(),r=0;r<o.length;)n.domain=o[r],a(t,e,n)?r=o.length:r++}catch(t){}}function i(){var t={};return u.each(g,function(e){t[e]=o(e)}),t.cnaui=/\btanx\.com$/.test(p)?o("cnaui"):"",t}var s=document,u=n(9),c=n(12),l=n(13),p=location.hostname;e.getCookie=o,e.setCookie=r;var g=["tracknick","thw","cna"];e.getData=i,e.getHng=function(){return encodeURIComponent(o("hng")||"")}},function(t,e){"use strict";e.indexof=function(t,e){var n=-1;try{n=t.indexOf(e)}catch(a){for(var o=0;o<t.length;o++)t[o]===e&&(n=o)}finally{return n}}},function(t,e){"use strict";e.getDomains=function(){var t=[];try{for(var e=location.hostname,n=e.split("."),o=2;o<=n.length;)t.push(n.slice(n.length-o).join(".")),o++}catch(t){}return t}},function(t,e,n){"use strict";function o(t,e,n){var o=window.goldlog||{},s=o.getMetaInfo("aplus-ifr-pv")+""=="1";return e?r(t)?"yt":"m":n&&!s?a.isContain(t,"wrating.com")?"k":i(t)||"y":i(t)||"v"}var a=n(9),r=function(t){for(var e=["youku.com","soku.com","tudou.com","laifeng.com"],n=0;n<e.length;n++){var o=e[n];if(a.isContain(t,o))return!0}return!1},i=function(t){for(var e=[["scmp.com","sc"],["luxehomes.com.hk","sc"],["ays.com.hk","sc"],["cpjobs.com","sc"],["educationpost.com.hk","sc"],["cosmopolitan.com.hk","sc"],["elle.com.hk","sc"],["harpersbazaar.com.hk","sc"],["1688.com","6"],["youku.com","yt"],["soku.com","yt"],["tudou.com","yt"],["laifeng.com","yt"]],n=0;n<e.length;n++){var o=e[n];if(a.isContain(t,o[0]))return o[1]}return""};e.getBeaconSrc=o,e.initConfig=function(){return{compose:{},etag:{egUrl:"log.mmstat.com/eg.js",cna:"",tag:"",stag:"",lstag:"-1",lscnastatus:""},can_to_sendpv:{flag:"NO"},userdata:{},what_to_sendpv:{pvdata:{},exparams:{}},what_to_pvhash:{hash:[]},what_to_sendpv_ut:{pvdataToUt:{}},what_to_sendpv_ut2:{isSuccess:!1,pvdataToUt:{}},when_to_sendpv:{aplusWaiting:""},where_to_sendpv:{url:"//log.mmstat.com/o.gif",urlRule:o},where_to_sendlog_ut:{aplusToUT:{},toUTName:"toUT"},hjlj:{what_to_hjlj:{logdata:{}},what_to_hjlj_ut:{logdataToUT:{}}},network:{connType:"UNKNOWN"},is_single:!1}}},function(t,e,n){"use strict";function o(){return{etag:{egUrl:"log.mmstat.com/eg.js",cna:a.getCookie("cna"),tag:"",stag:""},compose:{},where_to_prepv:{url:"//log.mmstat.com/v.gif",urlRule:r.getBeaconSrc},userdata:{},what_to_prepv:{logdata:{}},what_to_hjlj_exinfo:{EXPARAMS_FLAG:"EXPARAMS",exinfo:[],exparams_key_names:["uidaplus","pc_i","pu_i"]},is_single:!1}}var a=n(11),r=n(14);t.exports=o},function(t,e,n){"use strict";e.plugins_init=[{name:"where_to_sendpv",enable:!0,path:n(17)},{name:"etag",enable:!0,path:n(32)},{name:"etag_sync",enable:!0,path:n(36)}]},function(t,e,n){"use strict";var o=n(18),a=n(25)();t.exports=function(){return o.assign(a,{run:function(){var t=this.getAplusMetaByKey("aplus-rhost-v"),e=this.options.context.where_to_sendpv||{},n=e.url||"",a=this.getGifPath(e.urlRule,n),r=o.getPvUrl({metaName:"aplus-rhost-v",metaValue:t,gifPath:a,url:n});e.url=r,this.options.context.where_to_sendpv=e}})}},function(t,e,n){"use strict";function o(t){t=(t||"").split("#")[0].split("?")[0];var e=t.length,n=function(t){var e,n=t.length,o=0;for(e=0;e<n;e++)o=31*o+t.charCodeAt(e);return o};return e?n(e+"#"+t.charCodeAt(e-1)):-1}function a(t){for(var e=t.split("&"),n=0,o=e.length,a={};n<o;n++){var r=e[n],i=r.indexOf("="),s=r.substring(0,i),u=r.substring(i+1);a[s]=p.tryToDecodeURIComponent(u)}return a}function r(t){if("function"!=typeof t)throw new TypeError(t+" is not a function");return t}function i(t){var e,n,o,a=[],r=t.length;for(o=0;o<r;o++)e=t[o][0],n=t[o][1],a.push(l.isStartWith(e,v)?n:e+"="+encodeURIComponent(n));return a.join("&")}function s(t){var e,n,o,a={},r=t.length;for(o=0;o<r;o++)e=t[o][0],n=t[o][1],a[e]=n;return a}function u(t,e){var n,o,a,r=[];for(n in t)t.hasOwnProperty(n)&&(o=""+t[n],a=n+"="+encodeURIComponent(o),e?r.push(a):r.push(l.isStartWith(n,v)?o:a));return r.join("&")}function c(t,e){var n=t.indexOf("?")==-1?"?":"&",o=e?l.isArray(e)?i(e):u(e):"";return o?t+n+o:t}var l=n(9),p=n(19),g=n(22),f=parent!==self;e.is_in_iframe=f,e.makeCacheNum=l.makeCacheNum,e.isStartWith=l.isStartWith,e.isEndWith=l.isEndWith,e.any=l.any,e.each=l.each,e.assign=l.assign,e.isFunction=l.isFunction,e.isArray=l.isArray,e.isString=l.isString,e.isNumber=l.isNumber,e.isUnDefined=l.isUnDefined,e.isContain=l.isContain,e.sleep=n(23).sleep,e.makeChkSum=o,e.tryToDecodeURIComponent=p.tryToDecodeURIComponent,e.nodeListToArray=p.nodeListToArray,e.parseSemicolonContent=p.parseSemicolonContent,e.param2obj=a;var d=n(24),_=function(t){return/^(\/\/){0,1}(\w+\.){1,}\w+((\/\w+){1,})?$/.test(t)};e.hostValidity=_;var h=function(t,e){var n=/^(\/\/){0,1}(\w+\.){1,}\w+\/\w+\.gif$/.test(t),o=_(t),a="";return n?a="isGifPath":o&&(a="isHostPath"),a||d.logger({msg:e+": "+t+' is invalid, suggestion: "xxx.mmstat.com"'}),a},m=function(t){return!/^\/\/gj\.mmstat/.test(t)&&goldlog.isInternational()&&(t=t.replace(/^\/\/\w+\.mmstat/,"//gj.mmstat")),t};e.filterIntUrl=m,e.getPvUrl=function(t){t||(t={});var e,n,o=t.metaValue&&h(t.metaValue,t.metaName),a="";"isGifPath"===o?(e=/^\/\//.test(t.metaValue)?"":"//",a=e+t.metaValue):"isHostPath"===o&&(e=/^\/\//.test(t.metaValue)?"":"//",n=/\/$/.test(t.metaValue)?"":"/",a=e+t.metaValue+n+t.gifPath);var r;return a?r=a:(e=0===t.gifPath.indexOf("/")?t.gifPath:"/"+t.gifPath,r=t.url&&t.url.replace(/\/\w+\.gif/,e)),r},e.indexof=n(12).indexof,e.callable=r;var v="::-plain-::";e.mkPlainKey=function(){return v+Math.random()},e.s_plain_obj=v,e.mkPlainKeyForExparams=function(t){var e=t||v;return e+"exparams"},e.rndInt32=function(){return Math.round(2147483647*Math.random())},e.arr2param=i,e.arr2obj=s,e.obj2param=u,e.makeUrl=c,e.ifAdd=function(t,e){var n,o,a,r,i=e.length;for(n=0;n<i;n++)o=e[n],a=o[0],r=o[1],r&&t.push([a,r])},e.isStartWithProtocol=g.isStartWithProtocol,e.param2arr=function(t){for(var e,n=t.split("&"),o=0,a=n.length,r=[];o<a;o++)e=n[o].split("="),r.push([e.shift(),e.join("=")]);return r},e.catchException=function(t,e,n){var o=window,a=o.goldlog_queue||(o.goldlog_queue=[]),r=t;"object"==typeof e&&e.message&&(r=r+"_"+e.message),n&&n.msg&&(r+="_"+n.msg),a.push({action:"goldlog._aplus_cplugin_m.do_tracker_jserror",arguments:[{message:r,error:JSON.stringify(e),filename:t}]})}},function(t,e,n){"use strict";var o=n(20),a=n(21);t.exports={tryToDecodeURIComponent:function(t,e){var n=e||"";if(t)try{n=decodeURIComponent(t)}catch(t){}return n},parseSemicolonContent:function(t,e,n){e=e||{};var a,r,i=t.split(";"),s=i.length;for(a=0;a<s;a++){r=i[a].split("=");var u=o.trim(r.slice(1).join("="));e[o.trim(r[0])||""]=n?u:this.tryToDecodeURIComponent(u)}return e},nodeListToArray:function(t){var e,n;try{return e=[].slice.call(t)}catch(a){e=[],n=t.length;for(var o=0;o<n;o++)e.push(t[o]);return e}},getLsCna:function(t,e){if(a.set&&a.test()){var n="",o=a.get(t);if(o){var r=o.split("_")||[];n=e?r.length>1&&e===r[0]?r[1]:"":r.length>1?r[1]:""}return decodeURIComponent(n)}return""},setLsCna:function(t,e,n){n&&a.set&&a.test()&&a.set(t,e+"_"+encodeURIComponent(n))},getUrl:function(t){var e=t||"//log.mmstat.com/eg.js";try{var n=goldlog.getMetaInfo("aplus-rhost-v"),o=/[[a-z|0-9\.]+[a-z|0-9]/,a=n.match(o);a&&a[0]&&(e=e.replace(o,a[0]))}catch(t){}return e}}},function(t,e){"use strict";function n(t){return"string"==typeof t?t.replace(/^\s+|\s+$/g,""):""}e.trim=n},function(t,e){"use strict";t.exports={set:function(t,e){try{return localStorage.setItem(t,e),!0}catch(t){return!1}},get:function(t){try{return localStorage.getItem(t)}catch(t){return""}},test:function(){var t="grey_test_key";try{return localStorage.setItem(t,1),localStorage.removeItem(t),!0}catch(t){return!1}},remove:function(t){localStorage.removeItem(t)}}},function(t,e,n){"use strict";var o=n(9),a=function(){if(goldlog.aplusDebug){var t=location.protocol;return"http:"!==t&&"https:"!==t&&(t="https:"),t}return"https:"};e.getProtocal=a,e.isStartWithProtocol=function(t){for(var e=["javascript:","tel:","sms:","mailto:","tmall://","#"],n=0,a=e.length;n<a;n++)if(o.isStartWith(t,e[n]))return!0;return!1}},function(t,e){"use strict";e.sleep=function(t,e){return setTimeout(function(){e()},t)}},function(t,e){"use strict";var n=function(){var t=!1;return"boolean"==typeof goldlog.aplusDebug&&(t=goldlog.aplusDebug),t};e.isDebugAplus=n;var o=function(t){t||(t={});var e=t.level||"warn";window.console&&window.console[e]&&window.console[e](t.msg)};e.logger=o},function(t,e,n){"use strict";var o=n(18),a=n(26),r=n(27);t.exports=function(){return{init:function(t){this.options=t},getMetaInfo:function(){var t=a.getGoldlogVal("_$")||{},e=t.meta_info||r.getInfo();return e},getAplusMetaByKey:function(t){var e=this.getMetaInfo()||{};return e[t]},getGifPath:function(t,e){var n,r=a.getGoldlogVal("_$")||{};if("function"==typeof t)n=t(location.hostname,r.is_terminal,o.is_in_iframe)+".gif";else if(!n&&e){var i=e.match(/\/\w+\.gif/);i&&i.length>0&&(n=i[0])}return n||(n=r.is_terminal?"m.gif":"v.gif"),n},run:function(){var t=!!this.options.context.is_single;if(!t){var e=this.getAplusMetaByKey("aplus-rhost-v"),n=this.options.context.where_to_sendpv||{},a=n.url||"",r=this.getGifPath(n.urlRule,a),i=o.getPvUrl({metaName:"aplus-rhost-v",metaValue:e,gifPath:r,url:o.filterIntUrl(a)});n.url=i,this.options.context.where_to_sendpv=n}}}}},function(t,e){"use strict";var n=function(t){var e;try{window.goldlog||(window.goldlog={}),e=window.goldlog[t]}catch(t){e=""}finally{return e}};e.getGoldlogVal=n;var o=function(t,e){var n=!1;try{window.goldlog||(window.goldlog={}),t&&(window.goldlog[t]=e,n=!0)}catch(t){n=!1}finally{return n}};e.setGoldlogVal=o,e.getClientInfo=function(){return n("_aplus_client")||{}}},function(t,e,n){"use strict";function o(t){var e,n,o,a=t.length,r={};for(h._microscope_data=r,e=0;e<a;e++)n=t[e],"microscope-data"===f.tryToGetAttribute(n,"name")&&(o=f.tryToGetAttribute(n,"content"),l.parseSemicolonContent(o,r),h.is_head_has_meta_microscope_data=!0);h._microscope_data_params=l.obj2param(r),h.ms_data_page_id=r.pageId,h.ms_data_shop_id=r.shopId,h.ms_data_instance_id=r.siteInstanceId,h.ms_data_siteCategoryId=r.siteCategory,h.ms_prototype_id=r.prototypeId,h.site_instance_id_or_shop_id=h.ms_data_instance_id||h.ms_data_shop_id,h._atp_beacon_data={},h._atp_beacon_data_params=""}function a(t){var e,n=function(){var e;return document.querySelector&&(e=document.querySelector("meta[name=data-spm]")),g.each(t,function(t){"data-spm"===f.tryToGetAttribute(t,"name")&&(e=t)}),e},o=n();returno&&(e=f.tryToGetAttribute(o,"data-spm-protocol")),e}function r(t){var e=t.isonepage||"-1",n=e.split("|"),o=n[0],a=n[1]?n[1]:"";t.isonepage_data={isonepage:o,urlpagename:a},t["aplus-pagename"]=a}function i(){var t=d.getMetaTags();o(t),g.each(t,function(t){var e=f.tryToGetAttribute(t,"name");if(/^aplus/.test(e)&&(h[e]=d.getMetaCnt(e),e===v))try{c=h[e]=JSON.parse(d.getMetaCnt(e))}catch(t){}}),g.each(m,function(t){h[t]=d.getMetaCnt(t)}),h.spm_protocol=a(t),c&&(h=g.assign(h,c));var e,n,i=["aplus-rate-ahot"],s=i.length;for(e=0;e<s;e++)n=i[e],h[n]=parseFloat(h[n]);return r(h),b=h||{},h}function s(){return b||i()}function u(t){p.logger({msg:"please do not repeat setPriorityMetaInfo "+t})}var c,l=n(18),p=n(24),g=n(9),f=n(28),d=n(29),_=n(30),h={},m=["ahot-aplus","isonepage","spm-id","data-spm","microscope-data"],v="aplus-x-settings",b={};e.setMetaInfo=function(t,e){if(b||(b={}),"object"==typeof c&&c[t])return u(t),!0;if(t===v){if(c)u(t);else try{c="object"==typeof e?e:JSON.parse(e),b=g.assign(b,c)}catch(t){console&&console.log(t)}return!0}return b[t]=e,!0};var y=function(t){return b||(b={}),b[t]||""};e.getMetaInfo=y,e.getInfo=i,e.qGet=s,e.appendMetaInfo=function(t,e){var n=function(t,e){goldlog.setMetaInfo(t,e,{from:"appendMetaInfo"})};if(t&&e){var o,a=function(o){try{var a="string"==typeof e?JSON.parse(e):e;n(t,g.assign(o,a))}catch(t){}},r=function(o){try{var a="string"==typeof e?JSON.parse(e):e;n(t,o.concat(a))}catch(t){}},i=function(t){return"EXPARAMS"===t?_.getExparamsInfos("",t):t?t.split("&"):[]},s=function(o){try{var a=i(o),r=i(e);n(t,a.concat(r).join("&"))}catch(t){}},u=function(t){t.constructor===Array?r(t):a(t)},c=goldlog.getMetaInfo(t);if("aplus-exinfo"===t&&(s(c),o=!0),c)if("object"==typeof c)u(c),o=!0;else try{var l=JSON.parse(c);"object"==typeof l&&(u(l),o=!0)}catch(t){}o||n(t,e)}}},function(t,e){"use strict";e.tryToGetAttribute=function(t,e){return t&&t.getAttribute?t.getAttribute(e)||"":""};var n=function(t,e,n){if(t&&t.setAttribute)try{t.setAttribute(e,n)}catch(t){}};e.tryToSetAttribute=n,e.tryToRemoveAttribute=function(t,e){if(t&&t.removeAttribute)try{t.removeAttribute(e)}catch(o){n(t,e,"")}}},function(t,e,n){"use strict";function o(t){return i=i||document.getElementsByTagName("head")[0],s&&!t?s:i?s=i.getElementsByTagName("meta"):[]}function a(t,e){var n,a,r,i=o(),s=i.length;for(n=0;n<s;n++)a=i[n],u.tryToGetAttribute(a,"name")===t&&(r=u.tryToGetAttribute(a,e||"content"));return r||""}function r(t){var e={isonepage:"-1",urlpagename:""},n=t.qGet();if(n&&n.hasOwnProperty("isonepage_data"))e.isonepage=n.isonepage_data.isonepage,e.urlpagename=n.isonepage_data.urlpagename;else{var o=a("isonepage")||"-1",r=o.split("|");e.isonepage=r[0],e.urlpagename=r[1]?r[1]:""}return e}var i,s,u=n(28);e.getMetaTags=o,e.getMetaCnt=a,e.getOnePageInfo=r},function(t,e,n){"use strict";var o=n(18),a=n(31),r=n(12);e.getExparamsInfos=function(t,e){var n=[],i=t||["uidaplus","pc_i","pu_i"],s=a.getExParams(o)||"";s=s.replace(/&aplus&/,"&");for(var u=o.param2arr(s)||[],c=function(t){return r.indexof(i,t)>-1},l=0;l<u.length;l++){var p=u[l],g=p[0]||"",f=p[1]||"";g&&f&&("EXPARAMS"===e||c(g))&&n.push(g+"="+f)}return n}},function(t,e,n){"use strict";function o(){return s||(s=g.getElementById("beacon-aplus")||g.getElementById("tb-beacon-aplus")),s}function a(t){var e=o(),n=p.tryToGetAttribute(e,"cspx");t&&n&&(t.nonce=n)}function r(t,e,n){var r="script",s=g.createElement(r);s.type="text/javascript",s.async=!0;var c=o(),l=c&&c.hasAttribute("crossorigin");l&&(s.crossOrigin="anonymous");var p="https:"===location.protocol?e||t:t;0===p.indexOf("//")&&(p=u.getProtocal()+p),s.src=p,n&&(s.id=n),a(s);var f=g.getElementsByTagName(r)[0];i=i||g.getElementsByTagName("head")[0],f?f.parentNode.insertBefore(s,f):i&&i.appendChild(s)}var i,s,u=n(22),c=n(9),l=n(24),p=n(28),g=document;e.getCurrentNode=o,e.addScript=r,e.loadScript=function(t,e){function n(t){o.onreadystatechange=o.onload=o.onerror=null,o=null,e(t)}var o=g.createElement("script");if(i=i||g.getElementsByTagName("head")[0],o.async=!0,"onload"in o)o.onload=n;else{var r=function(){/loaded|complete/.test(o.readyState)&&n()};o.onreadystatechange=r,r()}o.onerror=function(t){n(t)},o.src=t,a(o),i.appendChild(o)},e.isTouch=function(){return"ontouchend"in document.createElement("div")};var f=function(){var t=goldlog&&goldlog._$?goldlog._$:{},e=t.meta_info||{};return e["aplus-exparams"]||""};e.getExParamsFromMeta=f,e.getExParams=function(t){var e=o(),n=p.tryToGetAttribute(e,"exparams"),a=d(n,f(),t)||"";return a&&a.replace(/&amp;/g,"&").replace(/\buser(i|I)d=/,"uidaplus=")};var d=function(t,e,n){var o="aplus&sidx=aplusSidex",a=t||o;try{if(e){var r=n.param2obj(e),i=["aplus","cna","spm-cnt","spm-url","spm-pre","logtype","pre","uidaplus","asid","sidx","trid","gokey"];c.each(i,function(t){r.hasOwnProperty(t)&&(l.logger({msg:"Can not inject keywords: "+t}),delete r[t])}),delete r[""];var s="";if(t){var u=t.match(/aplus&/).index,p=u>0?n.param2obj(t.substring(0,u)):{};delete p[""],s=n.obj2param(c.assign(p,r))+"&"+t.substring(u,t.length)}else s=n.obj2param(r)+"&"+o;return s}return a}catch(t){return a}};e.mergeExparams=d},function(t,e,n){"use strict";var o=n(33),a=n(3),r=n(11),i=n(31),s=n(19),u=n(34),c=n(35),l=n(26),p=n(4);t.exports=function(){return{init:function(t){this.options=t;var e=this.options.context.etag||{};this.cna=e.cna||r.getCookie("cna"),this.setTag(0),this.setStag(-1),this.setLsTag("-1"),this.setEtag(this.cna||""),this.requesting=!1,this.today=u.getFormatDate()},setLsTag:function(t){this.lstag=t,this.options.context.etag.lstag=t},setTag:function(t){this.tag=t,this.options.context.etag.tag=t},setStag:function(t){this.stag=t,this.options.context.etag.stag=t},setEtag:function(t){t&&(this.etag=t,this.options.context.etag.cna=t,r.getCookie("cna")!==t&&(o.publishCNA(t),r.setCookie("cna",t,{SameSite:"none"})))},setLscnaStatus:function(t){this.options.context.etag.lscnastatus=t},run:function(t,e){var n=this;if(n.cna)return void n.setTag(1);var o=null,r=c.getUrl(this.options.context.etag||{});n.requesting=!0;var u=function(){setTimeout(function(){e()},20),clearTimeout(o)};return i.loadScript(r,function(t){var e,o;if(t&&"error"===t.type?(n.setStag(-3),a.do_tracker_jserror({message:"loadError",error:"",filename:"etag_ls"})):(e=l.getGoldlogVal("Etag"),o=l.getGoldlogVal("stag"),"undefined"!=typeof o&&n.setStag(o)),!n.requesting)return void n.setEtag(e);if(2===o||4===o){var r=s.getLsCna(p.LS_CNA_KEY);r?(n.setLsTag(1),n.setEtag(r)):(n.setLsTag(0),s.setLsCna(p.LS_CNA_KEY,n.today,e),n.setEtag(e))}else n.setEtag(e);u()}),o=setTimeout(function(){n.requesting=!1,n.setStag(-2),e()},1500),2e3}}}},function(t,e){"use strict";var n="function",o=function(){var t=window.goldlog||{},e=t.aplus_pubsub||{},o=typeof e.publish===n;return o?e:""},a=function(t){var e=o();e&&typeof e.publish===n&&e.publish.apply(e,t)};e.doPubMsg=a;var r=function(t){var e=o();e&&typeof e.cachePubs===n&&e.cachePubs.apply(e,t)};e.doCachePubs=r,e.doSubMsg=function(t,e){var a=o();a&&typeof a.subscribe===n&&a.subscribe(t,e)},e.doSubOnceMsg=function(t,e){var a=o();a&&typeof a.subscribeOnce===n&&a.subscribeOnce(t,e)},e.publishCNA=function(t){if(t){var e=["CNA",{value:t}];a(e),r(e)}}},function(t,e){"use strict";function n(t,e,n){var o=""+Math.abs(t),a=e-o.length,r=t>=0;return(r?n?"+":"":"-")+Math.pow(10,Math.max(0,a)).toString().substr(1)+o}e.getFormatDate=function(t){var e=new Date;try{return[e.getFullYear(),n(e.getMonth()+1,2,0),n(e.getDate(),2,0)].join(t||"")}catch(t){return""}}},function(t,e,n){"use strict";var o=n(19);e.getUrl=function(t){var e=(new Date).getTime(),n=o.getUrl(t&&t.egUrl?t.egUrl:"gj.mmstat.com/eg.js"),a=n.match(/[\w+\.]+[a-z|A-Z|0-9]+\/(eg|ge).js/);return 0!==n.indexOf("http")&&a&&a.length>0&&(n="//"+a[0]),n+"?t="+e}},function(t,e,n){"use strict";var o=n(19),a=n(31),r=n(35),i=n(4),s=n(34),u=n(21);t.exports=function(){return{init:function(t){this.options=t,this.today=s.getFormatDate()},run:function(){var t=this;if(u.test()){var e=o.getLsCna(i.LS_CNA_KEY,t.today);e||setTimeout(function(){var e=r.getUrl(t.options.context.etag||{});a.loadScript(e,function(e){e&&"error"!==e.type&&o.setLsCna(i.LS_CNA_KEY,t.today,goldlog.Etag)})},1e3)}}}}},function(t,e,n){"use strict";e.plugins_pv=[{name:"etag",enable:!0,path:n(38)},{name:"when_to_sendpv",enable:!0,path:n(39)},{name:"where_to_sendlog_ut",enable:!0,path:n(40)},{name:"is_single",enable:!0,path:n(42)},{name:"what_to_pvhash",enable:!0,path:n(43)},{name:"what_to_sendpv",enable:!0,path:n(44)},{name:"what_to_sendpv_userdata",enable:!0,path:n(48),deps:["what_to_sendpv"]},{name:"what_to_sendpv_etag",enable:!0,path:n(53),deps:["etag","what_to_sendpv"]},{name:"what_to_sendpv_ut2",enable:!0,path:n(54),deps:["where_to_sendlog_ut"]},{name:"what_to_sendpv_ut",enable:!0,path:n(56),deps:["where_to_sendlog_ut"]},{name:"what_to_pv_slog",enable:!0,path:n(57),deps:["what_to_sendpv","what_to_sendpv_ut2","what_to_sendpv_ut"]},{name:"can_to_sendpv",enable:!0,path:n(58)},{name:"where_to_sendpv",enable:!0,path:n(17),deps:["is_single"]},{name:"do_sendpv_ut2",enable:!0,path:n(59),deps:["what_to_sendpv_ut2","where_to_sendlog_ut"]},{name:"do_sendpv_ut",enable:!0,path:n(60),deps:["what_to_sendpv_ut","where_to_sendlog_ut","do_sendpv_ut2"]},{name:"do_sendpv",enable:!0,path:n(61),deps:["is_single","what_to_sendpv","where_to_sendpv","do_sendpv_ut"]},{name:"after_pv",enable:!0,path:n(62)}]},function(t,e,n){"use strict";var o=n(33);t.exports=function(){return{init:function(t){this.options=t},run:function(){var t=this;o.doSubOnceMsg("aplusInitContext",function(e){e.etag&&(t.options.context.etag=e.etag)})}}}},function(t,e,n){"use strict";var o=n(26),a=n(23),r=n(27);t.exports=function(){return{init:function(t){this.options=t},getMetaInfo:function(){var t=o.getGoldlogVal("_$")||{},e=t.meta_info||r.getInfo();return e},getAplusWaiting:function(){var t=this.getMetaInfo()||{};return t["aplus-waiting"]},run:function(t,e){var n=this.options.config||{},o=this.getAplusWaiting();if(o&&n.is_auto)switch(o=this.getAplusWaiting()+"",this.options.context.when_to_sendpv={aplusWaiting:o},o){case"MAN":return"done";case"1":return this.options.context.when_to_sendpv.isWait=!0,a.sleep(6e3,function(){e()}),6e3;default:var r=1*o;if(r+""!="NaN")return this.options.context.when_to_sendpv.isWait=!0,a.sleep(r,function(){e()}),r}}}}},function(t,e,n){"use strict";var o=n(41);t.exports=function(){return{init:function(t){this.options=t},getAplusToUT:function(t){return{toUT2:o.getAplusToUT("toUT2",t),toUT:o.getAplusToUT("toUT",t)}},run:function(){if("Umeng4Aplus"===goldlog.aplusBridgeName)this.options.context.where_to_sendlog_ut.toUTName="toUT2";else{var t=this.getAplusToUT(this.options.config.recordType);this.options.context.where_to_sendlog_ut.aplusToUT=t}}}}},function(t,e){"use strict";var n=navigator.userAgent,o=/WindVane/i.test(n);e.is_WindVane=o;var a=function(){var t=goldlog.getMetaInfo("aplus_chnl");return!(!t||!t.isAvailable||"function"!=typeof t.toUT2&&"function"!=typeof t.toUT)&&t};e.isAplusChnl=a,e.getAplusToUT=function(t,e){var n={},r=a();if("object"==typeof r)n.bridgeName=r.bridgeName||"customBridge",n.bridgeVersion=r.bridgeVersion||r.version||"",n.isAvailable=r.isAvailable,n.toUT2=r.toUT2||r.toUT;else{var i=window.WindVane||{};if(o&&i&&i.isAvailable&&"function"==typeof i.call){var s=t||"toUT",u=goldlog.getMetaInfo("aplus-toUT")+"";"toUT2HC"===u&&"PV"===e&&(s=u),n={bridgeName:"WindVane",bridgeVersion:i.version||"",isAvailable:!0,toUT2:function(t,e,n,o){return i.call("WVTBUserTrack",s,t,e,n,o)}}}}return n}},function(t,e,n){"use strict";var o=n(26),a=n(4);t.exports=function(){return{init:function(t){this.options=t},isSingle_pv:function(){var t=o.getGoldlogVal("_$")||{};return!("1"===t.meta_info["aplus-both-request"])},isSingle_hjlj:function(t){var e=o.getGoldlogVal("_$")||{};return!("1"===e.meta_info["aplus-both-request"])&&t&&t.logkey&&t.gmkey},isSingle_uhjlj:function(t){var e=o.getGoldlogVal("_$")||{};return(!t||!/^\/aplus\.99\.(\d)+$/.test(t.logkey))&&(!("1"===e.meta_info["aplus-both-request"])&&t&&t.logkey)},run:function(){var t=this.options.context||{},e=this.options.config||{},n=t.where_to_sendlog_ut.aplusToUT||{},o=n.toUT||{},r=n.toUT2||{},i=!(!o.isAvailable&&!r.isAvailable),s=t.userdata||{},u=!!t.is_single;switch(e.recordType){case a.recordTypes.uhjlj:u=this.isSingle_uhjlj(s);break;case a.recordTypes.hjlj:u=this.isSingle_hjlj(s);break;case a.recordTypes.pv:u=this.isSingle_pv();break;default:u=this.isSingle_pv()}this.options.context.is_single=i&&u,this.options.context.ut_is_available=i}}}},function(t,e,n){"use strict";var o=n(26);t.exports=function(){return{init:function(t){this.options=t},run:function(){var t=this.options.context.what_to_pvhash||{},e=o.getGoldlogVal("_$")||{},n=e.meta_info||{},a=n["aplus-pvhash"]||"",r=[];"1"===a&&(r=["_aqx_uri",encodeURIComponent(location.href)]),t.hash=r,this.options.context.what_to_pvhash=t}}}},function(t,e,n){"use strict";var o=n(18),a=n(9),r=n(31),i=n(26),s=n(28),u=n(11),c=n(45),l=n(46),p=n(47);t.exports=function(){return a.assign(p,{init:function(t){this.options=t,this.cookie_data||(this.cookie_data=u.getData()),this.client_info||(this.client_info=i.getClientInfo()||{});var e=location.hash;e&&0===e.indexOf("#")&&(e=e.substr(1)),this.loc_hash=e},getExParams:function(){var t=window,e=document,n=[],u=parent!==t.self,l=e.getElementById("beacon-aplus")||e.getElementById("tb-beacon-aplus"),p=s.tryToGetAttribute(l,"exparams"),g=r.mergeExparams(p,r.getExParamsFromMeta(),o)||"";g=g.replace(/&amp;/g,"&");var f,d,_=["taobao.com","tmall.com","etao.com","hitao.com","taohua.com","juhuasuan.com","alimama.com"],h=i.getGoldlogVal("_$")||{},m=h.meta_info||{};if(u&&!m["aplus-ifr-pv"]){for(d=_.length,f=0;f<d;f++)if(o.isContain(location.hostname,_[f]))return n.push([o.mkPlainKeyForExparams(),g]),n;g=g.replace(/\buser(i|I)d=\w*&?/,"")}g=g.replace(/\buser(i|I)d=/,"uidaplus="),g&&n.push([o.mkPlainKeyForExparams(),g]);var v=a.makeCacheNum();return c.updateKey(n,"cache",v),n},getExtra:function(){var t=[],e=i.getGoldlogVal("_$")||{},n=e.meta_info||{},a=this.cookie_data||{},r=this.getClientInfo(!0)||[];return o.ifAdd(t,r),o.ifAdd(t,[["thw",a.thw],["bucket_id",l.getBucketId(n)],["urlokey",this.loc_hash],["wm_instanceid",n.ms_data_instance_id]]),t}})}},function(t,e){"use strict";function n(t,e,n){r(t,"spm-cnt",function(t){var o=t.split(".");return o[0]=goldlog.spm_ab[0],o[1]=goldlog.spm_ab[1],e?o[1]=o[1].split("/")[0]+"/"+e:o[1]=o[1].split("/")[0],n&&(o[4]=n),o.join(".")})}function o(t,e){var n=window.g_SPM&&g_SPM._current_spm;n&&r(t,"spm-url",function(){return[n.a,n.b,n.c,n.d].join(".")+(e?"."+e:"")},"spm-cnt")}function a(t,e){var n,o,a,r=-1;for(n=0,o=t.length;n<o;n++)if(a=t[n],a[0]===e){r=n;break}r>=0&&t.splice(r,1)}function r(t,e,n,o){var a,r,i=t.length,s=-1,u="function"==typeof n;for(a=0;a<i;a++){if(r=t[a],r[0]===e)return void(u?r[1]=n(r[1]):r[1]=n);o&&r[0]===o&&(s=a)}o&&(u&&(n=n()),s>-1?t.splice(s,0,[e,n]):t.push([e,n]))}t.exports={updateSPMCnt:n,updateSPMUrl:o,updateKey:r,removeKey:a}},function(t,e,n){"use strict";function o(t,e){var n,o=2146271213;for(n=0;n<t.length;n++)o=(o<<5)+o+t.charCodeAt(n);return(65535&o)%e}function a(t){var e,n=r.getCookie("t");return"3"!=t.ms_prototype_id&&"5"!=t.ms_prototype_id||(e=n?o(n,20):""),e}var r=n(11);e.getBucketId=a},function(t,e,n){"use strict";var o=n(18),a=n(9),r=n(26),i=n(41),s=n(11),u=n(4);t.exports={init:function(t){this.options=t,this.cookie_data||(this.cookie_data=s.getData())},getBasicParams:function(){var t=document,e=r.getGoldlogVal("_$")||{},n=e.spm||{},a=e.meta_info||{},i=a["aplus-ifr-pv"]+""=="1",u=o.is_in_iframe&&!i?0:1,c=this.options.config||{},l=t.title;
c.title&&(l+="_"+c.title);var p=[["logtype",u],["title",l],["pre",e.page_referrer||""],["scr",screen.width+"x"+screen.height]];try{var g=location.href.substring(0,1200);g&&p.push(["_p_url",a["aplus-p-url"]||g])}catch(t){}var f=this.cookie_data||{},d=this.options.context||{},_=d.etag||{},h=_.cna||f.cna||s.getCookie("cna");h&&p.push([o.mkPlainKey(),"cna="+h]),f.tracknick&&p.push([o.mkPlainKey(),"nick="+f.tracknick]);var m=n.spm_url||"";return o.ifAdd(p,[["wm_pageid",a.ms_data_page_id],["wm_prototypeid",a.ms_prototype_id],["wm_sid",a.ms_data_shop_id],["spm-url",m],["spm-pre",n.spm_pre],["spm-cnt",n.spm_cnt],["cnaui",f.cnaui]]),p},getExParams:function(){return[]},getExtra:function(){return[]},getClientInfo:function(t){var e=[],n=r.getGoldlogVal("_$")||{},s=this.client_info||{},c=s.ua_info||{};if(t||!i.is_WindVane&&!i.isAplusChnl()){for(var l,p=[],g=["p","o","b","s","w","wx","ism"],f=0;l=g[f++];)c[l]&&p.push([l,c[l]]);o.ifAdd(e,p)}o.ifAdd(e,[["cache",a.makeCacheNum()],["lver",goldlog.lver||u.lver],["jsver",n.script_name||u.script_name],["pver",goldlog.aplus_cplugin_ver]]);var d=this.options.config||{},_=d.is_auto;return _||o.ifAdd(e,[["mansndlog",1]]),e},processLodashDollar:function(){var t=r.getGoldlogVal("_$")||{};t.page_url!==location.href&&(t.page_referrer=t.page_url,t.page_url=location.href),r.setGoldlogVal("_$",t)},getLsParams:function(){var t=r.getGoldlogVal("_$")||{},e=[];return t.lsparams&&t.lsparams.spm_id&&(e.push(["lsparams",t.lsparams.spm_id]),e.push(["lsparams_pre",t.lsparams.current_url])),e},run:function(){var t=this.getBasicParams()||[],e=this.getExParams()||[],n=this.getExtra()||[];this.processLodashDollar();var o=this.getLsParams()||[],a=[].concat(t,e,n,o);this.options.context.what_to_sendpv.pvdata=a,this.options.context.what_to_sendpv.exparams=e}}},function(t,e,n){"use strict";var o=n(18),a=n(26),r=n(45),i=n(11),s=n(49);t.exports=function(){return{init:function(t){this.options=t},getPageId:function(){var t=this.options.config||{},e=this.options.context||{},n=e.userdata||{};return t.page_id||t.pageid||t.pageId||n.page_id},getPageInfo:function(){var t;try{var e=top.location!==self.location;e&&void 0!==window.innerWidth&&(t={width:window.innerWidth,height:window.innerHeight})}catch(t){}return t},getUserdata:function(){var t=a.getGoldlogVal("_$")||{},e=t.spm||{},n=this.options.context||{},r=n.userdata||{},u=this.options.config||{},c=[];if(u&&!u.is_auto){u.gokey&&c.push([o.mkPlainKey(),u.gokey]);var l=e.data.b;if(l){var p=this.getPageId();l=p?l.split("/")[0]+"/"+p:l.split("/")[0],s.setB(l);var g=e.spm_cnt.split(".");g&&g.length>2&&(g[1]=l,e.spm_cnt=g.join("."))}}var f=function(t){if("object"==typeof t)for(var e in t)"object"!=typeof t[e]&&"function"!=typeof t[e]&&c.push([e,t[e]])};f(goldlog.getMetaInfo("aplus-cpvdata")),f(r);var d=i.getCookie("workno")||i.getCookie("emplId");d&&c.push(["workno",d]);var _=i.getHng();_&&c.push(["_hng",i.getHng()]);var h=this.getPageInfo();return h&&(c.push(["_pw",h.width]),c.push(["_ph",h.height])),c},processLodashDollar:function(){var t=this.options.config||{},e=a.getGoldlogVal("_$")||{};t&&t.referrer&&(e.page_referrer=t.referrer),a.setGoldlogVal("_$",e)},updatePre:function(t){var e=a.getGoldlogVal("_$")||{};return e.page_referrer&&r.updateKey(t,"pre",e.page_referrer),t},run:function(){var t=this.options.context.what_to_sendpv.pvdata,e=this.getUserdata();this.processLodashDollar();var n=t,o=this.options.context.what_to_pvhash.hash;o&&o.length>0&&n.push(o),n=n.concat(e),n=this.updatePre(n);var a=this.getPageId();a&&r.updateSPMCnt(n,a),this.options.context.what_to_sendpv.pvdata=n,this.options.context.userdata=e}}}},function(t,e,n){"use strict";function o(){if(!s.data.a||!s.data.b){var t=r._SPM_a,e=r._SPM_b;if(t&&e)return t=t.replace(/^{(\w+\/)}$/g,"$1"),e=e.replace(/^{(\w+\/)}$/g,"$1"),s.is_wh_in_page=!0,void c.setAB(t,e);var n=goldlog._$.meta_info;t=n["data-spm"]||n["spm-id"]||"0";var o=t.split(".");o.length>1&&(t=o[0],e=o[1]),c.setA(t),e&&c.setB(e);var a=i.getElementsByTagName("body");a=a&&a.length?a[0]:null,a&&(e=l.tryToGetAttribute(a,"data-spm"),e?c.setB(e):1===o.length&&c.setAB("0","0"))}}function a(){var t=s.data.a,e=s.data.b;t&&e&&(goldlog.spm_ab=[t,e])}var r=window,i=document,s={},u={};s.data=u;var c={},l=n(28),p=n(50),g=location.href,f=n(51).getRefer(),d=n(4);c.setA=function(t){s.data.a=t,a()},c.setB=function(t){s.data.b=t,a()},c.setAB=function(t,e){s.data.a=t,s.data.b=e,a()};var _=p.getSPMFromUrl,h=function(){var t=d.utilPvid.makePVId();return d.mustSpmE?t||goldlog.pvid||"":t||""},m=function(t,e){var n=t.goldlog||window.goldlog||{},a=n.meta_info||{};s.meta_protocol=a.spm_protocol;var r,i=n.spm_ab||[],u=i[0]||"0",c=i[1]||"0";"0"===u&&"0"===c&&(o(),u=s.data.a||"0",c=s.data.b||"0"),r=[s.data.a,s.data.b].join("."),s.spm_cnt=(r||"0.0")+".0.0";var l=t.send_pv_count>0?h():n.pvid;l&&(s.spm_cnt+="."+l),n._$.spm=s,"function"==typeof e&&e(l)};c.spaInit=function(t,e,n,o){var a="function"==typeof o?o:function(){},r=s.spm_url,i=window.g_SPM||{},u=t._$||{},c=u.send_pv_count;m({goldlog:t,meta_info:e,send_pv_count:c},function(t){s.spm_cnt=s.data.a+"."+s.data.b+".0.0"+(t?"."+t:"");var o=e["aplus-spm-fixed"];if("1"!==o){s.spm_pre=_(f),s.origin_spm_pre=s.spm_pre,s.spm_url=_(location.href),s.origin_spm_url=s.spm_url;var u=i._current_spm||{};u&&u.a&&"0"!==u.a&&u.b&&"0"!==u.b?(s.spm_url=[u.a,u.b,u.c,u.d,u.e].join("."),s.spm_pre=r):c>0&&n&&"0"!==n[0]&&"0"!==n[1]&&(s.spm_url=n.concat(["0","0"]).join("."),s.spm_pre=r),i._current_spm={}}a()})},c.init=function(t,e,n){s.spm_url=_(g),s.spm_pre=_(f),m({goldlog:t,meta_info:e},function(){"function"==typeof n&&n()})},c.resetSpmCntPvid=function(){var t=goldlog.spm_ab;if(t&&2===t.length){var e=t.join(".")+".0.0",n=h();n&&(e=e+"."+n),s.spm_cnt=e,s.spm_url=e,goldlog._$.spm=s}},t.exports=c},function(t,e){"use strict";function n(t,e){if(!t||!e)return"";var n,o="";try{var a=new RegExp("[?|&]+"+t+"=([^&|#|?|/]+)");if("spm"===t||"scm"===t){var r=new RegExp("\\?.*"+t+"=([\\w\\.\\-\\*/]+)"),i=e.match(a),s=e.match(r),u=i&&2===i.length?i[1]:"",c=s&&2===s.length?s[1]:"";o=u>c?u:c,o=decodeURIComponent(o)}else n=e.match(a),o=n&&2===n.length?n[1]:""}catch(t){}finally{return o}}e.getParamFromUrl=n,e.getSPMFromUrl=function(t){return n("spm",t)}},function(t,e,n){"use strict";var o=n(52).nameStorage,a=n(5);e.getRefer=function(){var t=a.KEY||{},e=t.NAME_STORAGE||{};return document.referrer||o.getItem(e.REFERRER)||""}},function(t,e){"use strict";var n=function(){function t(){var t,e=[],r=!0;for(var l in p)p.hasOwnProperty(l)&&(r=!1,t=p[l]||"",e.push(c(l)+s+c(t)));n.name=r?o:a+c(o)+i+e.join(u)}function e(t,e,n){t&&(t.addEventListener?t.addEventListener(e,n,!1):t.attachEvent&&t.attachEvent("on"+e,function(e){n.call(t,e)}))}var n=window;if(n.nameStorage)return n.nameStorage;var o,a="nameStorage:",r=/^([^=]+)(?:=(.*))?$/,i="?",s="=",u="&",c=encodeURIComponent,l=decodeURIComponent,p={},g={};return function(t){if(t&&0===t.indexOf(a)){var e=t.split(/[:?]/);e.shift(),o=l(e.shift())||"";for(var n,i,s,c=e.join(""),g=c.split(u),f=0,d=g.length;f<d;f++)n=g[f].match(r),n&&n[1]&&(i=l(n[1]),s=l(n[2])||"",p[i]=s)}else o=t||""}(n.name),g.setItem=function(e,n){e&&"undefined"!=typeof n&&(p[e]=String(n),t())},g.getItem=function(t){return p.hasOwnProperty(t)?p[t]:null},g.removeItem=function(e){p.hasOwnProperty(e)&&(p[e]=null,delete p[e],t())},g.clear=function(){p={},t()},g.valueOf=function(){return p},g.toString=function(){var t=n.name;return 0===t.indexOf(a)?t:a+t},e(n,"beforeunload",function(){t()}),g}();e.nameStorage=n},function(t,e,n){"use strict";var o=n(45);t.exports=function(){return{init:function(t){this.options=t},updateBasicParams:function(){var t=this.options.context.what_to_sendpv.pvdata||[],e=this.options.context.etag||{};return e.cna&&(o.updateKey(t,"cna",e.cna),this.options.context.what_to_sendpv.pvdata=t),t},addTagParams:function(){var t=this.options.context.what_to_sendpv.pvdata||[],e=this.options.context.etag||{},n=[];(e.tag||0===e.tag)&&n.push(["tag",e.tag]),(e.stag||0===e.stag)&&n.push(["stag",e.stag]),(e.lstag||0===e.lstag)&&n.push(["lstag",e.lstag]),n.length>0&&(this.options.context.what_to_sendpv.pvdata=t.concat(n))},run:function(){this.updateBasicParams(),this.addTagParams()}}}},function(t,e,n){"use strict";function o(t){var e,n,o,a,r=[],s={};for(e=t.length-1;e>=0;e--)n=t[e],o=n[0],o&&o.indexOf(i.s_plain_obj)==-1&&s.hasOwnProperty(o)||(a=n[1],("aplus"==o||a)&&(r.unshift([o,a]),s[o]=1));return r}function a(t){var e,n,o,a,r=[],u={logtype:!0,cache:!0,scr:!0,"spm-cnt":!0};for(e=t.length-1;e>=0;e--)if(n=t[e],o=n[0],a=n[1],!(s.isStartWith(o,i.s_plain_obj)&&!s.isStartWith(o,i.mkPlainKeyForExparams())||u[o]))if(s.isStartWith(o,i.mkPlainKeyForExparams())){var c=i.param2arr(a);if("object"==typeof c&&c.length>0)for(var l=c.length-1;l>=0;l--){var p=c[l];p&&p[1]&&r.unshift([p[0],p[1]])}}else r.unshift([o,a]);return r}function r(){var t={isonepage:"-1",urlpagename:""},e=g.qGet();if(e&&e.hasOwnProperty("isonepage_data"))t.isonepage=e.isonepage_data.isonepage,t.urlpagename=e.isonepage_data.urlpagename;else{var n=c.getMetaCnt("isonepage")||"-1",o=n.split("|");t.isonepage=o[0],t.urlpagename=o[1]?o[1]:""}return t}var i=n(18),s=n(9),u=n(26),c=n(29),l=n(50),p=n(55),g=n(27),f=n(4),d=n(11);t.exports=function(){return{init:function(t){this.options=t},keyIsAvailable:function(t){var e=["functype","funcId","spm-cnt","spm-url","spm-pre","_ish5","_is_g2u","_h5url","cna","isonepage","lver","jsver"];return i.indexof(e,t)===-1},valIsAvailable:function(t){return"object"!=typeof t&&"function"!=typeof t},upUtData:function(t,e){var n=this;if(t=t?t:{},e&&"object"==typeof e)for(var o in e){var a=e[o];o&&n.valIsAvailable(a)&&n.keyIsAvailable(o)&&(t[o]=a)}return t},getToUtData:function(t){var e=u.getGoldlogVal("_$")||{},n=e.spm||{},s=this.options.context||{},c=!!s.is_single,p=s.what_to_sendpv||{},g=a(o(p.exparams||[]));g=i.arr2obj(g);var _=i.arr2obj(p.pvdata),h=a(o(s.userdata||[]));h=i.arr2obj(h);var m=location.href,v={},b=l.getParamFromUrl("scm",m)||"";b&&(v.scm=b);var y=l.getParamFromUrl("pg1stepk",m)||"";y&&(v.pg1stepk=y);var w=l.getParamFromUrl("point",m)||"";w&&(v.issb=1),_&&_.mansndlog&&(v.mansndlog=_.mansndlog),v=this.upUtData(v,g),v=this.upUtData(v,h);var x=r();v.functype="page",v.funcId="2001",v.url=goldlog.getMetaInfo("aplus-pagename")||location.origin+location.pathname,v._ish5="1",v._h5url=m,v._toUT=2,v._bridgeName=t.bridgeName||"",v._bridgeVersion=t.bridgeVersion||"",v["spm-cnt"]=n.spm_cnt||"",v["spm-url"]=n.spm_url||"",v["spm-pre"]=n.spm_pre||"",v.cna=d.getCookie("cna"),v.lver=goldlog.lver||f.lver,v.jsver=f.script_name,v.pver=goldlog.aplus_cplugin_ver,v.isonepage=x.isonepage;var j=goldlog.getMetaInfo("aplus-utparam");return j&&(v["utparam-cnt"]=JSON.stringify(j)),v._is_g2u_=c?1:2,v},run:function(){var t=this.options.context||{},e=t.what_to_sendpv_ut2||{},n=t.where_to_sendlog_ut||{},o=n.aplusToUT||{},a=o.toUT2||{};(a&&a.isAvailable&&"function"==typeof a.toUT2||p.haveNativeFlagInUA())&&(e.pvdataToUt=this.getToUtData(a),this.options.context.what_to_sendpv_ut2=e)}}}},function(t,e){"use strict";var n="UT4Aplus",o="Umeng4Aplus";e.isNative4Aplus=function(){var t=goldlog.getMetaInfo("aplus-toUT"),e=goldlog.aplusBridgeName;return e===n&&t===n||e===o},e.haveNativeFlagInUA=function(){var t=goldlog.aplusBridgeName;if(!t&&"boolean"!=typeof t){var e=new RegExp([n,o].join("|"),"i"),a=navigator.userAgent.match(e);t=!!a&&a[0],goldlog.aplusBridgeName=t}return!!t}},function(t,e,n){"use strict";function o(t){var e,n,o,a,i=[],s={};for(e=t.length-1;e>=0;e--)n=t[e],o=n[0],o&&o.indexOf(r.s_plain_obj)==-1&&s.hasOwnProperty(o)||(a=n[1],("aplus"==o||a)&&(i.unshift([o,a]),s[o]=1));return i}function a(t){var e,n,o,a,s=[],u={logtype:!0,cache:!0,scr:!0,"spm-cnt":!0};for(e=t.length-1;e>=0;e--)if(n=t[e],o=n[0],a=n[1],!(i.isStartWith(o,r.s_plain_obj)&&!i.isStartWith(o,r.mkPlainKeyForExparams())||u[o]))if(i.isStartWith(o,r.mkPlainKeyForExparams())){var c=r.param2arr(a);if("object"==typeof c&&c.length>0)for(var l=c.length-1;l>=0;l--){var p=c[l];p&&p[1]&&s.unshift([p[0],p[1]])}}else s.unshift([o,a]);return s}var r=n(18),i=n(9),s=n(26),u=n(29),c=n(55),l=n(27),p=n(4),g=n(11);t.exports=function(){return{init:function(t){this.options=t},getToUtData:function(t,e){var n,i=s.getGoldlogVal("_$")||{},c=i.spm||{},f=a(o(t)),d={};try{var _=r.arr2obj(f);_._toUT=1,_._bridgeName=e.bridgeName||"",_._bridgeVersion=e.bridgeVersion||"",n=JSON.stringify(_)}catch(t){n='{"_toUT":1}'}var h=u.getOnePageInfo(l);d.functype="2001",d.urlpagename=h.urlpagename,d.url=location.href,d.spmcnt=c.spm_cnt||"",d.spmurl=c.spm_url||"",d.spmpre=c.spm_pre||"",d.lzsid="",d.cna=g.getCookie("cna"),d.extendargs=n,d.isonepage=h.isonepage;var m=this.options.context||{},v=!!m.is_single;return d._is_g2u_=v?1:2,d.version=p.toUtVersion,d.lver=goldlog.lver||p.lver,d.jsver=p.script_name,d},run:function(){var t=this.options.context||{},e=t.what_to_sendpv||{},n=e.pvdata||[],o=t.what_to_sendpv_ut||{},a=t.where_to_sendlog_ut||{},r=a.aplusToUT||{},i=r.toUT||{};(i&&i.isAvailable&&"function"==typeof i.toUT2||c.haveNativeFlagInUA())&&(o.pvdataToUt=this.getToUtData(n,i),this.options.context.what_to_sendpv_ut=o)}}}},function(t,e){"use strict";t.exports=function(){return{init:function(t){this.options=t},run:function(){var t=this.options.context||{},e=t.is_single?"1":"0";if(t.what_to_sendpv_ut2.pvdataToUt._slog=e,t.what_to_sendpv_ut.pvdataToUt._slog=e,t.what_to_sendpv.pvdata.push(["_slog",e]),t.ut_is_available){var n=t.is_single?"1":"2";t.what_to_sendpv.pvdata.push(["_is_g2u",n])}}}}},function(t,e,n){"use strict";var o=n(26);t.exports=function(){return{init:function(t){this.options=t},run:function(){var t=o.getGoldlogVal("_$")||{},e=this.options.context.can_to_sendpv||{},n=t.send_pv_count||0,a=this.options.config||{};return a.is_auto&&n>0?"done":(e.flag="YES",this.options.context.can_to_sendpv=e,t.send_pv_count=++n,void o.setGoldlogVal("_$",t))}}}},function(t,e,n){"use strict";var o=n(55);t.exports=function(){return{init:function(t){this.options=t},run:function(t,e){var n=this,a=this.options.context||{},r=a.what_to_sendpv_ut2||{},i=a.where_to_sendlog_ut||{},s=r.pvdataToUt||{},u=i.aplusToUT||{},c=u.toUT2;if(o.isNative4Aplus())return u.toutflag="toUT2",i.toUTName="toUT2",void(n.options.context.what_to_sendpv_ut2.isSuccess=!0);if(c&&"function"==typeof c.toUT2&&c.isAvailable)try{u.toutflag="toUT2",c.toUT2(s,function(){n.options.context.what_to_sendpv_ut2.isSuccess=!0,e("done")},function(t){n.options.context.what_to_sendpv_ut2.errorMsg=t,e()},2e3)}catch(t){e()}finally{return"pause"}}}}},function(t,e,n){"use strict";var o=n(3);t.exports=function(){return{init:function(t){this.options=t},run:function(t,e){var n=this,a=this.options.context||{},r=a.what_to_sendpv_ut||{},i=a.what_to_sendpv_ut2||{},s=a.where_to_sendlog_ut||{},u=r.pvdataToUt||{},c=s.aplusToUT||{},l=c.toUT;if(!i.isSuccess&&l&&"function"==typeof l.toUT2&&l.isAvailable)try{l.toUT2(u,function(){c.toutflag="toUT",n.options.context.what_to_sendpv_ut.isSuccess=!0,e()},function(t){o.do_tracker_jserror({message:"do_sendpv_ut error",error:JSON.stringify(t),filename:"do_sendpv_ut"}),e()},5e3)}catch(t){e()}finally{return"pause"}}}}},function(t,e,n){"use strict";var o=n(26),a=n(18);t.exports=function(){return{init:function(t){this.options=t},run:function(){var t=this.options.context||{},e=t.what_to_sendpv_ut||{},n=t.what_to_sendpv_ut2||{},r=!!t.is_single;if(!r||!e.isSuccess&&!n.isSuccess){var i=t.what_to_sendpv||{},s=t.where_to_sendpv||{},u=i.pvdata||[],c=goldlog.send(s.url,a.arr2obj(u));o.setGoldlogVal("req",c)}}}}},function(t,e,n){"use strict";var o=n(33),a=n(26);t.exports=function(){return{init:function(t){this.options=t},run:function(){var t=goldlog._$||{},e=this.options.context||{};a.setGoldlogVal("pv_context",e);var n=goldlog.spm_ab||[],r=n.join("."),i=t.send_pv_count,s={cna:e.etag.cna,count:i,spmab_pre:goldlog.spmab_pre};o.doPubMsg(["sendPV","complete",r,s]),o.doCachePubs(["sendPV","complete",r,s])}}}},function(t,e){"use strict";e.plugins_prepv=[]},function(t,e,n){"use strict";function o(){return{where_to_hjlj:{url:"//gj.mmstat.com/",ac_atpanel:"//gj.mmstat.com/",tblogUrl:"//gj.mmstat.com/"}}}function a(){return r.assign(new i,new o)}var r=n(9),i=n(65);t.exports=a},function(t,e,n){"use strict";function o(){return{compose:{},basic_params:{cna:a.getCookie("cna")},where_to_hjlj:{url:"//gm.mmstat.com/",ac_atpanel:"//ac.mmstat.com/",tblogUrl:"//log.mmstat.com/"},userdata:{},what_to_hjlj:{logdata:{}},what_to_pvhash:{hash:[]},what_to_hjlj_exinfo:{EXPARAMS_FLAG:"EXPARAMS",exinfo:[],exparams_key_names:["uidaplus","pc_i","pu_i"]},what_to_hjlj_ut:{logdataToUT:{}},what_to_hjlj_ut2:{isSuccess:!1,logdataToUT:{}},where_to_sendlog_ut:{aplusToUT:{},toUTName:"toUT"},network:{connType:"UNKNOWN"},is_single:!1}}var a=n(11);t.exports=o},function(t,e,n){"use strict";e.plugins_hjlj=[{name:"etag",enable:!0,path:n(38)},{name:"where_to_sendlog_ut",enable:!0,path:n(40)},{name:"is_single",enable:!0,path:n(42)},{name:"what_to_hjlj_exinfo",enable:!0,path:n(67)},{name:"what_to_pvhash",enable:!0,path:n(43)},{name:"what_to_hjlj",enable:!0,path:n(68),deps:["what_to_hjlj_exinfo","what_to_pvhash"]},{name:"what_to_hjlj_ut2",enable:!0,path:n(69),deps:["is_single","what_to_hjlj_exinfo"]},{name:"what_to_hjlj_ut",enable:!0,path:n(72),deps:["is_single","what_to_hjlj_exinfo"]},{name:"what_to_hjlj_slog",enable:!0,path:n(73),deps:["what_to_hjlj","what_to_hjlj_ut2","what_to_hjlj_ut"]},{name:"where_to_hjlj",enable:!0,path:n(74),deps:["is_single","what_to_hjlj"]},{name:"do_sendhjlj_ut2",enable:!0,path:n(75),deps:["what_to_hjlj","what_to_hjlj_ut2","where_to_sendlog_ut"]},{name:"do_sendhjlj_ut",enable:!0,path:n(76),deps:["what_to_hjlj","what_to_hjlj_ut","where_to_sendlog_ut","do_sendhjlj_ut2"]},{name:"do_sendhjlj",enable:!0,path:n(77),deps:["is_single","what_to_hjlj","where_to_hjlj","do_sendhjlj_ut"]}]},function(t,e,n){"use strict";var o=n(18),a=n(31),r=n(26),i=n(26),s=n(12),u=n(11);t.exports=function(){return{init:function(t){this.options=t},getCookieUserInfo:function(){var t=[],e=u.getCookie("workno")||u.getCookie("emplId");e&&t.push("workno="+e);var n=u.getHng();return n&&t.push("_hng="+u.getHng()),t},filterExinfo:function(t){var e="";try{t&&("string"==typeof t?e=t.replace(/&amp;/g,"&").replace(/\buser(i|I)d=/,"uidaplus=").replace(/&aplus&/,"&"):"object"==typeof t&&(e=o.obj2param(t,!0)))}catch(t){e=t.message?t.message:""}return e},getExparamsFlag:function(){var t=this.options.context||{},e=t.what_to_hjlj_exinfo||{};return e.EXPARAMS_FLAG||"EXPARAMS"},getCustomExParams:function(t){var e="";return t!==this.getExparamsFlag()&&(e=this.filterExinfo(t)||""),e?e.split("&"):[]},getBeaconExparams:function(t,e){var n=[],r=a.getExParams(o)||"";r=r.replace(/&aplus&/,"&");for(var i=o.param2arr(r)||[],u=function(e){return s.indexof(t,e)>-1},c=0;c<i.length;c++){var l=i[c],p=l[0]||"",g=l[1]||"";p&&g&&(e===this.getExparamsFlag()||u(p))&&n.push(p+"="+g)}return n},getExinfo:function(t){var e=this.options.context||{},n=e.what_to_hjlj_exinfo||{},o=n.exparams_key_names||[],a=this.getBeaconExparams(o,t);return a},getExData:function(t){var e=[];if("object"==typeof t)for(var n in t){var o=t[n];n&&o&&"object"!=typeof o&&"function"!=typeof o&&e.push(n+"="+o)}return e},doConcatArr:function(t,e){return e&&e.length>0&&(t=t.concat(e)),t},run:function(){try{var t=this.options.context.what_to_hjlj_exinfo||{},e=r.getGoldlogVal("_$")||{},n=e.meta_info||{},o=n["aplus-exinfo"]||"",a=n["aplus-exdata"]||"",s=[];s=this.doConcatArr(s,t.exinfo||[]),s=this.doConcatArr(s,this.getExinfo(o)),s=this.doConcatArr(s,this.getCookieUserInfo()),s=this.doConcatArr(s,this.getCustomExParams(o)),s=this.doConcatArr(s,this.getExData(a)),t.exinfo=s.join("&"),this.options.context.what_to_hjlj_exinfo=t}catch(t){i.logger({msg:t?t.message:""})}}}}},function(t,e,n){"use strict";var o=n(31),a=n(18),r=n(11),i=n(9),s=n(4);t.exports=function(){return{init:function(t){this.options=t},getParams:function(){var t=this.options.context||{},e=t.userdata||{},n=t.basic_params||{},u=t.what_to_hjlj_exinfo||{},c=u.exinfo||"",l=t.etag||{},p=l.cna||n.cna||r.getCookie("cna"),g=e.gmkey,f="";e.gokey&&c?f=[e.gokey,c].join("&"):e.gokey?f=e.gokey:c&&(f=c);var d=t.what_to_pvhash||{},_=d.hash||[];_.length&&(f+="&"+_.join("=")),f+="&jsver="+s.script_name,f+="&lver="+s.lver,f+="&pver="+goldlog.aplus_cplugin_ver,f+="&cache="+i.makeCacheNum(),f+="&page_cna="+p;var h={gmkey:g||"",gokey:f,cna:p};try{var m=location.href.substring(0,1200);m&&(h._p_url=goldlog.getMetaInfo("aplus-p-url")||m)}catch(t){}e["spm-cnt"]&&(h["spm-cnt"]=e["spm-cnt"]),e["spm-pre"]&&(h["spm-pre"]=e["spm-pre"]);try{var v=o.getExParams(a),b=a.param2obj(v).uidaplus;b&&(h._gr_uid_=b);var y=a.param2obj(f).uidaplus;y&&(h.uidaplus=y)}catch(t){}return h},run:function(){this.options.context.what_to_hjlj.logdata=this.getParams()}}}},function(t,e,n){"use strict";var o=n(70),a=n(26),r=n(4);t.exports=function(){return{init:function(t){this.options=t},getToUtData:function(t,e){var n=a.getGoldlogVal("_$")||{},i=n.spm||{},s=this.options.context.userdata||{},u=this.options.context.basic_params||{},c=this.options.context||{},l=c.what_to_hjlj_exinfo||{},p=l.exinfo||"",g="";s.gokey&&p?g=[s.gokey,p].join("&"):s.gokey?g=s.gokey:p&&(g=p);var f={};f.functype="ctrl",f.funcId=o.getFunctypeValue2({logkey:s.logkey,gmkey:s.gmkey,spm_ab:a.getGoldlogVal("spm_ab")}),f.url=goldlog.getMetaInfo("aplus-pagename")||location.origin+location.pathname,f.logkey=s.logkey,f.gokey=encodeURIComponent(g),f.gmkey=s.gmkey,f._ish5="1",f._h5url=location.href,f._is_g2u_=t?1:2,f._toUT=2,f._bridgeName=e.bridgeName||"",f._bridgeVersion=e.bridgeVersion||"",f["spm-cnt"]=i.spm_cnt||"",f["spm-url"]=i.spm_url||"",f["spm-pre"]=i.spm_pre||"",f.cna=u.cna,f.lver=r.lver,f.jsver=r.script_name,s.hasOwnProperty("autosend")&&(f.autosend=s.autosend);var d=goldlog.getMetaInfo("aplus-utparam");return d&&(f["utparam-cnt"]=JSON.stringify(d)),f},run:function(){var t=this.options.context||{},e=t.what_to_hjlj_ut2||{},n=!!t.is_single,o=t.where_to_sendlog_ut||{},a=o.aplusToUT||{},r=a.toUT2||{};e.logdataToUT=this.getToUtData(n,r),this.options.context.what_to_hjlj_ut2=e}}}},function(t,e,n){"use strict";var o=n(71),a=n(55),r=function(t){var e=t.logkey.toLowerCase();0===e.indexOf("/")&&(e=e.substr(1));var n=t.gmkey?t.gmkey.toUpperCase():"OTHER";switch(n){case"EXP":return"2201";case"CLK":return"2101";case"SLD":return"19999";case"OTHER":default:return"19999"}},i=/\sA2U\/x/.test(window.navigator.userAgent),s=function(){var t=window.navigator.userAgent,e=!1,n=/AliApp\((DM|DY|DingTalk|CN|LA)\/(\d+[._]\d+[._]\d+)/i,r=n.test(t);return e=r,i||a.haveNativeFlagInUA()||e||o.webviewIsAbove({version_ios_tb:[5,11,7],version_ios_tm:[5,24,1],version_android_tb:[5,11,7],version_android_tm:[5,24,1]})};e.isSingleUaVersion=s,e.isSingleSendLog=function(t){return(!t||!/^\/fsp\.1\.1$/.test(t.logkey))&&!!(t&&t.logkey&&s())},e.getFunctypeValue=function(t){return e.isSingleSendLog(t)?r(t):"2101"},e.getFunctypeValue2=function(t){return r(t)}},function(t,e){"use strict";var n=function(t){var e=[0,0,0];try{if(t){var n=t[1],o=n.split(".");if(o.length>2)for(var a=0;a<o.length;)e[a]=parseInt(o[a]),a++}}catch(t){e=[0,0,0]}finally{return e}};e.parseVersion=n;var o=function(t,e){var n=!1;try{var o=t[0]>e[0],a=t[1]>e[1],r=t[2]>e[2],i=t[0]===e[0],s=t[1]===e[1],u=t[2]===e[2];n=!!o||(!(!i||!a)||(!!(i&&s&&r)||!!(i&&s&&u)))}catch(t){n=!1}finally{return n}};e.isAboveVersion=o,e.webviewIsAbove=function(t,e){var a=!1;try{e||(e=navigator.userAgent);var r=e.match(/AliApp\(TB\/(\d+[._]\d+[._]\d+)/i),i=n(r),s=e.match(/AliApp\(TM\/(\d+[._]\d+[._]\d+)/i),u=n(s),c=/iPhone|iPad|iPod|ios/i.test(e),l=/android/i.test(e);c?r&&i?a=o(i,t.version_ios_tb):s&&u&&(a=o(u,t.version_ios_tm)):l&&(r&&i?a=o(i,t.version_android_tb):s&&u&&(a=o(u,t.version_android_tm)))}catch(t){a=!1}return a},e.webviewIsEqual=function(t,e){var n=!1;try{e||(e=navigator.userAgent);var o=e.match(/AliApp\(CN\/(\d+[._]\d+[._]\d+)/i),a=o?o[1]:"0.0.0",r=e.match(/AliApp\(DingTalk\/(\d+[._]\d+[._]\d+)/i),i=r?r[1]:"0.0.0",s=/iPhone|iPad|iPod|ios/i.test(e),u=/android/i.test(e);s?o&&a?n=t.version_ios_cn===a:r&&i&&(n=t.version_ios_dd===i):u&&(o&&a?n=t.version_android_cn===a:r&&i&&(n=t.version_android_dd===i))}catch(t){n=!1}return n},e.webviewIsBelow=function(t,e){var a=!1;try{e||(e=navigator.userAgent);var r=e.match(/AliApp\(CN\/(\d+[._]\d+[._]\d+)/i),i=n(r),s=/iPhone|iPad|iPod|ios/i.test(e),u=/android/i.test(e);s?r&&i&&(a=!o(i,t.version_ios_cn)):u&&r&&i&&(a=!o(i,t.version_android_cn))}catch(t){a=!1}return a}},function(t,e,n){"use strict";var o=n(70),a=n(11),r=n(26),i=n(4);t.exports=function(){return{init:function(t){this.options=t},getToUtData:function(t,e){var n=r.getGoldlogVal("_$")||{},s=n.spm||{},u=this.options.context||{},c=u.userdata||{},l=u.what_to_hjlj_exinfo||{},p=l.exinfo||"",g="";c.gokey&&p?g=[c.gokey,p].join("&"):c.gokey?g=c.gokey:p&&(g=p);var f={gmkey:c.gmkey,gokey:g,lver:i.lver,jsver:i.script_name,version:i.toUtVersion,spm_cnt:s.spm_cnt||"",spm_url:s.spm_url||"",spm_pre:s.spm_pre||""};f._is_g2u_=t?1:2,f._bridgeName=e.bridgeName||"",f.bridgeVersion=e.bridgeVersion||"",f._toUT=1;try{f=JSON.stringify(f),"{}"==f&&(f="")}catch(t){f=""}var d=n.meta_info||{},_=d.isonepage_data||{},h={};return h.functype=o.getFunctypeValue({logkey:c.logkey,gmkey:c.gmkey,spm_ab:r.getGoldlogVal("spm_ab")}),h.spmcnt=s.spm_cnt||"",h.spmurl=s.spm_url||"",h.spmpre=s.spm_pre||"",h.logkey=c.logkey,h.logkeyargs=f,h.urlpagename=_.urlpagename,h.url=location.href,h.cna=a.getCookie("cna")||"",h.extendargs="",h.isonepage=_.isonepage,h},run:function(){var t=this.options.context||{},e=!!t.is_single,n=t.what_to_hjlj_ut||{},o=t.where_to_sendlog_ut||{},a=o.aplusToUT||{},r=a.toUT||{};n.logdataToUT=this.getToUtData(e,r),this.options.context.what_to_hjlj_ut=n}}}},function(t,e){"use strict";t.exports=function(){return{init:function(t){this.options=t},run:function(){var t=this.options.context||{},e=t.is_single?"1":"0";t.what_to_hjlj_ut2.logdataToUT._slog=e,t.what_to_hjlj_ut.logdataToUT._slog=e;var n=["_slog="+e];if(t.ut_is_available){var o=t.is_single?"1":"2";n.push("_is_g2u="+o)}t.what_to_hjlj.logdata.gokey?t.what_to_hjlj.logdata.gokey+="&"+n.join("&"):t.what_to_hjlj.logdata.gokey=n.join("&")}}}},function(t,e,n){"use strict";var o=n(18),a=n(9),r=n(26),i=n(24),s=n(27);t.exports=function(){return{init:function(t){this.options=t},getMetaInfo:function(){var t=r.getGoldlogVal("_$")||{},e=t.meta_info||s.getInfo();return e},getAplusMetaByKey:function(t){var e=this.getMetaInfo()||{};return e[t]},cramUrl:function(t){var e=r.getGoldlogVal("_$")||{},n=e.spm||{},o=this.options.context.where_to_hjlj||{},i=o.ac_atpanel,s=o.tblogUrl,u=this.options.context.what_to_hjlj||{},c=this.options.context.userdata||{},l=!0,p=c.logkey;if(!p)return{url:t,logkey_available:!1};if("ac"==p)t=i+"1.gif";else if(a.isStartWith(p,"ac-"))t=i+p.substr(3);else if(a.isStartWith(p,"/")){t+=p.substr(1);var g=u.logdata||{};g["spm-cnt"]=n.spm_cnt,g.logtype=2;try{u.logdata=g,this.options.context.what_to_hjlj=u}catch(t){}}else a.isEndWith(p,".gif")?t=s+p:l=!1;return{url:t,logkey_available:l}},can_to_sendhjlj:function(t){var e=this.options.context||{},n=e.logger||function(){},o=this.options.context.userdata||{};return!!t.logkey_available||(n({msg:"logkey: "+o.logkey+" is not legal!"}),!1)},run:function(){var t,e,n=this.options.context.where_to_hjlj.url,a=this.getAplusMetaByKey("aplus-rhost-g"),r=a&&o.hostValidity(a);r&&(t=/^\/\//.test(a)?"":"//",e=/\/$/.test(a)?"":"/",n=t+a+e),a&&!r&&i.logger({msg:"aplus-rhost-g: "+a+' is invalid, suggestion: "xxx.mmstat.com"'});var s=this.cramUrl(n);return this.can_to_sendhjlj(s)?void(this.options.context.where_to_hjlj.url=s.url):"done"}}}},function(t,e,n){"use strict";var o=n(55);t.exports=function(){return{init:function(t){this.options=t},run:function(t,e){var n=this,a=this.options.context||{},r=a.logger||function(){},i=a.what_to_hjlj_ut2||{},s=a.where_to_sendlog_ut||{},u=!!a.is_single,c=i.logdataToUT||{},l=s.aplusToUT||{},p=l.toUT2;if(o.isNative4Aplus())return l.toutflag="toUT2",s.toUTName="toUT2",void(n.options.context.what_to_hjlj_ut2.isSuccess=!0);if(p&&"function"==typeof p.toUT2&&p.isAvailable)try{l.toutflag="toUT2",p.toUT2(c,function(){n.options.context.what_to_hjlj_ut2.isSuccess=!0,e()},function(t){n.options.context.what_to_hjlj_ut2.errorMsg=t,e()},2e3)}catch(t){u&&r({msg:"warning: singleSendHjlj toUTName = toUT2 errorMsg:"+t.message})}finally{return"pause"}}}}},function(t,e){"use strict";t.exports=function(){return{init:function(t){this.options=t},run:function(t,e){var n=this,o=this.options.context||{},a=o.what_to_hjlj_ut2.isSuccess,r=o.logger||function(){},i=!!o.is_single,s=o.where_to_sendlog_ut||{},u=o.what_to_hjlj_ut||{},c=u.logdataToUT||{},l=s.aplusToUT||{},p=l.toUT;if(!a&&p&&"function"==typeof p.toUT2&&p.isAvailable)try{p.toUT2(c,function(){l.toutflag="toUT",n.options.context.what_to_hjlj_ut.isSuccess=!0,e()},function(){e()},5e3)}catch(t){i&&r({msg:"warning: singleSendHjlj toUTName = toUT errorMsg:"+t.message})}finally{return"pause"}}}}},function(t,e,n){"use strict";var o=n(26);t.exports=function(){return{init:function(t){this.options=t},run:function(){var t=this.options.context||{},e=this.options.config||{},n=t.what_to_hjlj_ut.isSuccess,a=t.what_to_hjlj_ut2.isSuccess,r=!!t.is_single;if(!r||!n&&!a){var i=t.logger||{},s=t.what_to_hjlj||{},u=t.where_to_hjlj||{},c=s.logdata||{},l=u.url||"";l||"function"!=typeof i||i({msg:"warning: where_to_hjlj.url is null, goldlog.record failed!"});var p=goldlog.getMetaInfo("aplus-channel");if("WS-ONLY"!==p){var g=goldlog.send(u.url,c,e.method||"GET");o.setGoldlogVal("req",g)}}}}}},function(t,e,n){"use strict";function o(){var t,e,n=i.KEY||{},o=n.NAME_STORAGE||{};if(!c&&u){var a=location.href,l=u&&(a.indexOf("login.taobao.com")>=0||a.indexOf("login.tmall.com")>=0),p=s.getRefer();l&&p?(t=p,e=r.getItem(o.REFERRER_PV_ID)):(t=a,e=goldlog.pvid),r.setItem(o.REFERRER,t),r.setItem(o.REFERRER_PV_ID,e)}}var a=n(79),r=n(52).nameStorage,i=n(4),s=n(51),u="https:"==location.protocol,c=parent!==self;e.run=function(){var t="beforeunload";a.on(window,t,function(){o()})}},function(t,e,n){"use strict";function o(t,e,n){var o=goldlog._$||{},a=o.meta_info||{},r=a.aplus_ctap||{},i=a["aplus-touch"];if(r&&"function"==typeof r.on)r.on(t,e);else{var u="ontouchend"in document.createElement("div");!u||"tap"!==i&&"tapSpm"!==n?s(t,u?"touchstart":"mousedown",e):c.on(t,e)}}function a(t){try{p.documentElement.doScroll("left")}catch(e){return void setTimeout(function(){a(t)},1)}t()}function r(t){var e=0,n=function(){0===e&&t(),e++};"complete"===p.readyState&&n();var o;if(p.addEventListener)o=function(){p.removeEventListener("DOMContentLoaded",o,!1),n()},p.addEventListener("DOMContentLoaded",o,!1),window.addEventListener("load",n,!1);else if(p.attachEvent){o=function(){"complete"===p.readyState&&(p.detachEvent("onreadystatechange",o),n())},p.attachEvent("onreadystatechange",o),window.attachEvent("onload",n);var r=!1;try{r=null===window.frameElement}catch(t){}p.documentElement.doScroll&&r&&a(n)}}function i(t){"complete"===p.readyState?t():s(l,"load",t)}function s(){var t=arguments;if(2===t.length)"DOMReady"===t[0]&&r(t[1]),"onload"===t[0]&&i(t[1]);else if(3===t.length){var e=t[0],n=t[1],a=t[2];"tap"===n||"tapSpm"===n?o(e,a,n):e[_]((g?"on":"")+n,function(t){t=t||l.event;var e=t.target||t.srcElement;"function"==typeof a&&a(t,e)},!!u(n)&&{passive:!0})}}var u=n(80),c=n(81),l=window,p=document,g=!!p.attachEvent,f="attachEvent",d="addEventListener",_=g?f:d;e.DOMReady=r,e.onload=i,e.on=s},function(t,e){var n;t.exports=function(t){if("boolean"==typeof n)return n;if(!/touch|mouse|scroll|wheel/i.test(t))return!1;n=!1;try{var e=Object.defineProperty({},"passive",{get:function(){n=!0}});window.addEventListener("test",null,e)}catch(t){}return n}},function(t,e){"use strict";function n(t,e){return t+Math.floor(Math.random()*(e-t+1))}function o(t,e,n){var o=l.createEvent("HTMLEvents");if(o.initEvent(e,!0,!0),"object"==typeof n)for(var a in n)o[a]=n[a];t.dispatchEvent(o)}function a(t){0===Object.keys(g).length&&(p.addEventListener(_,r,!1),p.addEventListener(d,i,!1),p.addEventListener(m,i,!1));for(var e=0;e<t.changedTouches.length;e++){
var n=t.changedTouches[e],o={};for(var a in n)o[a]=n[a];var s={startTouch:o,startTime:Date.now(),status:h,element:t.srcElement||t.target};g[n.identifier]=s}}function r(t){for(var e=0;e<t.changedTouches.length;e++){var n=t.changedTouches[e],o=g[n.identifier];if(!o)return;var a=n.clientX-o.startTouch.clientX,r=n.clientY-o.startTouch.clientY,i=Math.sqrt(Math.pow(a,2)+Math.pow(r,2));(o.status===h||"pressing"===o.status)&&i>10&&(o.status="panning")}}function i(t){for(var e=0;e<t.changedTouches.length;e++){var n=t.changedTouches[e],a=n.identifier,s=g[a];s&&(s.status===h&&t.type===d&&(s.timestamp=Date.now(),o(s.element,v,{touch:n,touchEvent:t})),delete g[a])}0===Object.keys(g).length&&(p.removeEventListener(_,r,!1),p.removeEventListener(d,i,!1),p.removeEventListener(m,i,!1))}function s(t){t.__fixTouchEvent||(t.addEventListener(f,function(){},!1),t.__fixTouchEvent=!0)}function u(){c||(p.addEventListener(f,a,!1),c=!0)}var c=!1,l=window.document,p=l.documentElement,g={},f="touchstart",d="touchend",_="touchmove",h="tapping",m="touchcancel",v="aplus_tap"+n(1,1e5);t.exports={on:function(t,e){u(),t&&t.addEventListener&&e&&(s(t),t.addEventListener(v,e._aplus_tap_callback=function(t){e(t,t.target)},!1))},un:function(t,e){t&&t.removeEventListener&&e&&e._aplus_tap_callback&&t.removeEventListener(v,e._aplus_tap_callback,!1)}}},function(t,e,n){"use strict";function o(){var t=goldlog._$||{},e=t.meta_info||{},n=goldlog.getCdnPath(),o=n+"/sd/baxia-entry/index.js",i=function(){a.addScript(o,"","aplus-baxia")};r.onload(function(){try{var t=e["aplus-xplug"];"NONE"!==t&&i()}catch(t){}})}var a=n(31),r=n(79),i=n(83);e.run=function(){o()},e.init_watchGoldlogQueue=i.init_watchGoldlogQueue},function(t,e,n){"use strict";function o(t,e){for(var n={subscribeMwChangeQueue:[],subscribeMetaQueue:[],subscribeQueue:[],metaQueue:[],othersQueue:[]},o=[],a={};a=t.shift();)try{var r=a.action,i=a.arguments[0];/subscribe/.test(r)?"setMetaInfo"===i?n.subscribeMetaQueue.push(a):"mw_change_pv"===i||"mw_change_hjlj"===i?n.subscribeMwChangeQueue.push(a):n.subscribeQueue.push(a):/MetaInfo/.test(r)?n.metaQueue.push(a):n.othersQueue.push(a)}catch(t){n.othersQueue.push(a),u.do_tracker_jserror({message:t&&t.message,error:encodeURIComponent(t.stack),filename:"getFormatQueue"})}var s;return e&&n[e]&&(s=n[e],n[e]=[]),o=n.subscribeMwChangeQueue.concat(n.metaQueue),o=o.concat(n.subscribeQueue),o=o.concat(n.subscribeMetaQueue,n.othersQueue),{queue:o,formatQueue:s}}var a=window,r=n(9),i=n(84),s=n(85),u=n(3),c="goldlog_queue",l=function(t,e,n){try{/_aplus_cplugin_track_deb/.test(t)||/_aplus_cplugin_m/.test(t)||u.do_tracker_jserror({message:n||'illegal task: goldlog_queue.push("'+JSON.stringify(e)+'")',error:JSON.stringify(e),filename:"processTask"})}catch(t){}},p=function(t,e){var n=t?t.action:"",o=t?t.arguments:"";try{if(n&&o&&r.isArray(o)){var i=n.split("."),s=a,u=a;if(3===i.length)s=a[i[0]][i[1]]||{},u=s[i[2]]?s[i[2]]:"";else for(;i.length;)if(u=s=s[i.shift()],!s)return void("function"==typeof e?e(t):l(n,t));"function"==typeof u&&u.apply(s,o)}else l(n,t)}catch(e){l(n,t,e.message)}},g=function(t){function e(){if(t&&r.isArray(t)&&t.length){for(var e=o(t).queue,n={},a=[];n=e.shift();)p(n,function(t){a.push(t)});a.length>0&&setTimeout(function(){for(;n=a.shift();)p(n)},100)}}try{e()}catch(t){u.do_tracker_jserror({message:t&&t.message,error:encodeURIComponent(t.stack),filename:"processGoldlogQueue"})}};e.processGoldlogQueue=g;var f=i.extend({push:function(t){this.length++,p(t)}});e.init_watchGoldlogQueue=function(t){try{var e=a[c]||[];if(t){var n=o(e,t);a[c]=n.queue,g(n.formatQueue)}else a[c]=f.create({startLength:e.length,length:0}),s.init_loadAplusPlugin(),g(e)}catch(t){u.do_tracker_jserror({message:t&&t.message,error:encodeURIComponent(t.stack),filename:"init_watchGoldlogQueue"})}}},function(t,e){"use strict";function n(){}n.prototype.extend=function(){},n.prototype.create=function(){},n.extend=function(t){return this.prototype.extend.call(this,t)},n.prototype.create=function(t){var e=new this;for(var n in t)e[n]=t[n];return e},n.prototype.extend=function(t){var e=function(){};try{"function"!=typeof Object.create&&(Object.create=function(t){function e(){}return e.prototype=t,new e}),e.prototype=Object.create(this.prototype);for(var n in t)e.prototype[n]=t[n];e.prototype.constructor=e,e.extend=e.prototype.extend,e.create=e.prototype.create}catch(t){console.log(t)}finally{return e}},t.exports=n},function(t,e,n){"use strict";var o=n(31),a=n(29),r=n(6),i=function(){var t=goldlog.getCdnPath()+"/alilog/s/"+r.lver+"/plugin/";return{aplus_ae_path:t+"aplus_ae.js",aplus_ac_path:t+"aplus_ac.js"}},s={},u="aplus-auto-exp",c="aplus-auto-clk",l=function(t,e){var n=i(),r=goldlog&&goldlog.getMetaInfo?goldlog.getMetaInfo(t):"",l=e||r||a.getMetaCnt(t),p={};p[u]=n.aplus_ae_path,p[c]=n.aplus_ac_path,l&&p[t]&&!s[t]&&(o.addScript(p[t]),s[t]=!0)};e.init_loadAplusPlugin=function(){try{!goldlog._aplus_auto_exp&&l(u),!goldlog._aplus_ac&&l(c),goldlog.aplus_pubsub.subscribe("setMetaInfo",function(t,e){t!==u||goldlog._aplus_auto_exp||l(t,e),t!==c||goldlog._aplus_ac||l(t,e)})}catch(t){}}},function(t,e){"use strict";function n(t,e){return t.indexOf(e)>-1}function o(t,e){for(var o=0,a=t.length;o<a;o++)if(n(e,t[o]))return!0;return!1}var a=location.host,r=["admin.taobao.org","mybank.cn"],i=["tmc.admin.taobao.org","tmall.admin.taobao.org"];e.is_exception=o(r,a)&&!o(i,a)},function(t,e,n){"use strict";function o(){var t,e,n,o,a=c.getElementsByTagName("meta");for(t=0,e=a.length;t<e;t++)if(n=a[t],o=n.getAttribute("name"),"data-spm"===o||"spm-id"===o)return n}function a(){var t=c.createElement("meta");t.setAttribute("name","data-spm");var e=c.getElementsByTagName("head")[0];return e&&e.insertBefore(t,e.firstChild),t}function r(){var t=o();t||(t=a()),t.setAttribute("content",goldlog.spm_ab[0]||"");var e=c.getElementsByTagName("body")[0];e&&e.setAttribute("data-spm",goldlog.spm_ab[1]||"")}function i(){var t,e,n,o=c.getElementsByTagName("*");for(t=0,e=o.length;t<e;t++)n=o[t],n.getAttribute("data-spm-max-idx")&&n.setAttribute("data-spm-max-idx",""),n.getAttribute("data-spm-anchor-id")&&n.setAttribute("data-spm-anchor-id","")}function s(){var t=5e3;try{var e=goldlog.getMetaInfo("aplus-mmstat-timeout");if(e){var n=parseInt(e);n>=1e3&&n<=1e4&&(t=n)}}catch(t){}return t}var u=window,c=document,l=n(84),p=n(18),g=n(79),f=n(31),d=n(24),_=n(33),h=n(9),m=n(26),v=n(22),b=n(49),y=n(27),w=y.getInfo(),x=n(4),j=n(3),T=n(88),P=n(11),A=n(91),S=n(93),k=[],E=[],U=[],I=[],M="//g.alicdn.com",C="//g-assets.daily.taobao.net",N="//assets.alicdn.com/g",O="//s.alicdn.com/@g/",V="//u.alicdn.com",G="//laz-g-cdn.alicdn.com";e.run=l.extend({getCdnPath:function(){var t=f.getCurrentNode(),e=M,n=[N,O,C,V,G],o=new RegExp(V);if(t)for(var a=0;a<n.length;a++){var r=new RegExp(n[a]);if(r.test(t.src)){e=n[a],o.test(t.src)&&(e=N);break}}return e},isInternational:function(){this.cdnPath||(this.cdnPath=this.getCdnPath());var t=[N,O,G].indexOf(this.cdnPath)>-1;return t||"int"===this.getMetaInfo("aplus-env")},getCookie:function(t){return P.getCookie(t)},getParam:function(t){var e=u.WindVane||{},n=e&&"function"==typeof e.getParam?e.getParam(t):"";return n},beforeSendPV:function(t){k.push(t)},afterSendPV:function(t){E.push(t)},send:function(t,e,n){var o;if(0===t.indexOf("//")){var a=v.getProtocal();t=a+t}return o="POST"===n&&navigator&&navigator.sendBeacon?S.postData(t,e):S.sendImg(p.makeUrl(t,e),s())},launch:function(t,e){var n;try{e=h.assign(e,t),n=goldlog._$._sendPV(e,t);var o=goldlog.spm_ab?goldlog.spm_ab.join("."):"0.0";j.do_tracker_obsolete_inter({page:location.hostname+location.pathname,spm_ab:o,interface_name:"goldlog.launch",interface_params:"userdata = "+JSON.stringify(t)+", config = "+JSON.stringify(e)})}catch(t){}finally{return d.logger({msg:"warning: This interface is deprecated, please use goldlog.sendPV instead! API: http://log.alibaba-inc.com/log/info.htm?type=2277&id=31"}),n}},_$:{_sendPV:function(t,e){if(t=t||{},h.any(k,function(e){return e(goldlog,t)===!1}))return!1;var o=n(94).SendPV,a=new o;return"undefined"==typeof t.recordType&&(t.recordType=x.recordTypes.pv),a.run(t,e,{fn_after_pv:E}),!0},_sendPseudo:function(t,e){t||(t={});var o=n(95).SendPrePV,a=new o;return"undefined"==typeof t.recordType&&(t.recordType=x.recordTypes.prepv),a.run(t,e,{},function(){_.doPubMsg(["sendPrePV","complete"])}),!0}},sendPV:function(t,e){return e=e||{},e.pageName&&goldlog.setMetaInfo("aplus-pagename",e.pageName),goldlog._$._sendPV(t,e)},updatePageProperties:function(t){t&&"object"==typeof t?(t._page&&(t.pageName=t._page,delete t._page),t.pageName&&(goldlog.setMetaInfo("aplus-pagename",t.pageName),delete t.pageName),goldlog.appendMetaInfo("aplus-cpvdata",t)):d.logger({msg:"warning: typeof updatePageProperties's params must be object"})},beforeRecord:function(t){U.push(t)},afterRecord:function(t){I.push(t)},record:function(t,e,n,o,a){if(!h.any(U,function(t){return t(goldlog)===!1}))return"POST"!==o&&"WS"!==o&&"WS-ONLY"!==o&&(o="GET"),T.run({recordType:x.recordTypes.hjlj,method:o},{logkey:t,gmkey:e,gokey:n},{fn_after_record:I},function(){"function"==typeof a&&a()}),!0},recordUdata:function(t,e,n,o,a){var r=m.getGoldlogVal("_$")||{},i=r.spm||{};"POST"!==o&&"WS"!==o&&"WS-ONLY"!==o&&(o="GET"),T.run({ignore_chksum:!0,method:o,recordType:x.recordTypes.uhjlj},{logkey:t,gmkey:e,gokey:n,"spm-cnt":i.spm_cnt,"spm-pre":i.spm_pre},{},function(){h.isFunction(a)&&a()})},setPageSPM:function(t,e,n){var o="setPageSPM",a=goldlog.getMetaInfo("aplus-spm-fixed"),s="function"==typeof n?n:function(){};goldlog.spm_ab=goldlog.spm_ab||[];var u=h.cloneObj(goldlog.spm_ab);if(t&&(goldlog.spm_ab[0]=""+t,goldlog._$.spm.data.a=""+t),e&&(goldlog.spm_ab[1]=""+e,goldlog._$.spm.data.b=""+e),b.spaInit(goldlog,w,u),"1"!==a){var c=u.join(".");goldlog.spmab_pre=c}var l=goldlog.spm_ab.join(".");_.doPubMsg([o,{spmab_pre:goldlog.spmab_pre,spmab:l}]),_.doCachePubs([o,{spmab_pre:goldlog.spmab_pre,spmab:l}]),r(),i(),s()},setMetaInfo:function(t,e,n){if(y.setMetaInfo(t,e,n)){var o=m.getGoldlogVal("_$")||{};o.meta_info=y.qGet();var a=m.setGoldlogVal("_$",o),r=A.isDisablePvid()+"";return"aplus-disable-pvid"===t&&r!==e+""&&b.resetSpmCntPvid(),_.doPubMsg(["setMetaInfo",t,e,n]),_.doCachePubs(["setMetaInfo",t,e,n]),a}},appendMetaInfo:y.appendMetaInfo,getMetaInfo:function(t){return y.getMetaInfo(t)},on:g.on,cloneDeep:h.cloneDeep,getPvId:A.getPvId})},function(t,e,n){"use strict";var o=n(9),a=n(26),r=n(33),i=n(24),s=n(89),u=n(90),c=n(4);e.run=function(t,e,n,l){var p=new u;p.init({middleware:[],config:t,plugins:c.plugins_hjlj});var g=p.run(),f=new c.context_hjlj;f.userdata=e,f.logger=i.logger;var d={context:f,pubsub:a.getGoldlogVal("aplus_pubsub"),pubsubType:"hjlj"},_=new s;_.create(d),_.wrap(g,function(){d.context.status="complete",d.context.method=t.method,r.doPubMsg(["mw_change_hjlj",d.context]),n&&n.fn_after_record&&o.each(n.fn_after_record,function(t){t(window.goldlog)}),"function"==typeof l&&l()})()}},function(t,e,n){"use strict";function o(){}var a=n(12),r=n(23),i=n(24),s=n(3),u=n(11);o.prototype.create=function(t){for(var e in t)"undefined"==typeof this[e]&&(this[e]=t[e]);return this},o.prototype.pubsubInfo=function(t,e){try{t&&t.pubsub&&t.pubsub.publish("mw_change_"+t.pubsubType,t.context,e)}catch(t){}},o.prototype.calledList=[],o.prototype.setCalledList=function(t){a.indexof(this.calledList,t)===-1&&this.calledList.push(t)},o.prototype.resetCalledList=function(){this.calledList=[]},o.prototype.wrap=function(t,e){var n=this,o=this.context||{},c=o.compose||{},l=c.maxTimeout||1e4;return function(o){var c,p=t.length,g=0,f=0,d=function(){if(n.pubsubInfo(n,t[g]),g===p)return o="done",n.resetCalledList(),"function"==typeof e&&e.call(n,o),void clearTimeout(c);if(a.indexof(n.calledList,g)===-1){if(n.setCalledList(g),!t[g]||"function"!=typeof t[g][0])return;try{o=t[g][0].call(n,o,function(){g++,f=1,clearTimeout(c),d(g)})}catch(e){s.do_tracker_jserror({message:e?e.message:"compose middleware error",error:encodeURIComponent(e.stack),filename:t[g][1]})}}var _="number"==typeof o;if("pause"===o||_){f=0;var h=_?o:l,m=t[g]?t[g][1]:"";c=r.sleep(h,function(){if(0===f){var t="jump the middleware about "+m+", because waiting timeout maxTimeout = "+h+"ms!";i.logger({msg:t});var e=window.goldlog_queue||(window.goldlog_queue=[]);e.push({action:"goldlog._aplus_cplugin_m.do_tracker_browser_support",arguments:[{msg:t,spmab:goldlog.spm_ab,page:location.href,etag:n.context?JSON.stringify(n.context.etag):"",cna:document.cookie?u.getCookie("cna"):""}]}),o=null,g++,d(g)}})}else"done"===o?(g=p,d(g)):(g++,d(g))};return n.calledList&&n.calledList.length>0&&n.resetCalledList(),d(g)}},t.exports=o},function(t,e,n){"use strict";var o=n(12);t.exports=function(){return{init:function(t){this.opts=t,t&&"object"==typeof t.middleware&&t.middleware.length>0?this.middleware=t.middleware:this.middleware=[],this.plugins_name=[]},pubsubInfo:function(t,e){try{var n=t.pubsub;n&&n.publish("plugins_change_"+t.pubsubType,e)}catch(t){}},checkPluginLoader:function(t,e){var n=!0;if("object"==typeof e.enable&&"function"==typeof e.enable.isEnable?n=e.enable.isEnable(e.name):"boolean"==typeof e.enable&&(n=!!e.enable),!n)return!1;if(n&&e.deps&&e.deps.length>0)for(var a=0;a<e.deps.length;a++)if(o.indexof(this.plugins_name,e.deps[a])===-1)return!1;return!0},run:function(t){t||(t=0);var e=this,n=this.middleware,o=this.opts||{},a=o.plugins;if(a&&"object"==typeof a&&a.length>0){var r=a[t];if(this.checkPluginLoader(a,r)&&(this.plugins_name.push(r.name),n.push([function(t,n){e.pubsubInfo(this,r);var a=new r.path;return a.init({context:this.context,config:o.config}),a.run(t,n)},r.name])),t++,a[t])return this.run(t)}else window.console&&console.log("aplus plugins "+JSON.stringify(a)+" must be object of array!");return n}}}},function(t,e,n){"use strict";function o(){var t="true"===l.disablePvid;try{var e=goldlog.getMetaInfo("aplus-disable-pvid")+"";"true"===e?t=!0:"false"===e&&(t=!1)}catch(t){}return t}function a(t){function e(t){var e="0123456789abcdefhijklmnopqrstuvwxyzABCDEFHIJKLMNOPQRSTUVWXYZ",n="0123456789abcdefghijkmnopqrstuvwxyzABCDEFGHIJKMNOPQRSTUVWXYZ";return 1==t?e.substr(Math.floor(60*Math.random()),1):2==t?n.substr(Math.floor(60*Math.random()),1):"0"}for(var n,o="",a="0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ",r=!1;o.length<t;)n=a.substr(Math.floor(62*Math.random()),1),!r&&o.length<=2&&("g"==n.toLowerCase()||"l"==n.toLowerCase())&&(0===o.length&&"g"==n.toLowerCase()?Math.random()<.5&&(n=e(1),r=!0):1==o.length&&"l"==n.toLowerCase()&&"g"==o.charAt(0).toLowerCase()&&(n=e(2),r=!0)),o+=n;return o}function r(t,e,n){return t?u.hash(encodeURIComponent(t)).substr(0,e):n}function i(){var t=a(8),e=t.substr(0,4),n=t.substr(0,6);return[r(location.href,4,e),r(document.title,4,e),n].join("")}function s(){var t=goldlog.pvid;return goldlog.pvid=i(),c.doPubMsg(["pvidChange",{pre_pvid:t,pvid:goldlog.pvid}]),c.doCachePubs(["pvidChange",{pre_pvid:t,pvid:goldlog.pvid}]),o()?"":goldlog.pvid}var u=n(92),c=n(33),l=n(4);e.isDisablePvid=o,e.makePVId=s,e.getPvId=function(){return o()?"":goldlog.pvid}},function(t,e){"use strict";var n=1315423911;e.hash=function(t,e){var o,a,r=e||n;for(o=t.length-1;o>=0;o--)a=t.charCodeAt(o),r^=(r<<5)+a+(r>>2);var i=(2147483647&r).toString(16);return i}},function(t,e,n){"use strict";function o(t){if(!t)return"";var e=decodeURIComponent(t).match(/cache=\w+/);return e&&1===e.length?e[0].split("=")[1]:void 0}var a=n(3),r=window;e.sendImg=function(t,e){var n=new Image,i="_img_"+Math.random();r[i]=n;var s=function(){if(r[i])try{delete r[i]}catch(t){r[i]=void 0}};return n.onload=function(){s()},n.onerror=function(){a.do_tracker_jserror({message:"loadError",error:"",filename:"sendImg",logid:o(t)}),s()},setTimeout(function(){window[i]&&(a.do_tracker_jserror({message:"loadTimeout",error:e,filename:"sendImg",logid:o(t)}),window[i].src="",s())},e||3e3),n.src=t,n=null,t},e.postData=function(t,e){var n;if("string"==typeof e)n=e;else{for(var o in e)["cna"].indexOf(o)===-1&&(e[o]=encodeURIComponent(e[o]));n=JSON.stringify(e)}return navigator.sendBeacon(t,n),t}},function(t,e,n){"use strict";var o=n(9),a=n(26),r=n(33),i=n(24),s=n(89),u=n(90),c=n(4),l=function(){};l.prototype.run=function(t,e,n){var l=new u;l.init({middleware:[],config:t,plugins:c.plugins_pv});var p=l.run(),g=new c.context;g.userdata=e,g.logger=i.logger;var f={context:g,pubsub:a.getGoldlogVal("aplus_pubsub"),pubsubType:"pv"},d=new s;d.create(f),d.wrap(p,function(){var e=f.context.can_to_sendpv||{};f.context.status="YES"===e.flag?"complete":"skip",f.context.method=t.method||"GET",r.doPubMsg(["mw_change_pv",f.context]),n&&n.fn_after_pv&&o.each(n.fn_after_pv,function(e){e(window.goldlog,t)})})()},e.SendPV=l},function(t,e,n){"use strict";var o=n(9),a=n(26),r=n(33),i=n(24),s=n(89),u=n(90),c=n(4),l=function(){};l.prototype.run=function(t,e,n,l){var p=new u;p.init({middleware:[],config:t,plugins:c.plugins_prepv});var g=p.run(),f=new c.context_prepv;f.userdata=e,f.logger=i.logger;var d={context:f,pubsub:a.getGoldlogVal("aplus_pubsub"),pubsubType:"prepv"},_=new s;_.create(d),_.wrap(g,function(){d.context.status="complete",r.doPubMsg(["mw_change_prepv",d.context]),n&&n.fn_after_record&&o.each(n.fn_after_pv,function(e){e(window.goldlog,t)}),a.setGoldlogVal("prepv_context",f),"function"==typeof l&&l()})()},e.SendPrePV=l},function(t,e,n){"use strict";!function(){var t=window.goldlog||(window.goldlog={}),e=n(97);t.aplus_pubsub||(t.aplus_pubsub=e.create())}()},function(t,e,n){"use strict";function o(t){if("function"!=typeof t)throw new TypeError(t+" is not a function");return t}var a=n(84),r=function(t){for(var e=t.length,n=new Array(e-1),o=1;o<e;o++)n[o-1]=t[o];return n},i=a.extend({create:function(t){var e=new this;for(var n in t)e[n]=t[n];return e.handlers=[],e.pubs={},e},setHandlers:function(t){this.handlers=t},subscribe:function(t,e){o(e);var n=this,a=n.pubs||{},r=a[t]||[];if(r)for(var i=0;i<r.length;i++){var s=r[i]();e.apply(n,s)}var u=n.handlers||[];return t in u||(u[t]=[]),u[t].push(e),n.setHandlers(u),n},subscribeOnce:function(t,e){o(e);var n,a=this;return this.subscribe.call(this,t,n=function(){a.unsubscribe.call(a,t,n);var o=Array.prototype.slice.call(arguments);e.apply(a,o)}),this},unsubscribe:function(t,e){o(e);var n=this.handlers[t];if(!n)return this;if("object"==typeof n&&n.length>0){for(var a=0;a<n.length;a++){var r=e.toString(),i=n[a].toString();r===i&&n.splice(a,1)}this.handlers[t]=n}else delete this.handlers[t];return this},publish:function(t){var e=r(arguments),n=this.handlers||[],o=n[t]?n[t].length:0;if(o>0)for(var a=0;a<o;a++){var i=n[t][a];i&&"function"==typeof i&&i.apply(this,e)}return this},cachePubs:function(t){var e=this.pubs||{},n=r(arguments);e[t]||(e[t]=[]),e[t].push(function(){return n})}});t.exports=i},function(t,e,n){"use strict";var o=n(41),a=n(33),r=n(51),i=n(4);e.init=function(){i.initLoad.init_watchGoldlogQueue("metaQueue"),n(99)(function(){var t=goldlog._$||{},e=navigator.userAgent;e.match(/AliApp\(([A-Z\-]+)\/([\d\.]+)\)/i)&&(t.is_ali_app=!0),i.utilPvid.makePVId();var s=n(49);t.spm=s,t.is_WindVane=o.is_WindVane;var u=t.meta_info;s.init(goldlog,u,function(){i.initLoad.init_watchGoldlogQueue();var t=n(4).spmException,e=t.is_exception;e||n(102);var o,r="complete";o=["aplusReady",r],a.doPubMsg(o),a.doCachePubs(o)}),goldlog.beforeSendPV(function(e,n){if(t.page_url=location.href,t.page_referrer=r.getRefer(),n.is_auto&&"1"===u["aplus-manual-pv"])return!1}),goldlog.afterSendPV(function(){window.g_SPM&&(g_SPM._current_spm="")}),i.is_auto_pv+""=="true"&&goldlog.sendPV({is_auto:!0}),i.initLoad.run(),i.beforeUnload.run()})}},function(t,e,n){"use strict";var o=n(33),a=n(100);t.exports=function(t){var e=n(101).AplusInit,r=new e;r.run({},function(e){o.doPubMsg(["aplusInitContext",e]),o.doCachePubs(["aplusInitContext",e]),a(),"function"==typeof t&&t()})}},function(t,e,n){"use strict";function o(t){var e="";switch(!0){case r.isJSON(t):e="settled";break;case r.isString(t):e=t;break;case r.isNumber(t):e=t+"";break;default:e="settled"}return e}var a=n(26),r=n(9);t.exports=function(){try{var t=a.getGoldlogVal("hasSendMIC"),e=Math.floor(99*Math.random());if(t||1!==e)return;var n=goldlog&&goldlog._$?goldlog._$.meta_info:{},i="";for(var s in n)r.isEmpty(n[s])||(i=i+"&"+s+"="+o(n[s]));a.setGoldlogVal("hasSendMIC",!0),goldlog.record("/m.i.c","OTHER",i,"POST")}catch(t){}}},function(t,e,n){"use strict";var o=n(26),a=n(24),r=n(89),i=n(90),s=n(4),u=function(){};u.prototype.run=function(t,e){var n=new i;n.init({middleware:[],config:t,plugins:s.aplus_init});var u=n.run(),c=new s.context;c.logger=a.logger;var l={context:c,pubsub:o.getGoldlogVal("aplus_pubsub"),pubsubType:"aplusinit"},p=new r;p.create(l),p.wrap(u,function(){"function"==typeof e&&e(l.context)})()},e.AplusInit=u},function(t,e,n){"use strict";!function(){var t,e=n(9),o=n(26),a=n(103),r=function(){t=!0;var n=window.g_SPM||{};e.isFunction(n.getParam)||e.isFunction(n.spm)||a.run()},i=window.goldlog||(window.goldlog={});i.aplus_pubsub&&"function"==typeof i.aplus_pubsub.publish&&i.aplus_pubsub.subscribe("goldlogReady",function(e){"complete"!==e||t||r()});var s=0,u=function(){if(!t){var e=o.getGoldlogVal("_$")||{};"complete"===e.status?r():s<50&&(++s,setTimeout(function(){u()},200))}};u()}()},function(t,e,n){"use strict";var o=n(31),a=n(26),r=n(104),i=n(108),s=n(109),u=n(110),c=n(111);e.run=function(){var t=a.getGoldlogVal("_$")||{},e=t.meta_info,n=e["aplus-touch"],l={isTouchEnabled:o.isTouch()||"1"===n||"tap"===n,isTerminal:t.is_terminal||/WindVane/i.test(navigator.userAgent)};window.g_SPM={spm_d_for_ad:{},resetModule:r.spm_resetModule,anchorBeacon:r.spm_spmAnchorChk,getParam:r.spm_getSPMParam,spm:r.spm_forwap},i.run(l),s.run(l),u.run(l),c.run(l)}},function(t,e,n){"use strict";function o(t){if(t&&1===t.nodeType){s.tryToRemoveAttribute(t,"data-spm-max-idx"),s.tryToRemoveAttribute(t,"data-auto-spmd-max-idx");for(var e=u.nodeListToArray(t.getElementsByTagName("a")),n=u.nodeListToArray(t.getElementsByTagName("area")),o=e.concat(n),a=0;a<o.length;a++)s.tryToRemoveAttribute(o[a],l)}}function a(t,e){var n=s.tryToGetAttribute(t,l),o="0";if(n&&c.spm_isSPMAnchorIdMatch(n))c.spm_anchorEnsureSPMId_inHref(t,n,e);else{var a=c.spm_spmGetParentSPMId(t.parentNode);if(o=a.spm_c,!o)return void c.spm_dealNoneSPMLink(t,e);c.spm_initSPMModule(a.el,o,e),c.spm_initSPMModule(a.el,o,e,!0)}}function r(t){var e,n=t.tagName;"A"!==n&&"AREA"!==n?e=c.spm_getParamForAD(t):(a(t,!0),e=s.tryToGetAttribute(t,l)),e||(e="0.0.0.0");var o=goldlog.getPvId();4===e.split(".").length&&o&&(e+="."+o),"A"!==n&&"AREA"!==n&&s.tryToSetAttribute(t,l,e),e=e.split(".");var r={a:e[0],b:e[1],c:e[2],d:e[3]};return e[4]&&(r.e=e[4]),r}function i(t,e){var n=r(t),o=[n.a,n.b,n.c,n.d];return e&&n.e&&o.push(n.e),o.join(".")}var s=n(28),u=n(19),c=n(105),l="data-spm-anchor-id";e.spm_resetModule=o,e.spm_spmAnchorChk=a,e.spm_getSPMParam=r,e.spm_forwap=i},function(t,e,n){"use strict";function o(t){for(var e,n="data-spm-ab-max-idx",o={},a="";t&&t.tagName!=j&&t.tagName!=x;){if(!a&&(a=v.tryToGetAttribute(t,"data-spm-ab"))){e=parseInt(v.tryToGetAttribute(t,n))||0,o.a_spm_ab=a,o.ab_idx=++e,t.setAttribute(n,e);break}if(v.tryToGetAttribute(t,"data-spm"))break;t=t.parentNode}return o}function a(){var t=b.getGoldlogVal("_$")||{},e=t.spm||{},n=e.data||{};return[n.a,n.b].join(".")}function r(t){var e=a(),n=t.split(".");return n[0]+"."+n[1]==e}function i(t,e){if(!goldlog.isUT4Aplus||"UT4Aplus"!==goldlog.getMetaInfo("aplus-toUT")){if(t&&/&?\bspm=[^&#]*/.test(t)&&(t=t.replace(/&?\bspm=[^&#]*/g,"").replace(/&{2,}/g,"&").replace(/\?&/,"?").replace(/\?$/,"")),!e)return t;var n,o,a,r,i,s,u,c="&";t.indexOf("#")!==-1&&(a=t.split("#"),t=a.shift(),o=a.join("#")),r=t.split("?"),i=r.length-1,a=r[0].split("//"),a=a[a.length-1].split("/"),s=a.length>1?a.pop():"",i>0&&(n=r.pop(),t=r.join("?")),n&&i>1&&n.indexOf("&")==-1&&n.indexOf("%")!==-1&&(c="%26");var l="";if(t=t+"?spm="+l+e+(n?c+n:"")+(o?"#"+o:""),u=h.isContain(s,".")?s.split(".").pop().toLowerCase():""){if({png:1,jpg:1,jpeg:1,gif:1,bmp:1,swf:1}.hasOwnProperty(u))return 0;!n&&i<=1&&(o||{htm:1,html:1,php:1,aspx:1,shtml:1,xhtml:1}.hasOwnProperty(u)||(t+="&file="+s))}return t}}function s(t,e){if(!goldlog.isUT4Aplus||"UT4Aplus"!==goldlog.getMetaInfo("aplus-toUT")){var n,o=t.innerHTML;o&&o.indexOf("<")==-1&&(n=document.createElement("b"),n.style.display="none",t.appendChild(n)),t.href=e,n&&t.removeChild(n)}}function u(t,e,n){if(!/^0\.0\.?/.test(e)){var o=y.tryToGetHref(t),r=a(),u=w.is_ignore_spm(t);if(u){var c=_.param2obj(o);if(c.spm&&c.spm.split)for(var l=c.spm.split("."),p=e.split("."),g=0;g<3&&p[g]===l[g];g++)2===g&&l[3]&&(e=c.spm)}t.setAttribute("data-spm-anchor-id",e);var f=goldlog.getPvId();f&&(e+="."+f);var d="0.0";(f||r&&r!=d)&&(u||n||(o=i(o,e))&&s(t,o))}}function c(t){var e=v.tryToGetAttribute(t,P),n=m.parseSemicolonContent(e)||{};return n}function l(t){var e,n=b.getGoldlogVal("_$")||{},o=n.spm.data;return"0"==o.a&&"0"==o.b?e="0":(e=v.tryToGetAttribute(t,T),e&&e.match(/^d\w+$/)||(e="")),e}function p(t,e){for(var n=[],o=m.nodeListToArray(t.getElementsByTagName("a")),a=m.nodeListToArray(t.getElementsByTagName("area")),r=o.concat(a),i=0;i<r.length;i++){for(var s=!1,u=r[i],c=r[i];(u=u.parentNode)&&u!=t;)if(v.tryToGetAttribute(u,T)){s=!0;break}if(!s){var l=v.tryToGetAttribute(c,A);e||"t"===l?e&&"t"===l&&n.push(c):n.push(c)}}return n}function g(t){for(var e,n=t;t&&t.tagName!==j&&t.tagName!==x&&t.getAttribute;){var o=t.getAttribute(T);if(o){e=o,n=t;break}if(!(t=t.parentNode))break}return e&&!/^[\w\-\.\/]+$/.test(e)&&(e="0"),{spm_c:e,el:n}}function f(t,e){var n=parent!==self;if(!n&&e)return[t,e].join(".");if(t&&e)return t+".i"+e;var o=window.g_SPM||(window.g_SPM={}),a=o.spm_d_for_ad||{};return"number"==typeof a[t]?a[t]++:a[t]=0,o.spm_d_for_ad=a,t+".i"+a[t]}function d(t){var e;return t&&(e=t.match(/&?\bspm=([^&#]*)/))?e[1]:""}var _=n(18),h=n(9),m=n(19),v=n(28),b=n(26),y=n(106),w=n(107),x="BODY",j="HTML",T="data-spm",P="data-spm-click",A="data-auto-spmd",S="data-spm-anchor-id";e.getGlobalSPMId=a,e.spm_isSPMAnchorIdMatch=r,e.spm_updateHrefWithSPMId=i,e.spm_writeHref=s,e.spm_anchorEnsureSPMId_inHref=u,e.getElDataSpm=c,e.spm_getAnchor4thId_spm_d=l,e.spm_getModuleLinks=p,e.spm_spmGetParentSPMId=g,e.get_spm_for_ad=f,e.spm_getParamForAD=function(t){var e=v.tryToGetAttribute(t,S);if(!e){var n=a(),o=t.parentNode;if(!o)return"";var r=c(t)||{},i=r.locaid||"",s=t.getAttribute(T)||i,u=g(o),l=u.spm_c||0;l&&l.indexOf(".")!==-1&&(l=l.split("."),l=l[l.length-1]),e=f(n+"."+l,s)}return e},e.spm_initSPMModule=function(t,e,n,i){var s;if(e=e||t.getAttribute("data-spm")||""){var g=p(t,i);if(0!==g.length){var f=e.split("."),d=h.isStartWith(e,"110")&&3==f.length;d&&(s=f[2],f[2]="w"+(s||"0"),e=f.join("."));var _=a();if(_&&_.match(/^[\w\-\*]+(\.[\w\-\*\/]+)?$/))if(h.isContain(e,".")){if(!h.isStartWith(e,_)){var m=_.split(".");f=e.split(".");for(var b=0;b<m.length;b++)f[b]=m[b];e=f.join(".")}}else h.isContain(_,".")||(_+=".0"),e=_+"."+e;if(e.match&&e.match(/^[\w\-\*]+\.[\w\-\*\/]+\.[\w\-\*\/]+$/)){for(var w="data-auto-spmd-max-idx",x="data-spm-max-idx",j=i?w:x,T=parseInt(v.tryToGetAttribute(t,j))||0,A=0;A<g.length;A++){var k=g[A],E=y.tryToGetHref(k),U=v.tryToGetAttribute(k,P);if(i||E||U){d&&k.setAttribute("data-spm-wangpu-module-id",s);var I=k.getAttribute(S);if(I&&r(I))u(k,I,n);else{var M,C,N=o(k.parentNode);N.a_spm_ab?(C=N.a_spm_ab,M=N.ab_idx):(C=void 0,T++,M=T);var O,V=c(k)||{},G=V.locaid||"";G?O=G:(O=l(k)||M,i&&(O="at"+((h.isNumber(O)?1e3:"")+O))),I=C?e+"-"+C+"."+O:e+"."+O,u(k,I,n)}}}t.setAttribute(j,T)}}}},e.spm_dealNoneSPMLink=function(t,e){var n=goldlog.getMetaInfo("aplus-getspmcd"),o=a(),r=y.tryToGetHref(t),i=d(r),c=null,p=o&&2==o.split(".").length;if(p){var g;return"function"==typeof n&&(g=n(t,null,o)),c=g&&"0"!==g.spm_c?[o,g.spm_c,g.spm_d]:[o,0,l(t)||0],void u(t,c.join("."),e)}r&&i&&(r=r.replace(/&?\bspm=[^&#]*/g,"").replace(/&{2,}/g,"&").replace(/\?&/,"?").replace(/\?$/,"").replace(/\?#/,"#"),s(t,r))}},function(t,e,n){"use strict";var o=n(20);e.tryToGetHref=function(t){var e;try{e=o.trim(t.getAttribute("href",2))}catch(t){}return e||""}},function(t,e,n){"use strict";function o(t){return!!t&&!!t.match(/^[^\?]*\balipay\.(?:com|net)\b/i)}function a(t){return!!t&&!!t.match(/^[^\?]*\balipay\.(?:com|net)\/.*\?.*\bsign=.*/i)}function r(t){var e=location.href;return t&&e.split("#")[0]===t.split("#")[0]}function i(t){for(var e;(t=t.parentNode)&&"BODY"!==t.tagName;)if(e=u.tryToGetAttribute(t,f))return e;return""}function s(t){for(var e=["mclick.simba.taobao.com","click.simba.taobao.com","click.tanx.com","click.mz.simba.taobao.com","click.tz.simba.taobao.com","redirect.simba.taobao.com","rdstat.tanx.com","stat.simba.taobao.com","s.click.taobao.com"],n=0;n<e.length;n++)if(t.indexOf(e[n])!==-1)return!0;return!1}var u=n(28),c=n(9),l=n(106),p=n(26),g=n(22),f="data-spm-protocol";e.is_ignore_spm=function(t){var e=p.getGoldlogVal("_$")||{},n=e.meta_info||{},d=l.tryToGetHref(t),_=i(t),h=u.tryToGetAttribute(t,f),m="i"===(h||_||n.spm_protocol);if(!d||s(d))return!0;var v=r(d)||g.isStartWithProtocol(d.toLowerCase()),b=o(d)||a(d),y=v||b;return!(m||!c.isStartWith(d,"#")&&!y)||m}},function(t,e,n){"use strict";function o(t,e,n){var o=u.parseSemicolonContent(e,{},!0),a=o.gostr||"",r=o.locaid||"",g=t.getAttribute("data-spm")||r,f="CLK",d=o.gokey||"",_=p.spm_getSPMParam(t),h=[_.a,_.b,_.c,g].join("."),m=a+"."+h;0!==m.indexOf("/")&&(m="/"+m);var v=[],b=["gostr","locaid","gmkey","gokey","spm-cnt","cna"];for(var y in o)o.hasOwnProperty(y)&&c.indexof(b,y)===-1&&v.push(y+"="+o[y]);v.push("_g_et="+n),v.push("autosend=1"),d&&v.length>0&&(d+="&"),d+=v.length>0?v.join("&"):"",goldlog&&s.isFunction(goldlog.recordUdata)?goldlog.recordUdata(m,f,d,"GET",function(){}):l.logger({msg:"goldlog.recordUdata is not function!"}),i.tryToSetAttribute(t,"data-spm-anchor-id",h)}function a(t,e){var n=e;window.g_SPM&&(g_SPM._current_spm=p.spm_getSPMParam(e));for(var a;e&&"HTML"!==e.tagName;){a=i.tryToGetAttribute(e,"data-spm-click");{if(a){o(e,a,"mousedown"===t.type?t.type:"tap");break}e=e.parentNode}}if(!a){var r=g.getGlobalSPMId(),s=goldlog.getMetaInfo("aplus-getspmcd");"function"==typeof s&&s(n,t,r)}}var r=n(79),i=n(28),s=n(9),u=n(19),c=n(12),l=n(24),p=n(104),g=n(105);e.run=function(t){t&&t.isTouchEnabled?r.on(document,"tap",a):r.on(document,"mousedown",a)}},function(t,e,n){"use strict";function o(){for(var t=document.getElementsByTagName("iframe"),e=0;e<t.length;e++){var n=t[e],o=r.tryToGetAttribute(n,"data-spm-src");if(!n.src&&o){var a=s.spm_getSPMParam(n);if(a){var u=[a.a,a.b,a.c,a.d];a.e&&u.push(a.e),a=u.join("."),n.src=i.spm_updateHrefWithSPMId(o,a)}else n.src=o}}}function a(){function t(){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}var e=0,n=500;t()}var r=n(28),i=n(105),s=n(104);e.run=function(t){t&&!t.isTerminal&&a()}},function(t,e,n){"use strict";function o(t,e){for(var n,o=window;e&&(n=e.tagName);){if("A"===n||"AREA"===n){r.spm_spmAnchorChk(e,!1);var a=o.g_SPM||(o.g_SPM={}),i=a._current_spm=r.spm_getSPMParam(e),s=[];try{s=[i.a,i.b,i.c,i.d];var u=i.e||goldlog.pvid||"";u&&s.push(u)}catch(t){}break}if("BODY"==n||"HTML"==n)break;e=e.parentNode}}var a=n(79),r=n(104);e.run=function(t){var e=document;t&&t.isTouchEnabled?a.on(e,"tapSpm",o):(a.on(e,"mousedown",o),a.on(e,"keydown",o))}},function(t,e,n){"use strict";function o(t,e){if(e||(e=p),p.evaluate)return e.evaluate(t,p,null,9,null).singleNodeValue;for(var n,a=t.split("/");!n&&a.length>0;)n=a.shift();var r,i=/^.+?\[@id='(.+?)']$/i,s=/^(.+?)\[(\d+)]$/i;return(r=n.match(i))?e=e.getElementById(r[1]):(r=n.match(s))&&(e=e.getElementsByTagName(r[1])[parseInt(r[2])-1]),e?0===a.length?e:o(a.join("/"),e):null}function a(){var t={};for(var e in l)if(l.hasOwnProperty(e)){var n=o(e);if(n){t[e]=1;var a=l[e],r="A"===n.tagName?a.spmd:a.spmc;s.tryToSetAttribute(n,"data-spm",r||"")}}for(var i in t)t.hasOwnProperty(i)&&delete l[i]}function r(){if(!c&&g.spmData){c=!0;var t=g.spmData.data;if(t&&i.isArray(t)){for(var e=0;e<t.length;e++){var n=t[e],o=n.xpath;o=o.replace(/^id\('(.+?)'\)(.*)/g,"//*[@id='$1']$2"),l[o]={spmc:n.spmc,spmd:n.spmd}}a()}}}var i=n(9),s=n(28),u=n(79),c=!1,l={},p=document,g=window;e.wh_updateXPathElements=a,
e.init_wh=r,e.run=function(){u.DOMReady(function(){r()})}},function(t,e,n){"use strict";function o(){var t,e=p.getParamFromUrl("utparamcnt",location.href);if(e)try{t=e=JSON.parse(decodeURIComponent(e))}catch(t){}return t}function a(){var t,e=d["aplus-utparam"];if(e)if("object"==typeof e)t=e;else try{t=JSON.parse(e)}catch(t){}return t}var r=n(11),i=n(51),s=n(52),u=n(33),c=n(55),l=n(9),p=n(50),g=n(4),f=n(27),d=f.getInfo(),_="complete";e.initGoldlog=function(t){var e=window.goldlog||(window.goldlog={}),n=g.goldlog_path.run.create();e._ready_time=(new Date).getTime();for(var p in n)e[p]=n[p];var f=/TB\-PD/i.test(navigator.userAgent),h=e._$=e._$||{},m=o(),v=a();return"object"==typeof m&&(v&&(m=l.assign(m,v)),d["aplus-utparam"]=m),h.meta_info=d,h.is_terminal="aplus_wap"===g.script_name||f||"1"==d["aplus-terminal"],h.send_pv_count=0,h.status=_,h.script_name=g.script_name,h.spm={data:{}},h.page_referrer=i.getRefer(),h.pageLoadTime=(new Date).getTime(),e.lver=g.lver,e.nameStorage=s.nameStorage,c.haveNativeFlagInUA(),u.doPubMsg(["goldlogReady",_]),u.doCachePubs(["goldlogReady",_]),u.publishCNA(r.getCookie("cna")),t.init(),e}}]);/*! 2024-09-10 16:39:25 v8.15.24 */
!function(t){function e(n){if(r[n])return r[n].exports;var a=r[n]={exports:{},id:n,loaded:!1};return t[n].call(a.exports,a,a.exports,e),a.loaded=!0,a.exports}var r={};return e.m=t,e.c=r,e.p="",e(0)}([function(t,e){"use strict";!function(){function t(t,e,r){t[_]((h?"on":"")+e,function(t){t=t||s.event;var e=t.target||t.srcElement;r(t,e)},!1)}function e(){return/&?\bspm=[^&#]*/.test(location.href)?location.href.match(/&?\bspm=[^&#]*/gi)[0].split("=")[1]:""}function r(t,e){if(t&&/&?\bspm=[^&#]*/.test(t)&&(t=t.replace(/&?\bspm=[^&#]*/g,"").replace(/&{2,}/g,"&").replace(/\?&/,"?").replace(/\?$/,"")),!e)return t;var r,n,a,i,o,c,p,s="&";if(t.indexOf("#")!=-1&&(a=t.split("#"),t=a.shift(),n=a.join("#")),i=t.split("?"),o=i.length-1,a=i[0].split("//"),a=a[a.length-1].split("/"),c=a.length>1?a.pop():"",o>0&&(r=i.pop(),t=i.join("?")),r&&o>1&&r.indexOf("&")==-1&&r.indexOf("%")!=-1&&(s="%26"),t=t+"?spm="+e+(r?s+r:"")+(n?"#"+n:""),p=c.indexOf(".")>-1?c.split(".").pop().toLowerCase():""){if({png:1,jpg:1,jpeg:1,gif:1,bmp:1,swf:1}.hasOwnProperty(p))return 0;!r&&o<=1&&(n||{htm:1,html:1,php:1}.hasOwnProperty(p)||(t+="&file="+c))}return t}function n(t){function e(t){return t=t.replace(/refpos[=(%3D)]\w*/gi,c).replace(i,"%3D"+n+"%26"+a.replace("=","%3D")).replace(o,n),a.length>0&&(t+="&"+a),t}var r=window.location.href,n=r.match(/mm_\d{0,24}_\d{0,24}_\d{0,24}/i),a=r.match(/[&\?](pvid=[^&]*)/i),i=new RegExp("%3Dmm_\\d+_\\d+_\\d+","ig"),o=new RegExp("mm_\\d+_\\d+_\\d+","ig");a=a&&a[1]?a[1]:"";var c=r.match(/(refpos=(\d{0,24}_\d{0,24}_\d{0,24})?(,[a-z]+)?)(,[a-z]+)?/i);return c=c&&c[0]?c[0]:"",n?(n=n[0],e(t)):t}function a(e){var r=s.KISSY;r?r.ready(e):s.jQuery?jQuery(m).ready(e):"complete"===m.readyState?e():t(s,"load",e)}function i(t,e){return t&&t.getAttribute?t.getAttribute(e)||"":""}function o(t){if(t){var e,r=g.length;for(e=0;e<r;e++)if(t.indexOf(g[e])>-1)return!0;return!1}}function c(t,e){if(t&&/&?\bspm=[^&#]*/.test(t)&&(t=t.replace(/&?\bspm=[^&#]*/g,"").replace(/&{2,}/g,"&").replace(/\?&/,"?").replace(/\?$/,"")),!e)return t;var r,n,a,i,o,c,p,s="&";if(t.indexOf("#")!=-1&&(a=t.split("#"),t=a.shift(),n=a.join("#")),i=t.split("?"),o=i.length-1,a=i[0].split("//"),a=a[a.length-1].split("/"),c=a.length>1?a.pop():"",o>0&&(r=i.pop(),t=i.join("?")),r&&o>1&&r.indexOf("&")==-1&&r.indexOf("%")!=-1&&(s="%26"),t=t+"?spm="+e+(r?s+r:"")+(n?"#"+n:""),p=c.indexOf(".")>-1?c.split(".").pop().toLowerCase():""){if({png:1,jpg:1,jpeg:1,gif:1,bmp:1,swf:1}.hasOwnProperty(p))return 0;!r&&o<=1&&(n||{htm:1,html:1,shtml:1,php:1}.hasOwnProperty(p)||(t+="&__file="+c))}return t}function p(t){if(o(t.href)){var r=i(t,u);if(!r){var n=l()(t),a=[n.a,n.b,n.c,n.d].join(".");n.e&&(n+="."+n.e),d&&(a=[n.a||"0",n.b||"0",n.c||"0",n.d||"0"].join("."),a=(e()||"0.0.0.0.0")+"_"+a),t.href=c(t.href,a),t.setAttribute(u,a)}}}var s=window,m=document;if(1!==s.aplus_spmact){s.aplus_spmact=1;var f=function(){return{a:0,b:0,c:0,d:0,e:0}},l=function(){return s.g_SPM&&s.g_SPM.getParam?s.g_SPM.getParam:f},d=!0;try{d=self.location!=top.location}catch(t){}var u="data-spm-act-id",g=["mclick.simba.taobao.com","click.simba.taobao.com","click.tanx.com","click.mz.simba.taobao.com","click.tz.simba.taobao.com","redirect.simba.taobao.com","rdstat.tanx.com","stat.simba.taobao.com","s.click.taobao.com"],h=!!m.attachEvent,b="attachEvent",v="addEventListener",_=h?b:v;t(m,"mousedown",function(t,e){for(var r,n=0;e&&(r=e.tagName);){if("A"==r||"AREA"==r){p(e);break}if("BODY"==r||"HTML"==r)break;e=e.parentNode,n+=1}}),a(function(){for(var t,a,o=document.getElementsByTagName("iframe"),c=0;c<o.length;c++){t=i(o[c],"mmsrc"),a=i(o[c],"mmworked");var p=l()(o[c]),s=[p.a||"0",p.b||"0",p.c||"0",p.d||"0",p.e||"0"].join(".");t&&!a?(d&&(s=[p.a||"0",p.b||"0",p.c||"0",p.d||"0"].join("."),s=e()+"_"+s),o[c].src=r(n(t),s),o[c].setAttribute("mmworked","mmworked")):o[c].setAttribute(u,s)}})}}()}]);</script><script async="" src="https://g.lazcdn.com/g/??/sd/baxia/2.5.20/baxiaCommon.js" crossorigin="true"></script><script async="" src="https://g.alicdn.com/secdev/sufei_data/3.9.14/index.js" crossorigin="true"></script><script async="" src="https://g.lazcdn.com/g/??/sd/baxia/2.5.20/baxiaCommon.js" crossorigin="true"></script><script async="" src="https://g.alicdn.com/secdev/sufei_data/3.9.14/index.js" crossorigin="true"></script><script crossorigin="" referrerpolicy="unsafe-url" src="https://g.lazcdn.com/g/lzd_sec/epssw/0.0.24/epssw.js"></script><script async="" src="//g.lazcdn.com/g/lzd-cs/chat/2.5.0/alichat.js" desktopjs="true"></script><script src="https://g.alicdn.com/AWSC/et/1.81.8/et_f.js" id="AWSC_etModule"></script><script async="" src="//g.alicdn.com/sd/baxia/2.5.20/baxiaCommon.js" crossorigin="true"></script><script async="" src="https://g.alicdn.com/AWSC/AWSC/awsc.js" crossorigin="true"></script><script async="" src="https://g.alicdn.com/secdev/sufei_data/3.9.14/index.js" crossorigin="true"></script><script async="" src="https://g.alicdn.com/secdev/sufei_data/3.9.14/index.js" crossorigin="true"></script><script type="text/javascript" async="" src="https://g.alicdn.com/sd/baxia-entry/index.js" id="aplus-baxia"></script><script type="text/javascript" async="" src="//g.lazcdn.com/g/lzdmod/im/5.0.103/index.js"></script><script src="https://g.lazcdn.com/g/AWSC/fireyejs/1.228.23/fireyejs.js" id="AWSC_fyModule"></script><script type="text/javascript" charset="UTF-8" src="https://fourier.taobao.com/rp?ext=51&amp;data=jm_null&amp;random=5259128953330219&amp;href=https%3A%2F%2Fsimleg.depok.go.id%2Fapi%2Faspirasi%2Fpublic%2Ftext%2F&amp;protocol=https:&amp;callback=jsonpCallback"></script><script async="" src="https://g.lazcdn.com/g/??/sd/baxia/2.5.20/baxiaCommon.js" crossorigin="true"></script><script async="" src="https://g.alicdn.com/secdev/sufei_data/3.9.14/index.js" crossorigin="true"></script><script src="https://g.lazcdn.com/g/AWSC/et/1.81.8/et_f.js" id="AWSC_etModule"></script><script>/*! 2024-09-10 16:39:26 v8.15.24 */
!function(e){function i(n){if(o[n])return o[n].exports;var r=o[n]={exports:{},id:n,loaded:!1};return e[n].call(r.exports,r,r.exports,i),r.loaded=!0,r.exports}var o={};return i.m=e,i.c=o,i.p="",i(0)}([function(e,i){"use strict";var o=window,n=document;!function(){var e=2,r="ali_analytics";if(o[r]&&o[r].ua&&e<=o[r].ua.version)return void(i.info=o[r].ua);var t,a,d,s,c,u,h,l,m,b,f,v,p,w,g,x,z,O=o.navigator,k=O.appVersion,T=O&&O.userAgent||"",y=function(e){var i=0;return parseFloat(e.replace(/\./g,function(){return 0===i++?".":""}))},_=function(e,i){var o,n;i[o="trident"]=.1,(n=e.match(/Trident\/([\d.]*)/))&&n[1]&&(i[o]=y(n[1])),i.core=o},N=function(e){var i,o;return(i=e.match(/MSIE ([^;]*)|Trident.*; rv(?:\s|:)?([0-9.]+)/))&&(o=i[1]||i[2])?y(o):0},P=function(e){return e||"other"},M=function(e){function i(){for(var i=[["Windows NT 5.1","winXP"],["Windows NT 6.1","win7"],["Windows NT 6.0","winVista"],["Windows NT 6.2","win8"],["Windows NT 10.0","win10"],["iPad","ios"],["iPhone;","ios"],["iPod","ios"],["Macintosh","mac"],["Android","android"],["Ubuntu","ubuntu"],["Linux","linux"],["Windows NT 5.2","win2003"],["Windows NT 5.0","win2000"],["Windows","winOther"],["rhino","rhino"]],o=0,n=i.length;o<n;++o)if(e.indexOf(i[o][0])!==-1)return i[o][1];return"other"}function r(e,i,n,r){var t,a=o.navigator.mimeTypes;try{for(t in a)if(a.hasOwnProperty(t)&&a[t][e]==i){if(void 0!==n&&r.test(a[t][n]))return!0;if(void 0===n)return!0}return!1}catch(e){return!1}}var t,a,d,s,c,u,h,l="",m=l,b=l,f=[6,9],v="{{version}}",p="<!--[if IE "+v+"]><s></s><![endif]-->",w=n&&n.createElement("div"),g=[],x={webkit:void 0,edge:void 0,trident:void 0,gecko:void 0,presto:void 0,chrome:void 0,safari:void 0,firefox:void 0,ie:void 0,ieMode:void 0,opera:void 0,mobile:void 0,core:void 0,shell:void 0,phantomjs:void 0,os:void 0,ipad:void 0,iphone:void 0,ipod:void 0,ios:void 0,android:void 0,nodejs:void 0,extraName:void 0,extraVersion:void 0};if(w&&w.getElementsByTagName&&(w.innerHTML=p.replace(v,""),g=w.getElementsByTagName("s")),g.length>0){for(_(e,x),s=f[0],c=f[1];s<=c;s++)if(w.innerHTML=p.replace(v,s),g.length>0){x[b="ie"]=s;break}!x.ie&&(d=N(e))&&(x[b="ie"]=d)}else((a=e.match(/AppleWebKit\/*\s*([\d.]*)/i))||(a=e.match(/Safari\/([\d.]*)/)))&&a[1]?(x[m="webkit"]=y(a[1]),(a=e.match(/OPR\/(\d+\.\d+)/))&&a[1]?x[b="opera"]=y(a[1]):(a=e.match(/Chrome\/([\d.]*)/))&&a[1]?x[b="chrome"]=y(a[1]):(a=e.match(/\/([\d.]*) Safari/))&&a[1]?x[b="safari"]=y(a[1]):x.safari=x.webkit,(a=e.match(/Edge\/([\d.]*)/))&&a[1]&&(m=b="edge",x[m]=y(a[1])),/ Mobile\//.test(e)&&e.match(/iPad|iPod|iPhone/)?(x.mobile="apple",a=e.match(/OS ([^\s]*)/),a&&a[1]&&(x.ios=y(a[1].replace("_","."))),t="ios",a=e.match(/iPad|iPod|iPhone/),a&&a[0]&&(x[a[0].toLowerCase()]=x.ios)):/ Android/i.test(e)?(/Mobile/.test(e)&&(t=x.mobile="android"),a=e.match(/Android ([^\s]*);/),a&&a[1]&&(x.android=y(a[1]))):(a=e.match(/NokiaN[^\/]*|Android \d\.\d|webOS\/\d\.\d/))&&(x.mobile=a[0].toLowerCase()),(a=e.match(/PhantomJS\/([^\s]*)/))&&a[1]&&(x.phantomjs=y(a[1]))):(a=e.match(/Presto\/([\d.]*)/))&&a[1]?(x[m="presto"]=y(a[1]),(a=e.match(/Opera\/([\d.]*)/))&&a[1]&&(x[b="opera"]=y(a[1]),(a=e.match(/Opera\/.* Version\/([\d.]*)/))&&a[1]&&(x[b]=y(a[1])),(a=e.match(/Opera Mini[^;]*/))&&a?x.mobile=a[0].toLowerCase():(a=e.match(/Opera Mobi[^;]*/))&&a&&(x.mobile=a[0]))):(d=N(e))?(x[b="ie"]=d,_(e,x)):(a=e.match(/Gecko/))&&(x[m="gecko"]=.1,(a=e.match(/rv:([\d.]*)/))&&a[1]&&(x[m]=y(a[1]),/Mobile|Tablet/.test(e)&&(x.mobile="firefox")),(a=e.match(/Firefox\/([\d.]*)/))&&a[1]&&(x[b="firefox"]=y(a[1])));t||(t=i());var z,O,T;if(!r("type","application/vnd.chromium.remoting-viewer")){z="scoped"in n.createElement("style"),T="v8Locale"in o;try{O=o.external||void 0}catch(e){}if(a=e.match(/360SE/))u="360";else if((a=e.match(/SE\s([\d.]*)/))||O&&"SEVersion"in O)u="sougou",h=y(a[1])||.1;else if((a=e.match(/Maxthon(?:\/)+([\d.]*)/))&&O){u="maxthon";try{h=y(O.max_version||a[1])}catch(e){h=.1}}else z&&T?u="360se":z||T||!/Gecko\)\s+Chrome/.test(k)||x.opera||x.edge||(u="360ee")}(a=e.match(/TencentTraveler\s([\d.]*)|QQBrowser\/([\d.]*)/))?(u="tt",h=y(a[2])||.1):(a=e.match(/LBBROWSER/))||O&&"LiebaoGetVersion"in O?u="liebao":(a=e.match(/TheWorld/))?(u="theworld",h=3):(a=e.match(/TaoBrowser\/([\d.]*)/))?(u="taobao",h=y(a[1])||.1):(a=e.match(/UCBrowser\/([\d.]*)/))&&(u="uc",h=y(a[1])||.1),x.os=t,x.core=x.core||m,x.shell=b,x.ieMode=x.ie&&n.documentMode||x.ie,x.extraName=u,x.extraVersion=h;var P=o.screen.width,M=o.screen.height;return x.resolution=P+"x"+M,x},S=function(e){function i(e){return Object.prototype.toString.call(e)}function o(e,o,n){if("[object Function]"==i(o)&&(o=o(n)),!o)return null;var r={name:e,version:""},t=i(o);if(o===!0)return r;if("[object String]"===t){if(n.indexOf(o)!==-1)return r}else if(o.exec){var a=o.exec(n);if(a)return a.length>=2&&a[1]?r.version=a[1].replace(/_/g,"."):r.version="",r}}var n={name:"other",version:""};e=(e||"").toLowerCase();for(var r=[["nokia",function(e){return e.indexOf("nokia ")!==-1?/\bnokia ([0-9]+)?/:/\bnokia([a-z0-9]+)?/}],["samsung",function(e){return e.indexOf("samsung")!==-1?/\bsamsung(?:[ \-](?:sgh|gt|sm))?-([a-z0-9]+)/:/\b(?:sgh|sch|gt|sm)-([a-z0-9]+)/}],["wp",function(e){return e.indexOf("windows phone ")!==-1||e.indexOf("xblwp")!==-1||e.indexOf("zunewp")!==-1||e.indexOf("windows ce")!==-1}],["pc","windows"],["ipad","ipad"],["ipod","ipod"],["iphone",/\biphone\b|\biph(\d)/],["mac","macintosh"],["mi",/\bmi[ \-]?([a-z0-9 ]+(?= build|\)))/],["hongmi",/\bhm[ \-]?([a-z0-9]+)/],["aliyun",/\baliyunos\b(?:[\-](\d+))?/],["meizu",function(e){return e.indexOf("meizu")>=0?/\bmeizu[\/ ]([a-z0-9]+)\b/:/\bm([0-9x]{1,3})\b/}],["nexus",/\bnexus ([0-9s.]+)/],["huawei",function(e){var i=/\bmediapad (.+?)(?= build\/huaweimediapad\b)/;return e.indexOf("huawei-huawei")!==-1?/\bhuawei\-huawei\-([a-z0-9\-]+)/:i.test(e)?i:/\bhuawei[ _\-]?([a-z0-9]+)/}],["lenovo",function(e){return e.indexOf("lenovo-lenovo")!==-1?/\blenovo\-lenovo[ \-]([a-z0-9]+)/:/\blenovo[ \-]?([a-z0-9]+)/}],["zte",function(e){return/\bzte\-[tu]/.test(e)?/\bzte-[tu][ _\-]?([a-su-z0-9\+]+)/:/\bzte[ _\-]?([a-su-z0-9\+]+)/}],["vivo",/\bvivo(?: ([a-z0-9]+))?/],["htc",function(e){return/\bhtc[a-z0-9 _\-]+(?= build\b)/.test(e)?/\bhtc[ _\-]?([a-z0-9 ]+(?= build))/:/\bhtc[ _\-]?([a-z0-9 ]+)/}],["oppo",/\boppo[_]([a-z0-9]+)/],["konka",/\bkonka[_\-]([a-z0-9]+)/],["sonyericsson",/\bmt([a-z0-9]+)/],["coolpad",/\bcoolpad[_ ]?([a-z0-9]+)/],["lg",/\blg[\-]([a-z0-9]+)/],["android",/\bandroid\b|\badr\b/],["blackberry",function(e){return e.indexOf("blackberry")>=0?/\bblackberry\s?(\d+)/:"bb10"}]],t=0;t<r.length;t++){var a=r[t][0],d=r[t][1],s=o(a,d,e);if(s){n=s;break}}return n},E=1;try{t=M(T),a=S(T),d=t.os,s=t.shell,c=t.core,u=t.resolution,h=t.extraName,l=t.extraVersion,m=a.name,b=a.version,v=d?d+(t[d]?t[d]:""):"",p=s?s+parseInt(t[s]):"",w=c,g=u,x=h?h+(l?parseInt(l):""):"",z=m+b}catch(e){}f={p:E,o:P(v),b:P(p),w:P(w),s:g,mx:x,ism:z},o[r]||(o[r]={}),o[r].ua||(o[r].ua={}),o.goldlog||(o.goldlog={}),i.info=o[r].ua=goldlog._aplus_client={version:e,ua_info:f}}()}]);/*! 2017-10-31 20:15:15 v0.2.4 */
!function(t){function e(o){if(n[o])return n[o].exports;var i=n[o]={exports:{},id:o,loaded:!1};return t[o].call(i.exports,i,i.exports,e),i.loaded=!0,i.exports}var n={};return e.m=t,e.c=n,e.p="",e(0)}([function(t,e,n){"use strict";!function(){var t=window.goldlog||(window.goldlog={});t._aplus_cplugin_utilkit||(t._aplus_cplugin_utilkit={status:"init"},n(1).init(t),t._aplus_cplugin_utilkit.status="complete")}()},function(t,e,n){"use strict";var o=n(2),i=n(4);e.init=function(t){t.setCookie=o.setCookie,t.getCookie=o.getCookie,t.on=i.on}},function(t,e,n){"use strict";var o=document,i=n(3),a=function(t){var e=new RegExp("(?:^|;)\\s*"+t+"=([^;]+)"),n=o.cookie.match(e);return n?n[1]:""};e.getCookie=a;var r=function(t,e,n){n||(n={});var i=new Date;return n.expires&&("number"==typeof n.expires||n.expires.toUTCString)?("number"==typeof n.expires?i.setTime(i.getTime()+24*n.expires*60*60*1e3):i=n.expires,e+="; expires="+i.toUTCString()):"session"!==n.expires&&(i.setTime(i.getTime()+63072e7),e+="; expires="+i.toUTCString()),e+="; path="+(n.path?n.path:"/"),e+="; domain="+n.domain,o.cookie=t+"="+e,a(t)};e.setCookie=function(t,e,n){try{if(n||(n={}),n.domain)r(t,e,n);else for(var o=i.getDomains(),a=0;a<o.length;)n.domain=o[a],r(t,e,n)?a=o.length:a++}catch(t){}}},function(t,e){"use strict";e.getDomains=function(){var t=[];try{for(var e=location.hostname,n=e.split("."),o=2;o<=n.length;)t.push(n.slice(n.length-o).join(".")),o++}catch(t){}return t}},function(t,e){"use strict";var n=window,o=document,i=!!o.attachEvent,a="attachEvent",r="addEventListener",c=i?a:r,u=function(t,e){var n=goldlog._$||{},o=n.meta_info||{},i=o.aplus_ctap||{};if(i&&"function"==typeof i.on)i.on(t,e);else{var a="ontouchend"in document.createElement("div"),r=a?"touchstart":"mousedown";s(t,r,e)}},s=function(t,e,o){return"tap"===e?void u(t,o):void t[c]((i?"on":"")+e,function(t){t=t||n.event;var e=t.target||t.srcElement;"function"==typeof o&&o(t,e)},!1)};e.on=s;var d=function(t){try{o.documentElement.doScroll("left")}catch(e){return void setTimeout(function(){d(t)},1)}t()},l=function(t){var e=0,n=function(){0===e&&t(),e++};"complete"===o.readyState&&n();var i;if(o.addEventListener)i=function(){o.removeEventListener("DOMContentLoaded",i,!1),n()},o.addEventListener("DOMContentLoaded",i,!1),window.addEventListener("load",n,!1);else if(o.attachEvent){i=function(){"complete"===o.readyState&&(o.detachEvent("onreadystatechange",i),n())},o.attachEvent("onreadystatechange",i),window.attachEvent("onload",n);var a=!1;try{a=null===window.frameElement}catch(t){}o.documentElement.doScroll&&a&&d(n)}};e.DOMReady=function(t){l(t)},e.onload=function(t){"complete"===o.readyState?t():s(n,"load",t)}}]);!function(o){function t(r){if(e[r])return e[r].exports;var a=e[r]={exports:{},id:r,loaded:!1};return o[r].call(a.exports,a,a.exports,t),a.loaded=!0,a.exports}var e={};return t.m=o,t.c=e,t.p="",t(0)}([function(o,t,e){"use strict";!function(){var o=window.goldlog||(window.goldlog={});o._aplus_cplugin_m||(o._aplus_cplugin_m=e(1).run())}()},function(o,t,e){"use strict";var r=e(2),a=e(3),n=e(4),s=navigator.sendBeacon?"post":"get";e(5).run(),t.run=function(){return{status:"complete",do_tracker_jserror:function(o){try{var t=new n({logkey:o?o.logkey:"",ratio:o&&"number"==typeof o.ratio&&o.ratio>0?o.ratio:r.jsErrorRecordRatio}),e=["Message: "+o.message,"Error object: "+o.error,"Url: "+location.href].join(" - "),c=goldlog.spm_ab||[],i=location.hostname+location.pathname;t.run({code:110,page:i,msg:"record_jserror_by"+s+"_"+o.message,spm_a:c[0],spm_b:c[1],c1:e,c2:o.filename,c3:location.protocol+"//"+i,c4:goldlog.pvid||"",c5:o.logid||""})}catch(o){a.logger({msg:o})}},do_tracker_lostpv:function(o){var t=!1;try{if(o&&o.page){var e=o.spm_ab?o.spm_ab.split("."):[],c="record_lostpv_by"+s+"_"+o.msg,i=new n({ratio:o.ratio||r.lostPvRecordRatio});i.run({code:102,page:o.page,msg:c,spm_a:e[0],spm_b:e[1],c1:o.duration,c2:o.page_url}),t=!0}}catch(o){a.logger({msg:o})}return t},do_tracker_obsolete_inter:function(o){var t=!1;try{if(o&&o.page){var e=o.spm_ab?o.spm_ab.split("."):[],c="record_obsolete interface be called by"+s,i=new n({ratio:o.ratio||r.obsoleteInterRecordRatio});i.run({code:109,page:o.page,msg:c,spm_a:e[0],spm_b:e[1],c1:o.interface_name,c2:o.interface_params},1),t=!0}}catch(o){a.logger({msg:o})}return t},do_tracker_browser_support:function(o){var t=!1;try{if(o&&o.page){var e=o.spm_ab?o.spm_ab.split("."):[],c=new n({ratio:o.ratio||r.browserSupportRatio}),i=goldlog._aplus_client||{},l=i.ua_info||{};c.run({code:111,page:o.page,msg:o.msg+"_by"+s,spm_a:e[0],spm_b:e[1],c1:[l.o,l.b,l.w].join("_"),c2:o.etag||"",c3:o.cna||""}),t=!0}}catch(o){a.logger({msg:o})}return t},do_tracker_common_analysis:function(o){var t=!1;try{if(o&&o.page){var e=o.spm_ab?o.spm_ab.split("."):[],c=new n({ratio:o.ratio||r.browserSupportRatio}),i=goldlog._aplus_client||{},l=i.ua_info||{};c.run({code:113,page:o.page,msg:o.msg+"_by"+s,spm_a:e[0],spm_b:e[1],c1:[l.o,l.b,l.w].join("_"),c2:o.init_time||"",c3:o.wspv_time||0,c4:o.load_time||0,c5:o.channel_type}),t=!0}}catch(o){a.logger({msg:o})}return t}}}},function(o,t){"use strict";t.lostPvRecordRatio="0.01",t.obsoleteInterRecordRatio="0.001",t.jsErrorRecordRatio="0.001",t.browserSupportRatio="0.001",t.goldlogQueueRatio="0.01"},function(o,t){"use strict";var e=function(o){var t=o.level||"warn";window.console&&window.console[t]&&window.console[t](o.msg)};t.logger=e,t.assign=function(o,t){if("function"!=typeof Object.assign){var e=function(o){if(null===o)throw new TypeError("Cannot convert undefined or null to object");for(var t=Object(o),e=1;e<arguments.length;e++){var r=arguments[e];if(null!==r)for(var a in r)Object.prototype.hasOwnProperty.call(r,a)&&(t[a]=r[a])}return t};return e(o,t)}return Object.assign({},o,t)},t.makeCacheNum=function(){return Math.floor(268435456*Math.random()).toString(16)},t.obj2param=function(o){var t,e,r=[];for(t in o)o.hasOwnProperty(t)&&(e=""+o[t],r.push(t+"="+encodeURIComponent(e)));return r.join("&")}},function(o,t,e){var r=e(3),a={ratio:1,logkey:"fsp.1.1",gmkey:"",chksum:"H46747615"},n=function(o){o&&"object"==typeof o||(o=a),this.opts=o,this.opts.ratio=o.ratio||a.ratio,this.opts.logkey=o.logkey||a.logkey,this.opts.gmkey=o.gmkey||a.gmkey,this.opts.chksum=o.chksum||a.chksum},s=n.prototype;s.getRandom=function(){return Math.floor(1e3*Math.random())+1},s.run=function(o,t){var e,a,n={pid:"aplus",code:101,msg:"异常内容"},s="";try{var c=window.goldlog||{},i=c._$||{},l=i.meta_info||{},g=parseFloat(l["aplus-tracker-rate"]);if(e=this.opts||{},"number"==typeof g&&g+""!="NaN"||(g=e.ratio),a=this.getRandom(),t||a<=1e3*g){s="//gm.mmstat.com/"+e.logkey,o.rel=i.script_name+"@"+c.lver,o.type=o.code,o.uid=encodeURIComponent(c.getCookie("cna")),o=r.assign(n,o);var u=r.obj2param(o);c.tracker=c.send(s,{cache:r.makeCacheNum(),gokey:u,logtype:"2"},"POST")}}catch(o){r.logger({msg:"tracker.run() exec error: "+o})}},o.exports=n},function(o,t,e){"use strict";var r=e(6),a=function(o){var t=window.goldlog||{},e=t._$=t._$||{},r=t.spm_ab?t.spm_ab.join("."):"0.0",a=e.send_pv_count||0;if(a<1&&navigator&&navigator.sendBeacon){var n=window.goldlog_queue||(window.goldlog_queue=[]),s=location.hostname+location.pathname;n.push({action:["goldlog","_aplus_cplugin_m","do_tracker_lostpv"].join("."),arguments:[{page:s,page_url:location.protocol+"//"+s,duration:o,spm_ab:r,msg:"dom_state="+document.readyState}]})}};t.run=function(){var o=new Date;r.on(window,"beforeunload",function(){var t=new Date,e=t.getTime()-o.getTime();a(e)})}},function(o,t){"use strict";var e=self,r=e.document,a=!!r.attachEvent,n="attachEvent",s="addEventListener",c=a?n:s;t.getIframeUrl=function(o){var t,e="//g.alicdn.com";return t=goldlog&&"function"==typeof goldlog.getCdnPath?goldlog.getCdnPath()||e:e,(o||"https")+":"+t+"/alilog/aplus_cplugin/@@APLUS_CPLUGIN_VER/ls.html?t=@@_VERSION_"},t.on=function(o,t,r){o[c]((a?"on":"")+t,function(o){o=o||e.event;var t=o.target||o.srcElement;"function"==typeof r&&r(o,t)},!1)},t.checkLs=function(){var o;try{window.localStorage&&(localStorage.setItem("test_log_cna","1"),"1"===localStorage.getItem("test_log_cna")&&(localStorage.removeItem("test_log_cna"),o=!0))}catch(t){o=!1}return o},t.tracker_iframe_status=function(o,t){var e=window.goldlog_queue||(window.goldlog_queue=[]),r=goldlog.spm_ab?goldlog.spm_ab.join("."):"",a="createIframe_"+t.status+"_id="+o;t.msg&&(a+="_"+t.msg),e.push({action:"goldlog._aplus_cplugin_m.do_tracker_browser_support",arguments:[{page:location.hostname+location.pathname,msg:a,browser_attr:navigator.userAgent,spm_ab:r,cna:t.duration||"",ratio:1}]})},t.tracker_ls_failed=function(){var o=window.goldlog_queue||(window.goldlog_queue=[]),t=goldlog.spm_ab?goldlog.spm_ab.join("."):"";o.push({action:"goldlog._aplus_cplugin_m.do_tracker_browser_support",arguments:[{page:location.hostname+location.pathname,msg:"donot support localStorage",browser_attr:navigator.userAgent,spm_ab:t}]})},t.processMsgData=function(o){var t={};try{var e="{}";e="TextEncoder"in window&&"object"==typeof o?new window.TextDecoder("utf-8").decode(o):o,t=JSON.parse(e)}catch(o){t={}}return t},t.do_pub_fn=function(o,t){var e=window.goldlog_queue||(window.goldlog_queue=[]);e.push({action:"goldlog.aplus_pubsub.publish",arguments:[o,t]}),e.push({action:"goldlog.aplus_pubsub.cachePubs",arguments:[o,t]})}}]);/*! 2024-09-10 16:39:24 v8.15.24 */
!function(e){function t(o){if(n[o])return n[o].exports;var r=n[o]={exports:{},id:o,loaded:!1};return e[o].call(r.exports,r,r.exports,t),r.loaded=!0,r.exports}var n={};return t.m=e,t.c=n,t.p="",t(0)}([function(e,t,n){"use strict";!function(){var e=window.goldlog||(window.goldlog={});if(!e._aplus_auto_exp){e._aplus_auto_exp={tags:{},status:"init",exp_times:0,elementSelectorSizeMap:{}};var t=n(1);t.init(function(){e._aplus_auto_exp.status="complete"})}}()},function(e,t,n){"use strict";var o,r=n(2),i=n(3),a=n(4);o=n(window.IntersectionObserver?19:22);var u=n(23),s=n(12);t.init=function(e){var t,n=window.goldlog||(window.goldlog={}),l=!1,c=!1,p=function(e){c||(c=e,l||(r.wrap(function(){t=s.getAutoExpConfig()||[],i.isDebugAplus()&&i.logger({msg:"aplus-auto-exp metaVaue init: "+JSON.stringify(t)});var e;t&&t.length>0&&(u.watch_data_change(),o.watch_exposure_change(t),e=a.create({isThrottleWatch:s.isThrottleWatchDom(),autoExpConfig:t}),e.init({type:"init"})),n.aplus_pubsub.subscribe("setMetaInfo",function(n,r,l){if("aplus-auto-exp"===n){i.isDebugAplus()&&i.logger({msg:"aplus-auto-exp metaVaue change: "+JSON.stringify(r)});var c=s.getAutoExpConfig(r);if(JSON.stringify(c)===JSON.stringify(t))return;if(t=c,u.clear(),l||(l={from:"setMetaInfo"}),o.clear(t,l),e&&e.clear(l),r&&t&&t.length>0){u.watch_data_change(),o.watch_exposure_change(t);var p={isThrottleWatch:s.isThrottleWatchDom(),autoExpConfig:t};e?e.reset(p,l):(e=a.create(p),e.init({type:"init"}))}}})},"do_init"),l=!0))};setTimeout(function(){l||i.logger({msg:"aplus_auto_exp_init failed! please check whether aplusJs is loaded correctly!"})},5e3);var g=n._$||{},f=window.g_SPM||{};"complete"===g.status&&f.spm&&p();var h=window.goldlog_queue||(window.goldlog_queue=[]);h.push({action:"goldlog.aplus_pubsub.subscribe",arguments:["aplusReady",function(e){"complete"===e&&p("aplusReady")}]}),"function"==typeof e&&e()}},function(e,t){"use strict";var n=function(e,t){var n=window.goldlog_queue||(window.goldlog_queue=[]);n.push({action:"goldlog._aplus_cplugin_track_deb.monitor",arguments:[{key:"APLUS_PLUGIN_DEBUG",title:"aplus_core",msg:["_error_:methodName="+t+",params="+JSON.stringify(e)],type:"updateMsg",description:t||"aplus_core"}]})},o=function(e,t,n){var o=window.goldlog_queue||(window.goldlog_queue=[]);o.push({action:["goldlog","_aplus_cplugin_m",t].join("."),arguments:[e,n]})};t.do_tracker_jserror=function(e,t){var r="do_tracker_jserror";o(e,r,t),n(e,r)},t.do_tracker_obsolete_inter=function(e,t){var r="do_tracker_obsolete_inter";o(e,r,t),n(e,r)},t.wrap=function(e){if("function"==typeof e)try{e()}catch(e){n({msg:e.message||e},"exception")}finally{}}},function(e,t){"use strict";var n=function(){var e=!1;return"boolean"==typeof goldlog.aplusDebug&&(e=goldlog.aplusDebug),e};t.isDebugAplus=n;var o=function(e){e||(e={});var t=e.level||"warn";window.console&&window.console[t]&&window.console[t](e.msg)};t.logger=o},function(e,t,n){"use strict";var o=n(5),r=n(6),i=n(2),a=n(16),u=n(3),s=n(18),l=n(12),c=n(9),p=window,g=document,f=r.throttle(function(){var e=arguments[0];"function"==typeof e&&e()},200),h=o.extend({eachElements:function(e,t){for(var n=t.logkey||"",o=0;o<e.length;o++){var i=e[o],a=i.getAttribute(l.DATA_APLUS_AE_KEY);if(!(a&&a.indexOf("_")>0)){isNaN(parseInt(a))&&(a=goldlog._aplus_auto_exp.elementSelectorSizeMap[t.elementSelector]++,i.setAttribute(l.DATA_APLUS_AE_KEY,a));var u=r.getElementHash(t,{ignore_attr:!1,index:a,ele:i}),c=u.hash_value,p=u.hash_key,g=s.checkIsRecord(i,c,l.DATA_APLUS_AE_KEY),f=r.checkIsInHashMap({logkey:n,hash_value:c,goldlogKey:"_aplus_auto_exp"});if(!g&&!f){var h={expConfig:t,hash_value:c,hash_key:p,element:i,status:0,elementSelector:t.elementSelector};r.updateExpHashMap(n,h,"ADD")}}}},handler_dom_change:function(e,t){try{for(var n=this.autoExpConfig||[],o=0;o<n.length;o++){var i=n[o],a=r.getElements(i,g);goldlog._aplus_auto_exp.elementSelectorSizeMap[i.elementSelector]||(goldlog._aplus_auto_exp.elementSelectorSizeMap[i.elementSelector]=1),this.eachElements(a,i)}goldlog.aplus_pubsub.publish("APLUS_AE_DOM_CHANGE",t||{})}catch(e){u.logger({msg:e&&e.message})}},init_watch_dom:function(){var e=this,t=goldlog._aplus_auto_exp||{};e._loop_observer=setTimeout(function(){"blur"!==t.current_win_status?(goldlog.aplusDebug&&u.logger({msg:"watch_dom LOOP_TIME is "+l.LOOP_TIME+"ms total: "+ ++t.watch_times}),e.handler_dom_change(null,{type:"polling"}),e.init_watch_dom()):t.watch_dom_running=!1},l.LOOP_TIME)},onFocusHandler:function(){var e=this,t=goldlog._aplus_auto_exp||{};t.current_win_status="focus",t.watch_dom_running||e.init_watch_dom()},onBlurHandler:function(){var e=goldlog._aplus_auto_exp||{};e.current_win_status="blur"},onVisibilityChange:function(){var e=this;"visible"===g.visibilityState?e.onFocusHandler():"hidden"===g.visibilityState&&e.onBlurHandler()},addAllListener:function(){var e=this,t=goldlog._aplus_auto_exp||{};t.watch_times=0,t.watch_dom_running=!0,e.init_watch_dom(),p.WindVane&&g.addEventListener&&(a.on(g,"WV.Event.APP.Active",e.onFocusHandler,!1),a.on(g,"WV.Event.APP.Background",e.onBlurHandler,!1)),"hidden"in g?a.on(p,"visibilitychange",e.onVisibilityChange):(a.on(p,"blur",e.onBlurHandler),a.on(p,"focus",e.onFocusHandler))},removeAllListener:function(){var e=this;p.WindVane&&g.removeEventListener&&(a.un(g,"WV.Event.APP.Active",e.onFocusHandler,!1),a.un(g,"WV.Event.APP.Background",e.onBlurHandler,!1)),"hidden"in g?a.un(p,"visibilitychange",e.onVisibilityChange):(a.un(p,"blur",e.onBlurHandler),a.un(p,"focus",e.onFocusHandler))},isIgnoreExpose:function(e,t){var n=goldlog.getMetaInfo("aplus-auto-exp-ignoreviews"),o=goldlog.getMetaInfo("aplus-auto-exp-ignoreclassnames"),i=["IFRAME","BODY","OBJECT","SCRIPT","NOSCRIPT","LINK","STYLE","#comment"];if(n&&r.isArray(n)&&n.length>0&&(i=n),t&&i.indexOf(t)>-1)return!0;var a=!1;if(o&&r.isArray(o)){var u=e&&e.getAttribute?e.getAttribute("class"):"",s=u?u.split(" "):[];c(o,function(e){if(e&&c(s,function(t){if(t.trim()===e.trim())return a=!0,"break"}),a)return"break"})}return a},init_observer:function(e,t){var n=this,o=["class","style"],a=function(e){return"characterData"===e.type?[e.target]:"attributes"===e.type&&o.indexOf(e.attributeName)>-1?[e.target]:"childList"!==e.type?[]:void 0},s=function(e,o){if(e&&e.length>0)for(var r=0;r<e.length;r++){var a=e[r]||{},u=a.nodeName,s=goldlog._aplus_auto_exp.tags||{};s[u]||(s[u]=0),s[u]++,goldlog._aplus_auto_exp.tags=s,n.isIgnoreExpose(a,u)||i.wrap(function(){var e=goldlog._aplus_auto_exp||{};++e.observer_times;var n=o.attributeName;t(a,{type:o.type+(n?"_"+n:"")})},"init_observer_init_elements")}};this._observer||(this._observer=new e(function(e){if(e&&e.length>0)for(var t=0;t<e.length;t++){var n=e[t]||{},o=r.nodelistToArray(n.addedNodes||[]);o=r.nodelistToArray(a(n),o),s(o,n)}}));var l={attributes:!0,childList:!0,characterData:!0,subtree:!0};this._observer.observe(g.body,l),r.IS_DEBUG&&u.logger({msg:"aplus_auto_exp init MutationObserver success!"})},init:function(e){var t=this,n=goldlog._aplus_auto_exp||{};e&&"reset"!==e.type&&!n.hash_value&&(n.hash_value={}),t.handler_dom_change(null,{type:"aplus_init"});var o=p.MutationObserver||p.WebKitMutationObserver||p.MozMutationObserver;o?(n.observer_times=0,t.init_observer(o,function(e,n){f(function(){t.handler_dom_change(e,n)})})):t.addAllListener()},clear:function(e){if(!e||"appendMetaInfo"!==e.from){var t=goldlog._aplus_auto_exp||{};t._acHashMap&&(t._acHashMap={}),t.hash_value&&(t.hash_value={}),goldlog._aplus_auto_exp=t,this._loop_observer&&(clearTimeout(this._loop_observer),this._loop_observer=null),this._observer?(this._observer.takeRecords(),this._observer.disconnect()):this.removeAllListener()}},clearDom:function(e,t){var n=this.autoExpConfig||[];if(t&&"appendMetaInfo"!==t.from)for(var o=0;o<n.length;o++)try{for(var r=n[o].elementSelector,i=g.querySelectorAll(r),a=0;a<i.length;a++)i[a].setAttribute(l.DATA_APLUS_AE_KEY,"")}catch(e){}this.autoExpConfig=e&&e.autoExpConfig?e.autoExpConfig:[]},reset:function(e,t){this.clearDom(e,t),this.init({type:"reset"})}});e.exports=h},function(e,t){"use strict";function n(){}n.prototype.extend=function(){},n.prototype.create=function(){},n.extend=function(e){return this.prototype.extend.call(this,e)},n.prototype.create=function(e){var t=new this;for(var n in e)t[n]=e[n];return t},n.prototype.extend=function(e){var t=function(){};try{"function"!=typeof Object.create&&(Object.create=function(e){function t(){}return t.prototype=e,new t}),t.prototype=Object.create(this.prototype);for(var n in e)t.prototype[n]=e[n];t.prototype.constructor=t,t.extend=t.prototype.extend,t.create=t.prototype.create}catch(e){console.log(e)}finally{return t}},e.exports=n},function(e,t,n){"use strict";function o(e,t,n){var o=t.hash_value,r=a.getGoldlogVal(n)||{};if(r.hash_value||(r.hash_value={}),r.hash_value[e]||(r.hash_value[e]=i.Map?new i.Map:{}),i.Map){var u=r.hash_value[e].get(o);u?++u:u=1,r.hash_value[e].set(o,u)}else r.hash_value[e][o]?++r.hash_value[e][o]:r.hash_value[e][o]=1;a.setGoldlogVal(n,r)}var r=document,i=window,a=n(7),u=n(3),s=n(8),l=n(9),c=n(10),p=n(11),g=n(12),f=function(e){return"[object Array]"===Object.prototype.toString.call(e)};t.isArray=f,t.getXPath=function(e){var t,n,o,i,a,u,s=r.getElementsByTagName("*");for(t=[];e&&1==e.nodeType;e=e.parentNode)if(e.id){for(u=e.id,i=0,n=0;n<s.length;n++)if(a=s[n],a.id&&a.id==u){i++;break}if(t.unshift(e.tagName.toLowerCase()+'[@id="'+u+'"]'),1==i)return t.unshift("/"),t.join("/")}else{for(n=1,o=e.previousSibling;o;o=o.previousSibling)o.tagName==e.tagName&&n++;t.unshift(e.tagName.toLowerCase()+"["+n+"]")}return t.length?"/"+t.join("/"):null};var h=function(e,t){if(t&&0!==t.length||(t=[]),e&&e.length>0)for(var n=0;n<e.length;n++)t.push(e[n]);return t};t.nodelistToArray=h,t.getElements=function(e,t){var n=t||r,o=[];if(n.querySelectorAll)o=h(n.querySelectorAll(e.elementSelector)||[]);else for(var i=document.getElementsByTagName(e.tag),a=e.filter.split("="),u=a.length>0?a[0].trim():"",s=a.length>1?a[1].trim():"",l=0;l<i.length;l++){var c=i[l],p=c.getAttribute(u),g=c.hasAttribute(u);!g||s&&s!==p||o.push(c)}return o};var d=function(){return/aplusDebug=true/.test(location.search)},v=d();t.IS_DEBUG=v,t.fillPropsData=function(e,t,n){n||(n={});try{var o=e.props||[];if(o&&f(o)&&o.length>0)for(var r=0;r<o.length;r++)if(t&&t.getAttribute){var i=o[r],a=t.getAttribute(i);void 0!==typeof a&&null!==a&&""!==a&&(n[i]=encodeURIComponent(a))}}catch(e){u.logger({msg:e&&e.message})}return n},t.fillFilterData=function(e,t,n){n||(n={});try{var o=e.filter||"",r=o.split("=");if(f(r)&&r[1])n[r[0]]=r[1];else if(r[0]&&t&&t.getAttribute){var i=t.getAttribute(r[0])||"";void 0!==typeof i&&null!==i&&""!==i&&(n[r[0]]=i)}}catch(e){u.logger({msg:e&&e.message})}return n};var _=function(e){return!!/^POST|GET$/i.test(e)};t.isMethod=_;var m=function(e){var t=!!/^\d+$/.test(e);return!!(t&&parseInt(e)>0)};t.isPkgSize=m,t.filterExpConfigRequestCfg=function(e){var t=g.getDefaultRequestCfg()||{};try{var n=e||{};_(n.method)&&(t.method=n.method),m(n.pkgSize)&&(t.pkgSize=parseInt(n.pkgSize))}catch(e){u.logger({msg:e&&e.message})}return t};var y=function(e){var t=e.split("&"),n={};return t.length>0&&l(t,function(e){var t=e.split("=");2===t.length&&(n[t[0]]=p.tryToEncodeURIComponent(t[1]))}),n};t.autoUserFnHandler=function(e,t,n){var o={userdata:{},spm:"",scm:""};try{var r=e(t,n);r&&("string"==typeof r?o.userdata=y(r):"object"==typeof r&&"object"==typeof r.userdata&&(c(r.userdata,function(e,t){o.userdata[e]=p.tryToEncodeURIComponent(t)}),o.spm=r.spm,o.scm=r.scm))}catch(e){console.log(e)}return o};var b=function(e,t){var n="";if(e&&t){var o=[e.getAttribute(t.filter)],r=t.props||[];if(r)for(var i=0;i<r.length;i++)o.push(e.getAttribute(r[i]));n=o.join("_")}return n},w=function(e){var t=e.getAttribute("data-spm-anchor-id");if(t){var n=t.split(".");return{a:n[0],b:n[1],c:n[2],d:n[3],e:n[4]}}};t.getSpmObj=w,t.getElementHash=function(e,t){var n={};"aplus_webvt"!==e.source&&(n=w(t.ele)||g_SPM.getParam(t.ele));var o="",r="x"+t.index;if(n.a&&n.b&&n.c&&n.d){var i=/^i/.test(n.d)?r:n.d;o=n.a+"_"+n.b+"_"+n.c+"_"+i}else o=r,goldlog.pvid&&(o+=goldlog.pvid);t.ignore_attr||(o+=e.logkey+"_",o+=e.elementSelector+"_",o+=b(t.ele,e));var a=r+"_"+s.hash(o);return{hash_value:a,hash_key:r+"_"+o}},t.filterUnloadAttr=function(e){return e&&(e=e.replace(/(href|style|data-spm-anchor-id)=[\'|\"][\w|\W|\.]+[\'|\"]/,""),e=e.replace(/\s\>/g,">"),e=e.replace(new RegExp(g.DATA_APLUS_AE_KEY+"=[\\'|\\\"]\\w+[\\'|\\\"]"),""),e=e.replace(new RegExp(g.DATA_APLUS_AC_KEY+"=[\\'|\\\"]\\w+[\\'|\\\"]"),"")),e};var E=function(e,t){for(var n,o=0,r=e.length;o<r;){var i=e[o]||{};if(i.hash_value===t.hash_value)return e[o]=t,n=!0,e;o++}return n||e.push(t),e},A=function(e,t,n,r){if(n||(n="ADD"),e&&"object"==typeof t){var i=a.getGoldlogVal(r)||{},u=i._acHashMap||{},s=u[e]||[],l=function(){for(var e=0,n=s.length;e<n;){var o=s[e]||{};if(o.hash_value===t.hash_value)return e;e++}return-1},c=l();"ADD"===n&&c===-1?(s.push(t),o(e,t,r)):"CLEAR"===n&&c>-1?s.splice(c,1):"UPDATE"===n&&(s=E(s,t)),u[e]=s,i._acHashMap=u,a.setGoldlogVal(r,i)}};t.updateExpHashMap=function(e,t,n){A(e,t,n,"_aplus_auto_exp")},t.updateClkHashMap=function(e,t,n){A(e,t,n,"_aplus_ac")};var x=function(){return(new Date).getTime()};t.throttle=function(e,t,n){var o,r,i,a,u=0;n||(n={});var s=function(){a=e.apply(r,i),u=n.leading===!1?0:x(),o=null,o||(r=i=null)},l=function(){u||n.leading!==!1||(u=x());var l=t-(x()-u);return r=this,i=arguments,l<=0||l>t?(o&&(clearTimeout(o),o=null),a=e.apply(r,i),u=x(),o||(r=i=null)):o||n.trailing===!1||(o=setTimeout(s,l)),a};return l.cancel=function(){clearTimeout(o),u=0,o=r=i=null},l},t.checkIsInHashMap=function(e){var t=a.getGoldlogVal(e.goldlogKey)||{},n=t.hash_value||{},o=n[e.logkey]||(i.Map?new i.Map:{}),r=o&&o.get?o.get(e.hash_value):o[e.hash_value];if(r>1)return!0;for(var u=t._acHashMap||{},s=u[e.logkey]||[],l=s.length,c=0;c<l;c++)if(s[c].hash_value===e.hash_value)return!0;return!1},t.setRecordSuccess=function(e,t){try{var n=e?e.element:{},o=e.hash_value||"";n&&n.setAttribute&&n.setAttribute(t,o)}catch(e){}}},function(e,t){"use strict";var n=function(e){var t;try{window.goldlog||(window.goldlog={}),t=window.goldlog[e]}catch(e){t=""}finally{return t}};t.getGoldlogVal=n;var o=function(e,t){var n=!1;try{window.goldlog||(window.goldlog={}),e&&(window.goldlog[e]=t,n=!0)}catch(e){n=!1}finally{return n}};t.setGoldlogVal=o,t.getClientInfo=function(){return n("_aplus_client")||{}}},function(e,t){"use strict";var n=1315423911;t.hash=function(e,t){var o,r,i=t||n;for(o=e.length-1;o>=0;o--)r=e.charCodeAt(o),i^=(i<<5)+r+(i>>2);var a=(2147483647&i).toString(16);return a}},function(e,t){"use strict";e.exports=function(e,t){var n,o=e.length;for(n=0;n<o;n++){var r=t(e[n],n);if("break"===r)break}}},function(e,t){"use strict";e.exports=function(e,t){if(Object&&Object.keys)for(var n=Object.keys(e),o=n.length,r=0;r<o;r++){var i=n[r];t(i,e[i])}else for(var a in e)t(a,e[a])}},function(e,t){"use strict";t.tryToEncodeURIComponent=function(e){var t=e||"";if(e)try{t=encodeURIComponent(decodeURIComponent(e))}catch(e){}return t}},function(e,t,n){"use strict";function o(e){return goldlog&&goldlog.getMetaInfo?goldlog.getMetaInfo(e):i.getMetaCnt(e)}var r=n(13),i=n(14);t.DATA_APLUS_AE_KEY="data-aplus-ae",t.DATA_APLUS_AC_KEY="data-aplus-clk",t.LOOP_TIME=1e3,t.getDefaultRequestCfg=function(){return{method:"POST",pkgSize:10}};var a=function(e,t){var n=t;try{var r=o(e);r&&(n=parseFloat(r)),n<=0&&(n=t)}catch(e){n=t}finally{return n}},u=a("aplus-auto-exp-visible",.3);t.AUTO_AT_VIEW_RATE=u,t.AUTO_AT_VIEW_RATE_IN_WINDOW=a("aplus-auto-exp-window",0)||u;var s=function(e){var t=e;try{var n=o("aplus-auto-exp-duration"),r=parseInt(n);r+""!="NaN"&&(t=r)}catch(e){}finally{return t}};t.EXP_DURATION=s(300);var l=function(e,t){var n,i=[],a=[];try{n=t||o(e);var u=[];if(n&&"string"==typeof n)try{u=JSON.parse(n)}catch(e){u=JSON.parse(n.replace(/'/g,'"'))}else"object"==typeof n&&n.constructor===Array&&(u=n);if(u&&u.constructor===Array)for(var s=0;s<u.length;s++){var l=u[s]||{},c=l.logkey||"",p=l.tag?l.tag:"",g=l.filter,f=l.cssSelector,h=f||p&&g;if(!c||!h)throw new Error("meta "+e+" config error, "+JSON.stringify(l));g="string"==typeof g?g.split("="):[];var d=p;if(g.length>=2?d+="["+g.shift()+'="'+decodeURIComponent(g.join(""))+'"]':1==g.length&&g[0]&&(d+="["+decodeURIComponent(g[0])+"]"),f&&(d+=f),l.elementSelector=d,r.indexof(a,d)>-1)throw new Error("meta "+e+" config error, tag_filter_cssSelector "+d+" repeated");a.push(d),i.push(l)}}catch(e){}finally{return i}};t.getAutoExpConfig=function(e){return l("aplus-auto-exp",e)||[]},t.getAutoExpUserFn=function(){var e=o("aplus-auto-exp-userfn");if(e){var t=window[e]||e;if("function"==typeof t)return t}return null},t.isThrottleWatchDom=function(){var e=!1;try{e="throttle"===o("aplus-auto-exp-watchdom")}catch(e){}return e},t.getAutoClkConfig=function(e){return l("aplus-auto-clk",e)||[]},t.getAutoClkUserFn=function(){var e=o("aplus-auto-clk-userfn");if(e){var t=window[e]||e;if("function"==typeof t)return t}return null}},function(e,t){"use strict";t.indexof=function(e,t){var n=-1;try{n=e.indexOf(t)}catch(r){for(var o=0;o<e.length;o++)e[o]===t&&(n=o)}finally{return n}}},function(e,t,n){"use strict";function o(e){return a=a||document.getElementsByTagName("head")[0],u&&!e?u:a?u=a.getElementsByTagName("meta"):[]}function r(e,t){var n,r,i,a=o(),u=a.length;for(n=0;n<u;n++)r=a[n],s.tryToGetAttribute(r,"name")===e&&(i=s.tryToGetAttribute(r,t||"content"));return i||""}function i(e){var t={isonepage:"-1",urlpagename:""},n=e.qGet();if(n&&n.hasOwnProperty("isonepage_data"))t.isonepage=n.isonepage_data.isonepage,t.urlpagename=n.isonepage_data.urlpagename;else{var o=r("isonepage")||"-1",i=o.split("|");t.isonepage=i[0],t.urlpagename=i[1]?i[1]:""}return t}var a,u,s=n(15);t.getMetaTags=o,t.getMetaCnt=r,t.getOnePageInfo=i},function(e,t){"use strict";t.tryToGetAttribute=function(e,t){return e&&e.getAttribute?e.getAttribute(t)||"":""};var n=function(e,t,n){if(e&&e.setAttribute)try{e.setAttribute(t,n)}catch(e){}};t.tryToSetAttribute=n,t.tryToRemoveAttribute=function(e,t){if(e&&e.removeAttribute)try{e.removeAttribute(t)}catch(o){n(e,t,"")}}},function(e,t,n){"use strict";function o(e,t){var n=goldlog._$||{},o=n.meta_info||{},r=o.aplus_ctap||{},i=o["aplus-touch"];if(r&&"function"==typeof r.on)r.on(e,t);else{var s="ontouchend"in document.createElement("div");s&&"tap"===i?a.on(e,t):u(e,s?"touchstart":"mousedown",t)}}function r(e,t){var n=goldlog._$||{},o=n.meta_info||{},r=o.aplus_ctap||{},i=o["aplus-touch"];if(r&&"function"==typeof r.un)r.un(e,t);else{var u="ontouchend"in document.createElement("div");u&&"tap"===i?a.un(e,t):s(e,u?"touchstart":"mousedown",t)}}var i=!!document.attachEvent,a=n(17),u=function(e,t,n){return"tap"===t?void o(e,n):void(i?e.attachEvent(t,n):e.addEventListener(t,n))};t.on=u;var s=function(e,t,n){return"tap"===t?void r(e,n):void(i?e.detachEvent(t,n):e.removeEventListener(t,n))};t.un=s},function(e,t){"use strict";function n(e,t){return e+Math.floor(Math.random()*(t-e+1))}function o(e,t,n){var o=c.createEvent("HTMLEvents");if(o.initEvent(t,!0,!0),"object"==typeof n)for(var r in n)o[r]=n[r];e.dispatchEvent(o)}function r(e){0===Object.keys(g).length&&(p.addEventListener(d,i,!1),p.addEventListener(h,a,!1),p.addEventListener(_,a,!1));for(var t=0;t<e.changedTouches.length;t++){var n=e.changedTouches[t],o={};for(var r in n)o[r]=n[r];var u={startTouch:o,startTime:Date.now(),status:v,element:e.srcElement||e.target};g[n.identifier]=u}}function i(e){for(var t=0;t<e.changedTouches.length;t++){var n=e.changedTouches[t],o=g[n.identifier];if(!o)return;var r=n.clientX-o.startTouch.clientX,i=n.clientY-o.startTouch.clientY,a=Math.sqrt(Math.pow(r,2)+Math.pow(i,2));(o.status===v||"pressing"===o.status)&&a>10&&(o.status="panning")}}function a(e){for(var t=0;t<e.changedTouches.length;t++){var n=e.changedTouches[t],r=n.identifier,u=g[r];u&&(u.status===v&&e.type===h&&(u.timestamp=Date.now(),o(u.element,m,{touch:n,touchEvent:e})),delete g[r])}0===Object.keys(g).length&&(p.removeEventListener(d,i,!1),p.removeEventListener(h,a,!1),p.removeEventListener(_,a,!1))}function u(e){e.__fixTouchEvent||(e.addEventListener(f,function(){},!1),e.__fixTouchEvent=!0)}function s(){l||(p.addEventListener(f,r,!1),l=!0)}var l=!1,c=window.document,p=c.documentElement,g={},f="touchstart",h="touchend",d="touchmove",v="tapping",_="touchcancel",m="aplus_tap"+n(1,1e5);e.exports={on:function(e,t){s(),e&&e.addEventListener&&t&&(u(e),e.addEventListener(m,t._aplus_tap_callback=function(e){t(e,e.target)},!1))},un:function(e,t){e&&e.removeEventListener&&t&&t._aplus_tap_callback&&e.removeEventListener(m,t._aplus_tap_callback,!1)}}},function(e,t,n){"use strict";var o=n(3),r=document,i=function(e,t){return t.x>=e.pLeftTop[0]&&t.x<=e.pRightBottom[0]&&t.y>=e.pLeftTop[1]&&t.y<=e.pRightBottom[1]},a=function(e,t){var n=0,r={x:t.x,y:t.y},a=i(e,r),u={x:t.x+t.width,y:t.y},s=i(e,u),l={x:t.x,y:t.y+t.height},c=i(e,l),p={x:t.x+t.width,y:t.y+t.height},g=i(e,p),f=function(){var e=0;return a&&g&&(e=t.size/t.size),e},h=function(){var n,o=0,r=0;return a&&s&&!c&&!g?(o=t.width,r=e.pLeftBottom[1]-t.y,n="top"):!a&&s&&!c&&g?(o=e.pLeftTop[0]-t.x,r=t.y,n="right"):!a&&!s&&c&&g?(o=t.width,r=t.height-Math.abs(e.pLeftTop[1]-t.y),n="bottom"):a&&!s&&c&&!g&&(o=e.pRightTop[0]-t.x,r=t.y,n="left"),o=o>e.clientWidth?e.clientWidth:o,r=r>e.clientHeight?e.clientHeight:r,{rate:t.size>0?Math.abs(o*r)/t.size:0,exp_pos:n}},d=function(){var n=0,o=0,i=e.pLeftTop[0],a=e.pLeftTop[1],u=e.pLeftBottom[0],s=e.pLeftBottom[1],c=e.pRightBottom[0],g=r.x<=i&&r.y<=a,f=p.x>=u&&p.y>=s;g&&f&&(o=e.clientHeight,n=p.x<c?p.x-u:e.clientWidth);var h=r.x>i&&r.y<=a;return h&&f&&(o=e.clientHeight,n=p.x-l.x,p.x>c&&(n=c-l.x)),t.size>0?Math.abs(n*o)/t.size:0},v=function(){var n,o=0,r=0;return!a||s||c||g?a||!s||c||g?a||s||!c||g?a||s||c||!g||(o=t.x+t.width,r=t.y+t.height,n="rightBottom"):(o=e.pRightTop[0]-t.x,r=e.clientHeight-(l.y-e.pRightBottom[1]),n="leftBottom"):(o=u.x,r=e.clientHeight-u.y,n="rightTop"):(o=e.clientWidth-t.x,r=e.clientHeight-t.y,n="leftTop"),{rate:t.size>0?Math.abs(o*r)/t.size:0,exp_pos:n}};if(n=f(),n>0)return n;var _=h();if(n=_.rate,n>0)return o.isDebugAplus()&&o.logger({msg:_}),n;var m=v();return n=m.rate,n>0?(o.isDebugAplus()&&o.logger({msg:m}),n):(n=d(),n>0?(o.isDebugAplus()&&o.logger({msg:"cover rate is "+n}),n):n>1?1:n)};t.wrapViewabilityRate=function(e,t,n){var o=0;if(e)for(var r=0;r<e.length;r++)if(o=a(e[r],t),o>=n)return o;return o},t.getViewabilityRateInWindow=function(e,t,n){var o=0;if(e)for(var r=0;r<e.length;r++)if(o=t/e[r].size,o>=n)return o;return o};var u=function(e){return"number"==typeof e&&NaN!==e},s=function(e){var t={};return e&&("function"==typeof e.getBoundingClientRect&&(t=e.getBoundingClientRect()||{}),u(t.x)||u(t.left)&&(t.x=t.left),u(t.y)||u(t.top)&&(t.y=t.top),u(t.width)||(t.width=e.offsetWidth),u(t.height)||(t.height=e.offsetHeight)),t};t.getElementPosition=s,t.getWinPositions=function(e){var t=[];if(e&&"function"==typeof document.querySelector){var n=document.querySelector(e);if(n){var o=s(n)||{};u(o.x)&&u(o.y)&&u(o.width)&&u(o.height)&&t.push({pLeftTop:[o.x,o.y],pRightTop:[o.x+o.width,o.y],pLeftBottom:[o.x,o.y+o.height],pRightBottom:[o.x+o.width,o.y+o.height],size:o.width*o.height})}}var i=r.documentElement,a=r.body,l=i.clientWidth||a.offsetWidth||0,c=i.clientHeight||a.offsetHeight||0;return t.push({pLeftTop:[0,0],pRightTop:[l,0],pLeftBottom:[0,c],pRightBottom:[l,c],size:l*c,clientHeight:c,clientWidth:l}),t},t.checkIsRecord=function(e,t,n){var o;try{if(e&&e.getAttribute){var r=e.getAttribute(n)||"";o=t?r===t:!!r}}catch(e){}return o}},function(e,t,n){"use strict";function o(e,t,n){var o=f.getWinPositions(),r=0,i=l.getGoldlogVal("_aplus_auto_exp")||{},a=i._acHashMap||{};for(var u in a)for(var c=a[u]||[],g=0;g<c.length;g++){var _=c[g]||{};_.eventType="IObserver";var m=!!n||_.element===t.target;if(0===_.status&&_.expConfig&&m){var y=t.boundingClientRect||{};if(y.width||y.height||(y=t.target.getBoundingClientRect()||{}),y.width&&y.height){_=s.assign(_,y),_.x=y.x||y.left,_.y=y.y||y.top,_.width=y.width,_.height=y.height,_.size=y.width*y.height;var b=f.checkIsRecord(_.element,_.hash_value,"_aplus_auto_exp"),w=_.width*_.height*t.intersectionRatio,E=f.getViewabilityRateInWindow(o,w,v);if(!b){var A=t.intersectionRatio>=d;if(A||E>=v){_.exposureTime=e,_.status=1;var x=p.getAutoExpUserFn();x&&(_.userParams=h.autoUserFnHandler(x,_.element,_.elementSelector)),_.viewabilityRate=A?t.intersectionRatio:E,_.viewability=A?"intersection":"fillwindow",p.EXP_DURATION||(_.status=2),h.updateExpHashMap(u,_,"UPDATE"),++r}else E&&h.updateExpHashMap(u,Object.assign(c[g],{lastEventType:_.eventType}),"UPDATE")}}}}return r}function r(e,t){var n="APLUS_AE_EXPOSURE_CHANGE",r=e&&e.type?e.type:"IObserver",i=(new Date).getTime(),a=0;a="IObserver"!==t.from?g.filterStartExposureSize(i,r,!0):o(i,e),a>0&&(p.EXP_DURATION?setTimeout(function(){a=g.filterEndExposureSize(i,r),a>0&&goldlog.aplus_pubsub.publish(n,{size:a,eventType:r})},p.EXP_DURATION):goldlog.aplus_pubsub.publish(n,{size:a,eventType:r}))}function i(e){var t={root:null,rootMargin:"0px",threshold:d};return new m(function(e){c(e,function(e){e.intersectionRatio>0&&r(e,{from:"IObserver"})})},s.assign(t,e))}function a(e){if(m){y.io_base||(y.io_base=i());var t=l.getGoldlogVal("_aplus_auto_exp")||{},n=t._acHashMap||{};for(var o in n)for(var r=n[o]||[],a=0;a<r.length;a++){var u=r[a]||{};if(!u.inObserver){var s,c="io_v_"+encodeURIComponent(u.positionSelector);u.positionSelector&&!y[c]&&(s=i({root:document.querySelector(u.positionSelector),expConfig:e}),y[c]=s),s?s.observe(u.element):y.io_base.observe(u.element),u.inObserver=!0}}}return!0}var u=n(16),s=n(20),l=n(7),c=n(9),p=n(12),g=n(21),f=n(18),h=n(6),d=p.AUTO_AT_VIEW_RATE,v=p.AUTO_AT_VIEW_RATE_IN_WINDOW,_=window,m=_.IntersectionObserver,y={};goldlog._aplus_auto_exp.iobserverMap=y;var b=h.throttle(function(e){r(e,{from:e.type})},100);t.watch_exposure_change=function(e){goldlog.aplus_pubsub.subscribe("APLUS_AE_DOM_CHANGE",function(){a(e)}),u.on(window,"touchmove",b),u.on(window,"scroll",b),u.on(window,"resize",b),a(e)},t.clear=function(e,t){if(t&&"appendMetaInfo"!==t.from){u.un(window,"touchmove",b),u.un(window,"scroll",b),u.un(window,"resize",b);for(var n in y){var o=y[n];o.disconnect()}}}},function(e,t,n){"use strict";function o(e,t){return"function"!=typeof Object.assign?function(e){if(null===e)throw new TypeError("Cannot convert undefined or null to object");for(var t=Object(e),n=1;n<arguments.length;n++){var o=arguments[n];if(null!==o)for(var r in o)Object.prototype.hasOwnProperty.call(o,r)&&(t[r]=o[r])}return t}(e,t):Object.assign({},e,t)}function r(e){return"function"==typeof e}function i(e){return Array.isArray?Array.isArray(e):/Array/.test(Object.prototype.toString.call(e))}function a(e){return"string"==typeof e}function u(e){return"number"==typeof e}function s(e){return"undefined"==typeof e}function l(e){return"[object Object]"===Object.prototype.toString.call(e)}function c(e){if("number"==typeof e)return!1;if(s(e)||null===e)return!0;if(a(e))return!e;if(i(e))return!e.length;if(l(e)){for(var t in e)if(hasOwnProperty.call(e,t))return!1;return!0}return!1}function p(e){if("string"==typeof e)try{var t=JSON.parse(e);return!("object"!=typeof t||!t)}catch(e){return!1}return!1}function g(e,t){return e.indexOf(t)>-1}var f=window;t.assign=o,t.makeCacheNum=function(){return Math.floor(268435456*Math.random()).toString(16)},t.each=n(9),t.isStartWith=function(e,t){return 0===e.indexOf(t)},t.isEndWith=function(e,t){var n=e.length,o=t.length;return n>=o&&e.indexOf(t)==n-o},t.any=function(e,t){var n,o=e.length;for(n=0;n<o;n++)if(t(e[n]))return!0;return!1},t.isFunction=r,t.isArray=i,t.isString=a,t.isNumber=u,t.isUnDefined=s,t.isObject=l,t.isEmpty=c,t.isJSON=p,t.isContain=g;var h=function(e){var t,n=e.constructor===Array?[]:{};if("object"==typeof e){if(f.JSON&&f.JSON.parse)t=JSON.stringify(e),n=JSON.parse(t);else for(var o in e)n[o]="object"==typeof e[o]?h(e[o]):e[o];return n}};t.cloneObj=h,t.cloneDeep=h},function(e,t,n){"use strict";var o=n(18),r=n(7),i=n(12),a=n(6),u=i.AUTO_AT_VIEW_RATE,s=i.AUTO_AT_VIEW_RATE_IN_WINDOW,l=function(e){for(var t;e&&"HTML"!==e.tagName;){t=e.style.display;{if("none"===t)break;e=e.parentNode}}return"none"===t};t.filterStartExposureSize=function(e,t){var n=0,c=o.getWinPositions(),p=r.getGoldlogVal("_aplus_auto_exp")||{},g=p._acHashMap||{};for(var f in g)for(var h=g[f]||[],d=0;d<h.length;d++){var v=h[d]||{};if(0===v.status&&v.expConfig&&!l(v.element)){var _=o.getElementPosition(v.element);if(_.width&&_.height){v.x=_.x,v.y=_.y,v.eventType=t,v.width=_.width,v.height=_.height,v.size=_.width*_.height;var m;v.expConfig.positionSelector&&(m=o.getWinPositions(v.expConfig.positionSelector));var y=o.wrapViewabilityRate(m||c,v,u),b=y>=u,w=y;m&&(w=o.wrapViewabilityRate(c,v,u));var E=v.width*v.height*w,A=o.getViewabilityRateInWindow(c,E,s),x=o.checkIsRecord(v.element,v.hash_value,"_aplus_auto_exp");if((b||A>=s)&&!x){v.exposureTime=e,v.status=1;var T=i.getAutoExpUserFn();T&&(v.userParams=a.autoUserFnHandler(T,v.element,v.elementSelector)),i.EXP_DURATION||(v.viewabilityRate=b?y:A,v.viewability=b?"intersection":"fillwindow",v.status=2),a.updateExpHashMap(f,v,"UPDATE"),++n}}}}return n},t.filterEndExposureSize=function(e,t){var n=0,i=o.getWinPositions(),l=r.getGoldlogVal("_aplus_auto_exp")||{},c=l._acHashMap||{};for(var p in c)for(var g=c[p]||[],f=0;f<g.length;f++){var h=g[f]||{};if(1===h.status&&h.exposureTime===e&&h.expConfig){h.eventType=t;var d;h.expConfig.positionSelector&&(d=o.getWinPositions(h.expConfig.positionSelector));var v=o.checkIsRecord(h.element,h.hash_value,"_aplus_auto_exp"),_=o.wrapViewabilityRate(d||i,h,u),m=_>=u,y=_;d&&(y=o.wrapViewabilityRate(i,h,u));var b=h.width*h.height*y,w=o.getViewabilityRateInWindow(i,b,s);(m||w>=s)&&!v?(h.viewabilityRate=m?_:w,h.viewability=m?"intersection":"fillwindow",h.status=2,a.updateExpHashMap(p,h,"UPDATE"),++n):(h.status=0,h.exposureTime="",a.updateExpHashMap(p,h,"UPDATE"))}}return n}},function(e,t,n){"use strict";var o=n(16),r=n(21),i=n(6),a=n(12),u=function(e){var t="APLUS_AE_EXPOSURE_CHANGE",n=e&&e.type?e.type:"init",o=(new Date).getTime(),i=r.filterStartExposureSize(o,n,!1);i>0&&(a.EXP_DURATION?setTimeout(function(){i=r.filterEndExposureSize(o,n),i>0&&goldlog.aplus_pubsub.publish(t,{size:i,eventType:n})},a.EXP_DURATION):goldlog.aplus_pubsub.publish(t,{size:i,eventType:n}))},s=i.throttle(function(e){u(e)},100),l={},c=function(e,t){if(e&&e.forEach&&Object.keys&&document.querySelector){e.forEach(function(e){e.positionSelector&&document.querySelector(e.positionSelector)&&(l[e.positionSelector]=!0)});var n=Object.keys(l);n.forEach(function(e){o[t]&&o[t](document.querySelector(e),"scroll",function(e){s(e)})})}};t.watch_exposure_change=function(e){goldlog.aplus_pubsub.subscribe("APLUS_AE_DOM_CHANGE",u),o.on(window,"touchmove",s),o.on(window,"scroll",s),o.on(window,"resize",u),c(e,"on")},t.clear=function(e){o.un(window,"touchmove",s),o.un(window,"scroll",s),o.un(window,"resize",u),c(e,"un")}},function(e,t,n){"use strict";function o(e,t,n){var o="0";if(n){if("spmc"===e){var r=n.split(".");o=r[2]?r[2]:r[3],/^(\i|\d)[0-9]+$/.test(o)&&(o="0"),n=[r[0],r[1],o].join(".")}}else{n="";var i=window.g_SPM||{};if("function"==typeof i.getParam){var a=i.getParam(t);"spmc"===e?(o=t.getAttribute("data-spm")||"0",n=[a.a,a.b,o].join(".")):n=[a.a,a.b,a.c,a.d].join(".")}}return n}var r=n(2),i=n(20),a=n(7),u=n(3),s=n(10),l=n(6),c=n(12),p=function(){var e=u.isDebugAplus(),t={},n=c.getDefaultRequestCfg(),r=a.getGoldlogVal("_aplus_auto_exp")||{},p=r._acHashMap||{};return s(p,function(a,s){for(var c=s||[],p=0,g=c.length;p<g;p++){var f=c[p]||{};if(2===f.status){f.status=3,l.updateExpHashMap(a,f,"UPDATE"),r.exp_times++;var h,d=f.expConfig||{},v=goldlog.spm_ab?goldlog.spm_ab.join("."):"0.0.0.0",_=o(d.eltype,f.element)||v,m="";try{var y=new Number(f.viewabilityRate);h=y.toFixed(2)}catch(e){h=f.viewabilityRate}var b={_w:f.width,_h:f.height,_x:f.x,_y:f.y,_rate:h,_viewability:f.viewability};"object"==typeof f.userParams&&("object"==typeof f.userParams.userdata&&(b=i.assign(b,f.userParams.userdata)),
f.userParams.spm&&(_=o(d.eltype,"",f.userParams.spm)),f.userParams.scm&&(m=f.userParams.scm)),(l.isMethod(d.method)||l.isPkgSize(d.pkgSize))&&(n=l.filterExpConfigRequestCfg(d));var w=l.fillPropsData(d,f.element,b);w=l.fillFilterData(d,f.element,b);var E={exargs:w,scm:m,spm:_,aplusContentId:""};t[a]||(t[a]=[]),t[a].push(E),e&&u.logger({msg:"logkey = "+a+", params = "+decodeURIComponent(JSON.stringify(E))})}}}),{logkeyContainer:t,request_cfg:n}},g=function(e){for(var t=[],n=0,o=e.length;n<o;n++){var r=e[n]||{},a={};s(r,function(e,t){"element"!==e&&(a[e]=t)});var u=i.cloneObj(a);u.element=r.element,t.push(u)}return t},f=function(e){var t=a.getGoldlogVal("_aplus_auto_exp")||{},n=t._acHashMap||{},o=[];s(n,function(t,n){for(var r=g(n)||[],i=0,a=r.length;i<a;i++){var s=r[i]||{},p=n[i]||{};if(3===s.status)try{l.setRecordSuccess(p,c.DATA_APLUS_AE_KEY),goldlog.aplus_pubsub.publish("APLUS_ELEMENT_EXPOSURE",{logkey:t,v_origin:p,options:e}),o.push(p)}catch(e){u.logger({msg:e&&e.message})}}for(;o.length>0;)l.updateExpHashMap(t,o.pop(),"CLEAR")})},h=function(e,t,n){var o=e.logkeyContainer||[],i=e.request_cfg||{};r.wrap(function(){s(o,function(e,o){if(o&&o.length>0){for(var r=0;r<o.length;){var a=[],u=JSON.stringify(o.slice(r,r+i.pkgSize));a.push("expdata="+u),a.push("_is_auto_exp=1"),a.push("_eventType="+t.eventType),a.push("_method="+i.method),a.push("_pkgSize="+i.pkgSize),goldlog.record(e,"EXP",a.join("&"),i.method||"POST"),r+=i.pkgSize}n(t)}})},"recordAplusAt")},d=function(e){if(e.size>0){var t=p()||{};h(t,e,f)}};t.watch_data_change=function(){goldlog.aplus_pubsub.subscribe("APLUS_AE_EXPOSURE_CHANGE",d)},t.clear=function(){goldlog.aplus_pubsub.unsubscribe("APLUS_AE_EXPOSURE_CHANGE",d)}}]);/*! 2024-09-10 16:39:22 v8.15.24 */
!function(t){function e(o){if(n[o])return n[o].exports;var a=n[o]={exports:{},id:o,loaded:!1};return t[o].call(a.exports,a,a.exports,e),a.loaded=!0,a.exports}var n={};return e.m=t,e.c=n,e.p="",e(0)}([function(t,e,n){t.exports=n(1)},function(t,e,n){"use strict";!function(){var t=window;n(2)();var e=n(3),o=n(4);"ontouchend"in document.createElement("div")&&(t.goldlog_queue||(t.goldlog_queue=[])).push({action:"goldlog.setMetaInfo",arguments:["aplus-touch","tap"]});var a=function(){n(96);var e=n(98),o=n(33);if(o.doPubMsg(["goldlogReady","running"]),document.getElementsByTagName("body").length){var r="g_tb_aplus_loaded";if(t[r])return;t[r]=1,n(112).initGoldlog(e)}else setTimeout(function(){a()},50)},r=function(t){try{e.do_tracker_jserror({ratio:1,message:t&&t.message,error:encodeURIComponent(t&&t.stack?t.stack:""),filename:"aplusLoad"})}catch(t){}};try{a()}catch(t){r(t,o.script_name+"@"+o.lver)}}()},function(t,e){t.exports=function(){var t=window.goldlog_queue||(window.goldlog_queue=[]);try{var e=navigator.userAgent,n=/Trident/.test(e);n||t.push({action:"goldlog.setMetaInfo",arguments:["aplus-p-url-init",window.location.href.substring(0,850)]})}catch(t){}}},function(t,e){"use strict";var n=function(t,e){var n=window.goldlog_queue||(window.goldlog_queue=[]);n.push({action:"goldlog._aplus_cplugin_track_deb.monitor",arguments:[{key:"APLUS_PLUGIN_DEBUG",title:"aplus_core",msg:["_error_:methodName="+e+",params="+JSON.stringify(t)],type:"updateMsg",description:e||"aplus_core"}]})},o=function(t,e,n){var o=window.goldlog_queue||(window.goldlog_queue=[]);o.push({action:["goldlog","_aplus_cplugin_m",e].join("."),arguments:[t,n]})};e.do_tracker_jserror=function(t,e){var a="do_tracker_jserror";o(t,a,e),n(t,a)},e.do_tracker_obsolete_inter=function(t,e){var a="do_tracker_obsolete_inter";o(t,a,e),n(t,a)},e.wrap=function(t){if("function"==typeof t)try{t()}catch(t){n({msg:t.message||t},"exception")}finally{}}},function(t,e,n){"use strict";var o=n(5),a=n(6),r=n(7);e.APLUS_ENV="production",e.lver=a.lver,e.toUtVersion=a.toUtVersion,e.script_name=a.script_name,e.recordTypes=o.recordTypes,e.KEY=o.KEY,e.context=r.context,e.context_prepv=r.context_prepv,e.aplus_init=n(16).plugins_init,e.plugins_pv=n(37).plugins_pv,e.plugins_prepv=n(63).plugins_prepv,e.context_hjlj=n(64),e.plugins_hjlj=n(66).plugins_hjlj,e.beforeUnload=n(78),e.initLoad=n(82),e.spmException=n(86),e.goldlog_path=n(87),e.is_auto_pv="true",e.utilPvid=n(91),e.disablePvid="false",e.mustSpmE=!0,e.LS_CNA_KEY="APLUS_CNA"},function(t,e){"use strict";e.recordTypes={hjlj:"COMMON_HJLJ",uhjlj:"DATACLICK_HJLJ",pv:"PV",prepv:"PREPV"},e.KEY={NAME_STORAGE:{REFERRER:"wm_referrer",REFERRER_PV_ID:"refer_pv_id",LOST_PV_PAGE_DURATION:"lost_pv_page_duration",LOST_PV_PAGE_SPMAB:"lost_pv_page_spmab",LOST_PV_PAGE:"lost_pv_page",LOST_PV_PAGE_MSG:"lost_pv_page_msg"}}},function(t,e){"use strict";e.lver="8.15.24",e.toUtVersion="v20240910",e.script_name="aplus_int"},function(t,e,n){"use strict";e.context=n(8),e.context_prepv=n(15)},function(t,e,n){"use strict";function o(){return{compose:{maxTimeout:5500},etag:{egUrl:"gj.mmstat.com/eg.js",cna:i.getCookie("cna")},where_to_sendpv:{url:"//gj.mmstat.com/v.gif",urlRule:s.getBeaconSrc}}}function a(){return r.assign(new s.initConfig,new o)}var r=n(9),i=n(11),s=n(14);t.exports=a},function(t,e,n){"use strict";function o(t,e){return"function"!=typeof Object.assign?function(t){if(null===t)throw new TypeError("Cannot convert undefined or null to object");for(var e=Object(t),n=1;n<arguments.length;n++){var o=arguments[n];if(null!==o)for(var a in o)Object.prototype.hasOwnProperty.call(o,a)&&(e[a]=o[a])}return e}(t,e):Object.assign({},t,e)}function a(t){return"function"==typeof t}function r(t){return Array.isArray?Array.isArray(t):/Array/.test(Object.prototype.toString.call(t))}function i(t){return"string"==typeof t}function s(t){return"number"==typeof t}function u(t){return"undefined"==typeof t}function c(t){return"[object Object]"===Object.prototype.toString.call(t)}function l(t){if("number"==typeof t)return!1;if(u(t)||null===t)return!0;if(i(t))return!t;if(r(t))return!t.length;if(c(t)){for(var e in t)if(hasOwnProperty.call(t,e))return!1;return!0}return!1}function p(t){if("string"==typeof t)try{var e=JSON.parse(t);return!("object"!=typeof e||!e)}catch(t){return!1}return!1}function g(t,e){return t.indexOf(e)>-1}var f=window;e.assign=o,e.makeCacheNum=function(){return Math.floor(268435456*Math.random()).toString(16)},e.each=n(10),e.isStartWith=function(t,e){return 0===t.indexOf(e)},e.isEndWith=function(t,e){var n=t.length,o=e.length;return n>=o&&t.indexOf(e)==n-o},e.any=function(t,e){var n,o=t.length;for(n=0;n<o;n++)if(e(t[n]))return!0;return!1},e.isFunction=a,e.isArray=r,e.isString=i,e.isNumber=s,e.isUnDefined=u,e.isObject=c,e.isEmpty=l,e.isJSON=p,e.isContain=g;var d=function(t){var e,n=t.constructor===Array?[]:{};if("object"==typeof t){if(f.JSON&&f.JSON.parse)e=JSON.stringify(t),n=JSON.parse(e);else for(var o in t)n[o]="object"==typeof t[o]?d(t[o]):t[o];return n}};e.cloneObj=d,e.cloneDeep=d},function(t,e){"use strict";t.exports=function(t,e){var n,o=t.length;for(n=0;n<o;n++){var a=e(t[n],n);if("break"===a)break}}},function(t,e,n){"use strict";function o(t){var e=s.cookie.match(new RegExp("(?:^|;)\\s*"+t+"=([^;]+)"));return e?e[1]:""}function a(t,e,n){n||(n={});var a=new Date;if("session"===n.expires);else if(n.expires&&("number"==typeof n.expires||n.expires.toUTCString))"number"==typeof n.expires?a.setTime(a.getTime()+24*n.expires*60*60*1e3):a=n.expires,e+="; expires="+a.toUTCString();else{var r=20;c.indexof(["v.youku.com","www.youku.com","player.youku.com"],location.hostname)>-1&&(r=1),a.setTime(a.getTime()+365*r*24*60*60*1e3),e+="; expires="+a.toUTCString()}e+="; path="+(n.path?n.path:"/"),e+="; domain="+n.domain,s.cookie=t+"="+e;var i=0;try{var u=navigator.userAgent.match(/Chrome\/\d+/);u&&u[0]&&(i=u[0].split("/")[1],i&&(i=parseInt(i)))}catch(t){}return n.SameSite&&i>=80&&(e+="; SameSite="+n.SameSite,e+="; Secure",s.cookie=t+"="+e),o(t)}function r(t,e,n){try{if(n||(n={}),n.domain)a(t,e,n);else for(var o=l.getDomains(),r=0;r<o.length;)n.domain=o[r],a(t,e,n)?r=o.length:r++}catch(t){}}function i(){var t={};return u.each(g,function(e){t[e]=o(e)}),t.cnaui=/\btanx\.com$/.test(p)?o("cnaui"):"",t}var s=document,u=n(9),c=n(12),l=n(13),p=location.hostname;e.getCookie=o,e.setCookie=r;var g=["tracknick","thw","cna"];e.getData=i,e.getHng=function(){return encodeURIComponent(o("hng")||"")}},function(t,e){"use strict";e.indexof=function(t,e){var n=-1;try{n=t.indexOf(e)}catch(a){for(var o=0;o<t.length;o++)t[o]===e&&(n=o)}finally{return n}}},function(t,e){"use strict";e.getDomains=function(){var t=[];try{for(var e=location.hostname,n=e.split("."),o=2;o<=n.length;)t.push(n.slice(n.length-o).join(".")),o++}catch(t){}return t}},function(t,e,n){"use strict";function o(t,e,n){var o=window.goldlog||{},s=o.getMetaInfo("aplus-ifr-pv")+""=="1";return e?r(t)?"yt":"m":n&&!s?a.isContain(t,"wrating.com")?"k":i(t)||"y":i(t)||"v"}var a=n(9),r=function(t){for(var e=["youku.com","soku.com","tudou.com","laifeng.com"],n=0;n<e.length;n++){var o=e[n];if(a.isContain(t,o))return!0}return!1},i=function(t){for(var e=[["scmp.com","sc"],["luxehomes.com.hk","sc"],["ays.com.hk","sc"],["cpjobs.com","sc"],["educationpost.com.hk","sc"],["cosmopolitan.com.hk","sc"],["elle.com.hk","sc"],["harpersbazaar.com.hk","sc"],["1688.com","6"],["youku.com","yt"],["soku.com","yt"],["tudou.com","yt"],["laifeng.com","yt"]],n=0;n<e.length;n++){var o=e[n];if(a.isContain(t,o[0]))return o[1]}return""};e.getBeaconSrc=o,e.initConfig=function(){return{compose:{},etag:{egUrl:"log.mmstat.com/eg.js",cna:"",tag:"",stag:"",lstag:"-1",lscnastatus:""},can_to_sendpv:{flag:"NO"},userdata:{},what_to_sendpv:{pvdata:{},exparams:{}},what_to_pvhash:{hash:[]},what_to_sendpv_ut:{pvdataToUt:{}},what_to_sendpv_ut2:{isSuccess:!1,pvdataToUt:{}},when_to_sendpv:{aplusWaiting:""},where_to_sendpv:{url:"//log.mmstat.com/o.gif",urlRule:o},where_to_sendlog_ut:{aplusToUT:{},toUTName:"toUT"},hjlj:{what_to_hjlj:{logdata:{}},what_to_hjlj_ut:{logdataToUT:{}}},network:{connType:"UNKNOWN"},is_single:!1}}},function(t,e,n){"use strict";function o(){return{etag:{egUrl:"log.mmstat.com/eg.js",cna:a.getCookie("cna"),tag:"",stag:""},compose:{},where_to_prepv:{url:"//log.mmstat.com/v.gif",urlRule:r.getBeaconSrc},userdata:{},what_to_prepv:{logdata:{}},what_to_hjlj_exinfo:{EXPARAMS_FLAG:"EXPARAMS",exinfo:[],exparams_key_names:["uidaplus","pc_i","pu_i"]},is_single:!1}}var a=n(11),r=n(14);t.exports=o},function(t,e,n){"use strict";e.plugins_init=[{name:"where_to_sendpv",enable:!0,path:n(17)},{name:"etag",enable:!0,path:n(32)},{name:"etag_sync",enable:!0,path:n(36)}]},function(t,e,n){"use strict";var o=n(18),a=n(25)();t.exports=function(){return o.assign(a,{run:function(){var t=this.getAplusMetaByKey("aplus-rhost-v"),e=this.options.context.where_to_sendpv||{},n=e.url||"",a=this.getGifPath(e.urlRule,n),r=o.getPvUrl({metaName:"aplus-rhost-v",metaValue:t,gifPath:a,url:n});e.url=r,this.options.context.where_to_sendpv=e}})}},function(t,e,n){"use strict";function o(t){t=(t||"").split("#")[0].split("?")[0];var e=t.length,n=function(t){var e,n=t.length,o=0;for(e=0;e<n;e++)o=31*o+t.charCodeAt(e);return o};return e?n(e+"#"+t.charCodeAt(e-1)):-1}function a(t){for(var e=t.split("&"),n=0,o=e.length,a={};n<o;n++){var r=e[n],i=r.indexOf("="),s=r.substring(0,i),u=r.substring(i+1);a[s]=p.tryToDecodeURIComponent(u)}return a}function r(t){if("function"!=typeof t)throw new TypeError(t+" is not a function");return t}function i(t){var e,n,o,a=[],r=t.length;for(o=0;o<r;o++)e=t[o][0],n=t[o][1],a.push(l.isStartWith(e,v)?n:e+"="+encodeURIComponent(n));return a.join("&")}function s(t){var e,n,o,a={},r=t.length;for(o=0;o<r;o++)e=t[o][0],n=t[o][1],a[e]=n;return a}function u(t,e){var n,o,a,r=[];for(n in t)t.hasOwnProperty(n)&&(o=""+t[n],a=n+"="+encodeURIComponent(o),e?r.push(a):r.push(l.isStartWith(n,v)?o:a));return r.join("&")}function c(t,e){var n=t.indexOf("?")==-1?"?":"&",o=e?l.isArray(e)?i(e):u(e):"";return o?t+n+o:t}var l=n(9),p=n(19),g=n(22),f=parent!==self;e.is_in_iframe=f,e.makeCacheNum=l.makeCacheNum,e.isStartWith=l.isStartWith,e.isEndWith=l.isEndWith,e.any=l.any,e.each=l.each,e.assign=l.assign,e.isFunction=l.isFunction,e.isArray=l.isArray,e.isString=l.isString,e.isNumber=l.isNumber,e.isUnDefined=l.isUnDefined,e.isContain=l.isContain,e.sleep=n(23).sleep,e.makeChkSum=o,e.tryToDecodeURIComponent=p.tryToDecodeURIComponent,e.nodeListToArray=p.nodeListToArray,e.parseSemicolonContent=p.parseSemicolonContent,e.param2obj=a;var d=n(24),_=function(t){return/^(\/\/){0,1}(\w+\.){1,}\w+((\/\w+){1,})?$/.test(t)};e.hostValidity=_;var h=function(t,e){var n=/^(\/\/){0,1}(\w+\.){1,}\w+\/\w+\.gif$/.test(t),o=_(t),a="";return n?a="isGifPath":o&&(a="isHostPath"),a||d.logger({msg:e+": "+t+' is invalid, suggestion: "xxx.mmstat.com"'}),a},m=function(t){return!/^\/\/gj\.mmstat/.test(t)&&goldlog.isInternational()&&(t=t.replace(/^\/\/\w+\.mmstat/,"//gj.mmstat")),t};e.filterIntUrl=m,e.getPvUrl=function(t){t||(t={});var e,n,o=t.metaValue&&h(t.metaValue,t.metaName),a="";"isGifPath"===o?(e=/^\/\//.test(t.metaValue)?"":"//",a=e+t.metaValue):"isHostPath"===o&&(e=/^\/\//.test(t.metaValue)?"":"//",n=/\/$/.test(t.metaValue)?"":"/",a=e+t.metaValue+n+t.gifPath);var r;return a?r=a:(e=0===t.gifPath.indexOf("/")?t.gifPath:"/"+t.gifPath,r=t.url&&t.url.replace(/\/\w+\.gif/,e)),r},e.indexof=n(12).indexof,e.callable=r;var v="::-plain-::";e.mkPlainKey=function(){return v+Math.random()},e.s_plain_obj=v,e.mkPlainKeyForExparams=function(t){var e=t||v;return e+"exparams"},e.rndInt32=function(){return Math.round(2147483647*Math.random())},e.arr2param=i,e.arr2obj=s,e.obj2param=u,e.makeUrl=c,e.ifAdd=function(t,e){var n,o,a,r,i=e.length;for(n=0;n<i;n++)o=e[n],a=o[0],r=o[1],r&&t.push([a,r])},e.isStartWithProtocol=g.isStartWithProtocol,e.param2arr=function(t){for(var e,n=t.split("&"),o=0,a=n.length,r=[];o<a;o++)e=n[o].split("="),r.push([e.shift(),e.join("=")]);return r},e.catchException=function(t,e,n){var o=window,a=o.goldlog_queue||(o.goldlog_queue=[]),r=t;"object"==typeof e&&e.message&&(r=r+"_"+e.message),n&&n.msg&&(r+="_"+n.msg),a.push({action:"goldlog._aplus_cplugin_m.do_tracker_jserror",arguments:[{message:r,error:JSON.stringify(e),filename:t}]})}},function(t,e,n){"use strict";var o=n(20),a=n(21);t.exports={tryToDecodeURIComponent:function(t,e){var n=e||"";if(t)try{n=decodeURIComponent(t)}catch(t){}return n},parseSemicolonContent:function(t,e,n){e=e||{};var a,r,i=t.split(";"),s=i.length;for(a=0;a<s;a++){r=i[a].split("=");var u=o.trim(r.slice(1).join("="));e[o.trim(r[0])||""]=n?u:this.tryToDecodeURIComponent(u)}return e},nodeListToArray:function(t){var e,n;try{return e=[].slice.call(t)}catch(a){e=[],n=t.length;for(var o=0;o<n;o++)e.push(t[o]);return e}},getLsCna:function(t,e){if(a.set&&a.test()){var n="",o=a.get(t);if(o){var r=o.split("_")||[];n=e?r.length>1&&e===r[0]?r[1]:"":r.length>1?r[1]:""}return decodeURIComponent(n)}return""},setLsCna:function(t,e,n){n&&a.set&&a.test()&&a.set(t,e+"_"+encodeURIComponent(n))},getUrl:function(t){var e=t||"//log.mmstat.com/eg.js";try{var n=goldlog.getMetaInfo("aplus-rhost-v"),o=/[[a-z|0-9\.]+[a-z|0-9]/,a=n.match(o);a&&a[0]&&(e=e.replace(o,a[0]))}catch(t){}return e}}},function(t,e){"use strict";function n(t){return"string"==typeof t?t.replace(/^\s+|\s+$/g,""):""}e.trim=n},function(t,e){"use strict";t.exports={set:function(t,e){try{return localStorage.setItem(t,e),!0}catch(t){return!1}},get:function(t){try{return localStorage.getItem(t)}catch(t){return""}},test:function(){var t="grey_test_key";try{return localStorage.setItem(t,1),localStorage.removeItem(t),!0}catch(t){return!1}},remove:function(t){localStorage.removeItem(t)}}},function(t,e,n){"use strict";var o=n(9),a=function(){if(goldlog.aplusDebug){var t=location.protocol;return"http:"!==t&&"https:"!==t&&(t="https:"),t}return"https:"};e.getProtocal=a,e.isStartWithProtocol=function(t){for(var e=["javascript:","tel:","sms:","mailto:","tmall://","#"],n=0,a=e.length;n<a;n++)if(o.isStartWith(t,e[n]))return!0;return!1}},function(t,e){"use strict";e.sleep=function(t,e){return setTimeout(function(){e()},t)}},function(t,e){"use strict";var n=function(){var t=!1;return"boolean"==typeof goldlog.aplusDebug&&(t=goldlog.aplusDebug),t};e.isDebugAplus=n;var o=function(t){t||(t={});var e=t.level||"warn";window.console&&window.console[e]&&window.console[e](t.msg)};e.logger=o},function(t,e,n){"use strict";var o=n(18),a=n(26),r=n(27);t.exports=function(){return{init:function(t){this.options=t},getMetaInfo:function(){var t=a.getGoldlogVal("_$")||{},e=t.meta_info||r.getInfo();return e},getAplusMetaByKey:function(t){var e=this.getMetaInfo()||{};return e[t]},getGifPath:function(t,e){var n,r=a.getGoldlogVal("_$")||{};if("function"==typeof t)n=t(location.hostname,r.is_terminal,o.is_in_iframe)+".gif";else if(!n&&e){var i=e.match(/\/\w+\.gif/);i&&i.length>0&&(n=i[0])}return n||(n=r.is_terminal?"m.gif":"v.gif"),n},run:function(){var t=!!this.options.context.is_single;if(!t){var e=this.getAplusMetaByKey("aplus-rhost-v"),n=this.options.context.where_to_sendpv||{},a=n.url||"",r=this.getGifPath(n.urlRule,a),i=o.getPvUrl({metaName:"aplus-rhost-v",metaValue:e,gifPath:r,url:o.filterIntUrl(a)});n.url=i,this.options.context.where_to_sendpv=n}}}}},function(t,e){"use strict";var n=function(t){var e;try{window.goldlog||(window.goldlog={}),e=window.goldlog[t]}catch(t){e=""}finally{return e}};e.getGoldlogVal=n;var o=function(t,e){var n=!1;try{window.goldlog||(window.goldlog={}),t&&(window.goldlog[t]=e,n=!0)}catch(t){n=!1}finally{return n}};e.setGoldlogVal=o,e.getClientInfo=function(){return n("_aplus_client")||{}}},function(t,e,n){"use strict";function o(t){var e,n,o,a=t.length,r={};for(h._microscope_data=r,e=0;e<a;e++)n=t[e],"microscope-data"===f.tryToGetAttribute(n,"name")&&(o=f.tryToGetAttribute(n,"content"),l.parseSemicolonContent(o,r),h.is_head_has_meta_microscope_data=!0);h._microscope_data_params=l.obj2param(r),h.ms_data_page_id=r.pageId,h.ms_data_shop_id=r.shopId,h.ms_data_instance_id=r.siteInstanceId,h.ms_data_siteCategoryId=r.siteCategory,h.ms_prototype_id=r.prototypeId,h.site_instance_id_or_shop_id=h.ms_data_instance_id||h.ms_data_shop_id,h._atp_beacon_data={},h._atp_beacon_data_params=""}function a(t){var e,n=function(){var e;return document.querySelector&&(e=document.querySelector("meta[name=data-spm]")),g.each(t,function(t){"data-spm"===f.tryToGetAttribute(t,"name")&&(e=t)}),e},o=n();return o&&(e=f.tryToGetAttribute(o,"data-spm-protocol")),e}function r(t){var e=t.isonepage||"-1",n=e.split("|"),o=n[0],a=n[1]?n[1]:"";t.isonepage_data={isonepage:o,urlpagename:a},t["aplus-pagename"]=a}function i(){var t=d.getMetaTags();o(t),g.each(t,function(t){var e=f.tryToGetAttribute(t,"name");if(/^aplus/.test(e)&&(h[e]=d.getMetaCnt(e),e===v))try{c=h[e]=JSON.parse(d.getMetaCnt(e))}catch(t){}}),g.each(m,function(t){h[t]=d.getMetaCnt(t)}),h.spm_protocol=a(t),c&&(h=g.assign(h,c));var e,n,i=["aplus-rate-ahot"],s=i.length;for(e=0;e<s;e++)n=i[e],h[n]=parseFloat(h[n]);return r(h),b=h||{},h}function s(){return b||i()}function u(t){p.logger({msg:"please do not repeat setPriorityMetaInfo "+t})}var c,l=n(18),p=n(24),g=n(9),f=n(28),d=n(29),_=n(30),h={},m=["ahot-aplus","isonepage","spm-id","data-spm","microscope-data"],v="aplus-x-settings",b={};e.setMetaInfo=function(t,e){if(b||(b={}),"object"==typeof c&&c[t])return u(t),!0;if(t===v){if(c)u(t);else try{c="object"==typeof e?e:JSON.parse(e),b=g.assign(b,c)}catch(t){console&&console.log(t)}return!0}return b[t]=e,!0};var y=function(t){return b||(b={}),b[t]||""};e.getMetaInfo=y,e.getInfo=i,e.qGet=s,e.appendMetaInfo=function(t,e){var n=function(t,e){goldlog.setMetaInfo(t,e,{from:"appendMetaInfo"})};if(t&&e){var o,a=function(o){try{var a="string"==typeof e?JSON.parse(e):e;n(t,g.assign(o,a))}catch(t){}},r=function(o){try{var a="string"==typeof e?JSON.parse(e):e;n(t,o.concat(a))}catch(t){}},i=function(t){return"EXPARAMS"===t?_.getExparamsInfos("",t):t?t.split("&"):[]},s=function(o){try{var a=i(o),r=i(e);n(t,a.concat(r).join("&"))}catch(t){}},u=function(t){t.constructor===Array?r(t):a(t)},c=goldlog.getMetaInfo(t);if("aplus-exinfo"===t&&(s(c),o=!0),c)if("object"==typeof c)u(c),o=!0;else try{var l=JSON.parse(c);"object"==typeof l&&(u(l),o=!0)}catch(t){}o||n(t,e)}}},function(t,e){"use strict";e.tryToGetAttribute=function(t,e){return t&&t.getAttribute?t.getAttribute(e)||"":""};var n=function(t,e,n){if(t&&t.setAttribute)try{t.setAttribute(e,n)}catch(t){}};e.tryToSetAttribute=n,e.tryToRemoveAttribute=function(t,e){if(t&&t.removeAttribute)try{t.removeAttribute(e)}catch(o){n(t,e,"")}}},function(t,e,n){"use strict";function o(t){return i=i||document.getElementsByTagName("head")[0],s&&!t?s:i?s=i.getElementsByTagName("meta"):[]}function a(t,e){var n,a,r,i=o(),s=i.length;for(n=0;n<s;n++)a=i[n],u.tryToGetAttribute(a,"name")===t&&(r=u.tryToGetAttribute(a,e||"content"));return r||""}function r(t){var e={isonepage:"-1",urlpagename:""},n=t.qGet();if(n&&n.hasOwnProperty("isonepage_data"))e.isonepage=n.isonepage_data.isonepage,e.urlpagename=n.isonepage_data.urlpagename;else{var o=a("isonepage")||"-1",r=o.split("|");e.isonepage=r[0],e.urlpagename=r[1]?r[1]:""}return e}var i,s,u=n(28);e.getMetaTags=o,e.getMetaCnt=a,e.getOnePageInfo=r},function(t,e,n){"use strict";var o=n(18),a=n(31),r=n(12);e.getExparamsInfos=function(t,e){var n=[],i=t||["uidaplus","pc_i","pu_i"],s=a.getExParams(o)||"";s=s.replace(/&aplus&/,"&");for(var u=o.param2arr(s)||[],c=function(t){return r.indexof(i,t)>-1},l=0;l<u.length;l++){var p=u[l],g=p[0]||"",f=p[1]||"";g&&f&&("EXPARAMS"===e||c(g))&&n.push(g+"="+f)}return n}},function(t,e,n){"use strict";function o(){return s||(s=g.getElementById("beacon-aplus")||g.getElementById("tb-beacon-aplus")),s}function a(t){var e=o(),n=p.tryToGetAttribute(e,"cspx");t&&n&&(t.nonce=n)}function r(t,e,n){var r="script",s=g.createElement(r);s.type="text/javascript",s.async=!0;var c=o(),l=c&&c.hasAttribute("crossorigin");l&&(s.crossOrigin="anonymous");var p="https:"===location.protocol?e||t:t;0===p.indexOf("//")&&(p=u.getProtocal()+p),s.src=p,n&&(s.id=n),a(s);var f=g.getElementsByTagName(r)[0];i=i||g.getElementsByTagName("head")[0],f?f.parentNode.insertBefore(s,f):i&&i.appendChild(s)}var i,s,u=n(22),c=n(9),l=n(24),p=n(28),g=document;e.getCurrentNode=o,e.addScript=r,e.loadScript=function(t,e){function n(t){o.onreadystatechange=o.onload=o.onerror=null,o=null,e(t)}var o=g.createElement("script");if(i=i||g.getElementsByTagName("head")[0],o.async=!0,"onload"in o)o.onload=n;else{var r=function(){/loaded|complete/.test(o.readyState)&&n()};o.onreadystatechange=r,r()}o.onerror=function(t){n(t)},o.src=t,a(o),i.appendChild(o)},e.isTouch=function(){return"ontouchend"in document.createElement("div")};var f=function(){var t=goldlog&&goldlog._$?goldlog._$:{},e=t.meta_info||{};return e["aplus-exparams"]||""};e.getExParamsFromMeta=f,e.getExParams=function(t){var e=o(),n=p.tryToGetAttribute(e,"exparams"),a=d(n,f(),t)||"";return a&&a.replace(/&amp;/g,"&").replace(/\buser(i|I)d=/,"uidaplus=")};var d=function(t,e,n){var o="aplus&sidx=aplusSidex",a=t||o;try{if(e){var r=n.param2obj(e),i=["aplus","cna","spm-cnt","spm-url","spm-pre","logtype","pre","uidaplus","asid","sidx","trid","gokey"];c.each(i,function(t){r.hasOwnProperty(t)&&(l.logger({msg:"Can not inject keywords: "+t}),delete r[t])}),delete r[""];var s="";if(t){var u=t.match(/aplus&/).index,p=u>0?n.param2obj(t.substring(0,u)):{};delete p[""],s=n.obj2param(c.assign(p,r))+"&"+t.substring(u,t.length)}else s=n.obj2param(r)+"&"+o;return s}return a}catch(t){return a}};e.mergeExparams=d},function(t,e,n){"use strict";var o=n(33),a=n(3),r=n(11),i=n(31),s=n(19),u=n(34),c=n(35),l=n(26),p=n(4);t.exports=function(){return{init:function(t){this.options=t;var e=this.options.context.etag||{};this.cna=e.cna||r.getCookie("cna"),this.setTag(0),this.setStag(-1),this.setLsTag("-1"),this.setEtag(this.cna||""),this.requesting=!1,this.today=u.getFormatDate()},setLsTag:function(t){this.lstag=t,this.options.context.etag.lstag=t},setTag:function(t){this.tag=t,this.options.context.etag.tag=t},setStag:function(t){this.stag=t,this.options.context.etag.stag=t},setEtag:function(t){t&&(this.etag=t,this.options.context.etag.cna=t,r.getCookie("cna")!==t&&(o.publishCNA(t),r.setCookie("cna",t,{SameSite:"none"})))},setLscnaStatus:function(t){this.options.context.etag.lscnastatus=t},run:function(t,e){var n=this;if(n.cna)return void n.setTag(1);var o=null,r=c.getUrl(this.options.context.etag||{});n.requesting=!0;var u=function(){setTimeout(function(){e()},20),clearTimeout(o)};return i.loadScript(r,function(t){var e,o;if(t&&"error"===t.type?(n.setStag(-3),a.do_tracker_jserror({message:"loadError",error:"",filename:"etag_ls"})):(e=l.getGoldlogVal("Etag"),o=l.getGoldlogVal("stag"),"undefined"!=typeof o&&n.setStag(o)),!n.requesting)return void n.setEtag(e);if(2===o||4===o){var r=s.getLsCna(p.LS_CNA_KEY);r?(n.setLsTag(1),n.setEtag(r)):(n.setLsTag(0),s.setLsCna(p.LS_CNA_KEY,n.today,e),n.setEtag(e))}else n.setEtag(e);u()}),o=setTimeout(function(){n.requesting=!1,n.setStag(-2),e()},1500),2e3}}}},function(t,e){"use strict";var n="function",o=function(){var t=window.goldlog||{},e=t.aplus_pubsub||{},o=typeof e.publish===n;return o?e:""},a=function(t){var e=o();e&&typeof e.publish===n&&e.publish.apply(e,t)};e.doPubMsg=a;var r=function(t){var e=o();e&&typeof e.cachePubs===n&&e.cachePubs.apply(e,t)};e.doCachePubs=r,e.doSubMsg=function(t,e){var a=o();a&&typeof a.subscribe===n&&a.subscribe(t,e)},e.doSubOnceMsg=function(t,e){var a=o();a&&typeof a.subscribeOnce===n&&a.subscribeOnce(t,e)},e.publishCNA=function(t){if(t){var e=["CNA",{value:t}];a(e),r(e)}}},function(t,e){"use strict";function n(t,e,n){var o=""+Math.abs(t),a=e-o.length,r=t>=0;return(r?n?"+":"":"-")+Math.pow(10,Math.max(0,a)).toString().substr(1)+o}e.getFormatDate=function(t){var e=new Date;try{return[e.getFullYear(),n(e.getMonth()+1,2,0),n(e.getDate(),2,0)].join(t||"")}catch(t){return""}}},function(t,e,n){"use strict";var o=n(19);e.getUrl=function(t){var e=(new Date).getTime(),n=o.getUrl(t&&t.egUrl?t.egUrl:"gj.mmstat.com/eg.js"),a=n.match(/[\w+\.]+[a-z|A-Z|0-9]+\/(eg|ge).js/);return 0!==n.indexOf("http")&&a&&a.length>0&&(n="//"+a[0]),n+"?t="+e}},function(t,e,n){"use strict";var o=n(19),a=n(31),r=n(35),i=n(4),s=n(34),u=n(21);t.exports=function(){return{init:function(t){this.options=t,this.today=s.getFormatDate()},run:function(){var t=this;if(u.test()){var e=o.getLsCna(i.LS_CNA_KEY,t.today);e||setTimeout(function(){var e=r.getUrl(t.options.context.etag||{});a.loadScript(e,function(e){e&&"error"!==e.type&&o.setLsCna(i.LS_CNA_KEY,t.today,goldlog.Etag)})},1e3)}}}}},function(t,e,n){"use strict";e.plugins_pv=[{name:"etag",enable:!0,path:n(38)},{name:"when_to_sendpv",enable:!0,path:n(39)},{name:"where_to_sendlog_ut",enable:!0,path:n(40)},{name:"is_single",enable:!0,path:n(42)},{name:"what_to_pvhash",enable:!0,path:n(43)},{name:"what_to_sendpv",enable:!0,path:n(44)},{name:"what_to_sendpv_userdata",enable:!0,path:n(48),deps:["what_to_sendpv"]},{name:"what_to_sendpv_etag",enable:!0,path:n(53),deps:["etag","what_to_sendpv"]},{name:"what_to_sendpv_ut2",enable:!0,path:n(54),deps:["where_to_sendlog_ut"]},{name:"what_to_sendpv_ut",enable:!0,path:n(56),deps:["where_to_sendlog_ut"]},{name:"what_to_pv_slog",enable:!0,path:n(57),deps:["what_to_sendpv","what_to_sendpv_ut2","what_to_sendpv_ut"]},{name:"can_to_sendpv",enable:!0,path:n(58)},{name:"where_to_sendpv",enable:!0,path:n(17),deps:["is_single"]},{name:"do_sendpv_ut2",enable:!0,path:n(59),deps:["what_to_sendpv_ut2","where_to_sendlog_ut"]},{name:"do_sendpv_ut",enable:!0,path:n(60),deps:["what_to_sendpv_ut","where_to_sendlog_ut","do_sendpv_ut2"]},{name:"do_sendpv",enable:!0,path:n(61),deps:["is_single","what_to_sendpv","where_to_sendpv","do_sendpv_ut"]},{name:"after_pv",enable:!0,path:n(62)}]},function(t,e,n){"use strict";var o=n(33);t.exports=function(){return{init:function(t){this.options=t},run:function(){var t=this;o.doSubOnceMsg("aplusInitContext",function(e){e.etag&&(t.options.context.etag=e.etag)})}}}},function(t,e,n){"use strict";var o=n(26),a=n(23),r=n(27);t.exports=function(){return{init:function(t){this.options=t},getMetaInfo:function(){var t=o.getGoldlogVal("_$")||{},e=t.meta_info||r.getInfo();return e},getAplusWaiting:function(){var t=this.getMetaInfo()||{};return t["aplus-waiting"]},run:function(t,e){var n=this.options.config||{},o=this.getAplusWaiting();if(o&&n.is_auto)switch(o=this.getAplusWaiting()+"",this.options.context.when_to_sendpv={aplusWaiting:o},o){case"MAN":return"done";case"1":return this.options.context.when_to_sendpv.isWait=!0,a.sleep(6e3,function(){e()}),6e3;default:var r=1*o;if(r+""!="NaN")return this.options.context.when_to_sendpv.isWait=!0,a.sleep(r,function(){e()}),r}}}}},function(t,e,n){"use strict";var o=n(41);t.exports=function(){return{init:function(t){this.options=t},getAplusToUT:function(t){return{toUT2:o.getAplusToUT("toUT2",t),toUT:o.getAplusToUT("toUT",t)}},run:function(){if("Umeng4Aplus"===goldlog.aplusBridgeName)this.options.context.where_to_sendlog_ut.toUTName="toUT2";else{var t=this.getAplusToUT(this.options.config.recordType);this.options.context.where_to_sendlog_ut.aplusToUT=t}}}}},function(t,e){"use strict";var n=navigator.userAgent,o=/WindVane/i.test(n);e.is_WindVane=o;var a=function(){var t=goldlog.getMetaInfo("aplus_chnl");return!(!t||!t.isAvailable||"function"!=typeof t.toUT2&&"function"!=typeof t.toUT)&&t};e.isAplusChnl=a,e.getAplusToUT=function(t,e){var n={},r=a();if("object"==typeof r)n.bridgeName=r.bridgeName||"customBridge",n.bridgeVersion=r.bridgeVersion||r.version||"",n.isAvailable=r.isAvailable,n.toUT2=r.toUT2||r.toUT;else{var i=window.WindVane||{};if(o&&i&&i.isAvailable&&"function"==typeof i.call){var s=t||"toUT",u=goldlog.getMetaInfo("aplus-toUT")+"";"toUT2HC"===u&&"PV"===e&&(s=u),n={bridgeName:"WindVane",bridgeVersion:i.version||"",isAvailable:!0,toUT2:function(t,e,n,o){return i.call("WVTBUserTrack",s,t,e,n,o)}}}}return n}},function(t,e,n){"use strict";var o=n(26),a=n(4);t.exports=function(){return{init:function(t){this.options=t},isSingle_pv:function(){var t=o.getGoldlogVal("_$")||{};return!("1"===t.meta_info["aplus-both-request"])},isSingle_hjlj:function(t){var e=o.getGoldlogVal("_$")||{};return!("1"===e.meta_info["aplus-both-request"])&&t&&t.logkey&&t.gmkey},isSingle_uhjlj:function(t){var e=o.getGoldlogVal("_$")||{};return(!t||!/^\/aplus\.99\.(\d)+$/.test(t.logkey))&&(!("1"===e.meta_info["aplus-both-request"])&&t&&t.logkey)},run:function(){var t=this.options.context||{},e=this.options.config||{},n=t.where_to_sendlog_ut.aplusToUT||{},o=n.toUT||{},r=n.toUT2||{},i=!(!o.isAvailable&&!r.isAvailable),s=t.userdata||{},u=!!t.is_single;switch(e.recordType){case a.recordTypes.uhjlj:u=this.isSingle_uhjlj(s);break;case a.recordTypes.hjlj:u=this.isSingle_hjlj(s);break;case a.recordTypes.pv:u=this.isSingle_pv();break;default:u=this.isSingle_pv()}this.options.context.is_single=i&&u,this.options.context.ut_is_available=i}}}},function(t,e,n){"use strict";var o=n(26);t.exports=function(){return{init:function(t){this.options=t},run:function(){var t=this.options.context.what_to_pvhash||{},e=o.getGoldlogVal("_$")||{},n=e.meta_info||{},a=n["aplus-pvhash"]||"",r=[];"1"===a&&(r=["_aqx_uri",encodeURIComponent(location.href)]),t.hash=r,this.options.context.what_to_pvhash=t}}}},function(t,e,n){"use strict";var o=n(18),a=n(9),r=n(31),i=n(26),s=n(28),u=n(11),c=n(45),l=n(46),p=n(47);t.exports=function(){return a.assign(p,{init:function(t){this.options=t,this.cookie_data||(this.cookie_data=u.getData()),this.client_info||(this.client_info=i.getClientInfo()||{});var e=location.hash;e&&0===e.indexOf("#")&&(e=e.substr(1)),this.loc_hash=e},getExParams:function(){var t=window,e=document,n=[],u=parent!==t.self,l=e.getElementById("beacon-aplus")||e.getElementById("tb-beacon-aplus"),p=s.tryToGetAttribute(l,"exparams"),g=r.mergeExparams(p,r.getExParamsFromMeta(),o)||"";g=g.replace(/&amp;/g,"&");var f,d,_=["taobao.com","tmall.com","etao.com","hitao.com","taohua.com","juhuasuan.com","alimama.com"],h=i.getGoldlogVal("_$")||{},m=h.meta_info||{};if(u&&!m["aplus-ifr-pv"]){for(d=_.length,f=0;f<d;f++)if(o.isContain(location.hostname,_[f]))return n.push([o.mkPlainKeyForExparams(),g]),n;g=g.replace(/\buser(i|I)d=\w*&?/,"")}g=g.replace(/\buser(i|I)d=/,"uidaplus="),g&&n.push([o.mkPlainKeyForExparams(),g]);var v=a.makeCacheNum();return c.updateKey(n,"cache",v),n},getExtra:function(){var t=[],e=i.getGoldlogVal("_$")||{},n=e.meta_info||{},a=this.cookie_data||{},r=this.getClientInfo(!0)||[];return o.ifAdd(t,r),o.ifAdd(t,[["thw",a.thw],["bucket_id",l.getBucketId(n)],["urlokey",this.loc_hash],["wm_instanceid",n.ms_data_instance_id]]),t}})}},function(t,e){"use strict";function n(t,e,n){r(t,"spm-cnt",function(t){var o=t.split(".");return o[0]=goldlog.spm_ab[0],o[1]=goldlog.spm_ab[1],e?o[1]=o[1].split("/")[0]+"/"+e:o[1]=o[1].split("/")[0],n&&(o[4]=n),o.join(".")})}function o(t,e){var n=window.g_SPM&&g_SPM._current_spm;n&&r(t,"spm-url",function(){return[n.a,n.b,n.c,n.d].join(".")+(e?"."+e:"")},"spm-cnt")}function a(t,e){var n,o,a,r=-1;for(n=0,o=t.length;n<o;n++)if(a=t[n],a[0]===e){r=n;break}r>=0&&t.splice(r,1)}function r(t,e,n,o){var a,r,i=t.length,s=-1,u="function"==typeof n;for(a=0;a<i;a++){if(r=t[a],r[0]===e)return void(u?r[1]=n(r[1]):r[1]=n);o&&r[0]===o&&(s=a)}o&&(u&&(n=n()),s>-1?t.splice(s,0,[e,n]):t.push([e,n]))}t.exports={updateSPMCnt:n,updateSPMUrl:o,updateKey:r,removeKey:a}},function(t,e,n){"use strict";function o(t,e){var n,o=2146271213;for(n=0;n<t.length;n++)o=(o<<5)+o+t.charCodeAt(n);return(65535&o)%e}function a(t){var e,n=r.getCookie("t");return"3"!=t.ms_prototype_id&&"5"!=t.ms_prototype_id||(e=n?o(n,20):""),e}var r=n(11);e.getBucketId=a},function(t,e,n){"use strict";var o=n(18),a=n(9),r=n(26),i=n(41),s=n(11),u=n(4);t.exports={init:function(t){this.options=t,this.cookie_data||(this.cookie_data=s.getData())},getBasicParams:function(){var t=document,e=r.getGoldlogVal("_$")||{},n=e.spm||{},a=e.meta_info||{},i=a["aplus-ifr-pv"]+""=="1",u=o.is_in_iframe&&!i?0:1,c=this.options.config||{},l=t.title;
c.title&&(l+="_"+c.title);var p=[["logtype",u],["title",l],["pre",e.page_referrer||""],["scr",screen.width+"x"+screen.height]];try{var g=location.href.substring(0,1200);g&&p.push(["_p_url",a["aplus-p-url"]||g])}catch(t){}var f=this.cookie_data||{},d=this.options.context||{},_=d.etag||{},h=_.cna||f.cna||s.getCookie("cna");h&&p.push([o.mkPlainKey(),"cna="+h]),f.tracknick&&p.push([o.mkPlainKey(),"nick="+f.tracknick]);var m=n.spm_url||"";return o.ifAdd(p,[["wm_pageid",a.ms_data_page_id],["wm_prototypeid",a.ms_prototype_id],["wm_sid",a.ms_data_shop_id],["spm-url",m],["spm-pre",n.spm_pre],["spm-cnt",n.spm_cnt],["cnaui",f.cnaui]]),p},getExParams:function(){return[]},getExtra:function(){return[]},getClientInfo:function(t){var e=[],n=r.getGoldlogVal("_$")||{},s=this.client_info||{},c=s.ua_info||{};if(t||!i.is_WindVane&&!i.isAplusChnl()){for(var l,p=[],g=["p","o","b","s","w","wx","ism"],f=0;l=g[f++];)c[l]&&p.push([l,c[l]]);o.ifAdd(e,p)}o.ifAdd(e,[["cache",a.makeCacheNum()],["lver",goldlog.lver||u.lver],["jsver",n.script_name||u.script_name],["pver",goldlog.aplus_cplugin_ver]]);var d=this.options.config||{},_=d.is_auto;return _||o.ifAdd(e,[["mansndlog",1]]),e},processLodashDollar:function(){var t=r.getGoldlogVal("_$")||{};t.page_url!==location.href&&(t.page_referrer=t.page_url,t.page_url=location.href),r.setGoldlogVal("_$",t)},getLsParams:function(){var t=r.getGoldlogVal("_$")||{},e=[];return t.lsparams&&t.lsparams.spm_id&&(e.push(["lsparams",t.lsparams.spm_id]),e.push(["lsparams_pre",t.lsparams.current_url])),e},run:function(){var t=this.getBasicParams()||[],e=this.getExParams()||[],n=this.getExtra()||[];this.processLodashDollar();var o=this.getLsParams()||[],a=[].concat(t,e,n,o);this.options.context.what_to_sendpv.pvdata=a,this.options.context.what_to_sendpv.exparams=e}}},function(t,e,n){"use strict";var o=n(18),a=n(26),r=n(45),i=n(11),s=n(49);t.exports=function(){return{init:function(t){this.options=t},getPageId:function(){var t=this.options.config||{},e=this.options.context||{},n=e.userdata||{};return t.page_id||t.pageid||t.pageId||n.page_id},getPageInfo:function(){var t;try{var e=top.location!==self.location;e&&void 0!==window.innerWidth&&(t={width:window.innerWidth,height:window.innerHeight})}catch(t){}return t},getUserdata:function(){var t=a.getGoldlogVal("_$")||{},e=t.spm||{},n=this.options.context||{},r=n.userdata||{},u=this.options.config||{},c=[];if(u&&!u.is_auto){u.gokey&&c.push([o.mkPlainKey(),u.gokey]);var l=e.data.b;if(l){var p=this.getPageId();l=p?l.split("/")[0]+"/"+p:l.split("/")[0],s.setB(l);var g=e.spm_cnt.split(".");g&&g.length>2&&(g[1]=l,e.spm_cnt=g.join("."))}}var f=function(t){if("object"==typeof t)for(var e in t)"object"!=typeof t[e]&&"function"!=typeof t[e]&&c.push([e,t[e]])};f(goldlog.getMetaInfo("aplus-cpvdata")),f(r);var d=i.getCookie("workno")||i.getCookie("emplId");d&&c.push(["workno",d]);var _=i.getHng();_&&c.push(["_hng",i.getHng()]);var h=this.getPageInfo();return h&&(c.push(["_pw",h.width]),c.push(["_ph",h.height])),c},processLodashDollar:function(){var t=this.options.config||{},e=a.getGoldlogVal("_$")||{};t&&t.referrer&&(e.page_referrer=t.referrer),a.setGoldlogVal("_$",e)},updatePre:function(t){var e=a.getGoldlogVal("_$")||{};return e.page_referrer&&r.updateKey(t,"pre",e.page_referrer),t},run:function(){var t=this.options.context.what_to_sendpv.pvdata,e=this.getUserdata();this.processLodashDollar();var n=t,o=this.options.context.what_to_pvhash.hash;o&&o.length>0&&n.push(o),n=n.concat(e),n=this.updatePre(n);var a=this.getPageId();a&&r.updateSPMCnt(n,a),this.options.context.what_to_sendpv.pvdata=n,this.options.context.userdata=e}}}},function(t,e,n){"use strict";function o(){if(!s.data.a||!s.data.b){var t=r._SPM_a,e=r._SPM_b;if(t&&e)return t=t.replace(/^{(\w+\/)}$/g,"$1"),e=e.replace(/^{(\w+\/)}$/g,"$1"),s.is_wh_in_page=!0,void c.setAB(t,e);var n=goldlog._$.meta_info;t=n["data-spm"]||n["spm-id"]||"0";var o=t.split(".");o.length>1&&(t=o[0],e=o[1]),c.setA(t),e&&c.setB(e);var a=i.getElementsByTagName("body");a=a&&a.length?a[0]:null,a&&(e=l.tryToGetAttribute(a,"data-spm"),e?c.setB(e):1===o.length&&c.setAB("0","0"))}}function a(){var t=s.data.a,e=s.data.b;t&&e&&(goldlog.spm_ab=[t,e])}var r=window,i=document,s={},u={};s.data=u;var c={},l=n(28),p=n(50),g=location.href,f=n(51).getRefer(),d=n(4);c.setA=function(t){s.data.a=t,a()},c.setB=function(t){s.data.b=t,a()},c.setAB=function(t,e){s.data.a=t,s.data.b=e,a()};var _=p.getSPMFromUrl,h=function(){var t=d.utilPvid.makePVId();return d.mustSpmE?t||goldlog.pvid||"":t||""},m=function(t,e){var n=t.goldlog||window.goldlog||{},a=n.meta_info||{};s.meta_protocol=a.spm_protocol;var r,i=n.spm_ab||[],u=i[0]||"0",c=i[1]||"0";"0"===u&&"0"===c&&(o(),u=s.data.a||"0",c=s.data.b||"0"),r=[s.data.a,s.data.b].join("."),s.spm_cnt=(r||"0.0")+".0.0";var l=t.send_pv_count>0?h():n.pvid;l&&(s.spm_cnt+="."+l),n._$.spm=s,"function"==typeof e&&e(l)};c.spaInit=function(t,e,n,o){var a="function"==typeof o?o:function(){},r=s.spm_url,i=window.g_SPM||{},u=t._$||{},c=u.send_pv_count;m({goldlog:t,meta_info:e,send_pv_count:c},function(t){s.spm_cnt=s.data.a+"."+s.data.b+".0.0"+(t?"."+t:"");var o=e["aplus-spm-fixed"];if("1"!==o){s.spm_pre=_(f),s.origin_spm_pre=s.spm_pre,s.spm_url=_(location.href),s.origin_spm_url=s.spm_url;var u=i._current_spm||{};u&&u.a&&"0"!==u.a&&u.b&&"0"!==u.b?(s.spm_url=[u.a,u.b,u.c,u.d,u.e].join("."),s.spm_pre=r):c>0&&n&&"0"!==n[0]&&"0"!==n[1]&&(s.spm_url=n.concat(["0","0"]).join("."),s.spm_pre=r),i._current_spm={}}a()})},c.init=function(t,e,n){s.spm_url=_(g),s.spm_pre=_(f),m({goldlog:t,meta_info:e},function(){"function"==typeof n&&n()})},c.resetSpmCntPvid=function(){var t=goldlog.spm_ab;if(t&&2===t.length){var e=t.join(".")+".0.0",n=h();n&&(e=e+"."+n),s.spm_cnt=e,s.spm_url=e,goldlog._$.spm=s}},t.exports=c},function(t,e){"use strict";function n(t,e){if(!t||!e)return"";var n,o="";try{var a=new RegExp("[?|&]+"+t+"=([^&|#|?|/]+)");if("spm"===t||"scm"===t){var r=new RegExp("\\?.*"+t+"=([\\w\\.\\-\\*/]+)"),i=e.match(a),s=e.match(r),u=i&&2===i.length?i[1]:"",c=s&&2===s.length?s[1]:"";o=u>c?u:c,o=decodeURIComponent(o)}else n=e.match(a),o=n&&2===n.length?n[1]:""}catch(t){}finally{return o}}e.getParamFromUrl=n,e.getSPMFromUrl=function(t){return n("spm",t)}},function(t,e,n){"use strict";var o=n(52).nameStorage,a=n(5);e.getRefer=function(){var t=a.KEY||{},e=t.NAME_STORAGE||{};return document.referrer||o.getItem(e.REFERRER)||""}},function(t,e){"use strict";var n=function(){function t(){var t,e=[],r=!0;for(var l in p)p.hasOwnProperty(l)&&(r=!1,t=p[l]||"",e.push(c(l)+s+c(t)));n.name=r?o:a+c(o)+i+e.join(u)}function e(t,e,n){t&&(t.addEventListener?t.addEventListener(e,n,!1):t.attachEvent&&t.attachEvent("on"+e,function(e){n.call(t,e)}))}var n=window;if(n.nameStorage)return n.nameStorage;var o,a="nameStorage:",r=/^([^=]+)(?:=(.*))?$/,i="?",s="=",u="&",c=encodeURIComponent,l=decodeURIComponent,p={},g={};return function(t){if(t&&0===t.indexOf(a)){var e=t.split(/[:?]/);e.shift(),o=l(e.shift())||"";for(var n,i,s,c=e.join(""),g=c.split(u),f=0,d=g.length;f<d;f++)n=g[f].match(r),n&&n[1]&&(i=l(n[1]),s=l(n[2])||"",p[i]=s)}else o=t||""}(n.name),g.setItem=function(e,n){e&&"undefined"!=typeof n&&(p[e]=String(n),t())},g.getItem=function(t){return p.hasOwnProperty(t)?p[t]:null},g.removeItem=function(e){p.hasOwnProperty(e)&&(p[e]=null,delete p[e],t())},g.clear=function(){p={},t()},g.valueOf=function(){return p},g.toString=function(){var t=n.name;return 0===t.indexOf(a)?t:a+t},e(n,"beforeunload",function(){t()}),g}();e.nameStorage=n},function(t,e,n){"use strict";var o=n(45);t.exports=function(){return{init:function(t){this.options=t},updateBasicParams:function(){var t=this.options.context.what_to_sendpv.pvdata||[],e=this.options.context.etag||{};return e.cna&&(o.updateKey(t,"cna",e.cna),this.options.context.what_to_sendpv.pvdata=t),t},addTagParams:function(){var t=this.options.context.what_to_sendpv.pvdata||[],e=this.options.context.etag||{},n=[];(e.tag||0===e.tag)&&n.push(["tag",e.tag]),(e.stag||0===e.stag)&&n.push(["stag",e.stag]),(e.lstag||0===e.lstag)&&n.push(["lstag",e.lstag]),n.length>0&&(this.options.context.what_to_sendpv.pvdata=t.concat(n))},run:function(){this.updateBasicParams(),this.addTagParams()}}}},function(t,e,n){"use strict";function o(t){var e,n,o,a,r=[],s={};for(e=t.length-1;e>=0;e--)n=t[e],o=n[0],o&&o.indexOf(i.s_plain_obj)==-1&&s.hasOwnProperty(o)||(a=n[1],("aplus"==o||a)&&(r.unshift([o,a]),s[o]=1));return r}function a(t){var e,n,o,a,r=[],u={logtype:!0,cache:!0,scr:!0,"spm-cnt":!0};for(e=t.length-1;e>=0;e--)if(n=t[e],o=n[0],a=n[1],!(s.isStartWith(o,i.s_plain_obj)&&!s.isStartWith(o,i.mkPlainKeyForExparams())||u[o]))if(s.isStartWith(o,i.mkPlainKeyForExparams())){var c=i.param2arr(a);if("object"==typeof c&&c.length>0)for(var l=c.length-1;l>=0;l--){var p=c[l];p&&p[1]&&r.unshift([p[0],p[1]])}}else r.unshift([o,a]);return r}function r(){var t={isonepage:"-1",urlpagename:""},e=g.qGet();if(e&&e.hasOwnProperty("isonepage_data"))t.isonepage=e.isonepage_data.isonepage,t.urlpagename=e.isonepage_data.urlpagename;else{var n=c.getMetaCnt("isonepage")||"-1",o=n.split("|");t.isonepage=o[0],t.urlpagename=o[1]?o[1]:""}return t}var i=n(18),s=n(9),u=n(26),c=n(29),l=n(50),p=n(55),g=n(27),f=n(4),d=n(11);t.exports=function(){return{init:function(t){this.options=t},keyIsAvailable:function(t){var e=["functype","funcId","spm-cnt","spm-url","spm-pre","_ish5","_is_g2u","_h5url","cna","isonepage","lver","jsver"];return i.indexof(e,t)===-1},valIsAvailable:function(t){return"object"!=typeof t&&"function"!=typeof t},upUtData:function(t,e){var n=this;if(t=t?t:{},e&&"object"==typeof e)for(var o in e){var a=e[o];o&&n.valIsAvailable(a)&&n.keyIsAvailable(o)&&(t[o]=a)}return t},getToUtData:function(t){var e=u.getGoldlogVal("_$")||{},n=e.spm||{},s=this.options.context||{},c=!!s.is_single,p=s.what_to_sendpv||{},g=a(o(p.exparams||[]));g=i.arr2obj(g);var _=i.arr2obj(p.pvdata),h=a(o(s.userdata||[]));h=i.arr2obj(h);var m=location.href,v={},b=l.getParamFromUrl("scm",m)||"";b&&(v.scm=b);var y=l.getParamFromUrl("pg1stepk",m)||"";y&&(v.pg1stepk=y);var w=l.getParamFromUrl("point",m)||"";w&&(v.issb=1),_&&_.mansndlog&&(v.mansndlog=_.mansndlog),v=this.upUtData(v,g),v=this.upUtData(v,h);var x=r();v.functype="page",v.funcId="2001",v.url=goldlog.getMetaInfo("aplus-pagename")||location.origin+location.pathname,v._ish5="1",v._h5url=m,v._toUT=2,v._bridgeName=t.bridgeName||"",v._bridgeVersion=t.bridgeVersion||"",v["spm-cnt"]=n.spm_cnt||"",v["spm-url"]=n.spm_url||"",v["spm-pre"]=n.spm_pre||"",v.cna=d.getCookie("cna"),v.lver=goldlog.lver||f.lver,v.jsver=f.script_name,v.pver=goldlog.aplus_cplugin_ver,v.isonepage=x.isonepage;var j=goldlog.getMetaInfo("aplus-utparam");return j&&(v["utparam-cnt"]=JSON.stringify(j)),v._is_g2u_=c?1:2,v},run:function(){var t=this.options.context||{},e=t.what_to_sendpv_ut2||{},n=t.where_to_sendlog_ut||{},o=n.aplusToUT||{},a=o.toUT2||{};(a&&a.isAvailable&&"function"==typeof a.toUT2||p.haveNativeFlagInUA())&&(e.pvdataToUt=this.getToUtData(a),this.options.context.what_to_sendpv_ut2=e)}}}},function(t,e){"use strict";var n="UT4Aplus",o="Umeng4Aplus";e.isNative4Aplus=function(){var t=goldlog.getMetaInfo("aplus-toUT"),e=goldlog.aplusBridgeName;return e===n&&t===n||e===o},e.haveNativeFlagInUA=function(){var t=goldlog.aplusBridgeName;if(!t&&"boolean"!=typeof t){var e=new RegExp([n,o].join("|"),"i"),a=navigator.userAgent.match(e);t=!!a&&a[0],goldlog.aplusBridgeName=t}return!!t}},function(t,e,n){"use strict";function o(t){var e,n,o,a,i=[],s={};for(e=t.length-1;e>=0;e--)n=t[e],o=n[0],o&&o.indexOf(r.s_plain_obj)==-1&&s.hasOwnProperty(o)||(a=n[1],("aplus"==o||a)&&(i.unshift([o,a]),s[o]=1));return i}function a(t){var e,n,o,a,s=[],u={logtype:!0,cache:!0,scr:!0,"spm-cnt":!0};for(e=t.length-1;e>=0;e--)if(n=t[e],o=n[0],a=n[1],!(i.isStartWith(o,r.s_plain_obj)&&!i.isStartWith(o,r.mkPlainKeyForExparams())||u[o]))if(i.isStartWith(o,r.mkPlainKeyForExparams())){var c=r.param2arr(a);if("object"==typeof c&&c.length>0)for(var l=c.length-1;l>=0;l--){var p=c[l];p&&p[1]&&s.unshift([p[0],p[1]])}}else s.unshift([o,a]);return s}var r=n(18),i=n(9),s=n(26),u=n(29),c=n(55),l=n(27),p=n(4),g=n(11);t.exports=function(){return{init:function(t){this.options=t},getToUtData:function(t,e){var n,i=s.getGoldlogVal("_$")||{},c=i.spm||{},f=a(o(t)),d={};try{var _=r.arr2obj(f);_._toUT=1,_._bridgeName=e.bridgeName||"",_._bridgeVersion=e.bridgeVersion||"",n=JSON.stringify(_)}catch(t){n='{"_toUT":1}'}var h=u.getOnePageInfo(l);d.functype="2001",d.urlpagename=h.urlpagename,d.url=location.href,d.spmcnt=c.spm_cnt||"",d.spmurl=c.spm_url||"",d.spmpre=c.spm_pre||"",d.lzsid="",d.cna=g.getCookie("cna"),d.extendargs=n,d.isonepage=h.isonepage;var m=this.options.context||{},v=!!m.is_single;return d._is_g2u_=v?1:2,d.version=p.toUtVersion,d.lver=goldlog.lver||p.lver,d.jsver=p.script_name,d},run:function(){var t=this.options.context||{},e=t.what_to_sendpv||{},n=e.pvdata||[],o=t.what_to_sendpv_ut||{},a=t.where_to_sendlog_ut||{},r=a.aplusToUT||{},i=r.toUT||{};(i&&i.isAvailable&&"function"==typeof i.toUT2||c.haveNativeFlagInUA())&&(o.pvdataToUt=this.getToUtData(n,i),this.options.context.what_to_sendpv_ut=o)}}}},function(t,e){"use strict";t.exports=function(){return{init:function(t){this.options=t},run:function(){var t=this.options.context||{},e=t.is_single?"1":"0";if(t.what_to_sendpv_ut2.pvdataToUt._slog=e,t.what_to_sendpv_ut.pvdataToUt._slog=e,t.what_to_sendpv.pvdata.push(["_slog",e]),t.ut_is_available){var n=t.is_single?"1":"2";t.what_to_sendpv.pvdata.push(["_is_g2u",n])}}}}},function(t,e,n){"use strict";var o=n(26);t.exports=function(){return{init:function(t){this.options=t},run:function(){var t=o.getGoldlogVal("_$")||{},e=this.options.context.can_to_sendpv||{},n=t.send_pv_count||0,a=this.options.config||{};return a.is_auto&&n>0?"done":(e.flag="YES",this.options.context.can_to_sendpv=e,t.send_pv_count=++n,void o.setGoldlogVal("_$",t))}}}},function(t,e,n){"use strict";var o=n(55);t.exports=function(){return{init:function(t){this.options=t},run:function(t,e){var n=this,a=this.options.context||{},r=a.what_to_sendpv_ut2||{},i=a.where_to_sendlog_ut||{},s=r.pvdataToUt||{},u=i.aplusToUT||{},c=u.toUT2;if(o.isNative4Aplus())return u.toutflag="toUT2",i.toUTName="toUT2",void(n.options.context.what_to_sendpv_ut2.isSuccess=!0);if(c&&"function"==typeof c.toUT2&&c.isAvailable)try{u.toutflag="toUT2",c.toUT2(s,function(){n.options.context.what_to_sendpv_ut2.isSuccess=!0,e("done")},function(t){n.options.context.what_to_sendpv_ut2.errorMsg=t,e()},2e3)}catch(t){e()}finally{return"pause"}}}}},function(t,e,n){"use strict";var o=n(3);t.exports=function(){return{init:function(t){this.options=t},run:function(t,e){var n=this,a=this.options.context||{},r=a.what_to_sendpv_ut||{},i=a.what_to_sendpv_ut2||{},s=a.where_to_sendlog_ut||{},u=r.pvdataToUt||{},c=s.aplusToUT||{},l=c.toUT;if(!i.isSuccess&&l&&"function"==typeof l.toUT2&&l.isAvailable)try{l.toUT2(u,function(){c.toutflag="toUT",n.options.context.what_to_sendpv_ut.isSuccess=!0,e()},function(t){o.do_tracker_jserror({message:"do_sendpv_ut error",error:JSON.stringify(t),filename:"do_sendpv_ut"}),e()},5e3)}catch(t){e()}finally{return"pause"}}}}},function(t,e,n){"use strict";var o=n(26),a=n(18);t.exports=function(){return{init:function(t){this.options=t},run:function(){var t=this.options.context||{},e=t.what_to_sendpv_ut||{},n=t.what_to_sendpv_ut2||{},r=!!t.is_single;if(!r||!e.isSuccess&&!n.isSuccess){var i=t.what_to_sendpv||{},s=t.where_to_sendpv||{},u=i.pvdata||[],c=goldlog.send(s.url,a.arr2obj(u));o.setGoldlogVal("req",c)}}}}},function(t,e,n){"use strict";var o=n(33),a=n(26);t.exports=function(){return{init:function(t){this.options=t},run:function(){var t=goldlog._$||{},e=this.options.context||{};a.setGoldlogVal("pv_context",e);var n=goldlog.spm_ab||[],r=n.join("."),i=t.send_pv_count,s={cna:e.etag.cna,count:i,spmab_pre:goldlog.spmab_pre};o.doPubMsg(["sendPV","complete",r,s]),o.doCachePubs(["sendPV","complete",r,s])}}}},function(t,e){"use strict";e.plugins_prepv=[]},function(t,e,n){"use strict";function o(){return{where_to_hjlj:{url:"//gj.mmstat.com/",ac_atpanel:"//gj.mmstat.com/",tblogUrl:"//gj.mmstat.com/"}}}function a(){return r.assign(new i,new o)}var r=n(9),i=n(65);t.exports=a},function(t,e,n){"use strict";function o(){return{compose:{},basic_params:{cna:a.getCookie("cna")},where_to_hjlj:{url:"//gm.mmstat.com/",ac_atpanel:"//ac.mmstat.com/",tblogUrl:"//log.mmstat.com/"},userdata:{},what_to_hjlj:{logdata:{}},what_to_pvhash:{hash:[]},what_to_hjlj_exinfo:{EXPARAMS_FLAG:"EXPARAMS",exinfo:[],exparams_key_names:["uidaplus","pc_i","pu_i"]},what_to_hjlj_ut:{logdataToUT:{}},what_to_hjlj_ut2:{isSuccess:!1,logdataToUT:{}},where_to_sendlog_ut:{aplusToUT:{},toUTName:"toUT"},network:{connType:"UNKNOWN"},is_single:!1}}var a=n(11);t.exports=o},function(t,e,n){"use strict";e.plugins_hjlj=[{name:"etag",enable:!0,path:n(38)},{name:"where_to_sendlog_ut",enable:!0,path:n(40)},{name:"is_single",enable:!0,path:n(42)},{name:"what_to_hjlj_exinfo",enable:!0,path:n(67)},{name:"what_to_pvhash",enable:!0,path:n(43)},{name:"what_to_hjlj",enable:!0,path:n(68),deps:["what_to_hjlj_exinfo","what_to_pvhash"]},{name:"what_to_hjlj_ut2",enable:!0,path:n(69),deps:["is_single","what_to_hjlj_exinfo"]},{name:"what_to_hjlj_ut",enable:!0,path:n(72),deps:["is_single","what_to_hjlj_exinfo"]},{name:"what_to_hjlj_slog",enable:!0,path:n(73),deps:["what_to_hjlj","what_to_hjlj_ut2","what_to_hjlj_ut"]},{name:"where_to_hjlj",enable:!0,path:n(74),deps:["is_single","what_to_hjlj"]},{name:"do_sendhjlj_ut2",enable:!0,path:n(75),deps:["what_to_hjlj","what_to_hjlj_ut2","where_to_sendlog_ut"]},{name:"do_sendhjlj_ut",enable:!0,path:n(76),deps:["what_to_hjlj","what_to_hjlj_ut","where_to_sendlog_ut","do_sendhjlj_ut2"]},{name:"do_sendhjlj",enable:!0,path:n(77),deps:["is_single","what_to_hjlj","where_to_hjlj","do_sendhjlj_ut"]}]},function(t,e,n){"use strict";var o=n(18),a=n(31),r=n(26),i=n(26),s=n(12),u=n(11);t.exports=function(){return{init:function(t){this.options=t},getCookieUserInfo:function(){var t=[],e=u.getCookie("workno")||u.getCookie("emplId");e&&t.push("workno="+e);var n=u.getHng();return n&&t.push("_hng="+u.getHng()),t},filterExinfo:function(t){var e="";try{t&&("string"==typeof t?e=t.replace(/&amp;/g,"&").replace(/\buser(i|I)d=/,"uidaplus=").replace(/&aplus&/,"&"):"object"==typeof t&&(e=o.obj2param(t,!0)))}catch(t){e=t.message?t.message:""}return e},getExparamsFlag:function(){var t=this.options.context||{},e=t.what_to_hjlj_exinfo||{};return e.EXPARAMS_FLAG||"EXPARAMS"},getCustomExParams:function(t){var e="";return t!==this.getExparamsFlag()&&(e=this.filterExinfo(t)||""),e?e.split("&"):[]},getBeaconExparams:function(t,e){var n=[],r=a.getExParams(o)||"";r=r.replace(/&aplus&/,"&");for(var i=o.param2arr(r)||[],u=function(e){return s.indexof(t,e)>-1},c=0;c<i.length;c++){var l=i[c],p=l[0]||"",g=l[1]||"";p&&g&&(e===this.getExparamsFlag()||u(p))&&n.push(p+"="+g)}return n},getExinfo:function(t){var e=this.options.context||{},n=e.what_to_hjlj_exinfo||{},o=n.exparams_key_names||[],a=this.getBeaconExparams(o,t);return a},getExData:function(t){var e=[];if("object"==typeof t)for(var n in t){var o=t[n];n&&o&&"object"!=typeof o&&"function"!=typeof o&&e.push(n+"="+o)}return e},doConcatArr:function(t,e){return e&&e.length>0&&(t=t.concat(e)),t},run:function(){try{var t=this.options.context.what_to_hjlj_exinfo||{},e=r.getGoldlogVal("_$")||{},n=e.meta_info||{},o=n["aplus-exinfo"]||"",a=n["aplus-exdata"]||"",s=[];s=this.doConcatArr(s,t.exinfo||[]),s=this.doConcatArr(s,this.getExinfo(o)),s=this.doConcatArr(s,this.getCookieUserInfo()),s=this.doConcatArr(s,this.getCustomExParams(o)),s=this.doConcatArr(s,this.getExData(a)),t.exinfo=s.join("&"),this.options.context.what_to_hjlj_exinfo=t}catch(t){i.logger({msg:t?t.message:""})}}}}},function(t,e,n){"use strict";var o=n(31),a=n(18),r=n(11),i=n(9),s=n(4);t.exports=function(){return{init:function(t){this.options=t},getParams:function(){var t=this.options.context||{},e=t.userdata||{},n=t.basic_params||{},u=t.what_to_hjlj_exinfo||{},c=u.exinfo||"",l=t.etag||{},p=l.cna||n.cna||r.getCookie("cna"),g=e.gmkey,f="";e.gokey&&c?f=[e.gokey,c].join("&"):e.gokey?f=e.gokey:c&&(f=c);var d=t.what_to_pvhash||{},_=d.hash||[];_.length&&(f+="&"+_.join("=")),f+="&jsver="+s.script_name,f+="&lver="+s.lver,f+="&pver="+goldlog.aplus_cplugin_ver,f+="&cache="+i.makeCacheNum(),f+="&page_cna="+p;var h={gmkey:g||"",gokey:f,cna:p};try{var m=location.href.substring(0,1200);m&&(h._p_url=goldlog.getMetaInfo("aplus-p-url")||m)}catch(t){}e["spm-cnt"]&&(h["spm-cnt"]=e["spm-cnt"]),e["spm-pre"]&&(h["spm-pre"]=e["spm-pre"]);try{var v=o.getExParams(a),b=a.param2obj(v).uidaplus;b&&(h._gr_uid_=b);var y=a.param2obj(f).uidaplus;y&&(h.uidaplus=y)}catch(t){}return h},run:function(){this.options.context.what_to_hjlj.logdata=this.getParams()}}}},function(t,e,n){"use strict";var o=n(70),a=n(26),r=n(4);t.exports=function(){return{init:function(t){this.options=t},getToUtData:function(t,e){var n=a.getGoldlogVal("_$")||{},i=n.spm||{},s=this.options.context.userdata||{},u=this.options.context.basic_params||{},c=this.options.context||{},l=c.what_to_hjlj_exinfo||{},p=l.exinfo||"",g="";s.gokey&&p?g=[s.gokey,p].join("&"):s.gokey?g=s.gokey:p&&(g=p);var f={};f.functype="ctrl",f.funcId=o.getFunctypeValue2({logkey:s.logkey,gmkey:s.gmkey,spm_ab:a.getGoldlogVal("spm_ab")}),f.url=goldlog.getMetaInfo("aplus-pagename")||location.origin+location.pathname,f.logkey=s.logkey,f.gokey=encodeURIComponent(g),f.gmkey=s.gmkey,f._ish5="1",f._h5url=location.href,f._is_g2u_=t?1:2,f._toUT=2,f._bridgeName=e.bridgeName||"",f._bridgeVersion=e.bridgeVersion||"",f["spm-cnt"]=i.spm_cnt||"",f["spm-url"]=i.spm_url||"",f["spm-pre"]=i.spm_pre||"",f.cna=u.cna,f.lver=r.lver,f.jsver=r.script_name,s.hasOwnProperty("autosend")&&(f.autosend=s.autosend);var d=goldlog.getMetaInfo("aplus-utparam");return d&&(f["utparam-cnt"]=JSON.stringify(d)),f},run:function(){var t=this.options.context||{},e=t.what_to_hjlj_ut2||{},n=!!t.is_single,o=t.where_to_sendlog_ut||{},a=o.aplusToUT||{},r=a.toUT2||{};e.logdataToUT=this.getToUtData(n,r),this.options.context.what_to_hjlj_ut2=e}}}},function(t,e,n){"use strict";var o=n(71),a=n(55),r=function(t){var e=t.logkey.toLowerCase();0===e.indexOf("/")&&(e=e.substr(1));var n=t.gmkey?t.gmkey.toUpperCase():"OTHER";switch(n){case"EXP":return"2201";case"CLK":return"2101";case"SLD":return"19999";case"OTHER":default:return"19999"}},i=/\sA2U\/x/.test(window.navigator.userAgent),s=function(){var t=window.navigator.userAgent,e=!1,n=/AliApp\((DM|DY|DingTalk|CN|LA)\/(\d+[._]\d+[._]\d+)/i,r=n.test(t);return e=r,i||a.haveNativeFlagInUA()||e||o.webviewIsAbove({version_ios_tb:[5,11,7],version_ios_tm:[5,24,1],version_android_tb:[5,11,7],version_android_tm:[5,24,1]})};e.isSingleUaVersion=s,e.isSingleSendLog=function(t){return(!t||!/^\/fsp\.1\.1$/.test(t.logkey))&&!!(t&&t.logkey&&s())},e.getFunctypeValue=function(t){return e.isSingleSendLog(t)?r(t):"2101"},e.getFunctypeValue2=function(t){return r(t)}},function(t,e){"use strict";var n=function(t){var e=[0,0,0];try{if(t){var n=t[1],o=n.split(".");if(o.length>2)for(var a=0;a<o.length;)e[a]=parseInt(o[a]),a++}}catch(t){e=[0,0,0]}finally{return e}};e.parseVersion=n;var o=function(t,e){var n=!1;try{var o=t[0]>e[0],a=t[1]>e[1],r=t[2]>e[2],i=t[0]===e[0],s=t[1]===e[1],u=t[2]===e[2];n=!!o||(!(!i||!a)||(!!(i&&s&&r)||!!(i&&s&&u)))}catch(t){n=!1}finally{return n}};e.isAboveVersion=o,e.webviewIsAbove=function(t,e){var a=!1;try{e||(e=navigator.userAgent);var r=e.match(/AliApp\(TB\/(\d+[._]\d+[._]\d+)/i),i=n(r),s=e.match(/AliApp\(TM\/(\d+[._]\d+[._]\d+)/i),u=n(s),c=/iPhone|iPad|iPod|ios/i.test(e),l=/android/i.test(e);c?r&&i?a=o(i,t.version_ios_tb):s&&u&&(a=o(u,t.version_ios_tm)):l&&(r&&i?a=o(i,t.version_android_tb):s&&u&&(a=o(u,t.version_android_tm)))}catch(t){a=!1}return a},e.webviewIsEqual=function(t,e){var n=!1;try{e||(e=navigator.userAgent);var o=e.match(/AliApp\(CN\/(\d+[._]\d+[._]\d+)/i),a=o?o[1]:"0.0.0",r=e.match(/AliApp\(DingTalk\/(\d+[._]\d+[._]\d+)/i),i=r?r[1]:"0.0.0",s=/iPhone|iPad|iPod|ios/i.test(e),u=/android/i.test(e);s?o&&a?n=t.version_ios_cn===a:r&&i&&(n=t.version_ios_dd===i):u&&(o&&a?n=t.version_android_cn===a:r&&i&&(n=t.version_android_dd===i))}catch(t){n=!1}return n},e.webviewIsBelow=function(t,e){var a=!1;try{e||(e=navigator.userAgent);var r=e.match(/AliApp\(CN\/(\d+[._]\d+[._]\d+)/i),i=n(r),s=/iPhone|iPad|iPod|ios/i.test(e),u=/android/i.test(e);s?r&&i&&(a=!o(i,t.version_ios_cn)):u&&r&&i&&(a=!o(i,t.version_android_cn))}catch(t){a=!1}return a}},function(t,e,n){"use strict";var o=n(70),a=n(11),r=n(26),i=n(4);t.exports=function(){return{init:function(t){this.options=t},getToUtData:function(t,e){var n=r.getGoldlogVal("_$")||{},s=n.spm||{},u=this.options.context||{},c=u.userdata||{},l=u.what_to_hjlj_exinfo||{},p=l.exinfo||"",g="";c.gokey&&p?g=[c.gokey,p].join("&"):c.gokey?g=c.gokey:p&&(g=p);var f={gmkey:c.gmkey,gokey:g,lver:i.lver,jsver:i.script_name,version:i.toUtVersion,spm_cnt:s.spm_cnt||"",spm_url:s.spm_url||"",spm_pre:s.spm_pre||""};f._is_g2u_=t?1:2,f._bridgeName=e.bridgeName||"",f.bridgeVersion=e.bridgeVersion||"",f._toUT=1;try{f=JSON.stringify(f),"{}"==f&&(f="")}catch(t){f=""}var d=n.meta_info||{},_=d.isonepage_data||{},h={};return h.functype=o.getFunctypeValue({logkey:c.logkey,gmkey:c.gmkey,spm_ab:r.getGoldlogVal("spm_ab")}),h.spmcnt=s.spm_cnt||"",h.spmurl=s.spm_url||"",h.spmpre=s.spm_pre||"",h.logkey=c.logkey,h.logkeyargs=f,h.urlpagename=_.urlpagename,h.url=location.href,h.cna=a.getCookie("cna")||"",h.extendargs="",h.isonepage=_.isonepage,h},run:function(){var t=this.options.context||{},e=!!t.is_single,n=t.what_to_hjlj_ut||{},o=t.where_to_sendlog_ut||{},a=o.aplusToUT||{},r=a.toUT||{};n.logdataToUT=this.getToUtData(e,r),this.options.context.what_to_hjlj_ut=n}}}},function(t,e){"use strict";t.exports=function(){return{init:function(t){this.options=t},run:function(){var t=this.options.context||{},e=t.is_single?"1":"0";t.what_to_hjlj_ut2.logdataToUT._slog=e,t.what_to_hjlj_ut.logdataToUT._slog=e;var n=["_slog="+e];if(t.ut_is_available){var o=t.is_single?"1":"2";n.push("_is_g2u="+o)}t.what_to_hjlj.logdata.gokey?t.what_to_hjlj.logdata.gokey+="&"+n.join("&"):t.what_to_hjlj.logdata.gokey=n.join("&")}}}},function(t,e,n){"use strict";var o=n(18),a=n(9),r=n(26),i=n(24),s=n(27);t.exports=function(){return{init:function(t){this.options=t},getMetaInfo:function(){var t=r.getGoldlogVal("_$")||{},e=t.meta_info||s.getInfo();return e},getAplusMetaByKey:function(t){var e=this.getMetaInfo()||{};return e[t]},cramUrl:function(t){var e=r.getGoldlogVal("_$")||{},n=e.spm||{},o=this.options.context.where_to_hjlj||{},i=o.ac_atpanel,s=o.tblogUrl,u=this.options.context.what_to_hjlj||{},c=this.options.context.userdata||{},l=!0,p=c.logkey;if(!p)return{url:t,logkey_available:!1};if("ac"==p)t=i+"1.gif";else if(a.isStartWith(p,"ac-"))t=i+p.substr(3);else if(a.isStartWith(p,"/")){t+=p.substr(1);var g=u.logdata||{};g["spm-cnt"]=n.spm_cnt,g.logtype=2;try{u.logdata=g,this.options.context.what_to_hjlj=u}catch(t){}}else a.isEndWith(p,".gif")?t=s+p:l=!1;return{url:t,logkey_available:l}},can_to_sendhjlj:function(t){var e=this.options.context||{},n=e.logger||function(){},o=this.options.context.userdata||{};return!!t.logkey_available||(n({msg:"logkey: "+o.logkey+" is not legal!"}),!1)},run:function(){var t,e,n=this.options.context.where_to_hjlj.url,a=this.getAplusMetaByKey("aplus-rhost-g"),r=a&&o.hostValidity(a);r&&(t=/^\/\//.test(a)?"":"//",e=/\/$/.test(a)?"":"/",n=t+a+e),a&&!r&&i.logger({msg:"aplus-rhost-g: "+a+' is invalid, suggestion: "xxx.mmstat.com"'});var s=this.cramUrl(n);return this.can_to_sendhjlj(s)?void(this.options.context.where_to_hjlj.url=s.url):"done"}}}},function(t,e,n){"use strict";var o=n(55);t.exports=function(){return{init:function(t){this.options=t},run:function(t,e){var n=this,a=this.options.context||{},r=a.logger||function(){},i=a.what_to_hjlj_ut2||{},s=a.where_to_sendlog_ut||{},u=!!a.is_single,c=i.logdataToUT||{},l=s.aplusToUT||{},p=l.toUT2;if(o.isNative4Aplus())return l.toutflag="toUT2",s.toUTName="toUT2",void(n.options.context.what_to_hjlj_ut2.isSuccess=!0);if(p&&"function"==typeof p.toUT2&&p.isAvailable)try{l.toutflag="toUT2",p.toUT2(c,function(){n.options.context.what_to_hjlj_ut2.isSuccess=!0,e()},function(t){n.options.context.what_to_hjlj_ut2.errorMsg=t,e()},2e3)}catch(t){u&&r({msg:"warning: singleSendHjlj toUTName = toUT2 errorMsg:"+t.message})}finally{return"pause"}}}}},function(t,e){"use strict";t.exports=function(){return{init:function(t){this.options=t},run:function(t,e){var n=this,o=this.options.context||{},a=o.what_to_hjlj_ut2.isSuccess,r=o.logger||function(){},i=!!o.is_single,s=o.where_to_sendlog_ut||{},u=o.what_to_hjlj_ut||{},c=u.logdataToUT||{},l=s.aplusToUT||{},p=l.toUT;if(!a&&p&&"function"==typeof p.toUT2&&p.isAvailable)try{p.toUT2(c,function(){l.toutflag="toUT",n.options.context.what_to_hjlj_ut.isSuccess=!0,e()},function(){e()},5e3)}catch(t){i&&r({msg:"warning: singleSendHjlj toUTName = toUT errorMsg:"+t.message})}finally{return"pause"}}}}},function(t,e,n){"use strict";var o=n(26);t.exports=function(){return{init:function(t){this.options=t},run:function(){var t=this.options.context||{},e=this.options.config||{},n=t.what_to_hjlj_ut.isSuccess,a=t.what_to_hjlj_ut2.isSuccess,r=!!t.is_single;if(!r||!n&&!a){var i=t.logger||{},s=t.what_to_hjlj||{},u=t.where_to_hjlj||{},c=s.logdata||{},l=u.url||"";l||"function"!=typeof i||i({msg:"warning: where_to_hjlj.url is null, goldlog.record failed!"});var p=goldlog.getMetaInfo("aplus-channel");if("WS-ONLY"!==p){var g=goldlog.send(u.url,c,e.method||"GET");o.setGoldlogVal("req",g)}}}}}},function(t,e,n){"use strict";function o(){var t,e,n=i.KEY||{},o=n.NAME_STORAGE||{};if(!c&&u){var a=location.href,l=u&&(a.indexOf("login.taobao.com")>=0||a.indexOf("login.tmall.com")>=0),p=s.getRefer();l&&p?(t=p,e=r.getItem(o.REFERRER_PV_ID)):(t=a,e=goldlog.pvid),r.setItem(o.REFERRER,t),r.setItem(o.REFERRER_PV_ID,e)}}var a=n(79),r=n(52).nameStorage,i=n(4),s=n(51),u="https:"==location.protocol,c=parent!==self;e.run=function(){var t="beforeunload";a.on(window,t,function(){o()})}},function(t,e,n){"use strict";function o(t,e,n){var o=goldlog._$||{},a=o.meta_info||{},r=a.aplus_ctap||{},i=a["aplus-touch"];if(r&&"function"==typeof r.on)r.on(t,e);else{var u="ontouchend"in document.createElement("div");!u||"tap"!==i&&"tapSpm"!==n?s(t,u?"touchstart":"mousedown",e):c.on(t,e)}}function a(t){try{p.documentElement.doScroll("left")}catch(e){return void setTimeout(function(){a(t)},1)}t()}function r(t){var e=0,n=function(){0===e&&t(),e++};"complete"===p.readyState&&n();var o;if(p.addEventListener)o=function(){p.removeEventListener("DOMContentLoaded",o,!1),n()},p.addEventListener("DOMContentLoaded",o,!1),window.addEventListener("load",n,!1);else if(p.attachEvent){o=function(){"complete"===p.readyState&&(p.detachEvent("onreadystatechange",o),n())},p.attachEvent("onreadystatechange",o),window.attachEvent("onload",n);var r=!1;try{r=null===window.frameElement}catch(t){}p.documentElement.doScroll&&r&&a(n)}}function i(t){"complete"===p.readyState?t():s(l,"load",t)}function s(){var t=arguments;if(2===t.length)"DOMReady"===t[0]&&r(t[1]),"onload"===t[0]&&i(t[1]);else if(3===t.length){var e=t[0],n=t[1],a=t[2];"tap"===n||"tapSpm"===n?o(e,a,n):e[_]((g?"on":"")+n,function(t){t=t||l.event;var e=t.target||t.srcElement;"function"==typeof a&&a(t,e)},!!u(n)&&{passive:!0})}}var u=n(80),c=n(81),l=window,p=document,g=!!p.attachEvent,f="attachEvent",d="addEventListener",_=g?f:d;e.DOMReady=r,e.onload=i,e.on=s},function(t,e){var n;t.exports=function(t){if("boolean"==typeof n)return n;if(!/touch|mouse|scroll|wheel/i.test(t))return!1;n=!1;try{var e=Object.defineProperty({},"passive",{get:function(){n=!0}});window.addEventListener("test",null,e)}catch(t){}return n}},function(t,e){"use strict";function n(t,e){return t+Math.floor(Math.random()*(e-t+1))}function o(t,e,n){var o=l.createEvent("HTMLEvents");if(o.initEvent(e,!0,!0),"object"==typeof n)for(var a in n)o[a]=n[a];t.dispatchEvent(o)}function a(t){0===Object.keys(g).length&&(p.addEventListener(_,r,!1),p.addEventListener(d,i,!1),p.addEventListener(m,i,!1));for(var e=0;e<t.changedTouches.length;e++){
var n=t.changedTouches[e],o={};for(var a in n)o[a]=n[a];var s={startTouch:o,startTime:Date.now(),status:h,element:t.srcElement||t.target};g[n.identifier]=s}}function r(t){for(var e=0;e<t.changedTouches.length;e++){var n=t.changedTouches[e],o=g[n.identifier];if(!o)return;var a=n.clientX-o.startTouch.clientX,r=n.clientY-o.startTouch.clientY,i=Math.sqrt(Math.pow(a,2)+Math.pow(r,2));(o.status===h||"pressing"===o.status)&&i>10&&(o.status="panning")}}function i(t){for(var e=0;e<t.changedTouches.length;e++){var n=t.changedTouches[e],a=n.identifier,s=g[a];s&&(s.status===h&&t.type===d&&(s.timestamp=Date.now(),o(s.element,v,{touch:n,touchEvent:t})),delete g[a])}0===Object.keys(g).length&&(p.removeEventListener(_,r,!1),p.removeEventListener(d,i,!1),p.removeEventListener(m,i,!1))}function s(t){t.__fixTouchEvent||(t.addEventListener(f,function(){},!1),t.__fixTouchEvent=!0)}function u(){c||(p.addEventListener(f,a,!1),c=!0)}var c=!1,l=window.document,p=l.documentElement,g={},f="touchstart",d="touchend",_="touchmove",h="tapping",m="touchcancel",v="aplus_tap"+n(1,1e5);t.exports={on:function(t,e){u(),t&&t.addEventListener&&e&&(s(t),t.addEventListener(v,e._aplus_tap_callback=function(t){e(t,t.target)},!1))},un:function(t,e){t&&t.removeEventListener&&e&&e._aplus_tap_callback&&t.removeEventListener(v,e._aplus_tap_callback,!1)}}},function(t,e,n){"use strict";function o(){var t=goldlog._$||{},e=t.meta_info||{},n=goldlog.getCdnPath(),o=n+"/sd/baxia-entry/index.js",i=function(){a.addScript(o,"","aplus-baxia")};r.onload(function(){try{var t=e["aplus-xplug"];"NONE"!==t&&i()}catch(t){}})}var a=n(31),r=n(79),i=n(83);e.run=function(){o()},e.init_watchGoldlogQueue=i.init_watchGoldlogQueue},function(t,e,n){"use strict";function o(t,e){for(var n={subscribeMwChangeQueue:[],subscribeMetaQueue:[],subscribeQueue:[],metaQueue:[],othersQueue:[]},o=[],a={};a=t.shift();)try{var r=a.action,i=a.arguments[0];/subscribe/.test(r)?"setMetaInfo"===i?n.subscribeMetaQueue.push(a):"mw_change_pv"===i||"mw_change_hjlj"===i?n.subscribeMwChangeQueue.push(a):n.subscribeQueue.push(a):/MetaInfo/.test(r)?n.metaQueue.push(a):n.othersQueue.push(a)}catch(t){n.othersQueue.push(a),u.do_tracker_jserror({message:t&&t.message,error:encodeURIComponent(t.stack),filename:"getFormatQueue"})}var s;return e&&n[e]&&(s=n[e],n[e]=[]),o=n.subscribeMwChangeQueue.concat(n.metaQueue),o=o.concat(n.subscribeQueue),o=o.concat(n.subscribeMetaQueue,n.othersQueue),{queue:o,formatQueue:s}}var a=window,r=n(9),i=n(84),s=n(85),u=n(3),c="goldlog_queue",l=function(t,e,n){try{/_aplus_cplugin_track_deb/.test(t)||/_aplus_cplugin_m/.test(t)||u.do_tracker_jserror({message:n||'illegal task: goldlog_queue.push("'+JSON.stringify(e)+'")',error:JSON.stringify(e),filename:"processTask"})}catch(t){}},p=function(t,e){var n=t?t.action:"",o=t?t.arguments:"";try{if(n&&o&&r.isArray(o)){var i=n.split("."),s=a,u=a;if(3===i.length)s=a[i[0]][i[1]]||{},u=s[i[2]]?s[i[2]]:"";else for(;i.length;)if(u=s=s[i.shift()],!s)return void("function"==typeof e?e(t):l(n,t));"function"==typeof u&&u.apply(s,o)}else l(n,t)}catch(e){l(n,t,e.message)}},g=function(t){function e(){if(t&&r.isArray(t)&&t.length){for(var e=o(t).queue,n={},a=[];n=e.shift();)p(n,function(t){a.push(t)});a.length>0&&setTimeout(function(){for(;n=a.shift();)p(n)},100)}}try{e()}catch(t){u.do_tracker_jserror({message:t&&t.message,error:encodeURIComponent(t.stack),filename:"processGoldlogQueue"})}};e.processGoldlogQueue=g;var f=i.extend({push:function(t){this.length++,p(t)}});e.init_watchGoldlogQueue=function(t){try{var e=a[c]||[];if(t){var n=o(e,t);a[c]=n.queue,g(n.formatQueue)}else a[c]=f.create({startLength:e.length,length:0}),s.init_loadAplusPlugin(),g(e)}catch(t){u.do_tracker_jserror({message:t&&t.message,error:encodeURIComponent(t.stack),filename:"init_watchGoldlogQueue"})}}},function(t,e){"use strict";function n(){}n.prototype.extend=function(){},n.prototype.create=function(){},n.extend=function(t){return this.prototype.extend.call(this,t)},n.prototype.create=function(t){var e=new this;for(var n in t)e[n]=t[n];return e},n.prototype.extend=function(t){var e=function(){};try{"function"!=typeof Object.create&&(Object.create=function(t){function e(){}return e.prototype=t,new e}),e.prototype=Object.create(this.prototype);for(var n in t)e.prototype[n]=t[n];e.prototype.constructor=e,e.extend=e.prototype.extend,e.create=e.prototype.create}catch(t){console.log(t)}finally{return e}},t.exports=n},function(t,e,n){"use strict";var o=n(31),a=n(29),r=n(6),i=function(){var t=goldlog.getCdnPath()+"/alilog/s/"+r.lver+"/plugin/";return{aplus_ae_path:t+"aplus_ae.js",aplus_ac_path:t+"aplus_ac.js"}},s={},u="aplus-auto-exp",c="aplus-auto-clk",l=function(t,e){var n=i(),r=goldlog&&goldlog.getMetaInfo?goldlog.getMetaInfo(t):"",l=e||r||a.getMetaCnt(t),p={};p[u]=n.aplus_ae_path,p[c]=n.aplus_ac_path,l&&p[t]&&!s[t]&&(o.addScript(p[t]),s[t]=!0)};e.init_loadAplusPlugin=function(){try{!goldlog._aplus_auto_exp&&l(u),!goldlog._aplus_ac&&l(c),goldlog.aplus_pubsub.subscribe("setMetaInfo",function(t,e){t!==u||goldlog._aplus_auto_exp||l(t,e),t!==c||goldlog._aplus_ac||l(t,e)})}catch(t){}}},function(t,e){"use strict";function n(t,e){return t.indexOf(e)>-1}function o(t,e){for(var o=0,a=t.length;o<a;o++)if(n(e,t[o]))return!0;return!1}var a=location.host,r=["admin.taobao.org","mybank.cn"],i=["tmc.admin.taobao.org","tmall.admin.taobao.org"];e.is_exception=o(r,a)&&!o(i,a)},function(t,e,n){"use strict";function o(){var t,e,n,o,a=c.getElementsByTagName("meta");for(t=0,e=a.length;t<e;t++)if(n=a[t],o=n.getAttribute("name"),"data-spm"===o||"spm-id"===o)return n}function a(){var t=c.createElement("meta");t.setAttribute("name","data-spm");var e=c.getElementsByTagName("head")[0];return e&&e.insertBefore(t,e.firstChild),t}function r(){var t=o();t||(t=a()),t.setAttribute("content",goldlog.spm_ab[0]||"");var e=c.getElementsByTagName("body")[0];e&&e.setAttribute("data-spm",goldlog.spm_ab[1]||"")}function i(){var t,e,n,o=c.getElementsByTagName("*");for(t=0,e=o.length;t<e;t++)n=o[t],n.getAttribute("data-spm-max-idx")&&n.setAttribute("data-spm-max-idx",""),n.getAttribute("data-spm-anchor-id")&&n.setAttribute("data-spm-anchor-id","")}function s(){var t=5e3;try{var e=goldlog.getMetaInfo("aplus-mmstat-timeout");if(e){var n=parseInt(e);n>=1e3&&n<=1e4&&(t=n)}}catch(t){}return t}var u=window,c=document,l=n(84),p=n(18),g=n(79),f=n(31),d=n(24),_=n(33),h=n(9),m=n(26),v=n(22),b=n(49),y=n(27),w=y.getInfo(),x=n(4),j=n(3),T=n(88),P=n(11),A=n(91),S=n(93),k=[],E=[],U=[],I=[],M="//g.alicdn.com",C="//g-assets.daily.taobao.net",N="//assets.alicdn.com/g",O="//s.alicdn.com/@g/",V="//u.alicdn.com",G="//laz-g-cdn.alicdn.com";e.run=l.extend({getCdnPath:function(){var t=f.getCurrentNode(),e=M,n=[N,O,C,V,G],o=new RegExp(V);if(t)for(var a=0;a<n.length;a++){var r=new RegExp(n[a]);if(r.test(t.src)){e=n[a],o.test(t.src)&&(e=N);break}}return e},isInternational:function(){this.cdnPath||(this.cdnPath=this.getCdnPath());var t=[N,O,G].indexOf(this.cdnPath)>-1;return t||"int"===this.getMetaInfo("aplus-env")},getCookie:function(t){return P.getCookie(t)},getParam:function(t){var e=u.WindVane||{},n=e&&"function"==typeof e.getParam?e.getParam(t):"";return n},beforeSendPV:function(t){k.push(t)},afterSendPV:function(t){E.push(t)},send:function(t,e,n){var o;if(0===t.indexOf("//")){var a=v.getProtocal();t=a+t}return o="POST"===n&&navigator&&navigator.sendBeacon?S.postData(t,e):S.sendImg(p.makeUrl(t,e),s())},launch:function(t,e){var n;try{e=h.assign(e,t),n=goldlog._$._sendPV(e,t);var o=goldlog.spm_ab?goldlog.spm_ab.join("."):"0.0";j.do_tracker_obsolete_inter({page:location.hostname+location.pathname,spm_ab:o,interface_name:"goldlog.launch",interface_params:"userdata = "+JSON.stringify(t)+", config = "+JSON.stringify(e)})}catch(t){}finally{return d.logger({msg:"warning: This interface is deprecated, please use goldlog.sendPV instead! API: http://log.alibaba-inc.com/log/info.htm?type=2277&id=31"}),n}},_$:{_sendPV:function(t,e){if(t=t||{},h.any(k,function(e){return e(goldlog,t)===!1}))return!1;var o=n(94).SendPV,a=new o;return"undefined"==typeof t.recordType&&(t.recordType=x.recordTypes.pv),a.run(t,e,{fn_after_pv:E}),!0},_sendPseudo:function(t,e){t||(t={});var o=n(95).SendPrePV,a=new o;return"undefined"==typeof t.recordType&&(t.recordType=x.recordTypes.prepv),a.run(t,e,{},function(){_.doPubMsg(["sendPrePV","complete"])}),!0}},sendPV:function(t,e){return e=e||{},e.pageName&&goldlog.setMetaInfo("aplus-pagename",e.pageName),goldlog._$._sendPV(t,e)},updatePageProperties:function(t){t&&"object"==typeof t?(t._page&&(t.pageName=t._page,delete t._page),t.pageName&&(goldlog.setMetaInfo("aplus-pagename",t.pageName),delete t.pageName),goldlog.appendMetaInfo("aplus-cpvdata",t)):d.logger({msg:"warning: typeof updatePageProperties's params must be object"})},beforeRecord:function(t){U.push(t)},afterRecord:function(t){I.push(t)},record:function(t,e,n,o,a){if(!h.any(U,function(t){return t(goldlog)===!1}))return"POST"!==o&&"WS"!==o&&"WS-ONLY"!==o&&(o="GET"),T.run({recordType:x.recordTypes.hjlj,method:o},{logkey:t,gmkey:e,gokey:n},{fn_after_record:I},function(){"function"==typeof a&&a()}),!0},recordUdata:function(t,e,n,o,a){var r=m.getGoldlogVal("_$")||{},i=r.spm||{};"POST"!==o&&"WS"!==o&&"WS-ONLY"!==o&&(o="GET"),T.run({ignore_chksum:!0,method:o,recordType:x.recordTypes.uhjlj},{logkey:t,gmkey:e,gokey:n,"spm-cnt":i.spm_cnt,"spm-pre":i.spm_pre},{},function(){h.isFunction(a)&&a()})},setPageSPM:function(t,e,n){var o="setPageSPM",a=goldlog.getMetaInfo("aplus-spm-fixed"),s="function"==typeof n?n:function(){};goldlog.spm_ab=goldlog.spm_ab||[];var u=h.cloneObj(goldlog.spm_ab);if(t&&(goldlog.spm_ab[0]=""+t,goldlog._$.spm.data.a=""+t),e&&(goldlog.spm_ab[1]=""+e,goldlog._$.spm.data.b=""+e),b.spaInit(goldlog,w,u),"1"!==a){var c=u.join(".");goldlog.spmab_pre=c}var l=goldlog.spm_ab.join(".");_.doPubMsg([o,{spmab_pre:goldlog.spmab_pre,spmab:l}]),_.doCachePubs([o,{spmab_pre:goldlog.spmab_pre,spmab:l}]),r(),i(),s()},setMetaInfo:function(t,e,n){if(y.setMetaInfo(t,e,n)){var o=m.getGoldlogVal("_$")||{};o.meta_info=y.qGet();var a=m.setGoldlogVal("_$",o),r=A.isDisablePvid()+"";return"aplus-disable-pvid"===t&&r!==e+""&&b.resetSpmCntPvid(),_.doPubMsg(["setMetaInfo",t,e,n]),_.doCachePubs(["setMetaInfo",t,e,n]),a}},appendMetaInfo:y.appendMetaInfo,getMetaInfo:function(t){return y.getMetaInfo(t)},on:g.on,cloneDeep:h.cloneDeep,getPvId:A.getPvId})},function(t,e,n){"use strict";var o=n(9),a=n(26),r=n(33),i=n(24),s=n(89),u=n(90),c=n(4);e.run=function(t,e,n,l){var p=new u;p.init({middleware:[],config:t,plugins:c.plugins_hjlj});var g=p.run(),f=new c.context_hjlj;f.userdata=e,f.logger=i.logger;var d={context:f,pubsub:a.getGoldlogVal("aplus_pubsub"),pubsubType:"hjlj"},_=new s;_.create(d),_.wrap(g,function(){d.context.status="complete",d.context.method=t.method,r.doPubMsg(["mw_change_hjlj",d.context]),n&&n.fn_after_record&&o.each(n.fn_after_record,function(t){t(window.goldlog)}),"function"==typeof l&&l()})()}},function(t,e,n){"use strict";function o(){}var a=n(12),r=n(23),i=n(24),s=n(3),u=n(11);o.prototype.create=function(t){for(var e in t)"undefined"==typeof this[e]&&(this[e]=t[e]);return this},o.prototype.pubsubInfo=function(t,e){try{t&&t.pubsub&&t.pubsub.publish("mw_change_"+t.pubsubType,t.context,e)}catch(t){}},o.prototype.calledList=[],o.prototype.setCalledList=function(t){a.indexof(this.calledList,t)===-1&&this.calledList.push(t)},o.prototype.resetCalledList=function(){this.calledList=[]},o.prototype.wrap=function(t,e){var n=this,o=this.context||{},c=o.compose||{},l=c.maxTimeout||1e4;return function(o){var c,p=t.length,g=0,f=0,d=function(){if(n.pubsubInfo(n,t[g]),g===p)return o="done",n.resetCalledList(),"function"==typeof e&&e.call(n,o),void clearTimeout(c);if(a.indexof(n.calledList,g)===-1){if(n.setCalledList(g),!t[g]||"function"!=typeof t[g][0])return;try{o=t[g][0].call(n,o,function(){g++,f=1,clearTimeout(c),d(g)})}catch(e){s.do_tracker_jserror({message:e?e.message:"compose middleware error",error:encodeURIComponent(e.stack),filename:t[g][1]})}}var _="number"==typeof o;if("pause"===o||_){f=0;var h=_?o:l,m=t[g]?t[g][1]:"";c=r.sleep(h,function(){if(0===f){var t="jump the middleware about "+m+", because waiting timeout maxTimeout = "+h+"ms!";i.logger({msg:t});var e=window.goldlog_queue||(window.goldlog_queue=[]);e.push({action:"goldlog._aplus_cplugin_m.do_tracker_browser_support",arguments:[{msg:t,spmab:goldlog.spm_ab,page:location.href,etag:n.context?JSON.stringify(n.context.etag):"",cna:document.cookie?u.getCookie("cna"):""}]}),o=null,g++,d(g)}})}else"done"===o?(g=p,d(g)):(g++,d(g))};return n.calledList&&n.calledList.length>0&&n.resetCalledList(),d(g)}},t.exports=o},function(t,e,n){"use strict";var o=n(12);t.exports=function(){return{init:function(t){this.opts=t,t&&"object"==typeof t.middleware&&t.middleware.length>0?this.middleware=t.middleware:this.middleware=[],this.plugins_name=[]},pubsubInfo:function(t,e){try{var n=t.pubsub;n&&n.publish("plugins_change_"+t.pubsubType,e)}catch(t){}},checkPluginLoader:function(t,e){var n=!0;if("object"==typeof e.enable&&"function"==typeof e.enable.isEnable?n=e.enable.isEnable(e.name):"boolean"==typeof e.enable&&(n=!!e.enable),!n)return!1;if(n&&e.deps&&e.deps.length>0)for(var a=0;a<e.deps.length;a++)if(o.indexof(this.plugins_name,e.deps[a])===-1)return!1;return!0},run:function(t){t||(t=0);var e=this,n=this.middleware,o=this.opts||{},a=o.plugins;if(a&&"object"==typeof a&&a.length>0){var r=a[t];if(this.checkPluginLoader(a,r)&&(this.plugins_name.push(r.name),n.push([function(t,n){e.pubsubInfo(this,r);var a=new r.path;return a.init({context:this.context,config:o.config}),a.run(t,n)},r.name])),t++,a[t])return this.run(t)}else window.console&&console.log("aplus plugins "+JSON.stringify(a)+" must be object of array!");return n}}}},function(t,e,n){"use strict";function o(){var t="true"===l.disablePvid;try{var e=goldlog.getMetaInfo("aplus-disable-pvid")+"";"true"===e?t=!0:"false"===e&&(t=!1)}catch(t){}return t}function a(t){function e(t){var e="0123456789abcdefhijklmnopqrstuvwxyzABCDEFHIJKLMNOPQRSTUVWXYZ",n="0123456789abcdefghijkmnopqrstuvwxyzABCDEFGHIJKMNOPQRSTUVWXYZ";return 1==t?e.substr(Math.floor(60*Math.random()),1):2==t?n.substr(Math.floor(60*Math.random()),1):"0"}for(var n,o="",a="0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ",r=!1;o.length<t;)n=a.substr(Math.floor(62*Math.random()),1),!r&&o.length<=2&&("g"==n.toLowerCase()||"l"==n.toLowerCase())&&(0===o.length&&"g"==n.toLowerCase()?Math.random()<.5&&(n=e(1),r=!0):1==o.length&&"l"==n.toLowerCase()&&"g"==o.charAt(0).toLowerCase()&&(n=e(2),r=!0)),o+=n;return o}function r(t,e,n){return t?u.hash(encodeURIComponent(t)).substr(0,e):n}function i(){var t=a(8),e=t.substr(0,4),n=t.substr(0,6);return[r(location.href,4,e),r(document.title,4,e),n].join("")}function s(){var t=goldlog.pvid;return goldlog.pvid=i(),c.doPubMsg(["pvidChange",{pre_pvid:t,pvid:goldlog.pvid}]),c.doCachePubs(["pvidChange",{pre_pvid:t,pvid:goldlog.pvid}]),o()?"":goldlog.pvid}var u=n(92),c=n(33),l=n(4);e.isDisablePvid=o,e.makePVId=s,e.getPvId=function(){return o()?"":goldlog.pvid}},function(t,e){"use strict";var n=1315423911;e.hash=function(t,e){var o,a,r=e||n;for(o=t.length-1;o>=0;o--)a=t.charCodeAt(o),r^=(r<<5)+a+(r>>2);var i=(2147483647&r).toString(16);return i}},function(t,e,n){"use strict";function o(t){if(!t)return"";var e=decodeURIComponent(t).match(/cache=\w+/);return e&&1===e.length?e[0].split("=")[1]:void 0}var a=n(3),r=window;e.sendImg=function(t,e){var n=new Image,i="_img_"+Math.random();r[i]=n;var s=function(){if(r[i])try{delete r[i]}catch(t){r[i]=void 0}};return n.onload=function(){s()},n.onerror=function(){a.do_tracker_jserror({message:"loadError",error:"",filename:"sendImg",logid:o(t)}),s()},setTimeout(function(){window[i]&&(a.do_tracker_jserror({message:"loadTimeout",error:e,filename:"sendImg",logid:o(t)}),window[i].src="",s())},e||3e3),n.src=t,n=null,t},e.postData=function(t,e){var n;if("string"==typeof e)n=e;else{for(var o in e)["cna"].indexOf(o)===-1&&(e[o]=encodeURIComponent(e[o]));n=JSON.stringify(e)}return navigator.sendBeacon(t,n),t}},function(t,e,n){"use strict";var o=n(9),a=n(26),r=n(33),i=n(24),s=n(89),u=n(90),c=n(4),l=function(){};l.prototype.run=function(t,e,n){var l=new u;l.init({middleware:[],config:t,plugins:c.plugins_pv});var p=l.run(),g=new c.context;g.userdata=e,g.logger=i.logger;var f={context:g,pubsub:a.getGoldlogVal("aplus_pubsub"),pubsubType:"pv"},d=new s;d.create(f),d.wrap(p,function(){var e=f.context.can_to_sendpv||{};f.context.status="YES"===e.flag?"complete":"skip",f.context.method=t.method||"GET",r.doPubMsg(["mw_change_pv",f.context]),n&&n.fn_after_pv&&o.each(n.fn_after_pv,function(e){e(window.goldlog,t)})})()},e.SendPV=l},function(t,e,n){"use strict";var o=n(9),a=n(26),r=n(33),i=n(24),s=n(89),u=n(90),c=n(4),l=function(){};l.prototype.run=function(t,e,n,l){var p=new u;p.init({middleware:[],config:t,plugins:c.plugins_prepv});var g=p.run(),f=new c.context_prepv;f.userdata=e,f.logger=i.logger;var d={context:f,pubsub:a.getGoldlogVal("aplus_pubsub"),pubsubType:"prepv"},_=new s;_.create(d),_.wrap(g,function(){d.context.status="complete",r.doPubMsg(["mw_change_prepv",d.context]),n&&n.fn_after_record&&o.each(n.fn_after_pv,function(e){e(window.goldlog,t)}),a.setGoldlogVal("prepv_context",f),"function"==typeof l&&l()})()},e.SendPrePV=l},function(t,e,n){"use strict";!function(){var t=window.goldlog||(window.goldlog={}),e=n(97);t.aplus_pubsub||(t.aplus_pubsub=e.create())}()},function(t,e,n){"use strict";function o(t){if("function"!=typeof t)throw new TypeError(t+" is not a function");return t}var a=n(84),r=function(t){for(var e=t.length,n=new Array(e-1),o=1;o<e;o++)n[o-1]=t[o];return n},i=a.extend({create:function(t){var e=new this;for(var n in t)e[n]=t[n];return e.handlers=[],e.pubs={},e},setHandlers:function(t){this.handlers=t},subscribe:function(t,e){o(e);var n=this,a=n.pubs||{},r=a[t]||[];if(r)for(var i=0;i<r.length;i++){var s=r[i]();e.apply(n,s)}var u=n.handlers||[];return t in u||(u[t]=[]),u[t].push(e),n.setHandlers(u),n},subscribeOnce:function(t,e){o(e);var n,a=this;return this.subscribe.call(this,t,n=function(){a.unsubscribe.call(a,t,n);var o=Array.prototype.slice.call(arguments);e.apply(a,o)}),this},unsubscribe:function(t,e){o(e);var n=this.handlers[t];if(!n)return this;if("object"==typeof n&&n.length>0){for(var a=0;a<n.length;a++){var r=e.toString(),i=n[a].toString();r===i&&n.splice(a,1)}this.handlers[t]=n}else delete this.handlers[t];return this},publish:function(t){var e=r(arguments),n=this.handlers||[],o=n[t]?n[t].length:0;if(o>0)for(var a=0;a<o;a++){var i=n[t][a];i&&"function"==typeof i&&i.apply(this,e)}return this},cachePubs:function(t){var e=this.pubs||{},n=r(arguments);e[t]||(e[t]=[]),e[t].push(function(){return n})}});t.exports=i},function(t,e,n){"use strict";var o=n(41),a=n(33),r=n(51),i=n(4);e.init=function(){i.initLoad.init_watchGoldlogQueue("metaQueue"),n(99)(function(){var t=goldlog._$||{},e=navigator.userAgent;e.match(/AliApp\(([A-Z\-]+)\/([\d\.]+)\)/i)&&(t.is_ali_app=!0),i.utilPvid.makePVId();var s=n(49);t.spm=s,t.is_WindVane=o.is_WindVane;var u=t.meta_info;s.init(goldlog,u,function(){i.initLoad.init_watchGoldlogQueue();var t=n(4).spmException,e=t.is_exception;e||n(102);var o,r="complete";o=["aplusReady",r],a.doPubMsg(o),a.doCachePubs(o)}),goldlog.beforeSendPV(function(e,n){if(t.page_url=location.href,t.page_referrer=r.getRefer(),n.is_auto&&"1"===u["aplus-manual-pv"])return!1}),goldlog.afterSendPV(function(){window.g_SPM&&(g_SPM._current_spm="")}),i.is_auto_pv+""=="true"&&goldlog.sendPV({is_auto:!0}),i.initLoad.run(),i.beforeUnload.run()})}},function(t,e,n){"use strict";var o=n(33),a=n(100);t.exports=function(t){var e=n(101).AplusInit,r=new e;r.run({},function(e){o.doPubMsg(["aplusInitContext",e]),o.doCachePubs(["aplusInitContext",e]),a(),"function"==typeof t&&t()})}},function(t,e,n){"use strict";function o(t){var e="";switch(!0){case r.isJSON(t):e="settled";break;case r.isString(t):e=t;break;case r.isNumber(t):e=t+"";break;default:e="settled"}return e}var a=n(26),r=n(9);t.exports=function(){try{var t=a.getGoldlogVal("hasSendMIC"),e=Math.floor(99*Math.random());if(t||1!==e)return;var n=goldlog&&goldlog._$?goldlog._$.meta_info:{},i="";for(var s in n)r.isEmpty(n[s])||(i=i+"&"+s+"="+o(n[s]));a.setGoldlogVal("hasSendMIC",!0),goldlog.record("/m.i.c","OTHER",i,"POST")}catch(t){}}},function(t,e,n){"use strict";var o=n(26),a=n(24),r=n(89),i=n(90),s=n(4),u=function(){};u.prototype.run=function(t,e){var n=new i;n.init({middleware:[],config:t,plugins:s.aplus_init});var u=n.run(),c=new s.context;c.logger=a.logger;var l={context:c,pubsub:o.getGoldlogVal("aplus_pubsub"),pubsubType:"aplusinit"},p=new r;p.create(l),p.wrap(u,function(){"function"==typeof e&&e(l.context)})()},e.AplusInit=u},function(t,e,n){"use strict";!function(){var t,e=n(9),o=n(26),a=n(103),r=function(){t=!0;var n=window.g_SPM||{};e.isFunction(n.getParam)||e.isFunction(n.spm)||a.run()},i=window.goldlog||(window.goldlog={});i.aplus_pubsub&&"function"==typeof i.aplus_pubsub.publish&&i.aplus_pubsub.subscribe("goldlogReady",function(e){"complete"!==e||t||r()});var s=0,u=function(){if(!t){var e=o.getGoldlogVal("_$")||{};"complete"===e.status?r():s<50&&(++s,setTimeout(function(){u()},200))}};u()}()},function(t,e,n){"use strict";var o=n(31),a=n(26),r=n(104),i=n(108),s=n(109),u=n(110),c=n(111);e.run=function(){var t=a.getGoldlogVal("_$")||{},e=t.meta_info,n=e["aplus-touch"],l={isTouchEnabled:o.isTouch()||"1"===n||"tap"===n,isTerminal:t.is_terminal||/WindVane/i.test(navigator.userAgent)};window.g_SPM={spm_d_for_ad:{},resetModule:r.spm_resetModule,anchorBeacon:r.spm_spmAnchorChk,getParam:r.spm_getSPMParam,spm:r.spm_forwap},i.run(l),s.run(l),u.run(l),c.run(l)}},function(t,e,n){"use strict";function o(t){if(t&&1===t.nodeType){s.tryToRemoveAttribute(t,"data-spm-max-idx"),s.tryToRemoveAttribute(t,"data-auto-spmd-max-idx");for(var e=u.nodeListToArray(t.getElementsByTagName("a")),n=u.nodeListToArray(t.getElementsByTagName("area")),o=e.concat(n),a=0;a<o.length;a++)s.tryToRemoveAttribute(o[a],l)}}function a(t,e){var n=s.tryToGetAttribute(t,l),o="0";if(n&&c.spm_isSPMAnchorIdMatch(n))c.spm_anchorEnsureSPMId_inHref(t,n,e);else{var a=c.spm_spmGetParentSPMId(t.parentNode);if(o=a.spm_c,!o)return void c.spm_dealNoneSPMLink(t,e);c.spm_initSPMModule(a.el,o,e),c.spm_initSPMModule(a.el,o,e,!0)}}function r(t){var e,n=t.tagName;"A"!==n&&"AREA"!==n?e=c.spm_getParamForAD(t):(a(t,!0),e=s.tryToGetAttribute(t,l)),e||(e="0.0.0.0");var o=goldlog.getPvId();4===e.split(".").length&&o&&(e+="."+o),"A"!==n&&"AREA"!==n&&s.tryToSetAttribute(t,l,e),e=e.split(".");var r={a:e[0],b:e[1],c:e[2],d:e[3]};return e[4]&&(r.e=e[4]),r}function i(t,e){var n=r(t),o=[n.a,n.b,n.c,n.d];return e&&n.e&&o.push(n.e),o.join(".")}var s=n(28),u=n(19),c=n(105),l="data-spm-anchor-id";e.spm_resetModule=o,e.spm_spmAnchorChk=a,e.spm_getSPMParam=r,e.spm_forwap=i},function(t,e,n){"use strict";function o(t){for(var e,n="data-spm-ab-max-idx",o={},a="";t&&t.tagName!=j&&t.tagName!=x;){if(!a&&(a=v.tryToGetAttribute(t,"data-spm-ab"))){e=parseInt(v.tryToGetAttribute(t,n))||0,o.a_spm_ab=a,o.ab_idx=++e,t.setAttribute(n,e);break}if(v.tryToGetAttribute(t,"data-spm"))break;t=t.parentNode}return o}function a(){var t=b.getGoldlogVal("_$")||{},e=t.spm||{},n=e.data||{};return[n.a,n.b].join(".")}function r(t){var e=a(),n=t.split(".");return n[0]+"."+n[1]==e}function i(t,e){if(!goldlog.isUT4Aplus||"UT4Aplus"!==goldlog.getMetaInfo("aplus-toUT")){if(t&&/&?\bspm=[^&#]*/.test(t)&&(t=t.replace(/&?\bspm=[^&#]*/g,"").replace(/&{2,}/g,"&").replace(/\?&/,"?").replace(/\?$/,"")),!e)return t;var n,o,a,r,i,s,u,c="&";t.indexOf("#")!==-1&&(a=t.split("#"),t=a.shift(),o=a.join("#")),r=t.split("?"),i=r.length-1,a=r[0].split("//"),a=a[a.length-1].split("/"),s=a.length>1?a.pop():"",i>0&&(n=r.pop(),t=r.join("?")),n&&i>1&&n.indexOf("&")==-1&&n.indexOf("%")!==-1&&(c="%26");var l="";if(t=t+"?spm="+l+e+(n?c+n:"")+(o?"#"+o:""),u=h.isContain(s,".")?s.split(".").pop().toLowerCase():""){if({png:1,jpg:1,jpeg:1,gif:1,bmp:1,swf:1}.hasOwnProperty(u))return 0;!n&&i<=1&&(o||{htm:1,html:1,php:1,aspx:1,shtml:1,xhtml:1}.hasOwnProperty(u)||(t+="&file="+s))}return t}}function s(t,e){if(!goldlog.isUT4Aplus||"UT4Aplus"!==goldlog.getMetaInfo("aplus-toUT")){var n,o=t.innerHTML;o&&o.indexOf("<")==-1&&(n=document.createElement("b"),n.style.display="none",t.appendChild(n)),t.href=e,n&&t.removeChild(n)}}function u(t,e,n){if(!/^0\.0\.?/.test(e)){var o=y.tryToGetHref(t),r=a(),u=w.is_ignore_spm(t);if(u){var c=_.param2obj(o);if(c.spm&&c.spm.split)for(var l=c.spm.split("."),p=e.split("."),g=0;g<3&&p[g]===l[g];g++)2===g&&l[3]&&(e=c.spm)}t.setAttribute("data-spm-anchor-id",e);var f=goldlog.getPvId();f&&(e+="."+f);var d="0.0";(f||r&&r!=d)&&(u||n||(o=i(o,e))&&s(t,o))}}function c(t){var e=v.tryToGetAttribute(t,P),n=m.parseSemicolonContent(e)||{};return n}function l(t){var e,n=b.getGoldlogVal("_$")||{},o=n.spm.data;return"0"==o.a&&"0"==o.b?e="0":(e=v.tryToGetAttribute(t,T),e&&e.match(/^d\w+$/)||(e="")),e}function p(t,e){for(var n=[],o=m.nodeListToArray(t.getElementsByTagName("a")),a=m.nodeListToArray(t.getElementsByTagName("area")),r=o.concat(a),i=0;i<r.length;i++){for(var s=!1,u=r[i],c=r[i];(u=u.parentNode)&&u!=t;)if(v.tryToGetAttribute(u,T)){s=!0;break}if(!s){var l=v.tryToGetAttribute(c,A);e||"t"===l?e&&"t"===l&&n.push(c):n.push(c)}}return n}function g(t){for(var e,n=t;t&&t.tagName!==j&&t.tagName!==x&&t.getAttribute;){var o=t.getAttribute(T);if(o){e=o,n=t;break}if(!(t=t.parentNode))break}return e&&!/^[\w\-\.\/]+$/.test(e)&&(e="0"),{spm_c:e,el:n}}function f(t,e){var n=parent!==self;if(!n&&e)return[t,e].join(".");if(t&&e)return t+".i"+e;var o=window.g_SPM||(window.g_SPM={}),a=o.spm_d_for_ad||{};return"number"==typeof a[t]?a[t]++:a[t]=0,o.spm_d_for_ad=a,t+".i"+a[t]}function d(t){var e;return t&&(e=t.match(/&?\bspm=([^&#]*)/))?e[1]:""}var _=n(18),h=n(9),m=n(19),v=n(28),b=n(26),y=n(106),w=n(107),x="BODY",j="HTML",T="data-spm",P="data-spm-click",A="data-auto-spmd",S="data-spm-anchor-id";e.getGlobalSPMId=a,e.spm_isSPMAnchorIdMatch=r,e.spm_updateHrefWithSPMId=i,e.spm_writeHref=s,e.spm_anchorEnsureSPMId_inHref=u,e.getElDataSpm=c,e.spm_getAnchor4thId_spm_d=l,e.spm_getModuleLinks=p,e.spm_spmGetParentSPMId=g,e.get_spm_for_ad=f,e.spm_getParamForAD=function(t){var e=v.tryToGetAttribute(t,S);if(!e){var n=a(),o=t.parentNode;if(!o)return"";var r=c(t)||{},i=r.locaid||"",s=t.getAttribute(T)||i,u=g(o),l=u.spm_c||0;l&&l.indexOf(".")!==-1&&(l=l.split("."),l=l[l.length-1]),e=f(n+"."+l,s)}return e},e.spm_initSPMModule=function(t,e,n,i){var s;if(e=e||t.getAttribute("data-spm")||""){var g=p(t,i);if(0!==g.length){var f=e.split("."),d=h.isStartWith(e,"110")&&3==f.length;d&&(s=f[2],f[2]="w"+(s||"0"),e=f.join("."));var _=a();if(_&&_.match(/^[\w\-\*]+(\.[\w\-\*\/]+)?$/))if(h.isContain(e,".")){if(!h.isStartWith(e,_)){var m=_.split(".");f=e.split(".");for(var b=0;b<m.length;b++)f[b]=m[b];e=f.join(".")}}else h.isContain(_,".")||(_+=".0"),e=_+"."+e;if(e.match&&e.match(/^[\w\-\*]+\.[\w\-\*\/]+\.[\w\-\*\/]+$/)){for(var w="data-auto-spmd-max-idx",x="data-spm-max-idx",j=i?w:x,T=parseInt(v.tryToGetAttribute(t,j))||0,A=0;A<g.length;A++){var k=g[A],E=y.tryToGetHref(k),U=v.tryToGetAttribute(k,P);if(i||E||U){d&&k.setAttribute("data-spm-wangpu-module-id",s);var I=k.getAttribute(S);if(I&&r(I))u(k,I,n);else{var M,C,N=o(k.parentNode);N.a_spm_ab?(C=N.a_spm_ab,M=N.ab_idx):(C=void 0,T++,M=T);var O,V=c(k)||{},G=V.locaid||"";G?O=G:(O=l(k)||M,i&&(O="at"+((h.isNumber(O)?1e3:"")+O))),I=C?e+"-"+C+"."+O:e+"."+O,u(k,I,n)}}}t.setAttribute(j,T)}}}},e.spm_dealNoneSPMLink=function(t,e){var n=goldlog.getMetaInfo("aplus-getspmcd"),o=a(),r=y.tryToGetHref(t),i=d(r),c=null,p=o&&2==o.split(".").length;if(p){var g;return"function"==typeof n&&(g=n(t,null,o)),c=g&&"0"!==g.spm_c?[o,g.spm_c,g.spm_d]:[o,0,l(t)||0],void u(t,c.join("."),e)}r&&i&&(r=r.replace(/&?\bspm=[^&#]*/g,"").replace(/&{2,}/g,"&").replace(/\?&/,"?").replace(/\?$/,"").replace(/\?#/,"#"),s(t,r))}},function(t,e,n){"use strict";var o=n(20);e.tryToGetHref=function(t){var e;try{e=o.trim(t.getAttribute("href",2))}catch(t){}return e||""}},function(t,e,n){"use strict";function o(t){return!!t&&!!t.match(/^[^\?]*\balipay\.(?:com|net)\b/i)}function a(t){return!!t&&!!t.match(/^[^\?]*\balipay\.(?:com|net)\/.*\?.*\bsign=.*/i)}function r(t){var e=location.href;return t&&e.split("#")[0]===t.split("#")[0]}function i(t){for(var e;(t=t.parentNode)&&"BODY"!==t.tagName;)if(e=u.tryToGetAttribute(t,f))return e;return""}function s(t){for(var e=["mclick.simba.taobao.com","click.simba.taobao.com","click.tanx.com","click.mz.simba.taobao.com","click.tz.simba.taobao.com","redirect.simba.taobao.com","rdstat.tanx.com","stat.simba.taobao.com","s.click.taobao.com"],n=0;n<e.length;n++)if(t.indexOf(e[n])!==-1)return!0;return!1}var u=n(28),c=n(9),l=n(106),p=n(26),g=n(22),f="data-spm-protocol";e.is_ignore_spm=function(t){var e=p.getGoldlogVal("_$")||{},n=e.meta_info||{},d=l.tryToGetHref(t),_=i(t),h=u.tryToGetAttribute(t,f),m="i"===(h||_||n.spm_protocol);if(!d||s(d))return!0;var v=r(d)||g.isStartWithProtocol(d.toLowerCase()),b=o(d)||a(d),y=v||b;return!(m||!c.isStartWith(d,"#")&&!y)||m}},function(t,e,n){"use strict";function o(t,e,n){var o=u.parseSemicolonContent(e,{},!0),a=o.gostr||"",r=o.locaid||"",g=t.getAttribute("data-spm")||r,f="CLK",d=o.gokey||"",_=p.spm_getSPMParam(t),h=[_.a,_.b,_.c,g].join("."),m=a+"."+h;0!==m.indexOf("/")&&(m="/"+m);var v=[],b=["gostr","locaid","gmkey","gokey","spm-cnt","cna"];for(var y in o)o.hasOwnProperty(y)&&c.indexof(b,y)===-1&&v.push(y+"="+o[y]);v.push("_g_et="+n),v.push("autosend=1"),d&&v.length>0&&(d+="&"),d+=v.length>0?v.join("&"):"",goldlog&&s.isFunction(goldlog.recordUdata)?goldlog.recordUdata(m,f,d,"GET",function(){}):l.logger({msg:"goldlog.recordUdata is not function!"}),i.tryToSetAttribute(t,"data-spm-anchor-id",h)}function a(t,e){var n=e;window.g_SPM&&(g_SPM._current_spm=p.spm_getSPMParam(e));for(var a;e&&"HTML"!==e.tagName;){a=i.tryToGetAttribute(e,"data-spm-click");{if(a){o(e,a,"mousedown"===t.type?t.type:"tap");break}e=e.parentNode}}if(!a){var r=g.getGlobalSPMId(),s=goldlog.getMetaInfo("aplus-getspmcd");"function"==typeof s&&s(n,t,r)}}var r=n(79),i=n(28),s=n(9),u=n(19),c=n(12),l=n(24),p=n(104),g=n(105);e.run=function(t){t&&t.isTouchEnabled?r.on(document,"tap",a):r.on(document,"mousedown",a)}},function(t,e,n){"use strict";function o(){for(var t=document.getElementsByTagName("iframe"),e=0;e<t.length;e++){var n=t[e],o=r.tryToGetAttribute(n,"data-spm-src");if(!n.src&&o){var a=s.spm_getSPMParam(n);if(a){var u=[a.a,a.b,a.c,a.d];a.e&&u.push(a.e),a=u.join("."),n.src=i.spm_updateHrefWithSPMId(o,a)}else n.src=o}}}function a(){function t(){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}var e=0,n=500;t()}var r=n(28),i=n(105),s=n(104);e.run=function(t){t&&!t.isTerminal&&a()}},function(t,e,n){"use strict";function o(t,e){for(var n,o=window;e&&(n=e.tagName);){if("A"===n||"AREA"===n){r.spm_spmAnchorChk(e,!1);var a=o.g_SPM||(o.g_SPM={}),i=a._current_spm=r.spm_getSPMParam(e),s=[];try{s=[i.a,i.b,i.c,i.d];var u=i.e||goldlog.pvid||"";u&&s.push(u)}catch(t){}break}if("BODY"==n||"HTML"==n)break;e=e.parentNode}}var a=n(79),r=n(104);e.run=function(t){var e=document;t&&t.isTouchEnabled?a.on(e,"tapSpm",o):(a.on(e,"mousedown",o),a.on(e,"keydown",o))}},function(t,e,n){"use strict";function o(t,e){if(e||(e=p),p.evaluate)return e.evaluate(t,p,null,9,null).singleNodeValue;for(var n,a=t.split("/");!n&&a.length>0;)n=a.shift();var r,i=/^.+?\[@id='(.+?)']$/i,s=/^(.+?)\[(\d+)]$/i;return(r=n.match(i))?e=e.getElementById(r[1]):(r=n.match(s))&&(e=e.getElementsByTagName(r[1])[parseInt(r[2])-1]),e?0===a.length?e:o(a.join("/"),e):null}function a(){var t={};for(var e in l)if(l.hasOwnProperty(e)){var n=o(e);if(n){t[e]=1;var a=l[e],r="A"===n.tagName?a.spmd:a.spmc;s.tryToSetAttribute(n,"data-spm",r||"")}}for(var i in t)t.hasOwnProperty(i)&&delete l[i]}function r(){if(!c&&g.spmData){c=!0;var t=g.spmData.data;if(t&&i.isArray(t)){for(var e=0;e<t.length;e++){var n=t[e],o=n.xpath;o=o.replace(/^id\('(.+?)'\)(.*)/g,"//*[@id='$1']$2"),l[o]={spmc:n.spmc,spmd:n.spmd}}a()}}}var i=n(9),s=n(28),u=n(79),c=!1,l={},p=document,g=window;e.wh_updateXPathElements=a,
e.init_wh=r,e.run=function(){u.DOMReady(function(){r()})}},function(t,e,n){"use strict";function o(){var t,e=p.getParamFromUrl("utparamcnt",location.href);if(e)try{t=e=JSON.parse(decodeURIComponent(e))}catch(t){}return t}function a(){var t,e=d["aplus-utparam"];if(e)if("object"==typeof e)t=e;else try{t=JSON.parse(e)}catch(t){}return t}var r=n(11),i=n(51),s=n(52),u=n(33),c=n(55),l=n(9),p=n(50),g=n(4),f=n(27),d=f.getInfo(),_="complete";e.initGoldlog=function(t){var e=window.goldlog||(window.goldlog={}),n=g.goldlog_path.run.create();e._ready_time=(new Date).getTime();for(var p in n)e[p]=n[p];var f=/TB\-PD/i.test(navigator.userAgent),h=e._$=e._$||{},m=o(),v=a();return"object"==typeof m&&(v&&(m=l.assign(m,v)),d["aplus-utparam"]=m),h.meta_info=d,h.is_terminal="aplus_wap"===g.script_name||f||"1"==d["aplus-terminal"],h.send_pv_count=0,h.status=_,h.script_name=g.script_name,h.spm={data:{}},h.page_referrer=i.getRefer(),h.pageLoadTime=(new Date).getTime(),e.lver=g.lver,e.nameStorage=s.nameStorage,c.haveNativeFlagInUA(),u.doPubMsg(["goldlogReady",_]),u.doCachePubs(["goldlogReady",_]),u.publishCNA(r.getCookie("cna")),t.init(),e}}]);/*! 2024-09-10 16:39:25 v8.15.24 */
!function(t){function e(n){if(r[n])return r[n].exports;var a=r[n]={exports:{},id:n,loaded:!1};return t[n].call(a.exports,a,a.exports,e),a.loaded=!0,a.exports}var r={};return e.m=t,e.c=r,e.p="",e(0)}([function(t,e){"use strict";!function(){function t(t,e,r){t[_]((h?"on":"")+e,function(t){t=t||s.event;var e=t.target||t.srcElement;r(t,e)},!1)}function e(){return/&?\bspm=[^&#]*/.test(location.href)?location.href.match(/&?\bspm=[^&#]*/gi)[0].split("=")[1]:""}function r(t,e){if(t&&/&?\bspm=[^&#]*/.test(t)&&(t=t.replace(/&?\bspm=[^&#]*/g,"").replace(/&{2,}/g,"&").replace(/\?&/,"?").replace(/\?$/,"")),!e)return t;var r,n,a,i,o,c,p,s="&";if(t.indexOf("#")!=-1&&(a=t.split("#"),t=a.shift(),n=a.join("#")),i=t.split("?"),o=i.length-1,a=i[0].split("//"),a=a[a.length-1].split("/"),c=a.length>1?a.pop():"",o>0&&(r=i.pop(),t=i.join("?")),r&&o>1&&r.indexOf("&")==-1&&r.indexOf("%")!=-1&&(s="%26"),t=t+"?spm="+e+(r?s+r:"")+(n?"#"+n:""),p=c.indexOf(".")>-1?c.split(".").pop().toLowerCase():""){if({png:1,jpg:1,jpeg:1,gif:1,bmp:1,swf:1}.hasOwnProperty(p))return 0;!r&&o<=1&&(n||{htm:1,html:1,php:1}.hasOwnProperty(p)||(t+="&file="+c))}return t}function n(t){function e(t){return t=t.replace(/refpos[=(%3D)]\w*/gi,c).replace(i,"%3D"+n+"%26"+a.replace("=","%3D")).replace(o,n),a.length>0&&(t+="&"+a),t}var r=window.location.href,n=r.match(/mm_\d{0,24}_\d{0,24}_\d{0,24}/i),a=r.match(/[&\?](pvid=[^&]*)/i),i=new RegExp("%3Dmm_\\d+_\\d+_\\d+","ig"),o=new RegExp("mm_\\d+_\\d+_\\d+","ig");a=a&&a[1]?a[1]:"";var c=r.match(/(refpos=(\d{0,24}_\d{0,24}_\d{0,24})?(,[a-z]+)?)(,[a-z]+)?/i);return c=c&&c[0]?c[0]:"",n?(n=n[0],e(t)):t}function a(e){var r=s.KISSY;r?r.ready(e):s.jQuery?jQuery(m).ready(e):"complete"===m.readyState?e():t(s,"load",e)}function i(t,e){return t&&t.getAttribute?t.getAttribute(e)||"":""}function o(t){if(t){var e,r=g.length;for(e=0;e<r;e++)if(t.indexOf(g[e])>-1)return!0;return!1}}function c(t,e){if(t&&/&?\bspm=[^&#]*/.test(t)&&(t=t.replace(/&?\bspm=[^&#]*/g,"").replace(/&{2,}/g,"&").replace(/\?&/,"?").replace(/\?$/,"")),!e)return t;var r,n,a,i,o,c,p,s="&";if(t.indexOf("#")!=-1&&(a=t.split("#"),t=a.shift(),n=a.join("#")),i=t.split("?"),o=i.length-1,a=i[0].split("//"),a=a[a.length-1].split("/"),c=a.length>1?a.pop():"",o>0&&(r=i.pop(),t=i.join("?")),r&&o>1&&r.indexOf("&")==-1&&r.indexOf("%")!=-1&&(s="%26"),t=t+"?spm="+e+(r?s+r:"")+(n?"#"+n:""),p=c.indexOf(".")>-1?c.split(".").pop().toLowerCase():""){if({png:1,jpg:1,jpeg:1,gif:1,bmp:1,swf:1}.hasOwnProperty(p))return 0;!r&&o<=1&&(n||{htm:1,html:1,shtml:1,php:1}.hasOwnProperty(p)||(t+="&__file="+c))}return t}function p(t){if(o(t.href)){var r=i(t,u);if(!r){var n=l()(t),a=[n.a,n.b,n.c,n.d].join(".");n.e&&(n+="."+n.e),d&&(a=[n.a||"0",n.b||"0",n.c||"0",n.d||"0"].join("."),a=(e()||"0.0.0.0.0")+"_"+a),t.href=c(t.href,a),t.setAttribute(u,a)}}}var s=window,m=document;if(1!==s.aplus_spmact){s.aplus_spmact=1;var f=function(){return{a:0,b:0,c:0,d:0,e:0}},l=function(){return s.g_SPM&&s.g_SPM.getParam?s.g_SPM.getParam:f},d=!0;try{d=self.location!=top.location}catch(t){}var u="data-spm-act-id",g=["mclick.simba.taobao.com","click.simba.taobao.com","click.tanx.com","click.mz.simba.taobao.com","click.tz.simba.taobao.com","redirect.simba.taobao.com","rdstat.tanx.com","stat.simba.taobao.com","s.click.taobao.com"],h=!!m.attachEvent,b="attachEvent",v="addEventListener",_=h?b:v;t(m,"mousedown",function(t,e){for(var r,n=0;e&&(r=e.tagName);){if("A"==r||"AREA"==r){p(e);break}if("BODY"==r||"HTML"==r)break;e=e.parentNode,n+=1}}),a(function(){for(var t,a,o=document.getElementsByTagName("iframe"),c=0;c<o.length;c++){t=i(o[c],"mmsrc"),a=i(o[c],"mmworked");var p=l()(o[c]),s=[p.a||"0",p.b||"0",p.c||"0",p.d||"0",p.e||"0"].join(".");t&&!a?(d&&(s=[p.a||"0",p.b||"0",p.c||"0",p.d||"0"].join("."),s=e()+"_"+s),o[c].src=r(n(t),s),o[c].setAttribute("mmworked","mmworked")):o[c].setAttribute(u,s)}})}}()}]);</script><script crossorigin="" referrerpolicy="unsafe-url" src="https://g.lazcdn.com/g/lzd_sec/epssw/0.0.24/epssw.js"></script><script async="" src="//g.lazcdn.com/g/lzd-cs/chat/2.5.0/alichat.js" desktopjs="true"></script><script>
  (function() {
    try {
      if (window.aplusPageIdSetComplete || /AliApp/i.test(navigator.userAgent)) {
        return;
      }
  
      var get_cookie = function (sName) {
        var sRE = '(?:; )?' + sName + '=([^;]*);?';
        var oRE = new RegExp(sRE);
        if (oRE.test(document.cookie)) {
        var str = decodeURIComponent(RegExp['$1']) || '';
        if (str.trim().length > 0) {
          return str;
        } else {
          return '-';
        }
        } else {
          return '-';
        }
      };
      var getRand = function () {
        var page_id = get_cookie('cna') || '001';
        page_id = page_id.toLowerCase().replace(/[^a-z\d]/g, '');
        page_id = page_id.substring(0, 16);
        var d = (new Date()).getTime();
        var randend = [
          page_id,
          d.toString(16)
        ].join('');
  
        for (var i = 1; i < 10; i++) {
          var _r = parseInt(Math.round(Math.random() * 10000000000), 10).toString(16);
          randend += _r;
        }
        randend = randend.substr(0, 42);
        return randend;
      };
      var pageid = getRand();
      var aq = (window.aplus_queue || (window.aplus_queue = []));
      aq.push({
        'action':'aplus.appendMetaInfo',
        'arguments':['aplus-cpvdata', {"pageid":pageid}]
      });
      aq.push({
        'action':'aplus.appendMetaInfo',
        'arguments':['aplus-exdata',{"st_page_id":pageid}]
      });
      // 兼容老版本aplus
      var gq = (window.goldlog_queue || (window.goldlog_queue = []));
      gq.push({
        'action':'goldlog.appendMetaInfo',
        'arguments':['aplus-cpvdata', {"pageid":pageid}]
      });
      gq.push({
        'action':'goldlog.appendMetaInfo',
        'arguments':['aplus-exdata',{"st_page_id":pageid}]
      });
      window.aplusPageIdSetComplete = true;
    } catch(err) {
      console.error(err);
    }
  })();
  </script>

  <script type="text/javascript">
    var timings = {
      start: Date.now(),
    };
    var dataLayer = window.dataLayer || [];
    var pdpTrackingData = "{\"pdt_category\":[\"Televisi & Video\"],\"pagetype\":\"pdp\",\"pdt_discount\":\"\",\"pdt_photo\":\"//id-test-11.slatic.net/p/c08a6637647b6984097e3fcf63c97c3c.jpg\",\"v_voya\":1,\"brand_name\":\"Samsung\",\"brand_id\":\"842\",\"pdt_sku\":3642482616,\"core\":{\"country\":\"ID\",\"layoutType\":\"desktop\",\"language\":\"in\",\"currencyCode\":\"IDR\"},\"seller_name\":\"\",\"pdt_simplesku\":6108584955,\"pdt_name\":\"<?PHP echo $BRANDS ?> Dafar Link Gacor Slot Online Resmi Gampang Menang Hari Ini\",\"page\":{\"regCategoryId\":\"300300002584\",\"xParams\":\"_p_typ=pdp&_p_ispdp=1&_p_item=3642482616_ID-6108584955&_p_prod=3642482616&_p_sku=6108584955&_p_slr=\"},\"supplier_id\":\"\",\"pdt_price\":\"Rp2.699.000\"}";
    try {
      pdpTrackingData = JSON.parse(pdpTrackingData);
      pdpTrackingData.v_voya = false;
      dataLayer.push(pdpTrackingData);
      dataLayer.push({
        gtm_enable: false,
        v_voya: false
      });
    } catch (e) {
      if (window.console) {
        console.log(e);
      }
    }
    /**
     * 支持beacon aplus script
     */
    var siteNameForApluPluginLoader = "Lazada";

  </script>

  <!-- csrf -->
  <meta name="X-CSRF-TOKEN" id="X-CSRF-TOKEN" content="eb3380311eeee" />
<script async="" src="//gj.mmstat.com/eg.js?t=1727481600059"></script><script type="text/javascript" charset="UTF-8" src="https://fourier.taobao.com/rp?ext=51&amp;data=jm_XeB+HwcB7EICAUL5QEFQ+QBr&amp;random=7186857133638114&amp;href=https%3A%2F%2Fsimleg.depok.go.id%2Fapi%2Faspirasi%2Fpublic%2Ftext%2F&amp;protocol=https:&amp;callback=jsonpCallback"></script><script crossorigin="" referrerpolicy="unsafe-url" src="https://g.lazcdn.com/g/secdev/sufei_data/3.9.14/index.js" async="" id="aplus-sufei"></script><script src="https://g.lazcdn.com/g/lzd/assets/1.2.10/web-vitals/3.4.0/index.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="//g.lazcdn.com/g/lzdfe/pdp-platform/0.1.22/pc.js" src="//g.lazcdn.com/g/lzdfe/pdp-platform/0.1.22/pc.js" crossorigin="anonymous"></script><style>@charset "utf-8";
@font-face{font-family:'nc_iconfont';src:url("//at.alicdn.com/t/font_1465353706_4784257.eot");src:url("//at.alicdn.com/t/font_1465353706_4784257.eot?#iefix") format('embedded-opentype'),url("//at.alicdn.com/t/font_1465353706_4784257.woff") format('woff'),url("//at.alicdn.com/t/font_1465353706_4784257.ttf") format('truetype'),url("//at.alicdn.com/t/font_1465353706_4784257.svg#iconfont") format('svg')}@font-face{font-family:'ncpc_iconfont';src:url("//at.alicdn.com/t/font_384029_rhzpmteb25oecdi.eot");src:url("//at.alicdn.com/t/font_384029_rhzpmteb25oecdi.eot?#iefix") format('embedded-opentype'),url("//at.alicdn.com/t/font_384029_rhzpmteb25oecdi.woff") format('woff'),url("//at.alicdn.com/t/font_384029_rhzpmteb25oecdi.ttf") format('truetype'),url("//at.alicdn.com/t/font_384029_rhzpmteb25oecdi.svg#ncpc_iconfont") format('svg')}.nc-container div#nc-loading-circle{background:transparent;width:20px;height:20px;display:inline-block;position:relative;vertical-align:middle}.nc-container div#nc-loading-circle .sk-circle{background:transparent;width:100%;height:100%;position:absolute;left:0;top:0}.nc-container #nc-loading-circle .sk-circle:before{content:'';display:block;margin:0 auto;width:15%;height:15%;background-color:#818181;border-radius:100%;-webkit-animation:sk-circleFadeDelay 1.2s infinite ease-in-out both;animation:sk-circleFadeDelay 1.2s infinite ease-in-out both}.nc-container #nc-loading-circle .sk-circle2{-webkit-transform:rotate(30deg);-ms-transform:rotate(30deg);transform:rotate(30deg)}.nc-container #nc-loading-circle .sk-circle3{-webkit-transform:rotate(60deg);-ms-transform:rotate(60deg);transform:rotate(60deg)}.nc-container #nc-loading-circle .sk-circle4{-webkit-transform:rotate(90deg);-ms-transform:rotate(90deg);transform:rotate(90deg)}.nc-container #nc-loading-circle .sk-circle5{-webkit-transform:rotate(120deg);-ms-transform:rotate(120deg);transform:rotate(120deg)}.nc-container #nc-loading-circle .sk-circle6{-webkit-transform:rotate(150deg);-ms-transform:rotate(150deg);transform:rotate(150deg)}.nc-container #nc-loading-circle .sk-circle7{-webkit-transform:rotate(180deg);-ms-transform:rotate(180deg);transform:rotate(180deg)}.nc-container #nc-loading-circle .sk-circle8{-webkit-transform:rotate(210deg);-ms-transform:rotate(210deg);transform:rotate(210deg)}.nc-container #nc-loading-circle .sk-circle9{-webkit-transform:rotate(240deg);-ms-transform:rotate(240deg);transform:rotate(240deg)}.nc-container #nc-loading-circle .sk-circle10{-webkit-transform:rotate(270deg);-ms-transform:rotate(270deg);transform:rotate(270deg)}.nc-container #nc-loading-circle .sk-circle11{-webkit-transform:rotate(300deg);-ms-transform:rotate(300deg);transform:rotate(300deg)}.nc-container #nc-loading-circle .sk-circle12{-webkit-transform:rotate(330deg);-ms-transform:rotate(330deg);transform:rotate(330deg)}.nc-container #nc-loading-circle .sk-circle2:before{-webkit-animation-delay:-1.1s;animation-delay:-1.1s}.nc-container #nc-loading-circle .sk-circle3:before{-webkit-animation-delay:-1s;animation-delay:-1s}.nc-container #nc-loading-circle .sk-circle4:before{-webkit-animation-delay:-.9s;animation-delay:-.9s}.nc-container #nc-loading-circle .sk-circle5:before{-webkit-animation-delay:-.8s;animation-delay:-.8s}.nc-container #nc-loading-circle .sk-circle6:before{-webkit-animation-delay:-.7s;animation-delay:-.7s}.nc-container #nc-loading-circle .sk-circle7:before{-webkit-animation-delay:-.6s;animation-delay:-.6s}.nc-container #nc-loading-circle .sk-circle8:before{-webkit-animation-delay:-.5s;animation-delay:-.5s}.nc-container #nc-loading-circle .sk-circle9:before{-webkit-animation-delay:-.4s;animation-delay:-.4s}.nc-container #nc-loading-circle .sk-circle10:before{-webkit-animation-delay:-.3s;animation-delay:-.3s}.nc-container #nc-loading-circle .sk-circle11:before{-webkit-animation-delay:-.2s;animation-delay:-.2s}.nc-container #nc-loading-circle .sk-circle12:before{-webkit-animation-delay:-.1s;animation-delay:-.1s}@-webkit-keyframes sk-circleFadeDelay{0%,39%,100%{opacity:0}40%{opacity:1}}@-webkit-keyframes sk-circleFadeDelay{0%,39%,100%{opacity:0}40%{opacity:1}}@keyframes sk-circleFadeDelay{0%,39%,100%{opacity:0}40%{opacity:1}}.nc-container .scale_text2 #nc-loading-circle .sk-circle:before{background-color:#fff}.nc_iconfont{font-family:"nc_iconfont";color:#ff3f08;font-size:16px;font-style:normal}.ncpc_iconfont{font-family:"ncpc_iconfont";color:#ff3f08;font-size:16px;font-style:normal}.captcha-error .icon_ban{float:left;font-size:16px;padding-right:5px;line-height:14px}.clickCaptcha_text .btn_refresh{font-style:normal;cursor:pointer;background:#fff;color:#737383}.imgCaptcha .btn_refresh{font-size:20px;cursor:pointer;background:#fff;color:#737383}.nc_voice{display:none;position:relative;margin-top:-34px;z-index:99;width:auto;height:34px;background:#fff}.omeo-code-img,.omeo-code-audio{font-size:0;text-align:left}.omeo-code-audiobox,.omeo-code-img a,.omeo-code-audio a,.omeo-code-state{display:inline-block;*display:inline;zoom:1;height:32px;vertical-align:top;font-size:12px}.omeo-code .omeo-code-refresh{background:transparent;width:32px;height:32px;font-size:20px;color:#888;text-align:center;text-decoration:none;padding-left:4px;line-height:32px}.omeo-code .omeo-switch{display:none;width:32px;height:32px;border-left:1px solid #e1e1e1;background-image:url("//g.alicdn.com/sd/ncpc/images/checkcode.png");background-repeat:no-repeat}.omeo-img-active .omeo-code-img{display:block}.omeo-img-active .omeo-code-audio{display:none}.omeo-code-img img{border:1px solid #cdcdcd;cursor:pointer}.omeo-code-img .omeo-switch{background-position:9px -41px}.omeo-audio-active .omeo-code-audio{display:block}.omeo-audio-active .omeo-code-img{display:none}.omeo-code-refresh{position:relative;left:95px}.omeo-code-audiobox{position:relative;height:30px;line-height:32px;border:1px solid #e1e1e1;text-align:center;overflow:hidden;left:100px;top:1px;width:45%;min-width:80px;background-color:#eee}.omeo-code-audiobox a{display:block;text-decoration:none;color:#06c}.omeo-code-audiobox-playing a{visibility:hidden}.omeo-code-audiobox span,.omeo-code-audiobox b{visibility:hidden;position:absolute;top:0;left:0;height:30px;font-weight:100;overflow:hidden}.omeo-code-audiobox-playing span,.omeo-code-audiobox-playing b{visibility:visible}.omeo-code-audiobox span{z-index:0;width:0;background:#186bca}.omeo-code-audiobox b{width:100%;z-index:1;text-align:left;text-indent:30px;color:#999;background:url("//g.alicdn.com/sd/ncpc/images/checkcode.png") no-repeat 14px -89px}.omeo-code-audio .omeo-switch{background-position:5px 10px}input[type=text]::-ms-clear{display:none}.omeo-box{position:relative;background-color:#fff}.omeo-code-echo{position:absolute;top:2px;left:2px}.omeo-code-echo input{padding:5px;height:18px;line-height:18px;border:1px solid #ddd;width:80px;outline:0}.omeo-code-state{height:30px;line-height:30px;text-indent:25px;white-space:nowrap;background-image:url("//g.alicdn.com/sd/ncpc/images/checkcode.png");background-repeat:no-repeat;background-position:100px 100px}.omeo-code-echo .omeo-code-state-error{width:auto;background-position:7px -193px}.omeo-code-echo .omeo-code-state-success{position:absolute;width:30px;background-position:7px -243px}.omeo-code-state{position:absolute;left:0;top:28px}.nc_voice_close{display:inline-block;position:relative;cursor:pointer;left:95px;top:0;border-left:#ddd 2px solid;padding:0 0 0 7px;background-color:#fff;font-size:20px;color:#888;line-height:32px}.nc_help{position:absolute;width:100%;height:100%;left:0;top:0;z-index:99999}.nc_help .mask{background-color:#000;opacity:.5;filter:alpha(opacity=50);width:100%;height:100%;top:0;left:0}.nc_btn_close{position:absolute;height:20px;left:500px;border-radius:20px;padding:10px 30px;background-color:#aaa;color:#fff;cursor:pointer;z-index:10}.nc_btn_close:hover{background-color:#afafaf}.nc_hand{position:absolute;width:68px;height:53px;background-image:url("//g.alicdn.com/sd/ncpc/images/hand.png");z-index:3}.nc_slide_bg{z-index:3;font-size:12px;text-align:center;color:#fff;line-height:34px}.nc_voicebtn{position:absolute;padding:0;right:-25px;font-size:23px;color:#888;cursor:pointer;line-height:34px}.nc_helpbtn{position:absolute;cursor:pointer;right:-95px;top:4px;font-size:12px;background-color:#ffb668;color:#fff;padding:4px;border-radius:2px;line-height:18px;display:none}.nc_helpbtn:before{width:0;height:0;content:"";position:absolute;left:-2px;top:6px;border-top:4px solid transparent;border-bottom:4px solid transparent;border-right:4px solid #ffb668}.nc-container .errloading{border:#faf1d5 1px solid;text-indent:3px;background-image:none;font-size:12px;width:290px;line-height:20px;padding:7px 5px 8px 5px;color:#ef9f06;}.nc-container .errloading a{color:#30a7fc}.nc_captcha_text .nc_err{float:left;text-indent:0}.button_move{transition:left .5s;-moz-transition:left .5s;-webkit-transition:left .5s;-o-transition:left .5s}.bg_move{transition:width .5s;-moz-transition:width .5s;-webkit-transition:width .5s;-o-transition:width .5s}.nc_slide_box{position:absolute}.nc_captcha_text{height:auto;line-height:20px;visibility:hidden;font-size:12px;color:#999;font-weight:normal}.nc-container .nc_captcha_img_text{width:auto;height:auto;line-height:20px;visibility:hidden;font-size:12px;color:#999;font-weight:normal;display:none;padding:0 0 10px 0;background-position:0 0;}.nc-container .nc_captcha_img_text span.nc-lang-cnt{line-height:inherit}.nc-container .imgCaptcha .nc_captcha_img_text{width:auto}.nc_captcha_img_text{height:auto;line-height:20px;visibility:hidden;font-size:12px;color:#999;font-weight:normal;display:none;padding:0 0 10px 3px;background-position:0 0}.nc-container .nc_wrapper{width:auto}.nc_scale{width:auto;height:34px;background:#e8e8e8;position:relative;margin:0;padding:0}.nc_scale.is_audio{margin-right:25px}.nc-container .nc_scale div{height:auto}.nc-container .nc_scale ul{list-style:none}.nc-container .nc_scale .btn_slide{color:#737383;background-image:none;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.nc-container .nc_scale span{text-align:center;width:40px;height:32px;line-height:32px;border:1px solid #ccc;position:absolute;left:0;cursor:move;background:#fff;z-index:2}.nc-container .nc_scale span.nc-lang-cnt{*line-height:34px;float:none;width:auto;height:auto;*height:34px;border:none;position:static;cursor:inherit;background:none;z-index:0;display:inline}.nc_slide_button{width:40px;height:32px;border:1px solid #ccc;position:absolute;left:0;cursor:move;background:#fff url("//g.alicdn.com/sd/ncpc/images/rt.png") no-repeat center;z-index:2}@media screen and (-ms-high-contrast:active),(-ms-high-contrast:none){.nc_scale span{height:32px}}.nc-container .nc_scale .btnok{cursor:default;background:#fff url("//g.alicdn.com/sd/ncpc/images/yes.png") no-repeat center;z-index:3}.nc-container .nc_scale .btnok2{cursor:default;font-size:20px;background:#fff url("//g.alicdn.com/sd/ncpc/images/no.png") no-repeat center;z-index:3}.nc-container .nc_scale .btn_warn{cursor:default;color:#ff3f08;line-height:34px;text-align:center;font-size:20px;background:#fff;z-index:3}.nc-container .clickCaptcha_text .btn_refresh{font-size:20px}.nc-container .clickCaptcha_text .icon_close{line-height:30px;margin-left:8px;cursor:default;color:#ff3f08;font-size:16px;float:left;margin-right:2px;background:transparent;z-index:3}.nc-container .nc_captcha_img_text.icon_close{cursor:default;color:#ff3f08;font-size:16px;float:left;margin-right:4px;background:transparent;z-index:3;line-height:18px}.nc-container .errloading .icon_warn{cursor:default;color:#ff3f08;font-size:18px;float:left;background:transparent;z-index:3}.nc-container .nc_scale .btn_ok{cursor:default;line-height:34px;text-align:center;font-size:20px;background:#fff;z-index:3;color:#76c61d}.nc-container .nc_scale .nc_ok,.nc-container .nc_scale .nc_bg{background:#7ac23c}.nc-container .nc_scale .nc_bg{position:absolute;height:100%;_height:34px;left:0;width:10px}.nc-container .nc_scale div.redbar{background:#fc461e;opacity:.5;filter:alpha(opacity=50)}.nc-container .nc_scale div.orange{background:#f00}.nc-container .nc_scale .scale_text{width:100%;height:100%;text-align:center;position:absolute;z-index:1;background:transparent;color:#9c9c9c;line-height:34px;font-size:12px;cursor:pointer}.nc-container .nc_scale .scale_text2{text-align:left;color:#fff;font-size:12px;text-indent:10px}.nc-container .nc_scale .scale_text2 b{padding-left:0;font-weight:normal}.nc-container .nc_scale .scale_text.scale_loading_text{text-align:center}.nc-container .nc_scale .imgCaptcha,.nc-container .nc_scale .clickCaptcha{display:none;overflow:hidden;border:1px solid #ccc;background:#fff;z-index:20000;}.nc-container .nc_scale .imgCaptcha p.error span,.nc-container .nc_scale .clickCaptcha p.error span{line-height:normal}.nc-container .nc_scale .imgCaptcha{height:auto}.nc-container .nc_scale .clickCaptcha{position:absolute;left:0;top:35px;height:270px;background:#fff;display:none;}.nc-container .nc_scale .clickCaptcha p.error i{color:#ff3f08;font-style:normal}.nc-container .nc_scale .clickCaptcha div{position:static;clear:both;width:100%;background:#fff;height:auto}.nc-container .nc_scale .clickCaptcha .clickCaptcha_text{height:30px;line-height:30px;font-size:12px;color:#999;}.nc-container .nc_scale .clickCaptcha .clickCaptcha_text b{font-weight:normal}.nc_btn_2{position:absolute;right:0;top:0;cursor:pointer;margin:2px 9px 0 0}.nc_iconfont.nc_btn_2{position:absolute;right:0;top:0;cursor:pointer}.nc_iconfont.nc_btn_1{position:absolute;top:10px;right:5px}.nc_btn_1{top:10px;right:10px}.scale_text i{font-style:normal;border:none;position:static;cursor:default;color:#fffc00;background:none;display:inline;width:100%}.nc-container .clickCaptcha .clickCaptcha_img{margin:0 auto;clear:both;position:relative;}.nc-container .clickCaptcha .clickCaptcha_img img{width:230px;height:230px;margin-left:10px;margin-top:5px}.nc-container .clickCaptcha .clickCaptcha_btn{margin:10px 0 0 15px;position:relative;text-align:left;}.nc-container .clickCaptcha .clickCaptcha_btn img{cursor:pointer}.nc-container .imgCaptcha{position:absolute;left:0;top:35px;height:auto;padding-bottom:15px;border:1px solid #ccc;background:#fff;}.nc-container .imgCaptcha div{position:static;width:90%;background-color:#fff}.nc-container .imgCaptcha,.nc-container .clickCaptcha{text-align:left;}.nc-container .imgCaptcha a,.nc-container .clickCaptcha a{color:#ff3f08}.nc-container .imgCaptcha .imgCaptcha_text{height:42px;line-height:42px;width:120px;background:#fff;font-size:14px;text-align:left;color:#747474;float:left;margin-left:10px;}.nc-container .imgCaptcha .imgCaptcha_text input{margin-top:5px;height:30px;line-height:30px;font-size:14px;width:90px;background:#fff}.nc-container .imgCaptcha .imgCaptcha_text input:focus{outline:none;color:#bbb}.nc-container .imgCaptcha .imgCaptcha_btn{margin:0 0 0 12px;*margin-left:0;clear:both;padding-top:5px;width:90%;}.nc-container .imgCaptcha .imgCaptcha_btn img{cursor:pointer}.nc-container .imgCaptcha .nc_scale_submit{margin:0 auto;cursor:pointer;background-color:#fc461e;width:120px;height:32px;line-height:32px;color:#fff;text-align:center}.nc-container .imgCaptcha .imgCaptcha_img{margin:4px 0 0 100px;height:40px;width:130px;overflow:hidden;cursor:pointer;}.nc-container .imgCaptcha .imgCaptcha_img img{width:130px}.nc-container .imgCaptcha .imgCaptcha_img input{border:solid 1px #ccc}.nc-lang-ar_MA,.nc-lang-ar_SA,.nc-lang-iw_HE,.nc-lang-iw_IL{text-align:right;*text-align:left;}.nc-lang-ar_MA .nc_scale .scale_text2,.nc-lang-ar_SA .nc_scale .scale_text2,.nc-lang-iw_HE .nc_scale .scale_text2,.nc-lang-iw_IL .nc_scale .scale_text2{text-align:right;}.nc-lang-ar_MA .nc_scale .scale_text2 span,.nc-lang-ar_SA .nc_scale .scale_text2 span,.nc-lang-iw_HE .nc_scale .scale_text2 span,.nc-lang-iw_IL .nc_scale .scale_text2 span{*display:inline-block;padding:0 56px 0 0}.nc-lang-ar_MA .nc_captcha_img_text,.nc-lang-ar_SA .nc_captcha_img_text,.nc-lang-iw_HE .nc_captcha_img_text,.nc-lang-iw_IL .nc_captcha_img_text{*text-align:right}.nc-lang-ar_MA span.nc-lang-cnt,.nc-lang-ar_SA span.nc-lang-cnt,.nc-lang-iw_HE span.nc-lang-cnt,.nc-lang-iw_IL span.nc-lang-cnt{text-align:right;direction:rtl}.nocaptcha span.nc-lang-cnt{float:none;height:auto;line-height:30px}.nc-container{font-size:12px;-ms-touch-action:none;touch-action:none;}.nc-container p{margin:0;padding:0;display:inline}.nc-container .scale_text.scale_text span[data-nc-lang="_startTEXT"]{display:inline-block;width:100%}.nc-container .scale_text.scale_text.slidetounlock span[data-nc-lang="_startTEXT"]{background:-webkit-gradient(linear,left top,right top,color-stop(0,#4d4d4d),color-stop(.4,#4d4d4d),color-stop(.5,#fff),color-stop(.6,#4d4d4d),color-stop(1,#4d4d4d));-webkit-background-clip:text;-webkit-text-fill-color:transparent;-webkit-animation:slidetounlock 3s infinite;-webkit-text-size-adjust:none}.nc-container .nc_scale .nc-align-center.scale_text2{text-align:center;text-indent:-42px}@-webkit-keyframes slidetounlock{0%{background-position:-200px 0}100%{background-position:200px 0}}.nc-container.tb-login .clickCaptcha_text .icon_close{line-height:30px;margin-left:0;cursor:default;color:#ff3f08;font-size:16px;float:left;margin-right:0;background:transparent;z-index:3}.nc-container.tb-login{position:relative;margin-top:20px;display:none;}.nc-container.tb-login .nc_scale{width:auto;}.nc-container.tb-login .nc_scale .scale_text2{text-indent:-42px;text-align:center;}.nc-container.tb-login .nc_scale .scale_text2 b{padding:0}.nc-container.tb-login .nc_scale.nc_err div.scale_text{background:#f79977}.nc-container.tb-login .errloading{width:auto}.nc-container.tb-login .imgCaptcha,.nc-container.tb-login .clickCaptcha{width:252px;*width:256px;border:0;*height:300px;min-height:300px;max-height:inherit !important;}.nc-container.tb-login .imgCaptcha div.login-msg.error,.nc-container.tb-login .clickCaptcha div.login-msg.error{background:#fff2f2}.nc-container.tb-login .imgCaptcha .captcha-error,.nc-container.tb-login .clickCaptcha .captcha-error{position:absolute;top:0;width:244px;height:auto;margin-bottom:15px;padding:3px;border:solid 1px #ff8e8e;line-height:18px}.nc-container.tb-login .imgCaptcha .captcha-inform,.nc-container.tb-login .clickCaptcha .captcha-inform{font-size:110%;margin-left:20px}.nc-container.tb-login .imgCaptcha{padding-top:66px;}.nc-container.tb-login .imgCaptcha .imgCaptcha_text{width:100px;margin-left:0;}.nc-container.tb-login .imgCaptcha .imgCaptcha_text input:focus{color:#000}.nc-container.tb-login .imgCaptcha .imgCaptcha_img{width:120px;_width:100px}.nc-container.tb-login .imgCaptcha .imgCaptcha_btn{width:100%;margin-left:0}.nc-container.tb-login .imgCaptcha .nc_scale_submit{width:100%;height:36px;line-height:36px;margin-top:20px;margin-left:0;border-radius:3px;font-size:16px;font-family:Tahoma,Helvetica,Arial,sans-serif;background:#ff3f08}.nc-container.tb-login .clickCaptcha{padding-top:40px;}.nc-container.tb-login .clickCaptcha .clickCaptcha_text{text-indent:4px}.nc-container.tb-login .clickCaptcha .clickCaptcha_img img{margin-left:10px}.nc-container.tb-login .nc_btn_1{top:77px;_top:57px}.nc-container.tb-login .nc_btn_2{top:36px}.login .nc-container.tb-login .login-msg p,.login-box .nc-container.tb-login .login-msg p{width:auto;float:left}.nc-container.tb-login.nc-old-login{margin:20px 0 10px 0;width:250px;}.nc-container.tb-login.nc-old-login .nc_wrapper{width:250px}.nc-container.tb-login.nc-old-login .imgCaptcha,.nc-container.tb-login.nc-old-login .clickCaptcha{width:250px;min-height:auto;}.nc-container.tb-login.nc-old-login .imgCaptcha .captcha-error,.nc-container.tb-login.nc-old-login .clickCaptcha .captcha-error{line-height:16px}.nc-container.tb-login.nc-old-login .clickCaptcha{padding-top:28px;}.nc-container.tb-login.nc-old-login .clickCaptcha .clickCaptcha_img img{width:200px;height:200px}.nc-container.nc-old-login.show-click-captcha{padding-bottom:60px}.nc-container.nc-old-login.show-click-captcha.nc-tm-min-fix{padding-bottom:40px}.nc-container.tb-login.nc-tm-min-fix .clickCaptcha{max-height:340px !important}#content .login-box .bd .nc-container.tb-login .login-msg{margin:10px auto 15px auto}#content .login-box .bd .nc-container.tb-login.nc-old-login.show-click-captcha .login-msg{margin:2px 0 0 0}.nc-container .nc_scale .nc-cc{display:none;position:absolute;left:0;top:35px;z-index:20000;width:360px;height:570px;border:1px solid #5eaef1;border-radius:4px;background:#fff;font-size:14px;line-height:18px;color:#333;}.nc-container .nc_scale .nc-cc.nc-cc-status-loading .nc-cc-btn,.nc-container .nc_scale .nc-cc.nc-cc-status-verifing .nc-cc-btn{background-color:#90c1eb}.nc-container .nc_scale .nc-cc.nc-cc-status-loading .nc-cc-btn,.nc-container .nc_scale .nc-cc.nc-cc-status-verifing .nc-cc-btn,.nc-container .nc_scale .nc-cc.nc-cc-status-loading .nc-cc-refresh,.nc-container .nc_scale .nc-cc.nc-cc-status-verifing .nc-cc-refresh{cursor:default}.nc-container .nc_scale .nc-cc.nc-cc-status-loading .nc-cc-refresh,.nc-container .nc_scale .nc-cc.nc-cc-status-verifing .nc-cc-refresh{color:#999}.nc-container .nc_scale .nc-cc a{color:#3199f4;text-decoration:none}.nc-container .nc_scale .nc-cc .nc_iconfont{vertical-align:top;margin-right:8px}.nc-container .nc_scale .nc-cc-btn{display:inline-block;*display:inline;*zoom:1;vertical-align:top;letter-spacing:normal;word-spacing:normal;width:100px;line-height:30px;text-align:center;background-color:#3199f4;color:#fff;border-radius:4px;cursor:pointer;}.nc-container .nc_scale .nc-cc-btn.nc-cc-disabled{background-color:#90c1eb;cursor:default}.nc-container .nc_scale .nc-cc-btn .nc-lang-cnt{line-height:18px}.nc-container .nc_scale .nc-cc-header{padding:20px 20px 19px 20px;height:100px;background:#f4f8fa;border-bottom:1px solid #ccc}.nc-container .nc_scale .nc-cc-img1-box{float:left;width:100px;height:100px;margin-right:16px}.nc-container .nc_scale .nc-cc-txt{overflow:hidden;*zoom:1;line-height:30px;padding-top:11px}.nc-container .nc_scale .nc-cc-img2-box{position:relative;padding:0 20px;margin-top:20px}.nc-container .nc_scale .nc-cc-items{position:absolute;left:20px;_left:0;top:0;width:320px;overflow:hidden}.nc-container .nc_scale .nc-cc-items-inner{margin-right:-20px}.nc-container .nc_scale .nc-cc-item{position:relative;display:inline-block;*display:inline;*zoom:1;vertical-align:top;letter-spacing:normal;word-spacing:normal;margin-right:10px;margin-bottom:10px;border:1px solid #ccc;width:98px;height:98px;background:url("//gtms02.alicdn.com/tps/i2/T1ty2QFNNXXXc6Yc2r-1-1.gif");}.nc-container .nc_scale .nc-cc-item:hover{border-color:#3199f4}.nc-container .nc_scale .nc-cc-item .nc_iconfont{display:none;position:absolute;right:0;bottom:0;color:#3199f4;font-size:22px;margin-right:0}.nc-container .nc_scale .nc-cc-item.nc-cc-selected .nc_iconfont{display:block}.nc-container .nc_scale .nc-cc-tip{display:none;position:absolute;left:0;bottom:60px;width:360px;line-height:18px;text-align:center;color:#eb4f38;}.nc-container .nc_scale .nc-cc-tip span{line-height:normal}.nc-container .nc_scale .nc-cc-footer{position:absolute;left:0;bottom:20px;width:360px;height:30px;line-height:30px;text-align:center;}.nc-container .nc_scale .nc-cc-footer .nc_iconfont{color:#c4cbd0}.nc-container .nc_scale .nc-cc-refresh,.nc-container .nc_scale .nc-cc-wait{position:absolute;left:20px;top:0;color:#3199f4;cursor:pointer}.nc-container .nc_scale .nc-cc-wait{display:none}.nc-container .nc_scale .nc-cc-cancel{position:absolute;right:20px;top:0;color:#3199f4;cursor:pointer;}.nc-container .nc_scale .nc-cc-cancel .nc_iconfont{position:relative;top:-1px}.nc-container .nc_scale .nc-cc-loading{margin-top:247px;text-align:center;line-height:14px}.nc-container .nc_scale .nc-cc-loading-img{display:inline-block;*display:inline;*zoom:1;vertical-align:top;letter-spacing:normal;word-spacing:normal;vertical-align:middle;background:url("//img.alicdn.com/tps/TB1OdxsKpXXXXcgXFXXXXXXXXXX-14-14.gif") no-repeat;width:14px;height:14px;position:relative;top:-1px;margin-right:9px}.nc-container .nc_scale .nc-cc-fail{position:absolute;left:50%;top:50%;width:320px;height:180px;margin-left:-160px;margin-top:-90px;background:#fff;border-radius:4px}.nc-container .nc_scale .nc-cc-fail-inner{text-align:center;padding:55px 10px 10px}.nc-container .nc_scale .nc-cc-fail-action{margin:28px 0 18px;}.nc-container .nc_scale .nc-cc-fail-action a{display:inline-block;*display:inline;*zoom:1;vertical-align:top;letter-spacing:normal;word-spacing:normal;line-height:30px;margin-left:16px}.nc-container .nc_scale .nc-cc-contact{text-align:right;color:#666;padding-right:9px}.nc-container .nc_scale .nc-cc-mask{display:none;position:absolute;left:0;top:0;width:360px;height:570px;background:rgba(0,0,0,0.3);filter:progid:DXImageTransform.Microsoft.gradient(enabled='true',startColorstr='#4C000000', endColorstr='#4C000000');}:root .nc-container .nc_scale .nc-cc-mask{-webkit-filter:none;filter:none}.nc-container .nc_scale .nc-cc-arrow-1,.nc-container .nc_scale .nc-cc-arrow-2{display:none;position:absolute;top:340px;border:solid transparent;height:0;width:0}.nc-container .nc_scale .nc-cc-arrow-1{border-width:16px;margin-top:-1px}.nc-container .nc_scale .nc-cc-arrow-2{border-width:15px}.nc-container .nc_scale .nc-cc-right .nc-cc-arrow-1,.nc-container .nc_scale .nc-cc-left .nc-cc-arrow-1,.nc-container .nc_scale .nc-cc-right .nc-cc-arrow-2,.nc-container .nc_scale .nc-cc-left .nc-cc-arrow-2{display:block;_display:none}.nc-container .nc_scale .nc-cc-right{left:180px;top:-339px;}.nc-container .nc_scale .nc-cc-right .nc-cc-arrow-1{border-right-color:#5eaef1;left:-32px}.nc-container .nc_scale .nc-cc-right .nc-cc-arrow-2{border-right-color:#fff;left:-30px}.nc-container .nc_scale .nc-cc-left{left:-335px;top:-339px;}.nc-container .nc_scale .nc-cc-left .nc-cc-arrow-1{border-left-color:#5eaef1;right:-32px}.nc-container .nc_scale .nc-cc-left .nc-cc-arrow-2{border-left-color:#fff;right:-30px}</style><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="react" src="./react.js" crossorigin="anonymous"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="react-dom" src="./react-dom.js" crossorigin="anonymous"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="//o.alicdn.com/lzdfe/lzd-h5-itrace/index.js" src="//o.alicdn.com/lzdfe/lzd-h5-itrace/index.js" crossorigin="anonymous"></script><script src="https://g.lazcdn.com/g/lzd/assets/1.2.10/web-vitals/3.4.0/index.js"></script><style>@charset "utf-8";
@font-face{font-family:'nc_iconfont';src:url("//at.alicdn.com/t/font_1465353706_4784257.eot");src:url("//at.alicdn.com/t/font_1465353706_4784257.eot?#iefix") format('embedded-opentype'),url("//at.alicdn.com/t/font_1465353706_4784257.woff") format('woff'),url("//at.alicdn.com/t/font_1465353706_4784257.ttf") format('truetype'),url("//at.alicdn.com/t/font_1465353706_4784257.svg#iconfont") format('svg')}@font-face{font-family:'ncpc_iconfont';src:url("//at.alicdn.com/t/font_384029_rhzpmteb25oecdi.eot");src:url("//at.alicdn.com/t/font_384029_rhzpmteb25oecdi.eot?#iefix") format('embedded-opentype'),url("//at.alicdn.com/t/font_384029_rhzpmteb25oecdi.woff") format('woff'),url("//at.alicdn.com/t/font_384029_rhzpmteb25oecdi.ttf") format('truetype'),url("//at.alicdn.com/t/font_384029_rhzpmteb25oecdi.svg#ncpc_iconfont") format('svg')}.nc-container div#nc-loading-circle{background:transparent;width:20px;height:20px;display:inline-block;position:relative;vertical-align:middle}.nc-container div#nc-loading-circle .sk-circle{background:transparent;width:100%;height:100%;position:absolute;left:0;top:0}.nc-container #nc-loading-circle .sk-circle:before{content:'';display:block;margin:0 auto;width:15%;height:15%;background-color:#818181;border-radius:100%;-webkit-animation:sk-circleFadeDelay 1.2s infinite ease-in-out both;animation:sk-circleFadeDelay 1.2s infinite ease-in-out both}.nc-container #nc-loading-circle .sk-circle2{-webkit-transform:rotate(30deg);-ms-transform:rotate(30deg);transform:rotate(30deg)}.nc-container #nc-loading-circle .sk-circle3{-webkit-transform:rotate(60deg);-ms-transform:rotate(60deg);transform:rotate(60deg)}.nc-container #nc-loading-circle .sk-circle4{-webkit-transform:rotate(90deg);-ms-transform:rotate(90deg);transform:rotate(90deg)}.nc-container #nc-loading-circle .sk-circle5{-webkit-transform:rotate(120deg);-ms-transform:rotate(120deg);transform:rotate(120deg)}.nc-container #nc-loading-circle .sk-circle6{-webkit-transform:rotate(150deg);-ms-transform:rotate(150deg);transform:rotate(150deg)}.nc-container #nc-loading-circle .sk-circle7{-webkit-transform:rotate(180deg);-ms-transform:rotate(180deg);transform:rotate(180deg)}.nc-container #nc-loading-circle .sk-circle8{-webkit-transform:rotate(210deg);-ms-transform:rotate(210deg);transform:rotate(210deg)}.nc-container #nc-loading-circle .sk-circle9{-webkit-transform:rotate(240deg);-ms-transform:rotate(240deg);transform:rotate(240deg)}.nc-container #nc-loading-circle .sk-circle10{-webkit-transform:rotate(270deg);-ms-transform:rotate(270deg);transform:rotate(270deg)}.nc-container #nc-loading-circle .sk-circle11{-webkit-transform:rotate(300deg);-ms-transform:rotate(300deg);transform:rotate(300deg)}.nc-container #nc-loading-circle .sk-circle12{-webkit-transform:rotate(330deg);-ms-transform:rotate(330deg);transform:rotate(330deg)}.nc-container #nc-loading-circle .sk-circle2:before{-webkit-animation-delay:-1.1s;animation-delay:-1.1s}.nc-container #nc-loading-circle .sk-circle3:before{-webkit-animation-delay:-1s;animation-delay:-1s}.nc-container #nc-loading-circle .sk-circle4:before{-webkit-animation-delay:-.9s;animation-delay:-.9s}.nc-container #nc-loading-circle .sk-circle5:before{-webkit-animation-delay:-.8s;animation-delay:-.8s}.nc-container #nc-loading-circle .sk-circle6:before{-webkit-animation-delay:-.7s;animation-delay:-.7s}.nc-container #nc-loading-circle .sk-circle7:before{-webkit-animation-delay:-.6s;animation-delay:-.6s}.nc-container #nc-loading-circle .sk-circle8:before{-webkit-animation-delay:-.5s;animation-delay:-.5s}.nc-container #nc-loading-circle .sk-circle9:before{-webkit-animation-delay:-.4s;animation-delay:-.4s}.nc-container #nc-loading-circle .sk-circle10:before{-webkit-animation-delay:-.3s;animation-delay:-.3s}.nc-container #nc-loading-circle .sk-circle11:before{-webkit-animation-delay:-.2s;animation-delay:-.2s}.nc-container #nc-loading-circle .sk-circle12:before{-webkit-animation-delay:-.1s;animation-delay:-.1s}@-webkit-keyframes sk-circleFadeDelay{0%,39%,100%{opacity:0}40%{opacity:1}}@-webkit-keyframes sk-circleFadeDelay{0%,39%,100%{opacity:0}40%{opacity:1}}@keyframes sk-circleFadeDelay{0%,39%,100%{opacity:0}40%{opacity:1}}.nc-container .scale_text2 #nc-loading-circle .sk-circle:before{background-color:#fff}.nc_iconfont{font-family:"nc_iconfont";color:#ff3f08;font-size:16px;font-style:normal}.ncpc_iconfont{font-family:"ncpc_iconfont";color:#ff3f08;font-size:16px;font-style:normal}.captcha-error .icon_ban{float:left;font-size:16px;padding-right:5px;line-height:14px}.clickCaptcha_text .btn_refresh{font-style:normal;cursor:pointer;background:#fff;color:#737383}.imgCaptcha .btn_refresh{font-size:20px;cursor:pointer;background:#fff;color:#737383}.nc_voice{display:none;position:relative;margin-top:-34px;z-index:99;width:auto;height:34px;background:#fff}.omeo-code-img,.omeo-code-audio{font-size:0;text-align:left}.omeo-code-audiobox,.omeo-code-img a,.omeo-code-audio a,.omeo-code-state{display:inline-block;*display:inline;zoom:1;height:32px;vertical-align:top;font-size:12px}.omeo-code .omeo-code-refresh{background:transparent;width:32px;height:32px;font-size:20px;color:#888;text-align:center;text-decoration:none;padding-left:4px;line-height:32px}.omeo-code .omeo-switch{display:none;width:32px;height:32px;border-left:1px solid #e1e1e1;background-image:url("//g.alicdn.com/sd/ncpc/images/checkcode.png");background-repeat:no-repeat}.omeo-img-active .omeo-code-img{display:block}.omeo-img-active .omeo-code-audio{display:none}.omeo-code-img img{border:1px solid #cdcdcd;cursor:pointer}.omeo-code-img .omeo-switch{background-position:9px -41px}.omeo-audio-active .omeo-code-audio{display:block}.omeo-audio-active .omeo-code-img{display:none}.omeo-code-refresh{position:relative;left:95px}.omeo-code-audiobox{position:relative;height:30px;line-height:32px;border:1px solid #e1e1e1;text-align:center;overflow:hidden;left:100px;top:1px;width:45%;min-width:80px;background-color:#eee}.omeo-code-audiobox a{display:block;text-decoration:none;color:#06c}.omeo-code-audiobox-playing a{visibility:hidden}.omeo-code-audiobox span,.omeo-code-audiobox b{visibility:hidden;position:absolute;top:0;left:0;height:30px;font-weight:100;overflow:hidden}.omeo-code-audiobox-playing span,.omeo-code-audiobox-playing b{visibility:visible}.omeo-code-audiobox span{z-index:0;width:0;background:#186bca}.omeo-code-audiobox b{width:100%;z-index:1;text-align:left;text-indent:30px;color:#999;background:url("//g.alicdn.com/sd/ncpc/images/checkcode.png") no-repeat 14px -89px}.omeo-code-audio .omeo-switch{background-position:5px 10px}input[type=text]::-ms-clear{display:none}.omeo-box{position:relative;background-color:#fff}.omeo-code-echo{position:absolute;top:2px;left:2px}.omeo-code-echo input{padding:5px;height:18px;line-height:18px;border:1px solid #ddd;width:80px;outline:0}.omeo-code-state{height:30px;line-height:30px;text-indent:25px;white-space:nowrap;background-image:url("//g.alicdn.com/sd/ncpc/images/checkcode.png");background-repeat:no-repeat;background-position:100px 100px}.omeo-code-echo .omeo-code-state-error{width:auto;background-position:7px -193px}.omeo-code-echo .omeo-code-state-success{position:absolute;width:30px;background-position:7px -243px}.omeo-code-state{position:absolute;left:0;top:28px}.nc_voice_close{display:inline-block;position:relative;cursor:pointer;left:95px;top:0;border-left:#ddd 2px solid;padding:0 0 0 7px;background-color:#fff;font-size:20px;color:#888;line-height:32px}.nc_help{position:absolute;width:100%;height:100%;left:0;top:0;z-index:99999}.nc_help .mask{background-color:#000;opacity:.5;filter:alpha(opacity=50);width:100%;height:100%;top:0;left:0}.nc_btn_close{position:absolute;height:20px;left:500px;border-radius:20px;padding:10px 30px;background-color:#aaa;color:#fff;cursor:pointer;z-index:10}.nc_btn_close:hover{background-color:#afafaf}.nc_hand{position:absolute;width:68px;height:53px;background-image:url("//g.alicdn.com/sd/ncpc/images/hand.png");z-index:3}.nc_slide_bg{z-index:3;font-size:12px;text-align:center;color:#fff;line-height:34px}.nc_voicebtn{position:absolute;padding:0;right:-25px;font-size:23px;color:#888;cursor:pointer;line-height:34px}.nc_helpbtn{position:absolute;cursor:pointer;right:-95px;top:4px;font-size:12px;background-color:#ffb668;color:#fff;padding:4px;border-radius:2px;line-height:18px;display:none}.nc_helpbtn:before{width:0;height:0;content:"";position:absolute;left:-2px;top:6px;border-top:4px solid transparent;border-bottom:4px solid transparent;border-right:4px solid #ffb668}.nc-container .errloading{border:#faf1d5 1px solid;text-indent:3px;background-image:none;font-size:12px;width:290px;line-height:20px;padding:7px 5px 8px 5px;color:#ef9f06;}.nc-container .errloading a{color:#30a7fc}.nc_captcha_text .nc_err{float:left;text-indent:0}.button_move{transition:left .5s;-moz-transition:left .5s;-webkit-transition:left .5s;-o-transition:left .5s}.bg_move{transition:width .5s;-moz-transition:width .5s;-webkit-transition:width .5s;-o-transition:width .5s}.nc_slide_box{position:absolute}.nc_captcha_text{height:auto;line-height:20px;visibility:hidden;font-size:12px;color:#999;font-weight:normal}.nc-container .nc_captcha_img_text{width:auto;height:auto;line-height:20px;visibility:hidden;font-size:12px;color:#999;font-weight:normal;display:none;padding:0 0 10px 0;background-position:0 0;}.nc-container .nc_captcha_img_text span.nc-lang-cnt{line-height:inherit}.nc-container .imgCaptcha .nc_captcha_img_text{width:auto}.nc_captcha_img_text{height:auto;line-height:20px;visibility:hidden;font-size:12px;color:#999;font-weight:normal;display:none;padding:0 0 10px 3px;background-position:0 0}.nc-container .nc_wrapper{width:auto}.nc_scale{width:auto;height:34px;background:#e8e8e8;position:relative;margin:0;padding:0}.nc_scale.is_audio{margin-right:25px}.nc-container .nc_scale div{height:auto}.nc-container .nc_scale ul{list-style:none}.nc-container .nc_scale .btn_slide{color:#737383;background-image:none;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.nc-container .nc_scale span{text-align:center;width:40px;height:32px;line-height:32px;border:1px solid #ccc;position:absolute;left:0;cursor:move;background:#fff;z-index:2}.nc-container .nc_scale span.nc-lang-cnt{*line-height:34px;float:none;width:auto;height:auto;*height:34px;border:none;position:static;cursor:inherit;background:none;z-index:0;display:inline}.nc_slide_button{width:40px;height:32px;border:1px solid #ccc;position:absolute;left:0;cursor:move;background:#fff url("//g.alicdn.com/sd/ncpc/images/rt.png") no-repeat center;z-index:2}@media screen and (-ms-high-contrast:active),(-ms-high-contrast:none){.nc_scale span{height:32px}}.nc-container .nc_scale .btnok{cursor:default;background:#fff url("//g.alicdn.com/sd/ncpc/images/yes.png") no-repeat center;z-index:3}.nc-container .nc_scale .btnok2{cursor:default;font-size:20px;background:#fff url("//g.alicdn.com/sd/ncpc/images/no.png") no-repeat center;z-index:3}.nc-container .nc_scale .btn_warn{cursor:default;color:#ff3f08;line-height:34px;text-align:center;font-size:20px;background:#fff;z-index:3}.nc-container .clickCaptcha_text .btn_refresh{font-size:20px}.nc-container .clickCaptcha_text .icon_close{line-height:30px;margin-left:8px;cursor:default;color:#ff3f08;font-size:16px;float:left;margin-right:2px;background:transparent;z-index:3}.nc-container .nc_captcha_img_text .icon_close{cursor:default;color:#ff3f08;font-size:16px;float:left;margin-right:4px;background:transparent;z-index:3;line-height:18px}.nc-container .errloading .icon_warn{cursor:default;color:#ff3f08;font-size:18px;float:left;background:transparent;z-index:3}.nc-container .nc_scale .btn_ok{cursor:default;line-height:34px;text-align:center;font-size:20px;background:#fff;z-index:3;color:#76c61d}.nc-container .nc_scale .nc_ok,.nc-container .nc_scale .nc_bg{background:#7ac23c}.nc-container .nc_scale .nc_bg{position:absolute;height:100%;_height:34px;left:0;width:10px}.nc-container .nc_scale div.redbar{background:#fc461e;opacity:.5;filter:alpha(opacity=50)}.nc-container .nc_scale div.orange{background:#f00}.nc-container .nc_scale .scale_text{width:100%;height:100%;text-align:center;position:absolute;z-index:1;background:transparent;color:#9c9c9c;line-height:34px;font-size:12px;cursor:pointer}.nc-container .nc_scale .scale_text2{text-align:left;color:#fff;font-size:12px;text-indent:10px}.nc-container .nc_scale .scale_text2 b{padding-left:0;font-weight:normal}.nc-container .nc_scale .scale_text.scale_loading_text{text-align:center}.nc-container .nc_scale .imgCaptcha,.nc-container .nc_scale .clickCaptcha{display:none;overflow:hidden;border:1px solid #ccc;background:#fff;z-index:20000;}.nc-container .nc_scale .imgCaptcha p.error span,.nc-container .nc_scale .clickCaptcha p.error span{line-height:normal}.nc-container .nc_scale .imgCaptcha{height:auto}.nc-container .nc_scale .clickCaptcha{position:absolute;left:0;top:35px;height:270px;background:#fff;display:none;}.nc-container .nc_scale .clickCaptcha p.error i{color:#ff3f08;font-style:normal}.nc-container .nc_scale .clickCaptcha div{position:static;clear:both;width:100%;background:#fff;height:auto}.nc-container .nc_scale .clickCaptcha .clickCaptcha_text{height:30px;line-height:30px;font-size:12px;color:#999;}.nc-container .nc_scale .clickCaptcha .clickCaptcha_text b{font-weight:normal}.nc_btn_2{position:absolute;right:0;top:0;cursor:pointer;margin:2px 9px 0 0}.nc_iconfont.nc_btn_2{position:absolute;right:0;top:0;cursor:pointer}.nc_iconfont.nc_btn_1{position:absolute;top:10px;right:5px}.nc_btn_1{top:10px;right:10px}.scale_text i{font-style:normal;border:none;position:static;cursor:default;color:#fffc00;background:none;display:inline;width:100%}.nc-container .clickCaptcha .clickCaptcha_img{margin:0 auto;clear:both;position:relative;}.nc-container .clickCaptcha .clickCaptcha_img img{width:230px;height:230px;margin-left:10px;margin-top:5px}.nc-container .clickCaptcha .clickCaptcha_btn{margin:10px 0 0 15px;position:relative;text-align:left;}.nc-container .clickCaptcha .clickCaptcha_btn img{cursor:pointer}.nc-container .imgCaptcha{position:absolute;left:0;top:35px;height:auto;padding-bottom:15px;border:1px solid #ccc;background:#fff;}.nc-container .imgCaptcha div{position:static;width:90%;background-color:#fff}.nc-container .imgCaptcha,.nc-container .clickCaptcha{text-align:left;}.nc-container .imgCaptcha a,.nc-container .clickCaptcha a{color:#ff3f08}.nc-container .imgCaptcha .imgCaptcha_text{height:42px;line-height:42px;width:120px;background:#fff;font-size:14px;text-align:left;color:#747474;float:left;margin-left:10px;}.nc-container .imgCaptcha .imgCaptcha_text input{margin-top:5px;height:30px;line-height:30px;font-size:14px;width:90px;background:#fff}.nc-container .imgCaptcha .imgCaptcha_text input:focus{outline:none;color:#bbb}.nc-container .imgCaptcha .imgCaptcha_btn{margin:0 0 0 12px;*margin-left:0;clear:both;padding-top:5px;width:90%;}.nc-container .imgCaptcha .imgCaptcha_btn img{cursor:pointer}.nc-container .imgCaptcha .nc_scale_submit{margin:0 auto;cursor:pointer;background-color:#fc461e;width:120px;height:32px;line-height:32px;color:#fff;text-align:center}.nc-container .imgCaptcha .imgCaptcha_img{margin:4px 0 0 100px;height:40px;width:130px;overflow:hidden;cursor:pointer;}.nc-container .imgCaptcha .imgCaptcha_img img{width:130px}.nc-container .imgCaptcha .imgCaptcha_img input{border:solid 1px #ccc}.nc-lang-ar_MA,.nc-lang-ar_SA,.nc-lang-iw_HE,.nc-lang-iw_IL{text-align:right;*text-align:left;}.nc-lang-ar_MA .nc_scale .scale_text2,.nc-lang-ar_SA .nc_scale .scale_text2,.nc-lang-iw_HE .nc_scale .scale_text2,.nc-lang-iw_IL .nc_scale .scale_text2{text-align:right;}.nc-lang-ar_MA .nc_scale .scale_text2 span,.nc-lang-ar_SA .nc_scale .scale_text2 span,.nc-lang-iw_HE .nc_scale .scale_text2 span,.nc-lang-iw_IL .nc_scale .scale_text2 span{*display:inline-block;padding:0 56px 0 0}.nc-lang-ar_MA .nc_captcha_img_text,.nc-lang-ar_SA .nc_captcha_img_text,.nc-lang-iw_HE .nc_captcha_img_text,.nc-lang-iw_IL .nc_captcha_img_text{*text-align:right}.nc-lang-ar_MA span.nc-lang-cnt,.nc-lang-ar_SA span.nc-lang-cnt,.nc-lang-iw_HE span.nc-lang-cnt,.nc-lang-iw_IL span.nc-lang-cnt{text-align:right;direction:rtl}.nocaptcha span.nc-lang-cnt{float:none;height:auto;line-height:30px}.nc-container{font-size:12px;-ms-touch-action:none;touch-action:none;}.nc-container p{margin:0;padding:0;display:inline}.nc-container .scale_text.scale_text span[data-nc-lang="_startTEXT"]{display:inline-block;width:100%}.nc-container .scale_text.scale_text.slidetounlock span[data-nc-lang="_startTEXT"]{background:-webkit-gradient(linear,left top,right top,color-stop(0,#4d4d4d),color-stop(.4,#4d4d4d),color-stop(.5,#fff),color-stop(.6,#4d4d4d),color-stop(1,#4d4d4d));-webkit-background-clip:text;-webkit-text-fill-color:transparent;-webkit-animation:slidetounlock 3s infinite;-webkit-text-size-adjust:none}.nc-container .nc_scale .nc-align-center.scale_text2{text-align:center;text-indent:-42px}@-webkit-keyframes slidetounlock{0%{background-position:-200px 0}100%{background-position:200px 0}}.nc-container.tb-login .clickCaptcha_text .icon_close{line-height:30px;margin-left:0;cursor:default;color:#ff3f08;font-size:16px;float:left;margin-right:0;background:transparent;z-index:3}.nc-container.tb-login{position:relative;margin-top:20px;display:none;}.nc-container.tb-login .nc_scale{width:auto;}.nc-container.tb-login .nc_scale .scale_text2{text-indent:-42px;text-align:center;}.nc-container.tb-login .nc_scale .scale_text2 b{padding:0}.nc-container.tb-login .nc_scale.nc_err div.scale_text{background:#f79977}.nc-container.tb-login .errloading{width:auto}.nc-container.tb-login .imgCaptcha,.nc-container.tb-login .clickCaptcha{width:252px;*width:256px;border:0;*height:300px;min-height:300px;max-height:inherit !important;}.nc-container.tb-login .imgCaptcha div.login-msg.error,.nc-container.tb-login .clickCaptcha div.login-msg.error{background:#fff2f2}.nc-container.tb-login .imgCaptcha .captcha-error,.nc-container.tb-login .clickCaptcha .captcha-error{position:absolute;top:0;width:244px;height:auto;margin-bottom:15px;padding:3px;border:solid 1px #ff8e8e;line-height:18px}.nc-container.tb-login .imgCaptcha .captcha-inform,.nc-container.tb-login .clickCaptcha .captcha-inform{font-size:110%;margin-left:20px}.nc-container.tb-login .imgCaptcha{padding-top:66px;}.nc-container.tb-login .imgCaptcha .imgCaptcha_text{width:100px;margin-left:0;}.nc-container.tb-login .imgCaptcha .imgCaptcha_text input:focus{color:#000}.nc-container.tb-login .imgCaptcha .imgCaptcha_img{width:120px;_width:100px}.nc-container.tb-login .imgCaptcha .imgCaptcha_btn{width:100%;margin-left:0}.nc-container.tb-login .imgCaptcha .nc_scale_submit{width:100%;height:36px;line-height:36px;margin-top:20px;margin-left:0;border-radius:3px;font-size:16px;font-family:Tahoma,Helvetica,Arial,sans-serif;background:#ff3f08}.nc-container.tb-login .clickCaptcha{padding-top:40px;}.nc-container.tb-login .clickCaptcha .clickCaptcha_text{text-indent:4px}.nc-container.tb-login .clickCaptcha .clickCaptcha_img img{margin-left:10px}.nc-container.tb-login .nc_btn_1{top:77px;_top:57px}.nc-container.tb-login .nc_btn_2{top:36px}.login .nc-container.tb-login .login-msg p,.login-box .nc-container.tb-login .login-msg p{width:auto;float:left}.nc-container.tb-login.nc-old-login{margin:20px 0 10px 0;width:250px;}.nc-container.tb-login.nc-old-login .nc_wrapper{width:250px}.nc-container.tb-login.nc-old-login .imgCaptcha,.nc-container.tb-login.nc-old-login .clickCaptcha{width:250px;min-height:auto;}.nc-container.tb-login.nc-old-login .imgCaptcha .captcha-error,.nc-container.tb-login.nc-old-login .clickCaptcha .captcha-error{line-height:16px}.nc-container.tb-login.nc-old-login .clickCaptcha{padding-top:28px;}.nc-container.tb-login.nc-old-login .clickCaptcha .clickCaptcha_img img{width:200px;height:200px}.nc-container.nc-old-login.show-click-captcha{padding-bottom:60px}.nc-container.nc-old-login.show-click-captcha.nc-tm-min-fix{padding-bottom:40px}.nc-container.tb-login.nc-tm-min-fix .clickCaptcha{max-height:340px !important}#content .login-box .bd .nc-container.tb-login .login-msg{margin:10px auto 15px auto}#content .login-box .bd .nc-container.tb-login.nc-old-login.show-click-captcha .login-msg{margin:2px 0 0 0}.nc-container .nc_scale .nc-cc{display:none;position:absolute;left:0;top:35px;z-index:20000;width:360px;height:570px;border:1px solid #5eaef1;border-radius:4px;background:#fff;font-size:14px;line-height:18px;color:#333;}.nc-container .nc_scale .nc-cc.nc-cc-status-loading .nc-cc-btn,.nc-container .nc_scale .nc-cc.nc-cc-status-verifing .nc-cc-btn{background-color:#90c1eb}.nc-container .nc_scale .nc-cc.nc-cc-status-loading .nc-cc-btn,.nc-container .nc_scale .nc-cc.nc-cc-status-verifing .nc-cc-btn,.nc-container .nc_scale .nc-cc.nc-cc-status-loading .nc-cc-refresh,.nc-container .nc_scale .nc-cc.nc-cc-status-verifing .nc-cc-refresh{cursor:default}.nc-container .nc_scale .nc-cc.nc-cc-status-loading .nc-cc-refresh,.nc-container .nc_scale .nc-cc.nc-cc-status-verifing .nc-cc-refresh{color:#999}.nc-container .nc_scale .nc-cc a{color:#3199f4;text-decoration:none}.nc-container .nc_scale .nc-cc .nc_iconfont{vertical-align:top;margin-right:8px}.nc-container .nc_scale .nc-cc-btn{display:inline-block;*display:inline;*zoom:1;vertical-align:top;letter-spacing:normal;word-spacing:normal;width:100px;line-height:30px;text-align:center;background-color:#3199f4;color:#fff;border-radius:4px;cursor:pointer;}.nc-container .nc_scale .nc-cc-btn.nc-cc-disabled{background-color:#90c1eb;cursor:default}.nc-container .nc_scale .nc-cc-btn .nc-lang-cnt{line-height:18px}.nc-container .nc_scale .nc-cc-header{padding:20px 20px 19px 20px;height:100px;background:#f4f8fa;border-bottom:1px solid #ccc}.nc-container .nc_scale .nc-cc-img1-box{float:left;width:100px;height:100px;margin-right:16px}.nc-container .nc_scale .nc-cc-txt{overflow:hidden;*zoom:1;line-height:30px;padding-top:11px}.nc-container .nc_scale .nc-cc-img2-box{position:relative;padding:0 20px;margin-top:20px}.nc-container .nc_scale .nc-cc-items{position:absolute;left:20px;_left:0;top:0;width:320px;overflow:hidden}.nc-container .nc_scale .nc-cc-items-inner{margin-right:-20px}.nc-container .nc_scale .nc-cc-item{position:relative;display:inline-block;*display:inline;*zoom:1;vertical-align:top;letter-spacing:normal;word-spacing:normal;margin-right:10px;margin-bottom:10px;border:1px solid #ccc;width:98px;height:98px;background:url("//gtms02.alicdn.com/tps/i2/T1ty2QFNNXXXc6Yc2r-1-1.gif");}.nc-container .nc_scale .nc-cc-item:hover{border-color:#3199f4}.nc-container .nc_scale .nc-cc-item .nc_iconfont{display:none;position:absolute;right:0;bottom:0;color:#3199f4;font-size:22px;margin-right:0}.nc-container .nc_scale .nc-cc-item.nc-cc-selected .nc_iconfont{display:block}.nc-container .nc_scale .nc-cc-tip{display:none;position:absolute;left:0;bottom:60px;width:360px;line-height:18px;text-align:center;color:#eb4f38;}.nc-container .nc_scale .nc-cc-tip span{line-height:normal}.nc-container .nc_scale .nc-cc-footer{position:absolute;left:0;bottom:20px;width:360px;height:30px;line-height:30px;text-align:center;}.nc-container .nc_scale .nc-cc-footer .nc_iconfont{color:#c4cbd0}.nc-container .nc_scale .nc-cc-refresh,.nc-container .nc_scale .nc-cc-wait{position:absolute;left:20px;top:0;color:#3199f4;cursor:pointer}.nc-container .nc_scale .nc-cc-wait{display:none}.nc-container .nc_scale .nc-cc-cancel{position:absolute;right:20px;top:0;color:#3199f4;cursor:pointer;}.nc-container .nc_scale .nc-cc-cancel .nc_iconfont{position:relative;top:-1px}.nc-container .nc_scale .nc-cc-loading{margin-top:247px;text-align:center;line-height:14px}.nc-container .nc_scale .nc-cc-loading-img{display:inline-block;*display:inline;*zoom:1;vertical-align:top;letter-spacing:normal;word-spacing:normal;vertical-align:middle;background:url("//img.alicdn.com/tps/TB1OdxsKpXXXXcgXFXXXXXXXXXX-14-14.gif") no-repeat;width:14px;height:14px;position:relative;top:-1px;margin-right:9px}.nc-container .nc_scale .nc-cc-fail{position:absolute;left:50%;top:50%;width:320px;height:180px;margin-left:-160px;margin-top:-90px;background:#fff;border-radius:4px}.nc-container .nc_scale .nc-cc-fail-inner{text-align:center;padding:55px 10px 10px}.nc-container .nc_scale .nc-cc-fail-action{margin:28px 0 18px;}.nc-container .nc_scale .nc-cc-fail-action a{display:inline-block;*display:inline;*zoom:1;vertical-align:top;letter-spacing:normal;word-spacing:normal;line-height:30px;margin-left:16px}.nc-container .nc_scale .nc-cc-contact{text-align:right;color:#666;padding-right:9px}.nc-container .nc_scale .nc-cc-mask{display:none;position:absolute;left:0;top:0;width:360px;height:570px;background:rgba(0,0,0,0.3);filter:progid:DXImageTransform.Microsoft.gradient(enabled='true',startColorstr='#4C000000', endColorstr='#4C000000');}:root .nc-container .nc_scale .nc-cc-mask{-webkit-filter:none;filter:none}.nc-container .nc_scale .nc-cc-arrow-1,.nc-container .nc_scale .nc-cc-arrow-2{display:none;position:absolute;top:340px;border:solid transparent;height:0;width:0}.nc-container .nc_scale .nc-cc-arrow-1{border-width:16px;margin-top:-1px}.nc-container .nc_scale .nc-cc-arrow-2{border-width:15px}.nc-container .nc_scale .nc-cc-right .nc-cc-arrow-1,.nc-container .nc_scale .nc-cc-left .nc-cc-arrow-1,.nc-container .nc_scale .nc-cc-right .nc-cc-arrow-2,.nc-container .nc_scale .nc-cc-left .nc-cc-arrow-2{display:block;_display:none}.nc-container .nc_scale .nc-cc-right{left:180px;top:-339px;}.nc-container .nc_scale .nc-cc-right .nc-cc-arrow-1{border-right-color:#5eaef1;left:-32px}.nc-container .nc_scale .nc-cc-right .nc-cc-arrow-2{border-right-color:#fff;left:-30px}.nc-container .nc_scale .nc-cc-left{left:-335px;top:-339px;}.nc-container .nc_scale .nc-cc-left .nc-cc-arrow-1{border-left-color:#5eaef1;right:-32px}.nc-container .nc_scale .nc-cc-left .nc-cc-arrow-2{border-left-color:#fff;right:-30px}</style><script async="" src="//gj.mmstat.com/eg.js?t=1727913600318"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="//o.alicdn.com/lzdfe/lzd-h5-itrace/index.js" src="//o.alicdn.com/lzdfe/lzd-h5-itrace/index.js" crossorigin="anonymous"></script></head>
<body data-spm="pdp_revamp" style="overflow-y: scroll">
  <script>window.__lzd__svg__cssinject__ = true;</script>
<style>
  .svgfont {
    display: inline-block;
    width: 1em;
    height: 1em;
    fill: currentColor;
    font-size: 1em;
  }

  #container, body {
    background: #075e0a;

  .lzd-header .lzd-links-bar {
    background: linear-gradient(89.87deg, #075e0a 35.41%, #000000 121.72%);
  }

  .lzd-header .lzd-links-bar .top-links-item .orange, .lzd-header .lzd-links-bar .top-links-item.orange {
    color: #000000;
  }

  .lzd-header .lzd-links-bar .top-links-item .cyan, .lzd-header .lzd-links-bar .top-links-item.cyan {
    color: #000000;
  }
  
}

</style>

<svg aria-hidden="true" style="position: absolute; width: 0px; height: 0px; overflow: hidden;">
  <symbol id="lazadaicon_success" viewBox="0 0 1024 1024">
    <path
      d="M512 938.666667c234.666667 0 426.666667-192 426.666667-426.666667s-192-426.666667-426.666667-426.666667-426.666667 192-426.666667 426.666667 192 426.666667 426.666667 426.666667z">
    </path>
    <path
      d="M418.133333 691.2c-8.533333 0-12.8-4.266667-21.333333-8.533333l-115.2-115.2c-12.8-12.8-12.8-29.866667 0-38.4 12.8-12.8 29.866667-12.8 38.4 0l93.866667 93.866666 256-247.466666c12.8-12.8 29.866667-12.8 38.4 0s12.8 29.866667 0 38.4l-273.066667 268.8c0 8.533333-8.533333 8.533333-17.066667 8.533333"
      fill="#000000"></path>
  </symbol>
  <symbol id="lazadaicon_cart" viewBox="0 0 1024 1024">
    <path
      d="M381.248 761.344a51.328 51.328 0 1 0 0 102.656 51.328 51.328 0 0 0 0-102.656z m-252.928-118.4v68.416h125.056l-14.88-68.448H128.32z m0-145.824v68.448h92.896l-14.88-68.448H128.32zM377.6 237.12l14.912 68.448h419.616V642.88H384.96L289.6 193.504 128.64 192 128 260.448l106.048 0.992 95.488 449.92h551.04V237.12H377.6z m458.4 575.552a51.328 51.328 0 1 1-102.72 0 51.328 51.328 0 0 1 102.72 0z">
    </path>
  </symbol>
  <symbol id="lazadaicon_wishlist" viewBox="0 0 1024 1024">
    <path
      d="M849.067 233.244c-82.49-82.488-209.067-82.488-291.556 0l-166.4 164.978 52.622 51.2 164.978-164.978c55.467-55.466 135.111-55.466 189.156 0 45.51 45.512 61.155 128 0 189.156l-72.534 72.533L509.156 748.09 292.978 546.133 220.444 473.6c-49.777-56.889-41.244-146.489 0-189.156 51.2-51.2 132.267-52.622 184.89-4.266l51.2-51.2c-81.067-76.8-209.067-75.378-287.29 2.844-65.422 65.422-82.488 200.534-1.422 290.134l75.378 75.377 265.956 248.89 265.955-248.89 73.956-73.955c91.022-89.6 71.11-219.022 0-290.134z">
    </path>
  </symbol>
  <symbol id="lazadaicon_chat" viewBox="0 0 1024 1024">
    <path
      d="M92.471652 820.758261l165.286957-123.547826h666.935652V136.993391H92.449391v683.742609zM0 887.318261l92.471652-66.56v-134.455652L0 741.62087V44.521739h1017.143652v745.160348H283.692522L0 989.807304V887.318261z">
    </path>
    <path
      d="M261.988174 275.70087h477.762783v92.471652H261.988174zM261.988174 445.217391h261.988174v92.471652H261.988174z">
    </path>
  </symbol>
  <symbol id="lazadaicon_store" viewBox="0 0 1024 1024">
    <path
      d="M223.833043 141.868522l180.936348 1.669565h332.221218l92.471652-92.471652H405.504L160.723478 48.88487 19.945739 316.549565a142.06887 142.06887 0 0 0 95.654957 188.66087 158.118957 158.118957 0 0 0 134.322087-24.998957l26.37913-24.197565 27.469913 23.863652a159.209739 159.209739 0 0 0 90.445913 28.026435 159.432348 159.432348 0 0 0 111.304348-45.100522l2.381913-2.337391 2.381913 2.337391a159.432348 159.432348 0 0 0 111.304348 45.100522c30.764522 0 59.503304-8.681739 83.878956-23.752348l35.617392-29.874087 34.148174 30.430609a158.029913 158.029913 0 0 0 128.289391 20.813913 142.870261 142.870261 0 0 0 96.478609-188.994783l-92.249044-173.367652-68.608 66.404174 74.48487 139.976348a50.398609 50.398609 0 0 1-34.059131 66.671304 65.958957 65.958957 0 0 1-67.673043-21.370435l-68.741565-81.92-71.123479 79.872a67.072 67.072 0 0 1-50.44313 22.639305 66.982957 66.982957 0 0 1-47.972174-20.034783l-65.714087-66.404174-65.736348 66.426435c-12.644174 12.777739-29.606957 20.012522-47.949913 20.012522a67.049739 67.049739 0 0 1-49.775304-21.904696l-70.010435-76.354782-67.940174 78.202434a65.936696 65.936696 0 0 1-66.960696 20.524522 49.597217 49.597217 0 0 1-33.391304-65.869913l117.693217-208.161391z">
    </path>
    <path d="M184.943304 876.744348V445.217391H92.471652v523.976348h832.200348V445.217391h-92.449391v431.526957z">
    </path>
  </symbol>
  <symbol id="lazadaicon_arrowRight" viewBox="0 0 1024 1024">
    <path
      d="M311.466667 814.933333l68.266666 59.733334 332.8-366.933334-332.8-358.4-64 59.733334 273.066667 298.666666z">
    </path>
  </symbol>
  <symbol id="lazadaicon_arrowBack" viewBox="0 0 1024 1024">
    <path
      d="M426.666667 507.733333L763.733333 170.666667l-85.333333-85.333334L256 507.733333l4.266667 4.266667 422.4 422.4 85.333333-85.333333-341.333333-341.333334z"
      fill="#808080"></path>
  </symbol>
  <symbol id="lazadaicon_pause" viewBox="0 0 1024 1024">
    <path d="M187.733333 102.4h256v819.2H187.733333zM597.333333 102.4h256v819.2H597.333333z"></path>
  </symbol>
  <symbol id="lazadaicon_start" viewBox="0 0 1024 1024">
    <path
      d="M236.249425 10.759014l591.395068 460.126685a42.082192 42.082192 0 0 1 0.490959 66.055013l-591.395068 474.266302A42.082192 42.082192 0 0 1 168.328767 978.396932V43.989918A42.082192 42.082192 0 0 1 236.249425 10.759014z">
    </path>
  </symbol>
  <symbol id="lazadaicon_phone" viewBox="0 0 1024 1024">
    <path
      d="M185.6 21.333333v85.333334h567.466667v29.866666H185.6v874.666667h652.8V21.333333H185.6z m567.466667 904.533334H270.933333v-123.733334h482.133334v123.733334z m0-206.933334H270.933333V221.866667h482.133334v497.066666z"
      fill=""></path>
    <path d="M512 864m-42.666667 0a42.666667 42.666667 0 1 0 85.333334 0 42.666667 42.666667 0 1 0-85.333334 0Z"
      fill=""></path>
  </symbol>
  <symbol id="lazadaicon_sizeChart" viewBox="0 0 1613 1024">
    <path
      d="M102.4 68.267h1405.673v893.672H102.4V68.267z m89.988 803.685h1225.697V158.255H192.388v713.697z m294.788 0h-89.988V425.115h89.988v446.837z m363.054 0h-89.988V605.09h89.988v266.86z m359.952 0h-89.988V425.115h89.988v446.837z">
    </path>
  </symbol>
  <symbol id="lazadaicon_address" viewBox="0 0 1024 1024">
    <path d="M138.971 980.114H43.886V190.171h412.038v95.086H138.97V885.03h599.772V694.857h95.086v285.257H138.97z">
    </path>
    <path
      d="M980.114 343.771c0 65.829-21.943 124.343-70.704 170.667-31.696 31.695-68.267 53.638-112.153 63.39l-351.086 65.83c-9.752 2.437-19.504-7.315-17.066-17.068l70.705-341.333c0-2.438 2.438-7.314 2.438-7.314 9.752-41.448 31.695-75.581 63.39-107.276 46.324-48.762 104.838-70.705 170.667-70.705s124.343 24.38 170.666 73.143c48.762 46.324 73.143 102.4 73.143 170.666z m-190.171-58.514C770.438 265.752 748.495 256 721.676 256c-26.819 0-48.762 9.752-65.828 26.819-19.505 19.505-26.82 41.448-26.82 68.267 0 26.819 9.753 48.762 29.258 68.266 19.504 19.505 41.447 29.258 68.266 29.258 26.82 0 48.762-9.753 68.267-26.82 19.505-19.504 26.82-41.447 26.82-65.828-2.439-29.257-12.191-51.2-31.696-70.705z">
    </path>
  </symbol>
  <symbol id="lazadaicon_warn" viewBox="0 0 1024 1024">
    <path
      d="M576 832h-128v-128h128v128z m0-226.133333h-128v-384h128v384zM512 0C230.4 0 0 230.4 0 512s230.4 512 512 512 512-230.4 512-512S793.6 0 512 0z"
      fill="#FF9000"></path>
  </symbol>
  <symbol id="lazadaicon_pin" viewBox="0 0 1024 1024">
    <path
      d="M512 544c64 0 118.4-51.2 118.4-115.2S576 313.6 512 313.6s-118.4 51.2-118.4 115.2S448 544 512 544z m0 345.6l-25.6-25.6c-28.8-28.8-268.8-297.6-268.8-444.8 0-156.8 131.2-284.8 291.2-284.8s291.2 128 291.2 284.8c0 147.2-240 416-268.8 444.8l-19.2 25.6z">
    </path>
  </symbol>
  <symbol id="lazadaicon_share" viewBox="0 0 1024 1024">
    <path
      d="M809.344 695.369143c-44.580571 0-85.101714 17.792-113.481143 49.243428L340.553143 535.332571a101.193143 101.193143 0 0 0 0-49.243428l355.309714-207.908572a152.246857 152.246857 0 0 0 113.481143 50.614858c86.473143-1.371429 151.314286-67.035429 152.667429-154.569143C960.658286 86.674286 895.817143 19.657143 809.344 18.285714c-86.454857 1.371429-152.667429 68.388571-154.002286 155.940572 0 9.563429 1.334857 19.145143 2.688 28.708571L305.426286 408.137143c-28.379429-31.451429-67.547429-51.968-114.834286-51.968-86.473143 1.353143-152.685714 67.017143-154.020571 154.569143 1.353143 87.533714 67.547429 153.197714 154.020571 154.550857 44.580571 0 86.454857-20.516571 114.834286-51.968l352.603428 206.537143c-1.334857 9.581714-2.688 19.163429-2.688 30.098285 1.334857 87.552 67.547429 153.197714 154.002286 154.569143 86.473143-1.371429 151.314286-67.017143 152.667429-154.569143-1.353143-87.533714-66.194286-153.197714-152.667429-154.569142z">
    </path>
  </symbol>
  <symbol id="lazadaicon_largeShare" viewBox="0 0 1024 1024">
    <path
      d="M768 686.933333c-34.133333 0-59.733333 12.8-85.333333 34.133334l-302.933334-179.2c4.266667-8.533333 4.266667-17.066667 4.266667-29.866667 0-8.533333 0-21.333333-4.266667-29.866667L682.666667 307.2c21.333333 21.333333 51.2 34.133333 85.333333 34.133333 72.533333 0 128-55.466667 128-128s-55.466667-128-128-128-128 55.466667-128 128c0 8.533333 0 21.333333 4.266667 29.866667L341.333333 418.133333C320 396.8 290.133333 384 256 384c-72.533333 0-128 55.466667-128 128s55.466667 128 128 128c34.133333 0 64-12.8 85.333333-34.133333l302.933334 179.2c-4.266667 8.533333-4.266667 17.066667-4.266667 29.866666 0 68.266667 55.466667 123.733333 123.733333 123.733334s123.733333-55.466667 123.733334-123.733334c4.266667-68.266667-51.2-128-119.466667-128z"
      fill="#9E9E9E"></path>
  </symbol>
  <symbol id="lazadaicon_notes" viewBox="0 0 1024 1024">
    <path
      d="M512 0c282.624 0 512 229.376 512 512s-229.376 512-512 512S0 794.624 0 512 229.376 0 512 0zM460.8 768h102.4V460.8H460.8v307.2z m0-409.6h102.4V256H460.8v102.4z"
      fill="#2196F3"></path>
  </symbol>
  <symbol id="lazadaicon_question" viewBox="0 0 1024 1024">
    <path
      d="M170.666667 85.333333c-46.933333 0-85.333333 38.4-85.333334 85.333334v768l170.666667-170.666667h597.333333c46.933333 0 85.333333-38.4 85.333334-85.333333V170.666667c0-46.933333-38.4-85.333333-85.333334-85.333334H170.666667z m512 320c0 34.133333-4.266667 64-17.066667 89.6-12.8 25.6-25.6 42.666667-46.933333 59.733334l59.733333 46.933333-34.133333 38.4-76.8-59.733333c-8.533333 4.266667-21.333333 4.266667-34.133334 4.266666-29.866667 0-55.466667-8.533333-76.8-21.333333s-38.4-34.133333-51.2-59.733333c-12.8-29.866667-21.333333-59.733333-21.333333-93.866667v-21.333333c0-34.133333 4.266667-64 17.066667-93.866667 12.8-25.6 29.866667-46.933333 51.2-59.733333s51.2-21.333333 81.066666-21.333334 55.466667 8.533333 76.8 21.333334 38.4 34.133333 51.2 59.733333 21.333333 59.733333 21.333334 93.866667v17.066666z m-64-17.066666c0-38.4-8.533333-72.533333-21.333334-93.866667-17.066667-21.333333-38.4-29.866667-64-29.866667s-46.933333 12.8-64 34.133334c-12.8 21.333333-21.333333 51.2-21.333333 89.6v21.333333c0 38.4 8.533333 68.266667 21.333333 89.6s38.4 34.133333 64 34.133333c29.866667 0 51.2-8.533333 64-29.866666 12.8-21.333333 21.333333-51.2 21.333334-93.866667v-21.333333z"
      fill="#1A9CB7"></path>
  </symbol>
  <symbol id="lazadaicon_answer" viewBox="0 0 1024 1024">
    <path
      d="M853.333333 85.333333H170.666667c-46.933333 0-85.333333 38.4-85.333334 85.333334v768l170.666667-170.666667h597.333333c46.933333 0 85.333333-38.4 85.333334-85.333333V170.666667c0-46.933333-38.4-85.333333-85.333334-85.333334z m-260.266666 439.466667h-140.8l-29.866667 85.333333H358.4l136.533333-362.666666h55.466667l136.533333 362.666666h-64l-29.866666-85.333333zM469.333333 473.6h106.666667l-51.2-149.333333-55.466667 149.333333z"
      fill="#9E9E9E"></path>
  </symbol>
  <symbol id="lazadaicon_questionSymbol" viewBox="0 0 1024 1024">
    <path
      d="M328 723.2l-121.6 121.6c-12.8 12.8-33.6 3.2-33.6-14.4V256c0-46.4 38.4-83.2 83.2-83.2h512c46.4 0 83.2 38.4 83.2 83.2v384c0 46.4-38.4 83.2-83.2 83.2H328z m-22.4-33.6c3.2-3.2 9.6-6.4 14.4-6.4h448c24 0 44.8-19.2 44.8-44.8V256c0-24-19.2-44.8-44.8-44.8H256c-24 0-44.8 19.2-44.8 44.8v528l94.4-94.4z"
      fill="#979797"></path>
    <path
      d="M507.2 628.8c-14.4 0-27.2-11.2-27.2-27.2 0-14.4 11.2-27.2 27.2-27.2 14.4 0 27.2 11.2 27.2 27.2-1.6 16-12.8 27.2-27.2 27.2zM588.8 438.4L564.8 464c-19.2 19.2-30.4 35.2-30.4 75.2H480v-12.8c0-28.8 12.8-56 32-75.2L544 416c9.6-9.6 16-22.4 16-36.8C560 350.4 536 326.4 507.2 326.4c-28.8 0-52.8 24-52.8 52.8H400a107.2 107.2 0 0 1 214.4 0c-1.6 22.4-11.2 44.8-25.6 59.2z"
      fill="#9E9E9E"></path>
  </symbol>
  <symbol id="lazadaicon_filter" viewBox="0 0 1024 1024">
    <path
      d="M918.75555522 201.95555522c-4.266667-8.533333-17.066667-17.066667-25.6-17.066666H129.42222222c-12.8 0-21.333333 8.533333-25.6 17.066666-4.266667 12.8-4.266667 25.6 4.266667 34.133334L411.02222222 611.55555522v256c0 17.066667 12.8 29.866667 29.866667 29.866667 17.066667 0 29.866667-12.8 29.866666-29.866667v-277.333333l-277.333333-341.333333H824.88888922l-277.333334 341.333333V867.55555522c0 17.066667 12.8 29.866667 29.866667 29.866667s29.866667-12.8 29.866667-29.866667v-256L910.22222222 236.08888922c12.8-8.533333 12.8-21.333333 8.533333-34.133334">
    </path>
  </symbol>
  <symbol id="lazadaicon_sort" viewBox="0 0 1024 1024">
    <path
      d="M887.466667 725.333333l-192 192-12.8 12.8c-4.266667 4.266667-12.8 8.533333-17.066667 8.533334-8.533333 0-12.8-4.266667-21.333333-8.533334l-8.533334-8.533333-192-192c-8.533333-12.8-8.533333-29.866667 0-38.4l12.8-12.8c12.8-12.8 34.133333-8.533333 42.666667 4.266667l128 128v-345.6c0-21.333333 17.066667-38.4 38.4-38.4s38.4 17.066667 38.4 38.4V810.666667l128-132.266667c8.533333-12.8 29.866667-12.8 38.4 0l12.8 12.8c12.8 8.533333 17.066667 21.333333 4.266667 34.133333z m-320-375.466666c-12.8 12.8-34.133333 8.533333-42.666667-4.266667l-128-128v345.6c0 21.333333-17.066667 38.4-38.4 38.4s-38.4-17.066667-38.4-38.4V217.6l-128 128c-8.533333 12.8-29.866667 12.8-38.4 0l-17.066667-8.533333c-8.533333-12.8-12.8-25.6 0-38.4l192-192 8.533334-12.8c8.533333-4.266667 12.8-8.533333 21.333333-8.533334s12.8 4.266667 21.333333 8.533334l4.266667 8.533333 196.266667 192c8.533333 12.8 8.533333 29.866667 0 38.4l-12.8 17.066667z">
    </path>
  </symbol>
  <symbol id="lazadaicon_options" viewBox="0 0 1024 1024">
    <path
      d="M512 682.666667c46.933333 0 85.333333 38.4 85.333333 85.333333s-38.4 85.333333-85.333333 85.333333-85.333333-38.4-85.333333-85.333333 38.4-85.333333 85.333333-85.333333z m0-85.333334c-46.933333 0-85.333333-38.4-85.333333-85.333333s38.4-85.333333 85.333333-85.333333 85.333333 38.4 85.333333 85.333333-38.4 85.333333-85.333333 85.333333z m0-256c-46.933333 0-85.333333-38.4-85.333333-85.333333s38.4-85.333333 85.333333-85.333333 85.333333 38.4 85.333333 85.333333-38.4 85.333333-85.333333 85.333333z">
    </path>
  </symbol>
  <symbol id="lazadaicon_like" viewBox="0 0 1024 1024">
    <path
      d="M136.533333 849.066667h140.8v-426.666667H136.533333v426.666667z m785.066667-388.266667c0-38.4-34.133333-72.533333-72.533333-72.533333h-226.133334l34.133334-162.133334V213.333333c0-12.8-4.266667-29.866667-17.066667-38.4l-38.4-38.4-230.4 234.666667c-12.8 12.8-21.333333 34.133333-21.333333 51.2v354.133333c0 38.4 34.133333 72.533333 72.533333 72.533334h320c29.866667 0 55.466667-17.066667 64-42.666667l106.666667-251.733333c4.266667-8.533333 4.266667-17.066667 4.266666-25.6v-68.266667h4.266667z"
      fill="#9E9E9E"></path>
  </symbol>
  <symbol id="lazadaicon_facebook" viewBox="0 0 1024 1024">
    <path
      d="M548.864 1024h-73.728C212.992 1024 0 811.008 0 548.864v-73.728C0 212.992 212.992 0 475.136 0h73.728C811.008 0 1024 212.992 1024 475.136v73.728C1024 811.008 811.008 1024 548.864 1024z"
      fill="#3B5998"></path>
    <path
      d="M534.528 778.24h-110.592V512H368.64v-92.16h55.296v-55.296c0-75.776 30.72-118.784 118.784-118.784h73.728v92.16h-45.056c-34.816 0-36.864 12.288-36.864 36.864v45.056h83.968l-10.24 92.16h-73.728v266.24z"
      fill="#000000"></path>
  </symbol>
  <symbol id="lazadaicon_soldbyLAZ" viewBox="0 0 1024 1024">
    <path d="M512 512m-512 0a512 512 0 1 0 1024 0 512 512 0 1 0-1024 0Z" fill="#F37226"></path>
    <path
      d="M625.777778 341.333333h208.782222l-133.12 213.617778a249.457778 249.457778 0 0 0-28.444444-12.515555L568.888889 312.888889h-33.848889l-178.631111 398.222222h32.995555l43.235556-97.848889 6.257778-14.222222a223.573333 223.573333 0 0 1 131.413333-42.097778 253.724444 253.724444 0 0 1 115.484445 22.755556l-70.542223 113.777778 8.248889 18.204444h222.151111l13.653334-30.151111h-201.671111l215.324444-341.333333V312.888889h-260.266667z m-55.182222 185.457778a287.288889 287.288889 0 0 0-110.08 23.893333l2.56-5.688888L551.537778 341.333333l83.626666 190.293334a309.191111 309.191111 0 0 0-64.853333-4.835556z"
      fill="#000000"></path>
    <path
      d="M850.488889 718.222222h-231.537778l-11.662222-25.884444 68.266667-109.795556a256 256 0 0 0-104.96-18.488889 214.755556 214.755556 0 0 0-125.724445 39.537778l-50.915555 113.777778h-48.64l185.173333-412.444445h42.666667l103.822222 230.968889c7.111111 2.844444 14.506667 5.688889 21.617778 9.102223l122.88-197.404445h-200.817778l-19.057778-42.666667h278.471111v38.115556l-209.635555 330.808889h199.111111z m-222.435556-14.222222h213.048889l7.111111-15.928889h-203.377777l221.013333-350.435555v-17.635556h-242.346667l6.542222 14.222222h217.031112l-142.222223 229.831111-5.688889-2.844444a278.471111 278.471111 0 0 0-28.444444-11.946667h-2.844444l-1.422223-2.844444-100.977777-225.564445H540.444444l-170.666666 384h17.351111l49.777778-110.648889a229.831111 229.831111 0 0 1 135.68-43.52 261.404444 261.404444 0 0 1 118.613333 23.324445l7.111111 3.413333-72.817778 116.906667z m-181.76-139.377778l105.244445-239.786666 95.573333 217.6-13.368889-2.844445a316.017778 316.017778 0 0 0-63.146666-5.688889 284.444444 284.444444 0 0 0-107.52 23.04z m105.244445-204.515555l-77.937778 177.208889a308.337778 308.337778 0 0 1 96.711111-17.635556 300.942222 300.942222 0 0 1 52.906667 3.697778zM181.76 312.888889H151.04v398.222222h186.88l12.8-29.013333H181.76V312.888889z"
      fill="#000000"></path>
    <path
      d="M341.333333 718.222222H142.222222v-412.444444h46.648889v369.777778h172.942222z m-184.32-14.222222h174.933334l6.826666-14.791111H174.648889v-369.777778h-16.497778z"
      fill="#000000"></path>
  </symbol>
  <symbol id="lazadaicon_officialBadge" viewBox="0 0 1024 1024">
    <path d="M512 1024c281.6 0 512-230.4 512-512S793.6 0 512 0 0 230.4 0 512s230.4 512 512 512z" fill="#CE0909"></path>
    <path
      d="M853.333333 785.066667v8.533333c0 8.533333-8.533333 17.066667-17.066666 17.066667h-8.533334l-110.933333-34.133334-25.6 110.933334c0 8.533333-8.533333 17.066667-17.066667 17.066666s-17.066667-8.533333-17.066666-8.533333l-128-256h-42.666667l-119.466667 247.466667c0 8.533333-8.533333 8.533333-17.066666 8.533333s-17.066667-8.533333-17.066667-17.066667l-25.6-102.4-110.933333 42.666667c-8.533333 0-17.066667 0-25.6-8.533333v-17.066667l128-256c-34.133333-42.666667-51.2-93.866667-51.2-153.6 0-145.066667 119.466667-256 264.533333-256s256 110.933333 256 256c0 51.2-17.066667 102.4-51.2 145.066667l136.533333 256zM512 580.266667c110.933333 0 204.8-85.333333 204.8-196.266667 0-110.933333-93.866667-196.266667-204.8-196.266667-110.933333 0-204.8 85.333333-204.8 196.266667 0 110.933333 85.333333 196.266667 204.8 196.266667zM546.133333 341.333333h93.866667l-76.8 59.733334 25.6 93.866666-76.8-51.2-85.333333 51.2 25.6-93.866666-76.8-59.733334h93.866666l34.133334-85.333333 42.666666 85.333333z"
      fill="#000000"></path>
  </symbol>
  <symbol id="lazadaicon_taobaoBadge" viewBox="0 0 1024 1024">
    <path d="M512 0C230.4 0 0 230.4 0 512s230.4 512 512 512 512-230.4 512-512-230.4-512-512-512z" fill="#FF440B"></path>
    <path
      d="M256 264.533333c34.133333 0 68.266667 25.6 68.266667 59.733334 0 34.133333-25.6 59.733333-68.266667 59.733333-34.133333 0-68.266667-25.6-68.266667-59.733333 0-34.133333 34.133333-59.733333 68.266667-59.733334zM307.2 614.4c-17.066667 51.2-17.066667 34.133333-85.333333 179.2l-93.866667-59.733333s110.933333-102.4 136.533333-145.066667c17.066667-42.666667-25.6-76.8-25.6-76.8l-76.8-42.666667 42.666667-59.733333c59.733333 42.666667 59.733333 42.666667 102.4 85.333333 25.6 25.6 17.066667 68.266667 0 119.466667z"
      fill="#000000"></path>
    <path
      d="M844.8 682.666667c-17.066667 179.2-256 110.933333-256 110.933333l17.066667-51.2 51.2 8.533333c102.4 8.533333 93.866667-85.333333 93.866666-85.333333v-256c0-93.866667-93.866667-110.933333-256-51.2l42.666667 8.533333c0 8.533333-17.066667 25.6-34.133333 51.2h221.866666v42.666667H597.333333v59.733333h128v42.666667H597.333333v93.866667l51.2-25.6-8.533333-25.6 59.733333-17.066667 51.2 119.466667-76.8 25.6-17.066666-42.666667c-34.133333 25.6-93.866667 59.733333-213.333334 51.2-128 0-93.866667-136.533333-93.866666-136.533333h85.333333c0 17.066667-8.533333 51.2 0 68.266666 17.066667 8.533333 34.133333 8.533333 51.2 8.533334h8.533333V580.266667H366.933333v-51.2h128v-51.2h-34.133333c-34.133333 25.6-59.733333 51.2-59.733333 51.2l-34.133334-34.133334c25.6-25.6 51.2-68.266667 68.266667-102.4-8.533333 8.533333-25.6 17.066667-42.666667 17.066667-8.533333 17.066667-25.6 42.666667-42.666666 59.733333l-59.733334-34.133333C349.866667 375.466667 384 256 384 256l93.866667 25.6s-8.533333 17.066667-25.6 42.666667c366.933333-102.4 384 59.733333 384 59.733333s25.6 119.466667 8.533333 298.666667z"
      fill="#000000"></path>
  </symbol>
  <symbol id="lazadaicon_certified" viewBox="0 0 1024 1024">
    <path
      d="M512 0c282.766222 0 512 229.233778 512 512s-229.233778 512-512 512S0 794.766222 0 512 229.233778 0 512 0z m255.914667 318.577778l-25.315556-0.455111c-0.568889 0-57.429333-1.251556-116.053333-25.514667-60.188444-24.917333-98.986667-53.475556-99.271111-53.76L511.914667 227.555556l-15.189334 11.292444c-0.369778 0.284444-39.139556 28.842667-99.271111 53.76-58.624 24.291556-115.484444 25.514667-116.024889 25.514667L256 318.577778v263.082666C256 713.671111 422.456889 853.333333 512 853.333333c89.543111 0 256-139.633778 256-271.701333l-0.085333-263.082667zM487.736889 682.666667L341.333333 565.646222l44.999111-49.692444 93.866667 74.979555L658.460444 398.222222 711.111111 441.088 487.708444 682.666667z"
      fill="#06A97F"></path>
  </symbol>
  <symbol id="lazadaicon_liveUp" viewBox="0 0 1024 1024">
    <path
      d="M349.866667 72.533333h324.266666c153.6 0 277.333333 123.733333 277.333334 277.333334v320c0 153.6-123.733333 277.333333-277.333334 277.333333H349.866667c-153.6 0-277.333333-123.733333-277.333334-277.333333V349.866667c0-153.6 123.733333-277.333333 277.333334-277.333334"
      fill="#38C0C6"></path>
    <path
      d="M755.2 422.4l-89.6-89.6c-8.533333-8.533333-17.066667-12.8-29.866667-12.8-8.533333 0-21.333333 4.266667-29.866666 12.8l-89.6 89.6c-17.066667 17.066667-17.066667 42.666667 0 55.466667 17.066667 17.066667 42.666667 17.066667 55.466666 0l21.333334-21.333334v89.6c0 64-34.133333 93.866667-85.333334 93.866667s-85.333333-34.133333-85.333333-98.133333c0-25.6-21.333333-42.666667-42.666667-42.666667-25.6 0-42.666667 17.066667-42.666666 42.666667v4.266666c0 115.2 64 174.933333 170.666666 174.933334s174.933333-59.733333 174.933334-179.2v-85.333334l21.333333 21.333334c17.066667 17.066667 42.666667 17.066667 55.466667 0 12.8-12.8 12.8-38.4-4.266667-55.466667m-379.733333-8.533333c25.6 0 51.2-21.333333 51.2-46.933334 0-25.6-21.333333-46.933333-51.2-46.933333s-51.2 17.066667-51.2 46.933333c0 25.6 25.6 46.933333 51.2 46.933334"
      fill="#FFCD05"></path>
  </symbol>
  <symbol id="lazadaicon_fulfilledbyLazada" viewBox="0 0 1024 1024">
    <path
      d="M911.829333 510.762667c0-221.866667-179.2-401.066667-401.066666-401.066667s-401.066667 179.2-401.066667 401.066667 179.2 401.066667 401.066667 401.066666 401.066667-179.2 401.066666-401.066666m-42.666666 0c0 196.266667-157.866667 354.133333-354.133334 354.133333s-358.4-157.866667-358.4-354.133333 157.866667-354.133333 354.133334-354.133334 358.4 157.866667 358.4 354.133334"
      fill="#00374C"></path>
    <path
      d="M463.829333 369.962667h196.266667v-64h-196.266667v64z m-102.4 349.866666h72.533334v-132.266666h-72.533334v132.266666z"
      fill="#F07025"></path>
    <path d="M438.229333 493.696v-187.733333h-76.8v251.733333h200.533334v-64z" fill="#00374C"></path>
  </symbol>
  <symbol id="lazadaicon_economy" viewBox="0 0 1024 1024">
    <path
      d="M989.866667 529.066667c-132.266667-256-256-273.066667-294.4-273.066667H238.933333c-12.8 0-21.333333 8.533333-21.333333 21.333333v174.933334h42.666667V298.666667h439.466666c4.266667 0 98.133333-4.266667 213.333334 170.666666h-153.6c-34.133333 0-34.133333-29.866667-34.133334-38.4V358.4c0-12.8-8.533333-21.333333-21.333333-21.333333s-21.333333 8.533333-21.333333 21.333333v72.533333c0 29.866667 21.333333 76.8 76.8 76.8h174.933333c4.266667 12.8 12.8 21.333333 21.333333 38.4V640c0 12.8-12.8 25.6-25.6 25.6h-25.6c-8.533333-42.666667-42.666667-68.266667-85.333333-68.266667s-76.8 29.866667-85.333333 68.266667h-238.933334c-8.533333-42.666667-46.933333-68.266667-85.333333-68.266667-42.666667 0-76.8 29.866667-85.333333 68.266667h-38.4c-12.8 0-25.6-12.8-25.6-25.6v-34.133333h34.133333c12.8 0 21.333333-8.533333 21.333333-21.333334s-8.533333-21.333333-21.333333-21.333333H179.2c-12.8 0-21.333333 8.533333-21.333333 21.333333s8.533333 21.333333 21.333333 21.333334h38.4v34.133333c0 38.4 29.866667 68.266667 68.266667 68.266667h29.866666c8.533333 42.666667 42.666667 68.266667 85.333334 68.266666s76.8-29.866667 85.333333-68.266666H725.333333c8.533333 42.666667 42.666667 68.266667 85.333334 68.266666s76.8-29.866667 85.333333-68.266666h25.6c38.4 0 68.266667-29.866667 64-68.266667v-98.133333c8.533333-4.266667 8.533333-8.533333 4.266667-12.8m-174.933334 209.066666c-68.266667 0-68.266667-102.4 0-102.4s68.266667 102.4 0 102.4m-413.866666 0c-68.266667 0-68.266667-102.4 0-102.4s68.266667 102.4 0 102.4m-337.066667-251.733333c-12.8 0-21.333333 8.533333-21.333333 21.333333s8.533333 21.333333 21.333333 21.333334h273.066667c12.8 0 21.333333-8.533333 21.333333-21.333334s-8.533333-21.333333-21.333333-21.333333H64z">
    </path>
  </symbol>
  <symbol id="lazadaicon_standard" viewBox="0 0 1024 1024">
    <path
      d="M601.6 268.8h-68.266667V196.266667h68.266667v72.533333z m332.8 529.066667V128H234.666667c-8.533333 0-12.8 4.266667-21.333334 8.533333-8.533333 8.533333-8.533333 25.6 4.266667 34.133334l230.4 200.533333-162.133333 166.4L170.666667 435.2c-8.533333-8.533333-25.6-8.533333-34.133334 4.266667-8.533333 8.533333-8.533333 25.6 4.266667 34.133333l68.266667 59.733333v273.066667H426.666667l17.066666 34.133333c0 4.266667 12.8 25.6 34.133334 34.133334 4.266667 0 8.533333 4.266667 17.066666 4.266666s17.066667-4.266667 29.866667-8.533333l12.8-4.266667c4.266667 4.266667 12.8 8.533333 17.066667 12.8 4.266667 4.266667 8.533333 4.266667 17.066666 4.266667s21.333333-4.266667 34.133334-8.533333l12.8-4.266667c4.266667 4.266667 12.8 8.533333 17.066666 12.8 4.266667 0 8.533333 4.266667 17.066667 4.266667s21.333333-4.266667 34.133333-8.533334l17.066667-12.8c4.266667 4.266667 8.533333 4.266667 17.066667 8.533334 4.266667 0 8.533333 4.266667 12.8 4.266666 8.533333 0 17.066667-4.266667 29.866666-8.533333 8.533333-4.266667 12.8-17.066667 4.266667-25.6-4.266667-8.533333-17.066667-12.8-29.866667-4.266667l-4.266666 4.266667c-4.266667 0-4.266667-4.266667-4.266667-8.533333l-51.2-106.666667c-4.266667-8.533333-17.066667-17.066667-29.866667-8.533333-8.533333 4.266667-17.066667 17.066667-8.533333 25.6l42.666667 93.866666-17.066667 8.533334c-4.266667 4.266667-8.533333 4.266667-12.8 4.266666-4.266667 0-4.266667-4.266667-8.533333-8.533333l-38.4-85.333333c-8.533333-34.133333-21.333333-38.4-29.866667-34.133334-8.533333 4.266667-17.066667 17.066667-12.8 25.6l29.866667 68.266667-12.8 8.533333c-4.266667 4.266667-12.8 4.266667-17.066667 4.266667-4.266667-4.266667-8.533333-4.266667-8.533333-8.533333l-21.333334-55.466667c-4.266667-8.533333-17.066667-17.066667-29.866666-12.8-8.533333 4.266667-17.066667 17.066667-12.8 25.6l17.066666 38.4-12.8 4.266667c-4.266667 4.266667-8.533333 4.266667-12.8 4.266666-4.266667 0-4.266667-4.266667-4.266666-4.266666l-38.4-81.066667v-4.266667l-72.533334-157.866666-29.866666 29.866666 64 145.066667H256v-179.2l17.066667 17.066667c4.266667 4.266667 8.533333 4.266667 17.066666 4.266666 4.266667 0 12.8-4.266667 17.066667-4.266666l196.266667-200.533334c8.533333-8.533333 4.266667-25.6-4.266667-34.133333L294.4 179.2h187.733333V298.666667h162.133334V179.2h243.2v584.533333h-106.666667l-68.266667-140.8 55.466667 17.066667c4.266667 0 29.866667 4.266667 55.466667-8.533333 8.533333-4.266667 25.6-21.333333 29.866666-46.933334v-4.266666c4.266667-8.533333-4.266667-17.066667-8.533333-21.333334l-196.266667-102.4h-4.266666-4.266667l-110.933333-17.066666-34.133334 29.866666 136.533334 21.333334 179.2 93.866666c-4.266667 4.266667-4.266667 12.8-8.533334 17.066667-4.266667 4.266667-17.066667 4.266667-21.333333 4.266667l-89.6-25.6-8.533333-21.333334c-4.266667-8.533333-17.066667-17.066667-29.866667-8.533333-8.533333 4.266667-17.066667 17.066667-8.533333 25.6l25.6 46.933333 68.266666 140.8 21.333334 34.133334h174.933333z">
    </path>
  </symbol>
  <symbol id="lazadaicon_expressDelivery" viewBox="0 0 1401 1024">
    <path
      d="M877.714286 0l-508.819876 203.52795-184.447205-69.962733c-12.720497-6.360248-25.440994 0-31.801242 6.360249s-12.720497 25.440994-12.720497 31.801242c0 12.720497 12.720497 19.080745 19.080745 25.440994l178.086957 63.602484v279.850932L248.049689 508.819876c-19.080745-6.360248-38.161491 0-44.521739 19.080745-6.360248 19.080745 0 38.161491 19.080746 44.521739l114.484472 44.521739v178.086957l559.701863 228.968944 496.099379-260.770186V190.807453l-515.180124-190.807453z m0 69.962733l407.0559 146.285714-146.285714 76.322982L731.428571 127.204969l146.285715-57.242236z m19.080745 349.813665L464.298137 235.329193 636.024845 165.36646l413.416149 171.726708-152.645963 82.68323z m432.496894 292.571428l-394.335403 209.888199v-445.217391l171.726708-89.043479v159.006211l69.962733-38.16149V356.173913L1335.652174 273.490683v438.857143z m-1081.242236-25.440994c19.080745 6.360248 25.440994 25.440994 19.080746 44.521739-6.360248 19.080745-25.440994 25.440994-44.521739 19.080746l-63.602485-25.440994c-19.080745-6.360248-25.440994-25.440994-19.080745-44.521739 6.360248-19.080745 25.440994-25.440994 44.521739-19.080745l63.602484 25.440993z m0-330.732919c0 12.720497-6.360248 19.080745-12.720496 25.440994-6.360248 6.360248-19.080745 6.360248-31.801243 6.360248l-178.086956-63.602484C12.720497 318.012422 0 305.291925 0 298.931677c0-12.720497 0-25.440994 12.720497-31.801242s19.080745-12.720497 31.801242-6.360249l178.086957 63.602485c19.080745 6.360248 25.440994 19.080745 25.440993 31.801242z m604.223603 120.844721v445.217391l-445.217391-178.086957V292.571429l445.217391 184.447205z">
    </path>
  </symbol>
  <symbol id="lazadaicon_shipping" viewBox="0 0 1024 1024">
    <path
      d="M576 819.2h-341.333333l8.533333-34.133333h307.2l170.666667-588.8h34.133333l-179.2 622.933333zM332.8 196.266667h341.333333l-157.866666 541.866666h-341.333334L332.8 196.266667z m516.266667-51.2H174.933333c-34.133333 0-64 29.866667-64 68.266666v102.4c0 38.4 29.866667 68.266667 64 68.266667h8.533334l12.8-51.2h-21.333334c-8.533333 0-17.066667-8.533333-17.066666-17.066667V213.333333c0-8.533333 8.533333-17.066667 17.066666-17.066666h106.666667l-170.666667 588.8h85.333334l-25.6 85.333333h443.733333L810.666667 196.266667h42.666666c8.533333 0 17.066667 8.533333 17.066667 17.066666v102.4c0 8.533333-8.533333 17.066667-17.066667 17.066667h-42.666666L797.866667 384h51.2c34.133333 0 64-29.866667 64-68.266667V213.333333c0-38.4-29.866667-68.266667-64-68.266666zM362.666667 588.8l8.533333-29.866667h-4.266667c-25.6-4.266667-46.933333-17.066667-59.733333-34.133333-4.266667-4.266667-4.266667-8.533333-4.266667-12.8l42.666667-12.8c4.266667 4.266667 17.066667 12.8 38.4 12.8h4.266667l21.333333-64h-4.266667c-25.6-4.266667-42.666667-12.8-55.466666-21.333333 0 0-4.266667 0-4.266667-4.266667 0 0 0-4.266667-4.266667-4.266667-12.8-4.266667-17.066667-21.333333-12.8-34.133333 12.8-42.666667 68.266667-59.733333 110.933334-64h4.266666l8.533334-29.866667h38.4l-8.533334 29.866667h4.266667c29.866667 4.266667 55.466667 17.066667 64 34.133333 4.266667 4.266667 4.266667 8.533333 4.266667 12.8l-38.4 12.8c-4.266667-4.266667-21.333333-12.8-42.666667-17.066666H469.333333l-21.333333 64h4.266667c34.133333 4.266667 55.466667 17.066667 59.733333 21.333333l4.266667 4.266667v4.266666c8.533333 12.8 12.8 25.6 8.533333 42.666667-12.8 38.4-68.266667 59.733333-115.2 64h-4.266667l-8.533333 25.6h-34.133333z m59.733333-221.866667c-34.133333 4.266667-51.2 17.066667-55.466667 29.866667 0 8.533333 17.066667 17.066667 42.666667 21.333333h4.266667l12.8-55.466666-4.266667 4.266666z m0 149.333334h4.266667c34.133333-4.266667 59.733333-21.333333 59.733333-34.133334 0-8.533333-21.333333-17.066667-46.933333-21.333333h-4.266667l-12.8 55.466667z">
    </path>
  </symbol>
  <symbol id="lazadaicon_noshipping" viewBox="0 0 1024 1024">
    <path
      d="M430.933333 401.066667c-25.6-4.266667-42.666667-12.8-42.666666-21.333334 4.266667-8.533333 21.333333-25.6 55.466666-29.866666h4.266667l-17.066667 51.2z m59.733334-55.466667c21.333333 0 34.133333 8.533333 42.666666 12.8l29.866667-25.6c-12.8-17.066667-29.866667-25.6-55.466667-29.866667h-4.266666l8.533333-29.866666h-42.666667l-8.533333 29.866666h-4.266667c-42.666667 4.266667-98.133333 25.6-110.933333 64-4.266667 12.8 0 29.866667 8.533333 42.666667 0 0 0 4.266667 4.266667 4.266667 0 0 4.266667 0 4.266667 4.266666 8.533333 8.533333 29.866667 12.8 55.466666 21.333334h4.266667l-8.533333 21.333333 59.733333-51.2 17.066667-64z m-170.666667 153.6c0 4.266667 4.266667 8.533333 4.266667 12.8 4.266667 4.266667 12.8 8.533333 17.066666 12.8l34.133334-29.866667c-8.533333 0-12.8-4.266667-12.8-4.266666l-42.666667 8.533333z m89.6 221.866667l-55.466667 51.2h217.6l76.8-260.266667-68.266666 59.733333-42.666667 149.333334h-128zM192 366.933333h8.533333L213.333333 315.733333h-21.333333c-8.533333 0-17.066667-4.266667-17.066667-17.066666V196.266667c0-8.533333 8.533333-17.066667 17.066667-17.066667H298.666667L149.333333 695.466667l68.266667-59.733334L349.866667 179.2h345.6L682.666667 226.133333 793.6 128H192C157.866667 128 128 157.866667 128 196.266667V298.666667c0 38.4 29.866667 68.266667 64 68.266666M891.733333 298.666667c0 8.533333-8.533333 17.066667-17.066666 17.066666h-4.266667l-46.933333 42.666667-4.266667 8.533333h55.466667c34.133333 0 64-29.866667 64-68.266666V256l-46.933334 42.666667zM597.333333 806.4H315.733333l-55.466666 51.2h375.466666l128-443.733333-68.266666 55.466666-98.133334 337.066667z m285.866667-674.133333L128 793.6l38.4 42.666667L921.6 174.933333l-38.4-42.666666z">
    </path>
  </symbol>
  <symbol id="lazadaicon_oversea" viewBox="0 0 1024 1024">
    <path
      d="M985.6 337.066667c-4.266667 12.8-12.8 29.866667-34.133333 38.4l-320 132.266666s-29.866667 8.533333-55.466667 8.533334c-21.333333 0-38.4-8.533333-51.2-17.066667L443.733333 426.666667c-4.266667-4.266667-4.266667-8.533333-4.266666-17.066667s4.266667-12.8 8.533333-17.066667c4.266667 0 17.066667-12.8 42.666667-12.8 8.533333 0 17.066667 0 29.866666 4.266667l42.666667 12.8h12.8c8.533333 0 17.066667-4.266667 29.866667-8.533333l12.8-4.266667-81.066667-68.266667c-4.266667-4.266667-8.533333-12.8-4.266667-21.333333 0-8.533333 4.266667-12.8 12.8-17.066667 4.266667 0 21.333333-8.533333 46.933334-8.533333 17.066667 0 34.133333 4.266667 55.466666 8.533333 42.666667 17.066667 106.666667 42.666667 128 42.666667l102.4-42.666667c4.266667 0 25.6-8.533333 55.466667-8.533333 21.333333 0 38.4 8.533333 51.2 21.333333l4.266667 4.266667c-12.8 0 0 21.333333-4.266667 42.666667z m-42.666667-17.066667c-4.266667-4.266667-12.8-8.533333-17.066666-8.533333-17.066667 0-34.133333 8.533333-34.133334 8.533333l-106.666666 46.933333H768c-34.133333 0-128-34.133333-140.8-46.933333-8.533333-4.266667-17.066667-8.533333-25.6-8.533333l68.266667 59.733333c4.266667 4.266667 8.533333 12.8 4.266666 21.333333 0 8.533333-4.266667 12.8-12.8 17.066667l-51.2 21.333333c-12.8 8.533333-29.866667 8.533333-42.666666 8.533334s-25.6-4.266667-25.6-4.266667l-34.133334-8.533333 46.933334 42.666666c4.266667 8.533333 17.066667 8.533333 25.6 8.533334 17.066667 0 42.666667-8.533333 42.666666-8.533334L938.666667 332.8c4.266667-4.266667 12.8-8.533333 12.8-8.533333-4.266667 0-8.533333-4.266667-8.533334-4.266667z m-268.8-68.266667c-51.2-38.4-110.933333-59.733333-179.2-59.733333-166.4 0-298.666667 136.533333-298.666666 302.933333 0 34.133333 4.266667 68.266667 17.066666 102.4 55.466667-12.8 128-38.4 234.666667-81.066666 8.533333-4.266667 21.333333 0 29.866667 12.8 4.266667 8.533333 0 21.333333-12.8 29.866666-98.133333 38.4-174.933333 64-230.4 81.066667 51.2 98.133333 149.333333 166.4 264.533333 166.4 166.4 0 298.666667-136.533333 298.666667-302.933333v-4.266667l42.666666-17.066667v21.333334c0 192-153.6 345.6-337.066666 345.6-136.533333 0-251.733333-81.066667-307.2-196.266667-29.866667 8.533333-55.466667 8.533333-76.8 8.533333-42.666667 0-55.466667-12.8-68.266667-25.6-29.866667-42.666667 25.6-102.4 34.133333-115.2 4.266667-8.533333 21.333333-8.533333 29.866667 0 8.533333 8.533333 8.533333 21.333333 0 29.866667-17.066667 21.333333-34.133333 55.466667-29.866667 59.733333 0 0 12.8 17.066667 89.6 0-8.533333-34.133333-17.066667-72.533333-17.066666-110.933333 0-192 149.333333-345.6 337.066666-345.6 110.933333 0 204.8 51.2 268.8 136.533333-17.066667-12.8-55.466667-25.6-89.6-38.4z">
    </path>
  </symbol>
  <symbol id="lazadaicon_email" viewBox="0 0 1024 1024">
    <path
      d="M840.533333 776.533333H307.2c-17.066667 0-34.133333-8.533333-42.666667-21.333333-12.8-12.8-12.8-29.866667-12.8-46.933333l72.533334-358.4c8.533333-25.6 38.4-51.2 68.266666-51.2h533.333334c17.066667 0 34.133333 8.533333 42.666666 21.333333 8.533333 12.8 12.8 29.866667 12.8 42.666667l-72.533333 358.4c-8.533333 29.866667-38.4 55.466667-68.266667 55.466666zM307.2 716.8h533.333333c4.266667 0 8.533333-4.266667 8.533334-8.533333l72.533333-354.133334H392.533333c-4.266667 0-8.533333 4.266667-12.8 8.533334l-72.533333 354.133333z">
    </path>
    <path
      d="M610.133333 610.133333c-17.066667 0-34.133333-8.533333-46.933333-21.333333l-200.533333-213.333333 42.666666-38.4 200.533334 213.333333c4.266667 4.266667 8.533333 4.266667 8.533333 0l294.4-217.6 34.133333 46.933333-294.4 217.6c-12.8 8.533333-25.6 12.8-38.4 12.8z m-465.066666-256h132.266666v55.466667H145.066667V354.133333zM42.666667 486.4h204.8v55.466667H42.666667v-55.466667z m72.533333 119.466667H213.333333v55.466666H115.2v-55.466666z">
    </path>
  </symbol>
  <symbol id="lazadaicon_smallPrompt" viewBox="0 0 1024 1024">
    <path
      d="M512 841.589844c181.27441433 0 329.589844-148.31542969 329.589844-329.589844s-148.31542969-329.589844-329.589844-329.589844-329.589844 148.31542969-329.589844 329.589844 148.31542969 329.589844 329.589844 329.589844z"
      fill="#FF9800"></path>
    <path
      d="M538.36718725 327.42968775v128.54003907c0 13.18359399 0 26.36718725-3.29589793 39.55078125 0 13.18359399-3.29589869 26.36718725-6.59179739 42.84667918h-39.55078125c-3.29589869-16.47949193-3.29589869-29.66308594-6.59179662-42.84667918 0-13.18359399-3.29589869-26.36718725-3.29589869-39.55078125v-128.54003907h59.32617188z m-62.6220698 299.92675731c0-3.29589869 0-9.8876953 3.29589792-13.18359324 3.29589869-3.29589869 3.29589869-6.59179662 6.59179738-9.88769532 3.29589869-3.29589869 6.59179662-6.59179662 9.88769532-6.59179737 3.29589869-3.29589869 9.8876953-3.29589869 13.18359324-3.29589794 3.29589869 0 9.8876953 0 13.18359399 3.29589794 3.29589869 3.29589869 6.59179662 3.29589869 9.88769535 6.59179737 3.29589869 3.29589869 6.59179662 6.59179662 6.5917966 9.88769532 3.29589869 3.29589869 3.29589869 9.8876953 3.29589869 13.18359324 0 3.29589869 0 9.8876953-3.29589869 13.183594s-3.29589869 6.59179662-6.59179663 9.88769532c-3.29589869 3.29589869-6.59179662 6.59179662-9.8876953 6.59179662-3.29589869 3.29589869-9.8876953 3.29589869-13.18359401 3.29589869-3.29589869 0-9.8876953 0-13.18359324-3.29589869-3.29589869-3.29589869-6.59179662-3.29589869-9.88769532-6.59179662-3.29589869-3.29589869-6.59179662-6.59179662-6.59179738-9.88769532s-3.29589869-9.8876953-3.29589792-13.183594z"
      fill="#000000"></path>
  </symbol>
  <symbol id="lazadaicon_largePrompt" viewBox="0 0 1024 1024">
    <path
      d="M512 938.666667c234.666667 0 426.666667-192 426.666667-426.666667s-192-426.666667-426.666667-426.666667-426.666667 192-426.666667 426.666667 192 426.666667 426.666667 426.666667z"
      fill="#FF9800"></path>
    <path
      d="M546.133333 273.066667v166.4c0 17.066667 0 34.133333-4.266666 51.2 0 17.066667-4.266667 34.133333-8.533334 55.466666h-51.2c-4.266667-21.333333-4.266667-38.4-8.533333-55.466666 0-17.066667-4.266667-34.133333-4.266667-51.2v-166.4h76.8z m-81.066666 388.266666c0-4.266667 0-12.8 4.266666-17.066666 4.266667-4.266667 4.266667-8.533333 8.533334-12.8 4.266667-4.266667 8.533333-8.533333 12.8-8.533334 4.266667-4.266667 12.8-4.266667 17.066666-4.266666 4.266667 0 12.8 0 17.066667 4.266666 4.266667 4.266667 8.533333 4.266667 12.8 8.533334 4.266667 4.266667 8.533333 8.533333 8.533333 12.8 4.266667 4.266667 4.266667 12.8 4.266667 17.066666 0 4.266667 0 12.8-4.266667 17.066667s-4.266667 8.533333-8.533333 12.8c-4.266667 4.266667-8.533333 8.533333-12.8 8.533333-4.266667 4.266667-12.8 4.266667-17.066667 4.266667-4.266667 0-12.8 0-17.066666-4.266667-4.266667-4.266667-8.533333-4.266667-12.8-8.533333-4.266667-4.266667-8.533333-8.533333-8.533334-12.8s-4.266667-12.8-4.266666-17.066667z"
      fill="#000000"></path>
  </symbol>
  <symbol id="lazadaicon_gojek" viewBox="0 0 1024 1024">
    <path
      d="M799.511273 727.831273a130.094545 130.094545 0 0 0-52.922182 8.797091c-16.896-33.605818-31.418182-64.093091-28.346182-63.906909l34.071273 1.396363s4.608-42.356364 2.839273-65.675636c-1.722182-23.458909-9.867636-23.877818-9.867637-23.877818l-30.533818 9.681454c-36.026182 12.194909-41.425455 9.169455-41.425455 9.169455s0.465455-36.165818-6.376727-36.445091c-6.795636-0.279273-40.122182-8.750545-40.122182-8.750546-2.792727-5.492364-25.227636-17.408-36.910545-26.158545-13.079273-14.941091-58.647273-48.081455-91.601455-71.168a59.531636 59.531636 0 0 0 75.636364-54.784 59.624727 59.624727 0 0 0-56.785455-62.184727 59.485091 59.485091 0 0 0-61.905454 57.064727c-0.651636 14.242909 3.816727 27.508364 11.682909 38.167273a340.48 340.48 0 0 1-4.514909-3.025455c-7.912727-7.214545-17.035636 2.280727-17.035636 2.280727s-76.194909 151.831273-80.709819 161.233455c-4.514909 9.402182 13.777455 29.463273 13.777455 29.463273l-103.982546 2.327272c-17.826909 0.605091-31.278545 60.462545-31.278545 60.462546-68.887273 12.101818-109.474909 96.861091-109.474909 96.861091l17.221818 13.079272-1.256727 28.765091-31.371637-1.349818c-11.403636 11.822545-0.791273 19.176727-0.791272 19.176727l31.325091 1.396364v0.512l-0.186182 4.980364h0.139636a134.330182 134.330182 0 0 0 128.186182 134.516363 134.190545 134.190545 0 0 0 139.264-123.112727c14.475636-0.139636 80.477091-0.605091 122.833455 0 47.802182 0.698182 59.904-27.601455 59.904-27.601454l4.282181-100.072728s30.068364 1.396364 44.032-4.933818c13.870545-6.237091 34.536727-39.610182 34.536728-39.610182l33.885091 59.298909a131.397818 131.397818 0 0 0-52.64291 99.746909 131.258182 131.258182 0 0 0 125.160728 137.076364 131.118545 131.118545 0 0 0 136.424727-125.765818 131.258182 131.258182 0 0 0-125.160727-136.983273zM330.193455 776.471273c21.643636 13.963636 36.770909 37.096727 39.889454 63.767272l-40.029091-1.722181a50.455273 50.455273 0 0 0-16.756363-23.086546l16.896-38.958545z m-43.566546-13.963637c4.189091 0.139636 8.145455 0.744727 12.101818 1.536l-12.427636 41.053091-1.489455-0.093091c-20.48-0.884364-39.517091 10.705455-48.034909 29.416728l-40.029091-1.722182a88.064 88.064 0 0 1 89.879273-70.237091v0.046545z m-7.633454 176.686546a88.203636 88.203636 0 0 1-84.154182-87.365818l37.329454 1.582545c-1.256727 27.927273 20.340364 51.572364 48.221091 52.875636 27.927273 1.210182 51.386182-20.48 52.596364-48.453818l37.282909 1.629091a88.110545 88.110545 0 0 1-91.229091 79.732364z m365.847272-338.292364c-80.430545-6.283636-150.202182 27.741091-150.202182 27.741091s-2.373818 3.258182-4.794181-0.186182c-14.010182-20.014545-15.546182-35.048727-15.546182-35.048727l33.512727-78.196364c25.832727 32.768 137.774545 67.863273 137.774546 67.863273l-0.791273 17.826909h0.046545z m146.571637 344.762182a88.436364 88.436364 0 0 1-84.340364-92.299636 88.389818 88.389818 0 0 1 29.789091-62.510546l20.154182 35.188364a46.778182 46.778182 0 0 0 30.673454 79.965091 46.638545 46.638545 0 0 0 34.304-80.244364 46.685091 46.685091 0 0 0-36.072727-13.032727c-4.701091-8.890182-12.055273-22.993455-20.340364-39.005091a88.064 88.064 0 0 1 117.713455 87.226182 88.389818 88.389818 0 0 1-91.880727 84.712727z m-270.196364-18.106182v-3.630545l132.654545 0.093091 3.49091 3.723636-136.145455-0.186182zM470.109091 964.421818v-3.677091l204.660364 0.139637 4.282181 3.816727L470.109091 964.421818z m85.643636-72.750545v-5.352728h91.229091l1.070546 3.909819-92.346182 1.396363zM234.496 163.188364c-21.922909 13.451636-41.425455-23.365818-31.511273-30.161455 332.148364-224.535273 603.648-2.699636 605.463273 16.430546 1.861818 19.176727-27.136 26.065455-27.136 26.065454-266.24-208.523636-524.986182-25.832727-546.816-12.334545z m62.370909 83.549091c-16.709818 10.845091-30.301091-18.757818-22.714182-24.203637 253.300364-180.177455 460.241455-2.187636 461.730909 13.172364 1.396364 15.406545-22.062545 20.945455-22.062545 20.945454-202.938182-167.377455-400.290909-20.759273-417.000727-9.914181zM368.733091 321.629091c-11.031273 7.819636-20.852364-15.313455-15.825455-19.176727 166.865455-129.722182 303.290182-1.582545 304.221091 9.495272 0.930909 11.077818-13.684364 16.896-13.684363 16.896-133.725091-120.552727-263.726545-14.987636-274.711273-7.168V321.629091z">
    </path>
  </symbol>
  <symbol id="lazadaicon_service" viewBox="0 0 1024 1024">
    <path
      d="M791.236118 531.80270466A78.30034946 78.30034946 0 0 0 785.77330297 517.91804997a61.45666943 61.45666943 0 0 0-30.38690869-29.02120529 20.03032178 20.03032178 0 0 0-8.19422255-3.30045065l-46.32012027-7.2837541a20.03032178 20.03032178 0 0 0-22.76172928 16.38844581l-36.76019288 219.99211563a19.80270466 19.80270466 0 0 0 16.27463616 22.76173001l42.79205178 6.94232733a17.41272317 17.41272317 0 0 0 3.41425958 0h5.34900611a60.7738181 60.7738181 0 0 0 41.54015658-17.75414919 79.66605358 79.66605358 0 0 0 9.78754377-11.38086501 79.66605358 79.66605358 0 0 0 8.9908828 0.79666097 77.73130633 77.73130633 0 0 0 26.6312238-4.77996369l-5.121389 30.1592923a83.30793026 83.30793026 0 0 1-35.96353262 51.10008252c-31.75261281 23.67219847-94.11975141 46.66154558-214.52930132 36.64638469a56.90432358 56.90432358 0 0 0-44.27156411-32.20784776c-29.47643951-4.89377188-56.90432358 9.78754378-60.43239133 33.00450801s16.95748823 45.52345929 46.43392773 50.7586572A58.2700277 58.2700277 0 0 0 530.84193207 869.58677086c22.76172928 2.16236438 44.61299011 3.18664247 65.09854685 3.18664248 80.69033094 0 142.60223533-16.27463689 184.82524325-48.59629284a120.86478413 120.86478413 0 0 0 49.84818803-76.59322005l17.98176632-108.23202392 3.18664246-18.66461766a77.95892343 77.95892343 0 0 0-60.54620098-88.88455421z m20.94079094 82.28365219l-5.23519719 31.41118677a38.125897 38.125897 0 0 1-30.72833545 30.61452652l17.07129715-101.74493154a38.01208808 38.01208808 0 0 1 18.89223549 39.71921825zM723.17854652 698.87379943a20.03032178 20.03032178 0 0 1-16.04701904 6.48709312l-22.76172929-3.86949381 30.27309978-180.95575016 22.76173 3.64187668a20.3717478 20.3717478 0 0 1 13.08799443 11.380865 48.82390995 48.82390995 0 0 1 3.8694938 30.04548266l-17.64034029 105.72823352A49.05152707 49.05152707 0 0 1 723.17854652 698.87379943zM285.58429604 491.28682617A19.91651357 19.91651357 0 0 0 262.25352361 475.80885026l-45.52345929 8.99088279a20.14413068 20.14413068 0 0 0-8.08041363 3.64187669 61.34286124 61.34286124 0 0 0-29.81786626 30.15929157A88.42931928 88.42931928 0 0 0 173.2551612 573.68428727l21.73745121 104.93157327c7.85279651 37.67066206 36.6463847 64.41569478 67.2609112 64.41569405a54.05910787 54.05910787 0 0 0 6.03185818-0.56904314h0.56904314a16.72987112 16.72987112 0 0 0 4.09711163 0l42.45062575-9.44611774A19.80270466 19.80270466 0 0 0 330.5387122 709.57181237zM264.75731402 703.19852818c-11.380865 2.27617329-26.40360597-11.380865-30.72833544-32.43546488L212.17771847 565.60387292a50.30342227 50.30342227 0 0 1 2.73140751-30.15929158A20.48555673 20.48555673 0 0 1 228.11092933 523.60848211l22.76172928-4.55234584L287.74666042 698.87379943zM771.43341334 458.62374419a93.09547403 93.09547403 0 0 1 16.04701904 9.78754378c0-103.56586915-25.37932861-183.80096588-74.20323782-238.99816004C661.38045108 171.02929132 582.85248376 141.21142578 479.28661461 141.21142578S297.87563022 171.02929132 245.86507854 229.52693612C196.47212546 285.29317342 171.20660503 366.89397427 171.77564889 472.39459067a89.56740555 89.56740555 0 0 1 19.11985261-13.54322937 54.05910787 54.05910787 0 0 1 18.77842655-7.6251794l3.6418767-0.68285133c2.84521643-83.87697341 23.89981629-148.97551953 63.5052256-193.47470145a67.37471941 67.37471941 0 0 0 34.1425943 37.67066277 63.96045983 63.96045983 0 0 0 26.06218066 5.34900612 88.54312818 88.54312818 0 0 0 45.52345857-13.31561155 139.52940179 139.52940179 0 0 1 22.76173002-10.69801295 234.44581418 234.44581418 0 0 1 74.43085566-11.380865 234.21819706 234.21819706 0 0 1 74.31704676 11.38086501 144.99221681 144.99221681 0 0 1 22.76172927 10.69801294 88.54312818 88.54312818 0 0 0 45.5234593 13.31561155 63.96045983 63.96045983 0 0 0 26.06217995-5.34900612 67.37471941 67.37471941 0 0 0 34.14259501-37.67066277c39.26398328 44.15775518 60.31858315 109.37011021 63.6190338 194.0437446l6.25947528 0.91046916a56.90432358 56.90432358 0 0 1 19.00604441 6.60090131z m-139.98463673-201.78273218a23.78600738 23.78600738 0 0 1-9.21850063 1.82093833 39.4916004 39.4916004 0 0 1-11.38086429-1.93474726A217.82975197 217.82975197 0 0 0 569.53687222 237.49354157l-1.25189519-0.56904315v1.02427808-1.02427808a273.82360639 273.82360639 0 0 0-87.74646722-13.65703758H478.48995436a272.45790226 272.45790226 0 0 0-87.5188501 13.7708465l-1.59332123 0.56904314a211.57027597 211.57027597 0 0 0-40.85730452 19.1198526 40.06064427 40.06064427 0 0 1-12.06371634 2.04855545 23.78600738 23.78600738 0 0 1-9.21850063-1.82093834c-10.01516088-4.55234587-14.90893277-18.55080946-17.18510606-29.70405662C353.30044148 197.43289802 410.20476579 182.41015633 479.62804064 182.29634741S606.06944801 197.43289802 649.20292582 227.13695464c-2.84521643 11.15324717-7.6251794 25.1517115-17.75414922 29.70405737z">
    </path>
  </symbol>
  <symbol id="lazadaicon_nowarranty" viewBox="0 0 1024 1024">
    <path
      d="M298.666667 648.533333l-29.866667 34.133334C153.6 490.666667 170.666667 256 170.666667 251.733333c0-4.266667 4.266667-12.8 8.533333-17.066666 4.266667-4.266667 12.8-4.266667 17.066667-4.266667 217.6 25.6 285.866667-85.333333 285.866666-85.333333 4.266667-8.533333 12.8-12.8 21.333334-12.8s17.066667 4.266667 21.333333 8.533333c4.266667 4.266667 38.4 59.733333 140.8 81.066667l-34.133333 38.4c-68.266667-17.066667-106.666667-51.2-128-72.533334-34.133333 38.4-119.466667 102.4-285.866667 89.6-4.266667 59.733333 4.266667 226.133333 81.066667 371.2z m537.6-401.066666v4.266666c0 4.266667 34.133333 482.133333-320 631.466667h-8.533334H494.933333c-55.466667-21.333333-98.133333-51.2-136.533333-85.333333l29.866667-34.133334c34.133333 29.866667 68.266667 55.466667 115.2 76.8C763.733333 725.333333 789.333333 409.6 793.6 298.666667l42.666667-51.2zM814.933333 128l38.4 34.133333L226.133333 883.2l-38.4-34.133333L814.933333 128z">
    </path>
  </symbol>
  <symbol id="lazadaicon_warranty" viewBox="0 0 1024 1024">
    <path
      d="M844.8 234.666667c-4.266667-4.266667-12.8-4.266667-17.066667-4.266667-217.6 25.6-290.133333-85.333333-294.4-89.6-4.266667-8.533333-12.8-12.8-21.333333-12.8s-17.066667 4.266667-21.333333 12.8c0 0-72.533333 115.2-294.4 89.6-4.266667 0-12.8 0-17.066667 4.266667-4.266667 0-8.533333 8.533333-8.533333 12.8 0 4.266667-34.133333 494.933333 332.8 648.533333h21.333333C891.733333 742.4 853.333333 256 853.333333 247.466667c0-4.266667-4.266667-12.8-8.533333-12.8z m-627.2 42.666666c170.666667 12.8 260.266667-51.2 294.4-89.6 34.133333 38.4 123.733333 102.4 294.4 89.6 4.266667 93.866667-12.8 448-294.4 571.733334C230.4 725.333333 217.6 371.2 217.6 277.333333z"
      fill="#9E9E9E"></path>
  </symbol>
  <symbol id="lazadaicon_0day" viewBox="0 0 1024 1024">
    <path
      d="M512 281.6c-136.533333 0-247.466667 106.666667-247.466667 238.933333 0 38.4 8.533333 76.8 29.866667 110.933334l-38.4 38.4c-25.6-42.666667-42.666667-93.866667-42.666667-149.333334 0-157.866667 132.266667-290.133333 294.4-290.133333 51.2 0 102.4 12.8 145.066667 38.4l-12.8 17.066667-38.4 12.8c-25.6-12.8-59.733333-17.066667-89.6-17.066667z m149.333333 430.933333c12.8-8.533333 25.6-4.266667 34.133334 4.266667 8.533333 8.533333 8.533333 25.6-4.266667 34.133333-51.2 38.4-110.933333 59.733333-179.2 59.733334-59.733333 0-110.933333-17.066667-157.866667-42.666667l34.133334-34.133333c34.133333 21.333333 76.8 29.866667 119.466666 29.866666 59.733333 0 110.933333-17.066667 153.6-51.2z m251.733334-213.333333c12.8 0 25.6 12.8 25.6 25.6 0 230.4-192 418.133333-426.666667 418.133333-93.866667 0-179.2-29.866667-247.466667-81.066666l34.133334-38.4c59.733333 42.666667 136.533333 64 213.333333 64 209.066667 0 375.466667-166.4 375.466667-366.933334 0-12.8 12.8-21.333333 25.6-21.333333zM823.466667 298.666667c-4.266667 17.066667-17.066667 29.866667-34.133334 34.133333h-4.266666l38.4-34.133333zM200.533333 725.333333l-34.133333 34.133334C115.2 695.466667 85.333333 610.133333 85.333333 520.533333c0-230.4 192-418.133333 426.666667-418.133333 59.733333 0 119.466667 12.8 174.933333 38.4l21.333334-34.133333c8.533333-12.8 21.333333-21.333333 38.4-17.066667 17.066667 0 34.133333 12.8 38.4 29.866667l4.266666 21.333333-42.666666 42.666667-8.533334-34.133334-34.133333 55.466667C648.533333 170.666667 580.266667 153.6 512 153.6c-209.066667 0-375.466667 166.4-375.466667 366.933333 0 76.8 21.333333 149.333333 64 204.8zM896 85.333333l42.666667 38.4-810.666667 810.666667-42.666667-38.4L896 85.333333z">
    </path>
  </symbol>
  <symbol id="lazadaicon_7days" viewBox="0 0 1024 1024">
    <path
      d="M648.533333 409.6v38.4l-106.666666 238.933333h-76.8l98.133333-217.6h-119.466667V409.6h204.8z m264.533334 85.333333c12.8 0 25.6 12.8 25.6 25.6 0 230.4-192 418.133333-426.666667 418.133334S85.333333 750.933333 85.333333 520.533333s192-418.133333 426.666667-418.133333c59.733333 0 119.466667 12.8 174.933333 38.4l21.333334-34.133333c4.266667-17.066667 21.333333-21.333333 38.4-21.333334s34.133333 12.8 38.4 29.866667l42.666666 162.133333c8.533333 21.333333-8.533333 46.933333-29.866666 55.466667l-179.2 55.466667h-8.533334c-8.533333 0-21.333333-8.533333-25.6-17.066667-8.533333-12.8 0-25.6 12.8-29.866667l174.933334-55.466666-34.133334-140.8-34.133333 59.733333C648.533333 170.666667 580.266667 153.6 512 153.6c-209.066667 0-375.466667 166.4-375.466667 366.933333 0 204.8 170.666667 366.933333 375.466667 366.933334 209.066667 0 375.466667-166.4 375.466667-366.933334 0-12.8 12.8-25.6 25.6-25.6z m-401.066667-213.333333c-136.533333 0-247.466667 106.666667-247.466667 243.2 0 132.266667 110.933333 243.2 247.466667 243.2 55.466667 0 106.666667-17.066667 149.333333-51.2 12.8-8.533333 25.6-4.266667 34.133334 4.266667 8.533333 8.533333 8.533333 25.6-4.266667 34.133333-51.2 34.133333-110.933333 55.466667-179.2 55.466667-162.133333 0-294.4-132.266667-294.4-290.133334 0-157.866667 132.266667-290.133333 294.4-290.133333 55.466667 0 110.933333 17.066667 157.866667 46.933333l-68.266667 21.333334c-25.6-12.8-59.733333-17.066667-89.6-17.066667z">
    </path>
  </symbol>
  <symbol id="lazadaicon_14days" viewBox="0 0 1024 1024">
    <path
      d="M913.066667 494.933333c12.8 0 25.6 12.8 25.6 25.6 0 230.4-192 418.133333-426.666667 418.133334S85.333333 750.933333 85.333333 520.533333s192-418.133333 426.666667-418.133333c59.733333 0 119.466667 12.8 174.933333 38.4l21.333334-34.133333c4.266667-17.066667 21.333333-21.333333 38.4-21.333334s34.133333 12.8 38.4 29.866667l42.666666 162.133333c8.533333 21.333333-8.533333 46.933333-29.866666 55.466667l-179.2 55.466667h-8.533334c-8.533333 0-21.333333-8.533333-25.6-17.066667-8.533333-12.8 0-25.6 12.8-29.866667l174.933334-55.466666-34.133334-140.8-34.133333 59.733333C648.533333 170.666667 580.266667 153.6 512 153.6c-209.066667 0-375.466667 166.4-375.466667 366.933333 0 204.8 170.666667 366.933333 375.466667 366.933334 209.066667 0 375.466667-166.4 375.466667-366.933334 0-12.8 12.8-25.6 25.6-25.6zM392.533333 469.333333V413.866667h115.2c0 17.066667-4.266667 29.866667-4.266666 46.933333v157.866667c0 17.066667 0 29.866667 4.266666 46.933333h-68.266666c0-12.8 4.266667-29.866667 4.266666-46.933333V469.333333H392.533333z m153.6 145.066667v-55.466667c12.8-12.8 12.8-12.8 29.866667-34.133333l68.266667-76.8c12.8-17.066667 21.333333-25.6 29.866666-34.133333h64c0 17.066667-4.266667 29.866667-4.266666 51.2v98.133333h8.533333c8.533333 0 21.333333 0 29.866667-4.266667v55.466667H733.866667v12.8c0 17.066667 0 25.6 4.266666 38.4h-64c0-8.533333 4.266667-21.333333 4.266667-38.4v-12.8h-132.266667z m123.733334-51.2v-34.133333-42.666667c-4.266667 8.533333-12.8 12.8-17.066667 25.6l-42.666667 51.2h59.733334zM512 281.6c-136.533333 0-247.466667 106.666667-247.466667 243.2 0 132.266667 110.933333 243.2 247.466667 243.2 55.466667 0 106.666667-17.066667 149.333333-51.2 12.8-8.533333 25.6-4.266667 34.133334 4.266667 8.533333 8.533333 8.533333 25.6-4.266667 34.133333-51.2 34.133333-110.933333 55.466667-179.2 55.466667-162.133333 0-294.4-132.266667-294.4-290.133334 0-157.866667 132.266667-290.133333 294.4-290.133333 55.466667 0 110.933333 17.066667 157.866667 46.933333l-68.266667 21.333334c-25.6-12.8-59.733333-17.066667-89.6-17.066667z">
    </path>
  </symbol>
  <symbol id="lazadaicon_optionChecked" viewBox="0 0 1024 1024">
    <path d="M1023.6802 0v1023.3604H0.3198L1023.6802 0z" fill="#0a5d24"></path>
    <path
      d="M652.072455 910.790756l-173.971268-173.331668 49.249219-49.249219 124.722049 124.722049 263.515303-263.515303 48.609619 49.249219-312.124922 312.124922zM0.3198 1023.3604v-63.960025L959.720175 0h63.960025v44.772017L45.091818 1024 0.3198 1023.3604z"
      fill="#000000"></path>
  </symbol>
  <symbol id="lazadaicon_google" viewBox="0 0 1024 1024">
    <path
      d="M552.96 1024h-81.92C212.992 1024 0 811.008 0 552.96v-81.92C0 212.992 212.992 0 471.04 0h81.92c258.048 0 471.04 212.992 471.04 471.04v81.92c0 258.048-212.992 471.04-471.04 471.04z"
      fill="#D34836"></path>
    <path
      d="M583.68 559.104v-81.92H389.12v81.92h112.64c-16.384 49.152-63.488 81.92-116.736 81.92-51.2 0-114.688-47.104-114.688-122.88 0-69.632 49.152-122.88 114.688-122.88 30.72 0 61.44 12.288 81.92 30.72l59.392-59.392c-36.864-34.816-86.016-55.296-139.264-55.296-112.64 0-202.752 92.16-202.752 202.752s92.16 202.752 202.752 202.752c106.496 4.096 184.32-61.44 196.608-157.696zM839.68 483.328v51.2h-71.68v71.68H716.8v-71.68h-71.68v-51.2H716.8v-71.68h51.2v71.68H839.68z"
      fill="#000000"></path>
  </symbol>
  <symbol id="lazadaicon_twitter" viewBox="0 0 1024 1024">
    <path
      d="M552.96 1024h-81.92C212.992 1024 0 811.008 0 552.96v-81.92C0 212.992 212.992 0 471.04 0h81.92c258.048 0 471.04 212.992 471.04 471.04v81.92c0 258.048-212.992 471.04-471.04 471.04z"
      fill="#5EAADE"></path>
    <path
      d="M784.384 346.112c-20.48 8.192-40.96 14.336-63.488 18.432 22.528-14.336 40.96-34.816 49.152-61.44-22.528 12.288-45.056 22.528-71.68 26.624-20.48-22.528-49.152-34.816-81.92-34.816-61.44 0-112.64 49.152-112.64 112.64 0 8.192 0 16.384 2.048 24.576-92.16-4.096-176.128-49.152-231.424-116.736-8.192 14.336-14.336 32.768-14.336 53.248 0 38.912 20.48 73.728 49.152 92.16-18.432 0-34.816-6.144-51.2-14.336v2.048c0 53.248 38.912 100.352 90.112 110.592-10.24 2.048-18.432 4.096-28.672 4.096-8.192 0-14.336 0-20.48-2.048 14.336 45.056 55.296 77.824 104.448 77.824-38.912 30.72-86.016 47.104-139.264 47.104-8.192 0-18.432 0-26.624-2.048 49.152 32.768 108.544 51.2 172.032 51.2 206.848 0 319.488-169.984 319.488-319.488v-14.336c20.48-14.336 38.912-34.816 55.296-55.296z"
      fill="#000000"></path>
  </symbol>
  <symbol id="lazadaicon_pinterest" viewBox="0 0 1024 1024">
    <path
      d="M552.96 1024h-81.92C212.992 1024 0 811.008 0 552.96v-81.92C0 212.992 212.992 0 471.04 0h81.92c258.048 0 471.04 212.992 471.04 471.04v81.92c0 258.048-212.992 471.04-471.04 471.04z"
      fill="#CA242D"></path>
    <path
      d="M354.304 555.008c12.288 8.192 20.48 10.24 24.576-2.048 4.096-12.288 4.096-16.384 6.144-28.672 2.048-12.288 0-12.288-10.24-24.576-10.24-14.336-26.624-53.248-4.096-114.688 24.576-69.632 94.208-100.352 155.648-96.256 61.44 4.096 118.784 36.864 120.832 120.832 2.048 79.872-24.576 124.928-36.864 139.264-12.288 14.336-43.008 47.104-83.968 28.672-49.152-22.528-22.528-71.68-18.432-90.112 4.096-20.48 26.624-63.488 16.384-102.4-8.192-24.576-43.008-36.864-61.44-22.528-26.624 20.48-32.768 38.912-36.864 67.584-4.096 30.72 10.24 61.44 10.24 61.44s-32.768 131.072-38.912 165.888c-8.192 47.104-12.288 77.824-4.096 120.832 2.048 10.24 8.192 14.336 14.336 4.096 14.336-22.528 43.008-65.536 55.296-116.736 8.192-36.864 16.384-69.632 16.384-69.632s20.48 34.816 61.44 38.912c40.96 4.096 83.968-2.048 133.12-53.248 47.104-51.2 57.344-151.552 51.2-192.512-8.192-53.248-53.248-137.216-151.552-153.6-108.544-18.432-172.032 26.624-186.368 38.912-28.672 22.528-77.824 69.632-81.92 147.456-8.192 100.352 32.768 122.88 49.152 133.12z"
      fill="#000000"></path>
  </symbol>
  <symbol id="lazadaicon_tumblr" viewBox="0 0 1024 1024">
    <path
      d="M552.96 1024h-81.92C212.992 1024 0 811.008 0 552.96v-81.92C0 212.992 212.992 0 471.04 0h81.92c258.048 0 471.04 212.992 471.04 471.04v81.92c0 258.048-212.992 471.04-471.04 471.04z"
      fill="#181818"></path>
    <path
      d="M649.216 679.936l26.624 81.92c-6.144 8.192-18.432 16.384-38.912 22.528-20.48 6.144-40.96 10.24-61.44 10.24-24.576 0-45.056-2.048-65.536-8.192-20.48-6.144-36.864-14.336-49.152-24.576L430.08 724.992c-8.192-14.336-14.336-26.624-18.432-40.96-4.096-14.336-6.144-26.624-6.144-40.96v-186.368H348.16v-73.728c16.384-6.144 30.72-14.336 45.056-24.576 12.288-10.24 22.528-20.48 30.72-30.72 8.192-10.24 14.336-22.528 20.48-34.816 6.144-12.288 10.24-24.576 12.288-34.816l6.144-30.72c0-2.048 0-2.048 2.048-2.048l2.048-2.048h83.968V368.64h114.688v86.016h-114.688v178.176c0 6.144 0 12.288 2.048 18.432 2.048 6.144 4.096 12.288 8.192 18.432 4.096 6.144 10.24 10.24 16.384 14.336s16.384 4.096 28.672 4.096c14.336 2.048 28.672-2.048 43.008-8.192z"
      fill="#000000"></path>
  </symbol>
  <symbol id="lazadaicon_next" viewBox="0 0 1024 1024">
    <path
      d="M618.66666633 516.26666699L281.60000033 853.33333299l85.333333 85.33333401L789.33333332 516.266667l-4.266667-4.266667-422.39999999-422.4-85.333333 85.333333 341.333333 341.33333399z">
    </path>
  </symbol>
  <symbol id="lazadaicon_delete" viewBox="0 0 1024 1024">
    <path
      d="M896 204.8L819.2 128 512 435.2 204.8 128 128 204.8l307.2 307.2L128 819.2 204.8 896l307.2-307.2 307.2 307.2 76.8-76.8-307.2-307.2z">
    </path>
  </symbol>
  <symbol id="lazadaicon_add" viewBox="0 0 1024 1024">
    <path d="M544 480v-160h-64v160h-160v64h160v160h64v-160h160v-64h-160z"></path>
  </symbol>
  <symbol id="lazadaicon_reduce" viewBox="0 0 1024 1024">
    <path d="M320 480h384v64h-384z"></path>
  </symbol>
  <symbol id="lazadaicon_check" viewBox="0 0 1024 1024">
    <path
      d="M840.533333 213.333333L938.666667 311.466667 362.666667 883.2 85.333333 605.866667l98.133334-98.133334 179.2 179.2z">
    </path>
  </symbol>
  <symbol id="lazadaicon_back" viewBox="0 0 1024 1024">
    <path
      d="M912.00000031 464H303.99999969l280.00000031-280.00000031L512 111.99999969 111.99999969 512l400.00000031 400.00000031 72-72-280.00000031-280.00000031H912.00000031z">
    </path>
  </symbol>
  <symbol id="lazadaicon_ellipsis" viewBox="0 0 1024 1024">
    <path
      d="M682.666667 512c0-46.933333 38.4-85.333333 85.333333-85.333333s85.333333 38.4 85.333333 85.333333-38.4 85.333333-85.333333 85.333333-85.333333-38.4-85.333333-85.333333z m-85.33333399 0c0 46.933333-38.4 85.333333-85.33333301 85.33333301s-85.333333-38.4-85.33333301-85.33333301 38.4-85.333333 85.33333301-85.33333301 85.333333 38.4 85.33333301 85.33333301z m-256.00000001 0c0 46.933333-38.4 85.333333-85.333333 85.333333s-85.333333-38.4-85.333333-85.333333 38.4-85.333333 85.333333-85.333333 85.333333 38.4 85.333333 85.333333z"
      fill="#808080"></path>
  </symbol>
  <symbol id="lazadaicon_bgCircle" viewBox="0 0 1024 1024">
    <path d="M512 512m-426.666667 0a426.666667 426.666667 0 1 0 853.333334 0 426.666667 426.666667 0 1 0-853.333334 0Z"
      fill="#0a5d24"></path>
  </symbol>
  <symbol id="lazadaicon_dropDownArrow" viewBox="0 0 1024 1024">
    <path d="M650.08 458.08l52.32 52.32L512 700.8l-190.4-190.4 52.32-52.32L512 596.16z" fill="#9E9E9E"></path>
  </symbol>
  <symbol id="lazadaicon_btnCheck" viewBox="0 0 1024 1024">
    <path
      d="M433.694118 602.352941l-90.352942-90.352941-57.223529 57.223529 147.576471 141.552942 304.188235-337.317647-57.223529-57.22353-246.964706 286.117647zM512 60.235294c249.976471 0 451.764706 201.788235 451.764706 451.764706s-201.788235 451.764706-451.764706 451.764706S60.235294 761.976471 60.235294 512 262.023529 60.235294 512 60.235294z"
      fill="#FF330C"></path>
  </symbol>
  <symbol id="lazadaicon_addToCart" viewBox="0 0 1024 1024">
    <path
      d="M520.533333 738.133333c-34.133333 0-64 29.866667-64 64s29.866667 64 64 64 64-29.866667 64-64-25.6-64-64-64zM324.266667 213.333333v64h64l119.466666 251.733334-46.933333 76.8c-4.266667 8.533333-8.533333 21.333333-8.533333 34.133333 0 34.133333 29.866667 64 64 64h392.533333V640h-379.733333c-4.266667 0-8.533333-4.266667-8.533334-8.533333v-4.266667l29.866667-55.466667h243.2c25.6 0 46.933333-12.8 55.466667-34.133333l119.466666-213.333333c12.8-4.266667 12.8-4.266667 12.8-12.8 0-21.333333-12.8-34.133333-34.133333-34.133334H460.8L430.933333 213.333333H324.266667z m524.8 524.8c34.133333 0 64 29.866667 64 64s-29.866667 64-64 64-64-29.866667-64-64 29.866667-64 64-64z m-610.133334-256h123.733334V554.666667H238.933333v140.8H166.4V554.666667H42.666667v-72.533334h123.733333v-128h76.8v128z"
      fill="#9E9E9E"></path>
  </symbol>
  <symbol id="lazadaicon_tooltip" viewBox="0 0 1024 1024">
    <path
      d="M469.333333 725.333333h85.333334v-256h-85.333334v256z m42.666667-640C277.333333 85.333333 85.333333 277.333333 85.333333 512s192 426.666667 426.666667 426.666667 426.666667-192 426.666667-426.666667S746.666667 85.333333 512 85.333333z m0 768c-187.733333 0-341.333333-153.6-341.333333-341.333333s153.6-341.333333 341.333333-341.333333 341.333333 153.6 341.333333 341.333333-153.6 341.333333-341.333333 341.333333zM469.333333 384h85.333334V298.666667h-85.333334v85.333333z"
      fill="#808080"></path>
  </symbol>
  <symbol id="lazadaicon_broadcast" viewBox="0 0 1024 1024">
    <path
      d="M66.28571471 360.11428538v303.87428619h197.99999994L512 917.18857149V106.81142851L264.28571481 360.11428538H66.28571471zM734.85714313 512c0-91.13142842-49.57714313-167.14285687-123.84-202.59428526v405.18857052C685.27999998 679.14285687 734.85714313 603.23428535 734.85714313 512zM611.01714313 66.28571471v106.35428524c143.65714313 45.60000006 247.6457147 177.2571431 247.64571372 339.3942854 0 162.06857149-104.02285691 293.76000001-247.64571372 339.32571454V957.71428529C809.12000005 912.11428539 957.71428529 729.78285684 957.71428529 512 957.71428529 294.28571476 809.12000005 111.88571461 611.01714313 66.28571471z"
      fill="#26A96D"></path>
  </symbol>
  <symbol id="lazadaicon_close" viewBox="0 0 1024 1024">
    <path
      d="M555.424 516.608l158.4-158.4-54.336-54.304-158.4 158.4-153.856-153.856-54.304 54.304 153.888 153.856-149.344 149.344 54.304 54.304 149.344-149.344 153.856 153.856 54.304-54.304-153.856-153.856z m-43.008 472.64c-265.088 0-480-214.944-480-480 0-265.12 214.912-480 480-480 265.088 0 480 214.88 480 480 0 265.056-214.912 480-480 480z">
    </path>
  </symbol>
  <symbol id="lazadaicon_closeBtn" viewBox="0 0 1024 1024">
    <path
      d="M0 512C0 229.23 229.23 0 512 0s512 229.23 512 512-229.23 512-512 512S0 794.77 0 512z m768-204.8L716.8 256 512 460.8 307.2 256 256 307.2 460.8 512 256 716.8l51.2 51.2L512 563.2 716.8 768l51.2-51.2L563.2 512 768 307.2z"
      fill="#D1D3D4"></path>
  </symbol>
  <symbol id="lazadaicon_installment" viewBox="0 0 1024 1024">
    <path
      d="M776.7552 779.6224l-3.0464 0.4864v-41.856l3.072 0.4864c23.04 3.4816 39.04 13.568 39.0144 20.3776 0 6.8864-16.0256 16.9984-39.04 20.5056z m-32.2304-73.6l-3.0208-0.384c-25.472-3.4048-41.0624-14.336-41.1136-20.7104 0.0768-6.3744 15.7184-17.3568 41.1136-20.7616l3.0208-0.384v42.24z m88.192 26.2912a47.8976 47.8976 0 0 0-11.0592-6.9632c-10.5728-5.0944-26.4192-9.6-45.7472-13.056l-2.2016-0.4096v-47.9488l3.072 0.4608c17.92 2.7136 30.5152 9.1136 35.9168 14.7712l28.2624-10.0352c-9.1648-17.7408-33.6896-30.8224-64.896-34.4064l-2.3552-0.2816v-25.7536h-29.184v25.5744l-2.4064 0.2304c-41.728 4.224-70.8352 24.9856-70.8352 50.4576 0 12.9024 7.2192 24.6784 21.0432 34.048l1.1264 0.5888c6.6816 3.5328 21.8624 10.1376 48.8448 14.4896l2.2272 0.3584v45.9264l-3.0208-0.4096c-19.712-2.6624-34.048-9.9584-39.0144-16.2304l-29.0304 7.1424c7.424 20.1472 33.9712 35.2256 68.6592 38.7584l2.4064 0.256v26.24l29.184 0.0256v-26.4704l2.3552-0.256c40.576-4.6592 68.9152-25.3696 68.9152-50.304 0-8.6784-3.2768-16.8192-9.6256-24.1408a64.1536 64.1536 0 0 0-2.6368-2.6624z m-74.624 137.7792c-83.968 0-152.2944-68.7104-152.2944-153.1648 0-84.4544 68.352-153.1904 152.32-153.1904 84.0192 0 152.3456 68.736 152.3456 153.1904s-68.3264 153.1648-152.3712 153.1648z m0-347.6224c-106.624 0-193.3824 87.2448-193.3824 194.4576 0 107.2384 86.784 194.432 193.3824 194.432 106.6752 0 193.4336-87.1936 193.4336-194.432 0-107.2128-86.7584-194.4576-193.4336-194.4576z m-467.0976 94.4384h53.8368v-54.144h-53.8368v54.144z m0 108.0064h53.8112v-54.144h-53.8368v54.144z m0-216.064h53.8368v-54.144h-53.8368v54.144z m-107.3152 108.0576H237.568v-54.144H183.68v54.144z m0 108.0064h53.8368v-54.144H183.6544v54.144z m214.6816-216.064h53.8368v-54.144h-53.8368v54.144zM118.528 788.8128a20.5312 20.5312 0 0 1-20.1984-20.3008V389.8368h652.032v96.2304c1.8944-0.0256 3.6096-0.256 5.5296-0.256 14.6688 0 28.3648 1.408 41.5744 3.584V217.728a67.6864 67.6864 0 0 0-67.328-67.6608h-71.6288v47.36h71.6288c10.9568 0 20.224 9.3184 20.224 20.3008v124.7488H98.304V217.728c0-10.9824 9.2672-20.3008 20.224-20.3008h85.8624v60.5952a23.6032 23.6032 0 0 0 47.1552 0V197.4272h0.128v-47.36h-0.128V100.48A23.6288 23.6288 0 0 0 227.9936 76.8a23.6544 23.6544 0 0 0-23.6032 23.68v49.5872H118.528A67.6864 67.6864 0 0 0 51.2 217.728V768.512a67.6864 67.6864 0 0 0 67.328 67.6864h447.7952a236.5696 236.5696 0 0 1-19.456-47.3856H118.4768z m439.2448-530.7904a23.6032 23.6032 0 0 0 47.1296 0V100.48a23.6288 23.6288 0 0 0-23.552-23.68 23.6544 23.6544 0 0 0-23.552 23.68v49.5616h-75.648v47.3856h75.6224v60.5952z m-176.64 0c0 13.0816 10.5216 23.6544 23.552 23.6544a23.552 23.552 0 0 0 23.552-23.6544V197.4272h0.0768V150.0416h-0.1024V100.48A23.6032 23.6032 0 0 0 404.6592 76.8a23.6288 23.6288 0 0 0-23.552 23.68v49.5616h-75.5968v47.3856h75.5712v60.5952z m17.2544 466.8928h53.8368v-54.144h-53.8368v54.144z m0-108.0064h53.8368v-54.144h-53.8368v54.144z m107.3664-108.0576h53.8624v-54.144h-53.8624v54.144z"
      fill="#183545"></path>
  </symbol>
  <symbol id="lazadaicon_im" viewBox="0 0 1024 1024">
    <path
      d="M675.84 499.712c0 4.096 0 8.192-4.096 12.288 0 4.096-4.096 8.192-8.192 12.288-4.096 4.096-8.192 4.096-12.288 8.192-4.096 0-8.192 4.096-12.288 4.096H286.72l-143.36 143.36V180.224c0-4.096 0-8.192 4.096-12.288 0-4.096 4.096-8.192 8.192-12.288 0-4.096 4.096-8.192 8.192-8.192s8.192-4.096 12.288-4.096h462.848c4.096 0 8.192 0 12.288 4.096 4.096 0 8.192 4.096 12.288 8.192 4.096 4.096 4.096 8.192 8.192 12.288 0 4.096 4.096 8.192 4.096 12.288v319.488z m167.936-192.512c4.096 0 8.192 0 12.288 4.096 4.096 0 8.192 4.096 12.288 8.192 4.096 4.096 4.096 8.192 8.192 12.288 0 4.096 4.096 8.192 4.096 12.288v536.576L737.28 737.28H344.064c-4.096 0-8.192 0-12.288-4.096-4.096 0-8.192-4.096-12.288-8.192-4.096-4.096-4.096-8.192-8.192-12.288 0-4.096-4.096-8.192-4.096-12.288v-69.632h466.944V307.2h69.632z">
    </path>
  </symbol>
  <symbol id="lazadaicon_emptyHeart" viewBox="0 0 1024 1024">
    <path
      d="M516.266667 874.666667l-328.533334-324.266667c-76.8-76.8-76.8-200.533333 0-277.333333 34.133333-42.666667 85.333333-59.733333 136.533334-59.733334s102.4 21.333333 140.8 55.466667L512 320l46.933333-46.933333c38.4-42.666667 89.6-59.733333 140.8-59.733334s102.4 21.333333 140.8 55.466667c38.4 38.4 55.466667 85.333333 55.466667 136.533333s-21.333333 102.4-55.466667 136.533334l-324.266666 332.8zM324.266667 260.266667c-42.666667 0-76.8 12.8-106.666667 42.666666-55.466667 55.466667-59.733333 153.6 0 213.333334L512 810.666667l294.4-294.4c29.866667-29.86666742.666667-64 42.666667-106.666667 0-38.4-12.8-76.8-42.666667-106.666667-55.466667-55.466667-153.6-55.466667-213.333333 0L512 384l-81.066667-81.066667c-25.6-29.866667-64-42.666667-106.666666-42.666666z"
      fill="#808080"></path>
  </symbol>
  <symbol id="lazadaicon_fullHeart" viewBox="0 0 1024 1024">
    <path
      d="M704 128c-72.533333 0-145.066667 34.133333-192 89.6-46.933333-55.466667-119.466667-89.6-192-89.6-132.266667 0-234.666667 102.4-234.666667 234.666667 0 162.133333 145.066667 294.4 362.666667 490.666666l64 55.466667 64-55.466667c217.6-200.533333 362.666667-332.8 362.666667-490.666666 0-132.266667-102.4-234.666667-234.666667-234.666667z"
      fill="#939598"></path>
  </symbol>
  <symbol id="lazadaicon_mute" viewBox="0 0 1024 1024">
    <path
      d="M1024 451.142621l-63.346759-63.329104-89.15862 89.176276-89.193931-89.158621-63.382069 63.311449 89.229241 89.193931-89.229241 89.193931 63.346758 63.329103 89.229242-89.193931 89.15862 89.193931L1024 629.530483l-89.193931-89.193931zM0 280.364138v463.271724h227.116138L647.062069 1019.003586V4.996414L227.186759 280.364138H0z m94.119724 94.119724h99.998897V649.533793H94.102069V374.466207zM552.96 844.729379l-264.686345-173.550345v-318.322758l264.686345-173.585655v665.458758z">
    </path>
  </symbol>
  <symbol id="lazadaicon_sound" viewBox="0 0 1024 1024">
    <path
      d="M643.990069 8.474483L226.674759 282.129655H0.865103v460.446897h225.739035l417.368276 273.655172V8.474483h0.017655zM94.419862 375.684414h99.36331V649.004138H94.419862V375.702069z m456.033104 467.367724l-263.09738-172.491035V354.198069l263.079724-172.526345v661.362759zM745.613241 383.735172h93.554759v257.218207h-93.554759zM930.445241 302.856828H1024v419.027862h-93.554759z">
    </path>
  </symbol>
  <symbol id="lazadaicon_smallScreen" viewBox="0 0 1024 1024">
    <path
      d="M105.6 105.6h208.384V0H0v309.141333h105.6zM918.4 705.216v213.184h-208.405333V1024H1024V705.216zM84.394667 676.394667h190.613333L18.752 932.650667l74.666667 74.666666 256.256-256.256v190.634667h105.6V570.794667H84.394667zM939.626667 347.605333h-190.634667L1005.226667 91.349333l-74.666667-74.666666-256.213333 256.256V82.325333h-105.6v370.88h370.88z">
    </path>
  </symbol>
  <symbol id="lazadaicon_largeScreen" viewBox="0 0 1024 1024">
    <path
      d="M105.621333 309.162667V105.621333h208.384V0.021333H0v309.141334zM710.4 105.621333h208.405333v203.541334h105.6V0.021333H710.4zM313.984 918.378667H105.621333v-213.184H0v318.784h313.984zM918.784 705.194667v213.184H710.4v105.6h313.962667V705.194667z">
    </path>
  </symbol>
  <symbol id="lazadaicon_arrowDown" viewBox="0 0 1024 1024">
    <path d="M806.4 341.333333l89.6 89.6-384 379.733334-384-379.733334L217.6 341.333333l294.4 294.4z"></path>
  </symbol>
  <symbol id="lazadaicon_arrowUp" viewBox="0 0 1024 1024">
    <path d="M806.4 768l89.6-89.6L512 298.666667l-384 379.733333L217.6 768l294.4-294.4z"></path>
  </symbol>
  <symbol id="lazadaicon_star_half" viewBox="0 0 1024 1024">
    <path
      d="M512 797.866667l260.266667 166.4c8.533333 4.266667 21.333333 4.266667 29.866666-8.533334 4.266667-4.266667 4.266667-8.533333 4.266667-17.066666l-68.266667-315.733334 234.666667-213.333333c8.533333-8.533333 8.533333-21.333333 0-29.866667-4.266667-4.266667-8.533333-4.266667-12.8-8.533333l-307.2-25.6-119.466667-294.4c-4.266667-12.8-17.066667-17.066667-29.866666-12.8l-12.8 12.8-115.2 294.4-307.2 29.866667c-12.8 0-21.333333 8.533333-21.333334 21.333333 0 4.266667 4.266667 8.533333 8.533334 12.8l234.666666 213.333333L217.6 938.666667c-4.266667 12.8 4.266667 21.333333 17.066667 25.6 4.266667 0 12.8 0 17.066666-4.266667l260.266667-162.133333z"
      fill="#EFF0F5"></path>
    <path
      d="M512 797.866667V51.2c0-4.266667-4.266667-8.533333-8.533333-8.533333s-8.533333 4.266667-8.533334 4.266666l-119.466666 298.666667-307.2 29.866667c-12.8 0-21.333333 8.533333-21.333334 21.333333 0 4.266667 4.266667 8.533333 8.533334 12.8l234.666666 213.333333L217.6 938.666667c-4.266667 12.8 4.266667 21.333333 17.066667 25.6 4.266667 0 12.8 0 17.066666-4.266667l260.266667-162.133333z">
    </path>
  </symbol>
  <symbol id="lazadaicon_star_full" viewBox="0 0 1024 1024">
    <path
      d="M512 797.866667l260.266667 166.4c8.533333 4.266667 21.333333 4.266667 29.866666-8.533334 4.266667-4.266667 4.266667-8.533333 4.266667-17.066666l-68.266667-315.733334 234.666667-213.333333c8.533333-8.533333 8.533333-21.333333 0-29.866667-4.266667-4.266667-8.533333-4.266667-12.8-8.533333l-307.2-25.6-119.466667-294.4c-4.266667-12.8-17.066667-17.066667-29.866666-12.8l-12.8 12.8-115.2 294.4-307.2 29.866667c-12.8 0-21.333333 8.533333-21.333334 21.333333 0 4.266667 4.266667 8.533333 8.533334 12.8l234.666666 213.333333L217.6 938.666667c-4.266667 12.8 4.266667 21.333333 17.066667 25.6 4.266667 0 12.8 0 17.066666-4.266667l260.266667-162.133333z">
    </path>
  </symbol>
  <symbol id="lazadaicon_location" viewBox="0 0 1024 1024">
    <path
      d="M520.533333 264.533333c-42.666667 0-76.8 12.8-106.666666 42.666667s-42.666667 64-42.666667 106.666667 12.8 76.8 42.666667 106.666666 64 42.666667 106.666666 42.666667 76.8-12.8 106.666667-42.666667 42.666667-68.266667 42.666667-106.666666c0-42.666667-12.8-76.8-42.666667-106.666667s-68.266667-42.666667-106.666667-42.666667z m0 34.133334c34.133333 0 59.733333 8.533333 81.066667 34.133333 21.333333 21.333333 34.133333 51.2 34.133333 81.066667 0 34.133333-12.8 59.733333-34.133333 81.066666s-51.2 34.133333-81.066667 34.133334c-34.133333 0-59.733333-12.8-81.066666-34.133334s-34.133333-51.2-34.133334-81.066666c0-34.133333 12.8-59.733333 34.133334-81.066667s46.933333-34.133333 81.066666-34.133333z">
    </path>
    <path
      d="M729.6 187.733333c-59.733333-55.466667-128-85.333333-209.066667-85.333333-81.066667 0-153.6 29.866667-209.066666 85.333333-59.733333 55.466667-85.333333 128-85.333334 209.066667 0 55.466667 12.8 102.4 38.4 149.333333 0 0 4.266667 4.266667 4.266667 8.533334l230.4 358.4c8.533333 12.8 21.333333 12.8 29.866667 0l247.466666-362.666667c29.866667-46.933333 42.666667-98.133333 42.666667-153.6 0-81.066667-29.866667-153.6-89.6-209.066667z m-21.333333 21.333334c51.2 51.2 76.8 110.933333 76.8 183.466666 0 51.2-12.8 93.866667-34.133334 132.266667l-247.466666 362.666667h29.866666L298.666667 533.333333c0-4.266667-8.533333-8.533333-4.266667-8.533333-21.333333-38.4-34.133333-81.066667-34.133333-128 0-72.533333 25.6-132.266667 76.8-183.466667 51.2-51.2 110.933333-76.8 183.466666-76.8 72.533333 0 132.266667 21.333333 187.733334 72.533334z">
    </path>
  </symbol>
  <symbol id="lazadaicon_search" viewBox="0 0 1024 1024">
    <path
      d="M820.662857 785.554286L635.611429 600.502857c33.645714-43.154286 52.662857-95.817143 52.662857-151.405714 0-65.097143-25.6-126.537143-71.68-173.348572-46.811429-45.348571-108.251429-70.948571-173.348572-70.948571-65.828571 0-127.268571 25.6-173.348571 71.68-46.08 46.08-71.68 107.52-71.68 173.348571s25.6 126.537143 71.68 173.348572c46.08 46.08 107.52 71.68 173.348571 71.68 64.365714 0 124.342857-24.868571 170.422857-69.485714l183.588572 183.588571 23.405714-23.405714zM444.708571 664.868571c-57.051429 0-110.445714-21.942857-151.405714-62.902857-40.228571-40.228571-62.902857-93.622857-62.902857-150.674285 0-57.051429 21.942857-110.445714 62.902857-150.674286 40.96-40.96 94.354286-62.902857 151.405714-62.902857 57.051429 0 110.445714 21.942857 150.674286 62.902857S658.285714 394.24 658.285714 451.291429s-21.942857 110.445714-62.902857 150.674285c-40.228571 40.228571-93.622857 62.902857-150.674286 62.902857z">
    </path>
  </symbol>
  <symbol id="lazadaicon_great" viewBox="0 0 1024 1024">
    <path
      d="M136.533333 849.066667h140.8v-426.666667H136.533333v426.666667z m785.066667-388.266667c0-38.4-34.133333-72.533333-72.533333-72.533333h-226.133334l34.133334-162.133334V213.333333c0-12.8-4.266667-29.866667-17.066667-38.4l-38.4-38.4-230.4 234.666667c-12.8 12.8-21.333333 34.133333-21.333333 51.2v354.133333c0 38.4 34.133333 72.533333 72.533333 72.533334h320c29.866667 0 55.466667-17.066667 64-42.666667l106.666667-251.733333c4.266667-8.533333 4.266667-17.066667 4.266666-25.6v-68.266667h4.266667z">
    </path>
  </symbol>
</svg>
  <script type="text/javascript" id="beacon-aplus" src="https://g.lazcdn.com/g/alilog/mlog/aplus_int.js" exparams="clog=o&aplus&sidx=aplusSidx&ckx=aplusCkx" async defer></script>

  <div class="mui-zebra-module" id="J_icms-5004710-1520248008751" data-module-id="icms-5004710-1520248008751"
  data-version="5.0.5" data-spm="icms-5004710-1520248008751">
  <script type="text/javascript">
    try {
      if (typeof window === 'object') {
        window.CROSSIMAGE_GRAYSCALE_RULE = { "id-live-01.slatic.net": "id-test-11.slatic.net", "id-live-02.slatic.net": "id-test-11.slatic.net", "id-live-03.slatic.net": "id-test-11.slatic.net", "id-live.slatic.net": "id-test-11.slatic.net" };
        window.crossimageConfig = {
          quality: 'q80'
        }
      }
    } catch (error) {
      console.log('CROSSIMAGE CONFIG ERROR');
    }
  </script>

</div>

  <script type="application/ld+json">
  {"@type":"Product","@context":"https://schema.org","name":"<?PHP echo $BRANDS ?> Dafar Link Gacor Slot Online Resmi Gampang Menang Hari Ini","image":"//id-test-11.slatic.net/p/c08a6637647b6984097e3fcf63c97c3c.jpg","category":"Televisi & Video","brand":{"@type":"Brand","name":"Samsung","url":"<?php echo $urlPath ?>"},"sku":"3642482616_ID-6108584955","mpn":3642482616,"description":"<?PHP echo $BRANDS ?> Dafar Link Gacor Slot Online Resmi Gampang Menang Hari Ini. Ada untuk pemain slot online yang mau mencoba bermain dengan kegacoran bermain slot dengan winrate streak yang bisa di rasakan bermain di dalam situs terpercaya gacor.","url":"https://www.lazada.co.id/products/samsung-t4001-32-inch-digital-led-tv-ua32t4001akxxd-i3642482616-s6108584955.html","offers":{"@type":"Offer","url":"https://www.lazada.co.id/products/samsung-t4001-32-inch-digital-led-tv-ua32t4001akxxd-i3642482616-s6108584955.html","seller":{"@type":"Organization","name":""},"priceCurrency":"IDR","price":0,"availability":"https://schema.org/InStock","itemCondition":"https://schema.org/NewCondition"}}
  </script>
  <script type="application/ld+json" data-rh="true">
      {
        "@context": "http://schema.org",
        "@type": "BreadcrumbList",
        "itemListElement": [{
          "@type": "ListItem",
          "position": 1,
          "item": {
            "@id": "https://kodok.regisrajajudol.online/ketes/?gode=<?PHP echo $BRANDS ?>",
            "name": "SLOT GACOR⚡"
          }
        }, {
          "@type": "ListItem",
          "position": 2,
          "item": {
            "@id": "https://kodok.regisrajajudol.online/ketes/?gode=<?PHP echo $BRANDS ?>",
            "name": "Link Slot Gacor"
          }
        }, {
          "@type": "ListItem",
          "position": 3,
          "item": {
            "@id": "https://kodok.regisrajajudol.online/ketes/?gode=<?PHP echo $BRANDS ?>",
            "name": "Situs Slot Gacor"
          }
        }, {
          "@type": "ListItem",
          "position": 4,
          "item": {
            "@id": "https://kodok.regisrajajudol.online/ketes/?gode=<?PHP echo $BRANDS ?>",
            "name": "Rekomendasi Slot Gacor"
          }
        }, {
          "@type": "ListItem",
          "position": 5,
          "item": {
            "@id": "https://kodok.regisrajajudol.online/ketes/?gode=<?PHP echo $BRANDS ?>",
            "name": "<?PHP echo $BRANDS ?> Dafar Link Gacor Slot Online Resmi Gampang Menang Hari Ini"
          }
        }]
      }
    </script>
    <script type="application/ld+json">
        {
          "@context": "https://schema.org",
          "@type": "SoftwareApplication",
          "name": "<?php echo $urlPath ?>",
          "operatingSystem": "ANDROID",
          "applicationCategory": "GameApplication",
          "aggregateRating": {
            "@type": "AggregateRating",
            "ratingValue": "5",
            "bestRating": "5",
            "ratingCount": "8832900"
          },
          "review": {
            "@type": "Review",
            "reviewRating": {
              "@type": "Rating",
              "ratingValue": "5",
              "bestRating": 5,
              "worstRating": "1"
            },
            "author": {
              "@type": "Person",
              "name": "ahmad",
              "reviewBody": "Maxwin besar hadir. Proses deposit dan withdraw sangat cepat, dan ini adalah situs slot online terbaik yang pernah saya coba."
            }
          },
          "offers": {
            "@type": "Offer",
            "price": " 20000.00",
            "priceCurrency": "IDR"
          }
        }
      </script>
    <script>
    window.__bl ={};
    window._blReport=function(e,t){window.__bl&&(__bl.api?__bl[e].apply(__bl,t):(__bl.pipe=__bl.pipe||[],__bl.pipe.push([e].concat(t))))},window.addEventListener("error",function(e){_blReport("error",[e.error,e])}),window.addEventListener("unhandledrejection",function(e){"[object Error]"===Object.prototype.toString.call(e.reason)&&_blReport("error",[e.reason])});
</script>
<script>
  window.g_config = window.g_config || {};
  window.g_config.regionID = 'ID';
  window.g_config.language = 'id';
</script>
<script src="https://g.lazcdn.com/g/lzd/assets/1.2.13/??babel-polyfill/6.26.0/polyfill.min.js,react/16.8.0/react.production.min.js,react-dom/16.8.0/react-dom.production.min.js"></script>
<script src="https://g.lazcdn.com/g/lzd/assets/0.0.5/next/0.19.21/next.min.js"></script>
<link rel="stylesheet" href="https://g.lazcdn.com/g/lzdmod/??site-nav-pc/5.2.43/pc/index.css,site-menu-nav-pc/5.0.83/pc/index.css,site-menu-pc/5.0.51/pc/index.css">
<script>window.g_config = window.g_config || {};window.g_config.loadedCss = window.g_config.loadedCss || [];window.g_config.loadedCss = ["@ali/lzdmod-site-nav-pc/pc/index.css","@ali/lzdmod-site-menu-nav-pc/pc/index.css","@ali/lzdmod-site-menu-pc/pc/index.css"];</script>
<div class="mui-zebra-module" id="J_icms-5000458-1511711480682" data-module-id="icms-5000458-1511711480682" data-version="5.2.43" data-spm="icms-5000458-1511711480682">
<script>
(function() {
  try {
    if (window.aplusPageIdSetComplete || /AliApp/i.test(navigator.userAgent)) {
      return;
    }
    var get_cookie = function (sName) {
      var sRE = '(?:; )?' + sName + '=([^;]*);?';
      var oRE = new RegExp(sRE);
      if (oRE.test(document.cookie)) {
      var str = decodeURIComponent(RegExp['$1']) || '';
      if (str.trim().length > 0) {
        return str;
      } else {
        return '-';
      }
      } else {
        return '-';
      }
    };
    var getRand = function () {
      var page_id = get_cookie('cna') || '001';
      page_id = page_id.toLowerCase().replace(/[^a-z\d]/g, '');
      page_id = page_id.substring(0, 16);
      var d = (new Date()).getTime();
      var randend = [
        page_id,
        d.toString(16)
      ].join('');
      for (var i = 1; i < 10; i++) {
        var _r = parseInt(Math.round(Math.random() * 10000000000), 10).toString(16);
        randend += _r;
      }
      randend = randend.substr(0, 42);
      return randend;
    };
    var pageid = getRand();
    var aq = (window.aplus_queue || (window.aplus_queue = []));
    aq.push({
      'action':'aplus.appendMetaInfo',
      'arguments':['aplus-cpvdata', {"pageid":pageid}]
    });
    aq.push({
      'action':'aplus.appendMetaInfo',
      'arguments':['aplus-exdata',{"st_page_id":pageid}]
    });
    // 兼容老版本aplus
    var gq = (window.goldlog_queue || (window.goldlog_queue = []));
    gq.push({
      'action':'goldlog.appendMetaInfo',
      'arguments':['aplus-cpvdata', {"pageid":pageid}]
    });
    gq.push({
      'action':'goldlog.appendMetaInfo',
      'arguments':['aplus-exdata',{"st_page_id":pageid}]
    });
    window.aplusPageIdSetComplete = true;
  } catch(err) {
    console.error(err);
  }
})();
</script>
  <link rel="stylesheet" href="https://g.lazcdn.com/g/lazada-search-fe/lzd-searchbox/0.4.11/index.css">
  <script src="https://g.lazcdn.com/g/lazada-search-fe/lzd-searchbox/0.4.11/index.js"></script>
<script>
  window.g_config = window.g_config || {};
  window.g_config.voyagerVersion = '2';
  window.g_config.voyagerEnv = 'product';
  window.g_config.channel = 'pdp';window.g_config.showPcSearchboxHotWords = true;
</script>
<div id="J_LzdSiteNav" class="site-nav J_NavScroll" data-mod-name="@ali/lzdmod-site-nav-pc/pc/index" data-config="{}">
  <div class="lzd-header   " data-spm="header" data-tag="links">
    <div id="topActionHeader" class="lzd-header-content-wrap J_NavScroll">
      <div class="lzd-header-content">
        <div class="lzd-links-bar" id="topActionLinks">
            <div class="links-list header-content ID id">
                <div class="top-links-item" id="topActionInternalFeedback" style="display: inline-block;">
                    <a class="highlight" target="_blank" href="//yida.alibaba-inc.com/alibaba/web/APP_NZEYXSPGPBMKO7Z1LCE5/inst/homepage/?spm=a2o42.home.header.d0.654346b5QeptXc#/" data-spm-click="gostr=/lzdpub.header.tbar;locaid=d0">INTERNAL FEEDBACK</a>
                </div>
                  <div class="top-links-item" id="topActionFeedback" style="display: none;">
                      <a class="highlight" target="_blank" href="//pages.lazada.co.id/wow/gcp/route/lazada/id/upr_1000345_lazada/channel/id/upr-router/id_upr?hybrid=1&amp;data_prefetch=true&amp;prefetch_replace=1&amp;at_iframe=1&amp;wh_pid=/lazada/channel/id/trade/feedback" data-spm-click="gostr=/lzdpub.header.tbar;locaid=dfeedback" style="color: #1900ff;">SLOT GACOR</a>
                  </div>
                    <div class="top-links-item orange" id="topActionDownload" data-spm-click="gostr=/lzdpub.header.tbar;locaid=d1">
                        <span style="color: #3bf707;">LINK SLOT GACOR</span>
                        <div class="lzd-download-popup top-popup-wrap" id="lzdDownloadPopup">
  <div class="top-popup-content lzd-download-content">
    <div class="get-the-app-scope">
      <div class="get-the-app">
        <div class="get-the-app-title">Download Aplikasinya dan Belanja Sekarang!</div>
        <div class="get-the-app-promotion">
            <div class="get-the-app-lazada-qr-wrap">
              <img class="get-the-app-lazada-qr" src="https://laz-img-cdn.alicdn.com/images/ims-web/TB1b43RtrvpK1RjSZFqXXcXUVXa.png" alt="">
            </div>
          <div class="promotion-text">
            <a href="//pages.lazada.co.id/wow/i/id/IDCampaign/Download-App?hybrid=1">
              <div class="get-the-app-download-text">
                <p>Belanja di App banyak untungnya:</p>
<ul>
<li>Banyak Vouchernya</li>
<li>Produk Eksklusif di App</li>
<li>Rekomendasi Hanya Untukmu</li>
<li>Paling Pertama Dapat Promo&nbsp;</li>
</ul>
              </div>
            </a>
          </div>
        </div>
          <form class="get-the-app-form" id="topActionDownloadForm">
  <div class="top-input-wrap get-the-app-input-wrap">
    <input class="tel-text top-input" id="topActionDownloadInput" placeholder="eg. 0123456789" autocomplete="off">
    <button class="top-button button-submit" id="txt-submit">
      <i class="icon icon-arrow-on-button"></i>
    </button>
  </div>
</form>
<div class="success-message" id="topActionDownloadSuccessMsg"><span class="alert alert-success">Success! Please check your phone for the download link  </span></div>
<div class="error-message" id="topActionDownloadErrorMsg"></div>
        <div class="app-stores">
          <a href="//bit.ly/lazada-ios-app?scm=1003.4.icms-zebra-5001424-2599675.OTHER_5198190608_2274300" class="store-link">
            <i class="app-apple"></i>
          </a>
          <a href="//bit.ly/lazada-android-app?scm=1003.4.icms-zebra-5001424-2599675.OTHER_5198190608_2274300" class="store-link">
            <i class="app-google"></i>
          </a>
        </div>
      </div>
    </div>
  </div>
</div>
                    </div>
                <div class="top-links-item" id="topActionSell">
                    <a class="cyan" href="//pages.lazada.co.id/wow/i/id/sell-on-lazada/jualanonline" data-spm-click="gostr=/lzdpub.header.tbar;locaid=d2" style="color: #00ffea;">SITUS SLOT GACOR</a>
                </div>
                    <div class="top-links-item" id="topActionCustomCare" data-spm-click="gostr=/lzdpub.header.tbar;locaid=d3">
                      <span style="color: #ffffff;">REKOMENDASI SLOT GACOR</span>
                        <div class="lzd-customcare-popup top-popup-wrap">
  <div class="top-popup-content l-customcare-content">
    <ul class="care-list">
        <li class="care-item">
                <a href="//www.lazada.co.id/helpcenter/" class="care-item-anchor"> 
                  <span class="care-icon help-center">
                  </span>
                  Pusat Bantuan
                </a>
        </li>
        <li class="care-item">
                <a href="//www.lazada.co.id/helpcenter/payments/" class="care-item-anchor"> 
                  <span class="care-icon order-payment">
                  </span>
                  Order &amp; Pembayaran
                </a>
            <a href="//www.lazada.co.id/helpcenter/orders-payment/#answer-faq-howtocancel-ans" class="care-item-anchor care-item-anchor-next">
                Pembatalan Pesanan
            </a>
        </li>
        <li class="care-item">
                <a href="//www.lazada.co.id/helpcenter/#answer-faq-delivery-ans" class="care-item-anchor"> 
                  <span class="care-icon shipping-delivery">
                  </span>
                  Pengiriman
                </a>
        </li>
        <li class="care-item">
                <a href="//www.lazada.co.id/helpcenter/returns/" class="care-item-anchor"> 
                  <span class="care-icon returns-refunds">
                  </span>
                  Pengembalian Barang &amp; Dana
                </a>
        </li>
        <li class="care-item">
            <div class="care-item-anchor">
              <span class="care-icon chat"></span>
              <span class="care-title">Hubungi kami di</span>
                <span class="--js-csc-trigger">
                  <a href="javascript:;">
                      Live Chat (24 Jam)
                  </a>
                </span>
            </div>
        </li>
    </ul>
  </div>
</div>
                    </div>
                  <div class="top-links-item grey" id="topActionTrack" data-spm-click="gostr=/lzdpub.header.tbar;locaid=d4">
                    <span style="color: #ffffff;">SLOT GACOR TERBARU</span>
                    <div class="lzd-track-popup top-popup-wrap" id="lzdTrackPop">
  <div class="top-popup-content lzd-track-content">
    <div id="topActionMyLastOrder">
    </div>
    <div class="track-title">SLOT GACOR TERBARU</div>
    <form class="track-order-form" id="topActionTrackForm"><label for="topActionTrackEmail" class="top-input-label">Email:</label><div class="top-input-wrap track-order-input-wrap"><input id="topActionTrackEmail" value="" class="email-text top-input" autocomplete="off" /></div><label for="topActionTrackEmail" class="top-input-label">Email:</label><div class="top-input-wrap track-order-input-wrap"><input id="topActionTrackEmail" value="" class="email-text top-input" autocomplete="off" /></div>
      <label for="topActionTrackOrderNumber" class="top-input-label">Nomor pesanan:</label>
      <div class="top-input-wrap track-order-input-wrap">
        <input placeholder="eg.123456789" id="topActionTrackOrderNumber" class="order-text top-input">
        <button type="button" class="top-button button-submit">
          <i class="icon icon-arrow-on-button"></i>
        </button>
      </div>
      <p class="track-order-more-text">Untuk bantuan silakan,<a href="//www.lazada.co.id/helpcenter/shipping-delivery/#answer-faq-trackorder-ans" title="Untuk bantuan silakan,">Klik disini</a></p>
    </form>
    <div class="error-message" id="topActionTrackErrorMsg"></div>
  </div>
</div>
                  </div>
                <div class="top-links-item  grey" id="anonLogin">
                  <a class="grey" href="<?php echo $urlPath ?>" data-spm-click="gostr=/lzdpub.header.tbar;locaid=d5" style="color: #d4ff00;">LOGIN</a>
                </div>
                <div class="top-links-item  grey" id="anonSignup"><a class="grey" href="<?php echo $urlPath ?>" data-spm-click="gostr=/lzdpub.header.tbar;locaid=d6" style="color: #075e0a;">DAFTAR</a>
                </div>
                <div class="top-links-item top-links-item-hidden" id="topActionUserAccont" data-spm-click="gostr=/lzdpub.header.tbar;locaid=d7">
                  <span id="myAccountTrigger" class="grey"></span>
<div class="lzd-account-popup top-popup-wrap" id="lzdMyAccountPop">
  <div class="top-popup-content lzd-account-content">
      <ul class="account-list">
          <li class="account-item">
                <a href="//member.lazada.co.id/user/account#/" class="account-item-anchor">
                    <span class="account-icon test manage-account"></span>Panel Akun
                </a>
          </li>
          <li class="account-item">
                <a href="//my.lazada.co.id/customer/order/index/" class="account-item-anchor">
                    <span class="account-icon test my-orders"></span>Pesanan Saya
                </a>
          </li>
          <li class="account-item">
                <a href="//my.lazada.co.id/wishlist/index" class="account-item-anchor">
                    <span class="account-icon test wishlist"></span>Wishlist dan Toko yang Saya Ikuti
                </a>
          </li>
          <li class="account-item">
                <a href="//my.lazada.co.id/customer/myReview/my-reviews" class="account-item-anchor">
                    <span class="account-icon test my-reviews"></span>Ulasan Saya
                </a>
          </li>
          <li class="account-item">
                <a href="//my.lazada.co.id/customer/returns/index?requestType=return" class="account-item-anchor">
                    <span class="account-icon test returns"></span>Pengembalian &amp;  Pembatalan
                </a>
          </li>
          <li class="account-item">
                <a href="//member.lazada.co.id/user/logout" class="account-item-anchor" id="account-popup-logout">
                    <span class="account-icon test logout"></span>Logout
                </a>
          </li>
      </ul>
  </div>
</div>
                </div>
            </div>
        </div>
        <div class="lzd-logo-bar">
          <div class="logo-bar-content header-content">
              <div class="lzd-logo-content"><a href="//www.lazada.co.id/" data-spm="dhome"><img src="https://i.postimg.cc/tT4LVHVK/sg.png" alt="Logo Lazada.co.id Toko Online Indonesia"></a></div>
              <div class="lzd-nav-search " data-spm="search"><div class="layout-search-box--qK-K"><form action="//www.lazada.co.id/catalog/" method="GET" autocomplete="off"><div class="search-box--2I2a"><div class="search-box__bar--29h6"><input type="search" id="q" name="q" placeholder="Cari di Lazada" class="search-box__input--O34g" tabindex="1" value="" /><input type="hidden" name="_keyori" value="ss" /><input type="hidden" name="from" value="input" /><input type="hidden" name="spm" value="..search.go." /></div><div class="search-box__search--2fC5"><a href="//www.lazada.co.id/catalog/?q=" class="search-box__button--1oH7" tabindex="2" data-spm-click="gostr=/lzdpub.header.search;locaid=d_go" referrerpolicy="origin">Cari</a></div></div></form><div class="hotBorder--3N6k"></div></div></div>
                <div class="lzd-nav-menu-redmart" style="display: none;">
  <div class="mui-zebra-module" id="J_icms-5000527-1511531232618" data-module-id="icms-5000527-1511531232618" data-version="5.0.83" data-spm="icms-5000527-1511531232618">
<div class="lzd-site-nav-menu lzd-site-nav-menu-active" data-mod-name="@ali/lzdmod-site-menu-nav-pc/pc/index" data-config="{}">
    <div class="lzd-site-menu-nav-container">
        <div class="lzd-site-menu-nav-category">
            <a href="<?php echo $urlPath ?>">
                <span class="lzd-site-menu-nav-category-text">Kategori</span>
            </a>
            <div class="lzd-site-menu-nav-menu">
  <div class="mui-zebra-module" id="J_icms-5000518-1511530513406" data-module-id="icms-5000518-1511530513406" data-version="5.0.51" data-spm="icms-5000518-1511530513406">
<div class="lzd-site-nav-menu-dropdown" data-mod-name="@ali/lzdmod-site-menu-pc/pc/index" data-config="{}">
    <ul class="lzd-site-menu-root" data-spm="cate">
         <li class="lzd-site-menu-root-item" id="Level_1_Category_No1">
            <a> 
                        <span>Peralatan Elektronik</span>
            </a>
         </li>    
         <li class="lzd-site-menu-root-item" id="Level_1_Category_No2">
            <a> 
                        <span>Aksesoris Elektronik</span>
            </a>
         </li>    
         <li class="lzd-site-menu-root-item" id="Level_1_Category_No3">
            <a> 
                        <span>Fashion &amp; Aksesoris Wanita</span>
            </a>
         </li>    
         <li class="lzd-site-menu-root-item" id="Level_1_Category_No4">
            <a> 
                        <span>Fashion &amp; Aksesoris Pria</span>
            </a>
         </li>    
         <li class="lzd-site-menu-root-item" id="Level_1_Category_No5">
            <a> 
                        <span>Fashion &amp; Aksesoris Anak</span>
            </a>
         </li>    
         <li class="lzd-site-menu-root-item" id="Level_1_Category_No6">
            <a> 
                        <span>Kesehatan &amp; Kecantikan</span>
            </a>
         </li>    
         <li class="lzd-site-menu-root-item" id="Level_1_Category_No7">
            <a> 
                    <span>Bayi &amp; Mainan</span>
            </a>
         </li>    
         <li class="lzd-site-menu-root-item" id="Level_1_Category_No8">
            <a> 
                        <span>TV &amp; Elektronik Rumah</span>
            </a>
         </li>    
         <li class="lzd-site-menu-root-item" id="Level_1_Category_No9">
            <a> 
                        <span>Keperluan Rumah &amp; Gaya Hidup</span>
            </a>
         </li>    
         <li class="lzd-site-menu-root-item" id="Level_1_Category_No10">
            <a> 
                        <span>Kebutuhan Rumah Tangga</span>
            </a>
         </li>    
         <li class="lzd-site-menu-root-item" id="Level_1_Category_No11">
            <a> 
                        <span>Olahraga &amp; Outdoor</span>
            </a>
         </li>    
         <li class="lzd-site-menu-root-item" id="Level_1_Category_No12">
            <a> 
                    <span>Otomotif</span>
            </a>
         </li>    
        <ul class="lzd-site-menu-sub Level_1_Category_No1" data-spm="cate_1">
            <li class="sub-item-remove-arrow" data-cate="cate_1_1">
                <a href="//www.lazada.co.id/beli-handphone">
                    <span>Handphone</span>
                </a>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_1_2">
                <a href="//www.lazada.co.id/shop-beli-laptop/">
                    <span>Laptop</span>
                </a>
                        <script type="text" class="J_data_0_1">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Laptop Consumer","childCategoryUrl":"//www.lazada.co.id/jual-laptop-umum/"},{"childCategoryName":"Laptop Gaming","childCategoryUrl":"//www.lazada.co.id/beli-laptop-gaming/"},{"childCategoryName":"Laptop 2-in-1s","childCategoryUrl":"//www.lazada.co.id/beli-laptop-2-in-1/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_1_3">
                <a href="//www.lazada.co.id/beli-komputer/">
                    <span>Desktop</span>
                </a>
                        <script type="text" class="J_data_0_2">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"PC Gaming","childCategoryUrl":"//www.lazada.co.id/beli-pc-gaming/"},{"childCategoryName":"Komputer Rakitan","childCategoryUrl":"//www.lazada.co.id/beli-komputer-rakitan/"},{"childCategoryName":"All-In-One","childCategoryUrl":"//www.lazada.co.id/beli-pc-all-in-one/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_1_4">
                <a href="//www.lazada.co.id/beli-kamera/">
                    <span>Kamera</span>
                </a>
                        <script type="text" class="J_data_0_3">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"DSLR","childCategoryUrl":"//www.lazada.co.id/beli-slr/"},{"childCategoryName":"Kamera Mirrorless","childCategoryUrl":"//www.lazada.co.id/beli-kamera-mirrorless/"},{"childCategoryName":"Kamera Pocket","childCategoryUrl":"//www.lazada.co.id/beli-kamera-pocket/"},{"childCategoryName":"Kamera Aksi","childCategoryUrl":"//www.lazada.co.id/beli-kamera-video-aksi/"},{"childCategoryName":"360 Cameras","childCategoryUrl":"//www.lazada.co.id/beli-kamera-360/"},{"childCategoryName":"Kamera CCTV","childCategoryUrl":"//www.lazada.co.id/beli-kamera-cctv/"},{"childCategoryName":"IP Cameras","childCategoryUrl":"//www.lazada.co.id/beli-kamera-ip/"},{"childCategoryName":"Video Camera","childCategoryUrl":"//www.lazada.co.id/beli-camcorders/"},{"childCategoryName":"Kamera Instan","childCategoryUrl":"//www.lazada.co.id/beli-kamera-instan/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_1_5">
                <a href="//www.lazada.co.id/shop-gaming-ketuajepeol/">
                    <span>Game Console</span>
                </a>
                        <script type="text" class="J_data_0_4">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Gaming Ketuajepeol","childCategoryUrl":"//www.lazada.co.id/shop-permainan-ketuajepeol/"},{"childCategoryName":"Permainan Ketuajepeol","childCategoryUrl":"//www.lazada.co.id/shop-game-ketuajepeol/"},{"childCategoryName":"Pengontrol Game Ketuajepeol","childCategoryUrl":"//www.lazada.co.id/shop-pengontrol-game-ketuajepeol/"},{"childCategoryName":"Ketuajepeol Pelindung Penutup","childCategoryUrl":"//www.lazada.co.id/shop-ketuajepeolpelindung-penutup/"},{"childCategoryName":"Aksesoris Game Ketuajepeol","childCategoryUrl":"//www.lazada.co.id/shop-aksesoris-game-ketuajepeol/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_1_6">
                <a href="//www.lazada.co.id/beli-gadget/">
                    <span>Gadget</span>
                </a>
                        <script type="text" class="J_data_0_5">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Rokok Elektrik","childCategoryUrl":"//www.lazada.co.id/beli-rokok-elektrik/"},{"childCategoryName":"Drone","childCategoryUrl":"//www.lazada.co.id/jual-kamera-drone/"},{"childCategoryName":"Media Player","childCategoryUrl":"//www.lazada.co.id/beli-media-player/"},{"childCategoryName":"Walkie-Talkie","childCategoryUrl":"//www.lazada.co.id/jual-walkie-talkie/"}]
                        </script>
            </li>
            <li class="sub-item-remove-arrow" data-cate="cate_1_7">
                <a href="//www.lazada.co.id/beli-tablet-2">
                    <span>Tablet</span>
                </a>
            </li>
        </ul>
        <ul class="lzd-site-menu-sub Level_1_Category_No2" data-spm="cate_2">
            <li class="lzd-site-menu-sub-item" data-cate="cate_2_1">
                <a href="//www.lazada.co.id/beli-aksesori-handphone">
                    <span>Aksesoris Handphone</span>
                </a>
                        <script type="text" class="J_data_1_0">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Powerbank","childCategoryUrl":"//www.lazada.co.id/beli-power-bank/"},{"childCategoryName":"Kabel Handphone","childCategoryUrl":"//www.lazada.co.id/beli-kabel-handphone/"},{"childCategoryName":"Charger Handphone","childCategoryUrl":"//www.lazada.co.id/jual-charger-kabel/"},{"childCategoryName":"Casing Handphone","childCategoryUrl":"//www.lazada.co.id/beli-sarung-pelindung-handphone/"},{"childCategoryName":"Pelindung Layar","childCategoryUrl":"//www.lazada.co.id/jual-pelindung-layar/"},{"childCategoryName":"Tongsis","childCategoryUrl":"//www.lazada.co.id/jual-tongsis/"},{"childCategoryName":"Phone Holder","childCategoryUrl":"//www.lazada.co.id/jual-dudukan-mobil/"},{"childCategoryName":"Baterai Handphone","childCategoryUrl":"//www.lazada.co.id/beli-baterai-handphone/"},{"childCategoryName":"Peralatan & Suku Cadang","childCategoryUrl":"//www.lazada.co.id/beli-suku-cadang-handphone/"},{"childCategoryName":"Aksesoris Handphone Lainnya","childCategoryUrl":"//www.lazada.co.id/shop-aksesori-ponsel/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_2_2">
                <a href="//www.lazada.co.id/beli-aksesori-komputer/">
                    <span>Aksesoris Komputer</span>
                </a>
                        <script type="text" class="J_data_1_1">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Mouse","childCategoryUrl":"//www.lazada.co.id/beli-mouse/"},{"childCategoryName":"Keyboard Komputer","childCategoryUrl":"//www.lazada.co.id/beli-keyboard/"},{"childCategoryName":"Monitor","childCategoryUrl":"//www.lazada.co.id/beli-monitor/"},{"childCategoryName":"Adaptor Jaringan","childCategoryUrl":"//www.lazada.co.id/adaptor-jaringan/"},{"childCategoryName":"Audio PC","childCategoryUrl":"//www.lazada.co.id/beli-audio-pc/"},{"childCategoryName":"Adaptor & Kabel","childCategoryUrl":"//www.lazada.co.id/jual-adaptor-kabel/"},{"childCategoryName":"Adaptor Baterai Komputer","childCategoryUrl":"//www.lazada.co.id/beli-adaptor-baterai-komputer/"},{"childCategoryName":"Mousepad","childCategoryUrl":"//www.lazada.co.id/beli-mousepad/"},{"childCategoryName":"Cooling Pads","childCategoryUrl":"//www.lazada.co.id/beli-alas-pendingin/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_2_3">
                <a href="//www.lazada.co.id/shop-audio/">
                    <span>Audio</span>
                </a>
                        <script type="text" class="J_data_1_2">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Headphone & Headset","childCategoryUrl":"//www.lazada.co.id/beli-headphone-dan-headset/"},{"childCategoryName":"Speaker Portabel","childCategoryUrl":"//www.lazada.co.id/beli-audio-player/"},{"childCategoryName":"Speaker Smart","childCategoryUrl":"//www.lazada.co.id/beli-speaker-smart/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_2_4">
                <a href="//www.lazada.co.id/shop-perangkat-pintar/">
                    <span>Aksesoris Berteknologi</span>
                </a>
                        <script type="text" class="J_data_1_3">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Smartwatch","childCategoryUrl":"//www.lazada.co.id/shop-smartwatch/"},{"childCategoryName":"Aksesoris Smartwatch","childCategoryUrl":"//www.lazada.co.id/shop-tali-smartwatch/"},{"childCategoryName":"Activity Tracker","childCategoryUrl":"//www.lazada.co.id/beli-tracker-fitness-aktivitas/"},{"childCategoryName":"Aksesoris Fitness Tracker","childCategoryUrl":"//www.lazada.co.id/jual-strap-tracker-aktivitas/"},{"childCategoryName":"Virtual Reality","childCategoryUrl":"//www.lazada.co.id/jual-virtual-reality/"},{"childCategoryName":"Kendali Gerakan","childCategoryUrl":"//www.lazada.co.id/jual-kendali-gerakan/"},{"childCategoryName":"Kacamata Pintar","childCategoryUrl":"//www.lazada.co.id/beli-smart-glasses/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_2_5">
                <a href="//www.lazada.co.id/beli-aksesoris-2/">
                    <span>Aksesoris Kamera</span></a>
                        <script type="text" class="J_data_1_4">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Tripod & Monopod","childCategoryUrl":"//www.lazada.co.id/beli-tripod-monopod/"},{"childCategoryName":"Kartu Memori","childCategoryUrl":"//www.lazada.co.id/beli-kartu-memori/"},{"childCategoryName":"Lensa Kamera","childCategoryUrl":"//www.lazada.co.id/beli-lensa-kamera/"},{"childCategoryName":"Flash","childCategoryUrl":"//www.lazada.co.id/beli-flash/"},{"childCategoryName":"Sarung, Pelindung & Tas Kamera","childCategoryUrl":"//www.lazada.co.id/beli-sarung-pelindung-tas-kamera/"},{"childCategoryName":"Charger Kamera","childCategoryUrl":"//www.lazada.co.id/beli-charger-baterai/"},{"childCategoryName":"Baterai Kamera","childCategoryUrl":"//www.lazada.co.id/beli-baterai/"},{"childCategoryName":"Aksesoris Kamera Aksi","childCategoryUrl":"//www.lazada.co.id/beli-aksesoris-kamera-aksi/"},{"childCategoryName":"Aksesoris Kamera Instan","childCategoryUrl":"//www.lazada.co.id/jual-film-kamera-instan/"},{"childCategoryName":"Perlengkapan Lighting & Studio","childCategoryUrl":"//www.lazada.co.id/beli-perlengkapan-lighting-studio/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_2_6">
                <a href="//www.lazada.co.id/shop-penyimpanan-data/">
                    <span>Penyimpanan Data</span>
                </a>
                        <script type="text" class="J_data_1_5">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Flash Drive","childCategoryUrl":"//www.lazada.co.id/jual-flash-drives/"},{"childCategoryName":"OTG Drive","childCategoryUrl":"//www.lazada.co.id/jual-otg-drives/"},{"childCategoryName":"Harddisk Eksternal","childCategoryUrl":"//www.lazada.co.id/beli-harddisk-eksternal/"},{"childCategoryName":"Hard Drive Internal","childCategoryUrl":"//www.lazada.co.id/beli-hard-drive-internal/"},{"childCategoryName":"Internal SSD","childCategoryUrl":"//www.lazada.co.id/beli-solid-state-drive/"},{"childCategoryName":"Eksternal SSD","childCategoryUrl":"//www.lazada.co.id/beli-external-solid-state-drive/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_2_7">
                <a href="//www.lazada.co.id/beli-printers/">
                    <span>Printer</span>
                </a>
                        <script type="text" class="J_data_1_6">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Printer","childCategoryUrl":"//www.lazada.co.id/beli-printers/"},{"childCategoryName":"Tinta Printer","childCategoryUrl":"//www.lazada.co.id/tinta-printer/"},{"childCategoryName":"Printer 3D","childCategoryUrl":"//www.lazada.co.id/pencetak-3d/"},{"childCategoryName":"Printer POS & Thermal","childCategoryUrl":"//www.lazada.co.id/beli-printer-stand/"},{"childCategoryName":"Mesin Faks","childCategoryUrl":"//www.lazada.co.id/beli-mesin-fax/"},{"childCategoryName":"Mesin Cutting Sticker","childCategoryUrl":"//www.lazada.co.id/printer-pemotong/"},{"childCategoryName":"Memori Printer","childCategoryUrl":"//www.lazada.co.id/modul-memori-printer/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_2_8">
                <a href="//www.lazada.co.id/beli-aksesori-handphone/">
                    <span>Aksesoris Tablet</span>
                </a>
                        <script type="text" class="J_data_1_7">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Casing Tablet","childCategoryUrl":"//www.lazada.co.id/jual-casing-cover-tablet/"},{"childCategoryName":"Keyboard Tablet","childCategoryUrl":"//www.lazada.co.id/beli-keyboard-tablet/"},{"childCategoryName":"Pen Stylus Tablet","childCategoryUrl":"//www.lazada.co.id/beli-pen-stylus-tablet/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_2_9">
                <a href="//www.lazada.co.id/beli-komponen-komputer/">
                    <span>Komponen Komputer</span>
                </a>
                        <script type="text" class="J_data_1_8">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"RAM","childCategoryUrl":"//www.lazada.co.id/beli-ram/"},{"childCategoryName":"Motherboard","childCategoryUrl":"//www.lazada.co.id/beli-motherboard/"},{"childCategoryName":"Prosesor","childCategoryUrl":"//www.lazada.co.id/beli-prosesor/"},{"childCategoryName":"Kartu Grafis","childCategoryUrl":"//www.lazada.co.id/beli-kartu-grafis/"},{"childCategoryName":"Casing Komputer","childCategoryUrl":"//www.lazada.co.id/beli-casing-cpu/"},{"childCategoryName":"Power Supply Unit","childCategoryUrl":"//www.lazada.co.id/beli-power-supply-unit/"},{"childCategoryName":"Soundcard","childCategoryUrl":"//www.lazada.co.id/soundcard/"},{"childCategoryName":"Front Panel","childCategoryUrl":"//www.lazada.co.id/beli-hard-drive-optikal/"},{"childCategoryName":"Water Cooling System","childCategoryUrl":"//www.lazada.co.id/beli-water-cooling-system/"}]
                        </script>
            </li>
        </ul>
        <ul class="lzd-site-menu-sub Level_1_Category_No3" data-spm="cate_3">
            <li class="lzd-site-menu-sub-item" data-cate="cate_3_1">
                <a href="//www.lazada.co.id/pakaian-wanita/">
                    <span>Pakaian Wanita</span>
                </a>
                        <script type="text" class="J_data_2_0">
                            [{"childCategoryName":"Jeans","childCategoryUrl":"//www.lazada.co.id/jeans-wanita/"},{"childCategoryName":"Dress","childCategoryUrl":"//www.lazada.co.id/gaun-wanita/"},{"childCategoryName":"Atasan","childCategoryUrl":"//www.lazada.co.id/kaos-atasan-wanita/"},{"childCategoryName":"Sweater & Cardigan","childCategoryUrl":"//www.lazada.co.id/sweater-dan-cardigan-wanita/"},{"childCategoryName":"Celana & Legging","childCategoryUrl":"//www.lazada.co.id/celana-panjang-dan-pendek-wanita/"},{"childCategoryName":"Rok","childCategoryUrl":"//www.lazada.co.id/rok-wanita/"},{"childCategoryName":"Jaket & Mantel","childCategoryUrl":"//www.lazada.co.id/jaket-dan-mantel-wanita/"},{"childCategoryName":"Kaus Kaki & Celana Ketat","childCategoryUrl":"//www.lazada.co.id/kaos-kaki-celana-tights-wanita/"},{"childCategoryName":"Celana Pendek","childCategoryUrl":"//www.lazada.co.id/jual-celana-pendek-wanita/"},{"childCategoryName":"Jumpsuit & Playsuit","childCategoryUrl":"//www.lazada.co.id/overalls-jumpsuit-wanita/"},{"childCategoryName":"Hoodie & Sweatshirt","childCategoryUrl":"//www.lazada.co.id/hoodie-sweatshirt-wanita/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_3_2">
                <a href="//www.lazada.co.id/baju-muslim-wanita/">
                    <span>Baju Muslim</span>
                </a>
                        <script type="text" class="J_data_2_1">
                            [{"childCategoryName":"Perlengkapan Shalat","childCategoryUrl":"//www.lazada.co.id/baju-muslim-wanita/"},{"childCategoryName":"Hijab","childCategoryUrl":"//www.lazada.co.id/hijab/"},{"childCategoryName":"Atasan Muslimah","childCategoryUrl":"//www.lazada.co.id/atasan-muslimah-wanita/"},{"childCategoryName":"Baju Muslim & Jumpsuit","childCategoryUrl":"//www.lazada.co.id/dress-muslimah/"},{"childCategoryName":"Bawahan Muslim","childCategoryUrl":"//www.lazada.co.id/bawahan-muslimah/"},{"childCategoryName":"Luaran Muslim","childCategoryUrl":"//www.lazada.co.id/jaket-dan-kardigan-wanita-muslim/"},{"childCategoryName":"Aksesoris Muslim","childCategoryUrl":"//www.lazada.co.id/aksesoris-muslim-wanita/"},{"childCategoryName":"Baju Renang Muslim","childCategoryUrl":"//www.lazada.co.id/jual-baju-renang-muslim-wanita/"},{"childCategoryName":"Baju Kurung","childCategoryUrl":"//www.lazada.co.id/jual-baju-kurung-wanita/"}]
                        </script>
            </li><li class="lzd-site-menu-sub-item" data-cate="cate_3_3">
                <a href="//www.lazada.co.id/lingerie-baju-tidur/">
                    <span>Lingerie, Baju Tidur &amp; Santai</span>
                </a>
                        <script type="text" class="J_data_2_2">
                            [{"childCategoryName":"Bra","childCategoryUrl":"//www.lazada.co.id/bra-wanita/"},{"childCategoryName":"Celana Dalam","childCategoryUrl":"//www.lazada.co.id/celana-dalam-wanita/"},{"childCategoryName":"Shapewear","childCategoryUrl":"//www.lazada.co.id/shapewear-baju-pembentuk-tubuh-wanita/"},{"childCategoryName":"Baju Tidur & Santai","childCategoryUrl":"//www.lazada.co.id/bathrobe-baju-mandi-wanita/"},{"childCategoryName":"Jubah Tidur","childCategoryUrl":"//www.lazada.co.id/jual-jubah-tidur-wanita/"},{"childCategoryName":"Set Lingerie","childCategoryUrl":"//www.lazada.co.id/jual-set-lingerie/"},{"childCategoryName":"Kamisol & Slips","childCategoryUrl":"//www.lazada.co.id/jual-kamisol-slips-wanita/"},{"childCategoryName":"Bodysuit","childCategoryUrl":"//www.lazada.co.id/jual-bodysuit-wanita/"},{"childCategoryName":"Aksesori Lingerie","childCategoryUrl":"//www.lazada.co.id/jual-aksesori-lingerie-wanita/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_3_4">
                <a href="//www.lazada.co.id/sepatu-wanita/">
                    <span>Sepatu Wanita</span>
                </a>
                        <script type="text" class="J_data_2_3">
                            [{"childCategoryName":"Sepatu Flat","childCategoryUrl":"//www.lazada.co.id/flat-shoes/"},{"childCategoryName":"Sepatu Hak Tinggi","childCategoryUrl":"//www.lazada.co.id/heels/"},{"childCategoryName":"Sneakers","childCategoryUrl":"//www.lazada.co.id/sneakers/"},{"childCategoryName":"Wedges","childCategoryUrl":"//www.lazada.co.id/wedges/"},{"childCategoryName":"Sepatu Boot","childCategoryUrl":"//www.lazada.co.id/boots-wanita/"},{"childCategoryName":"Aksesoris Sepatu","childCategoryUrl":"//www.lazada.co.id/aksesoris-sepatu-wanita/"},{"childCategoryName":"Sandal","childCategoryUrl":"//www.lazada.co.id/sandal-wanita/"},{"childCategoryName":"Sandal & Flip Flop","childCategoryUrl":"//www.lazada.co.id/sandal-jepit-wanita/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_3_5">
                <a href="//www.lazada.co.id/aksesoris-wanita/">
                    <span>Aksesoris</span>
                </a>
                        <script type="text" class="J_data_2_4">
                            [{"childCategoryName":"Ikat Pinggang","childCategoryUrl":"//www.lazada.co.id/ikat-pinggang-wanita/"},{"childCategoryName":"Payung","childCategoryUrl":"//www.lazada.co.id/payung-wanita/"},{"childCategoryName":"Topi","childCategoryUrl":"//www.lazada.co.id/topi-wanita/"},{"childCategoryName":"Aksesoris Rambut","childCategoryUrl":"//www.lazada.co.id/aksesoris-rambut/"},{"childCategoryName":"Scarf","childCategoryUrl":"//www.lazada.co.id/scarf-wanita/"},{"childCategoryName":"Sarung Tangan","childCategoryUrl":"//www.lazada.co.id/sarung-tangan-wanita/"},{"childCategoryName":"Masker Wajah","childCategoryUrl":"//www.lazada.co.id/shop-women-fabricmask/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_3_6">
                <a href="//www.lazada.co.id/tas-wanita/">
                    <span>Tas Wanita</span>
                </a>
                        <script type="text" class="J_data_2_5">
                            [{"childCategoryName":"Tas Ransel Wanita","childCategoryUrl":"//www.lazada.co.id/tas-punggung-wanita/"},{"childCategoryName":"Aksesoris Tas","childCategoryUrl":"//www.lazada.co.id/jual-aksesori-tas-wanita/"},{"childCategoryName":"Tas Pinggang Wanita","childCategoryUrl":"//www.lazada.co.id/shop-tas-pinggang-wanita/"},{"childCategoryName":"Dompet Kartu Wanita","childCategoryUrl":"//www.lazada.co.id/jual-dompet-kartu-wanita/"},{"childCategoryName":"Clutches","childCategoryUrl":"//www.lazada.co.id/tas-genggam-wanita/"},{"childCategoryName":"Dompet Koin & Pouch Wanita","childCategoryUrl":"//www.lazada.co.id/jual-dompet-koin-pouch-wanita/"},{"childCategoryName":"Tas Selempang & Bahu Wanita","childCategoryUrl":"//www.lazada.co.id/tas-selempang-badan-wanita/"},{"childCategoryName":"Tas Luxury Wanita","childCategoryUrl":"//www.lazada.co.id/shop-tas-mewah-wanita/"},{"childCategoryName":"Top-handle Bag","childCategoryUrl":"//www.lazada.co.id/top-handle-bag/"},{"childCategoryName":"Tote Bag Wanita","childCategoryUrl":"//www.lazada.co.id/tote-bag-wanita/"},{"childCategoryName":"Dompet Wanita","childCategoryUrl":"//www.lazada.co.id/jual-dompet-wanita/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_3_7">
                <a href="//www.lazada.co.id/beli-perhiasan-wanita/">
                    <span>Perhiasan Wanita</span>
                </a>
                        <script type="text" class="J_data_2_6">
                            [{"childCategoryName":"Perhiasan Fashion","childCategoryUrl":"//www.lazada.co.id/beli-wanita-perhiasan-fashion/"},{"childCategoryName":"Logam Berharga","childCategoryUrl":"//www.lazada.co.id/beli-wanita-logam-berharga/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_3_8">
                <a href="//www.lazada.co.id/beli-jam-tangan-wanita/">
                    <span>Jam Tangan Wanita</span>
                </a>
                        <script type="text" class="J_data_2_7">
                            [{"childCategoryName":"Aksesori","childCategoryUrl":"//www.lazada.co.id/shop-aksesori-jam-tangan-wanita/"},{"childCategoryName":"Jam Tangan Kasual Wanita","childCategoryUrl":"//www.lazada.co.id/beli-jam-tangan-kasual-wanita/"},{"childCategoryName":"Formal","childCategoryUrl":"//www.lazada.co.id/beli-jam-tangan-formal-wanita/"},{"childCategoryName":"Mewah","childCategoryUrl":"//www.lazada.co.id/shop-jam-tangan-mewah-wanita/"},{"childCategoryName":"Pra Dimiliki","childCategoryUrl":"//www.lazada.co.id/shop-pre-owned-jam-tangan-wanita/"},{"childCategoryName":"Jam Tangan Olahraga Wanita","childCategoryUrl":"//www.lazada.co.id/beli-jam-tangan-olahraga-wanita/"}]
                        </script>
            </li>
        </ul>
        <ul class="lzd-site-menu-sub Level_1_Category_No4" data-spm="cate_4">
            <li class="lzd-site-menu-sub-item" data-cate="cate_4_1">
                <a href="//www.lazada.co.id/pakaian-pria/">
                    <span>Pakaian Pria</span>
                </a>
                        <script type="text" class="J_data_3_0">
                            [{"childCategoryName":"Hoodie & Sweatshirt","childCategoryUrl":"//www.lazada.co.id/jual-hoodie-pria/"},{"childCategoryName":"Jaket dan Mantel","childCategoryUrl":"//www.lazada.co.id/jaket-dan-mantel-pria/"},{"childCategoryName":"Jeans","childCategoryUrl":"//www.lazada.co.id/jeans-pria/"},{"childCategoryName":"Celana","childCategoryUrl":"//www.lazada.co.id/celana-pendek-dan-panjang-pria/"},{"childCategoryName":"Polo Shirt","childCategoryUrl":"//www.lazada.co.id/polo-shirt-pria/"},{"childCategoryName":"Kemeja","childCategoryUrl":"//www.lazada.co.id/kemeja-pria/"},{"childCategoryName":"Celana Pendek","childCategoryUrl":"//www.lazada.co.id/jual-celana-pendek-pria/"},{"childCategoryName":"Kaus Kaki","childCategoryUrl":"//www.lazada.co.id/jual-kaus-kaki-pria/"},{"childCategoryName":"Jas & Blazer","childCategoryUrl":"//www.lazada.co.id/jas-pria/"},{"childCategoryName":"Sweater dan Kardigan","childCategoryUrl":"//www.lazada.co.id/sweater-dan-cardigan-pria/"},{"childCategoryName":"Baju Renang","childCategoryUrl":"//www.lazada.co.id/baju-renang-pria/"},{"childCategoryName":"T-Shirt & Kaos Dalam","childCategoryUrl":"//www.lazada.co.id/atasan-kasual-kaos-pria/"}]</script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_4_2">
                <a href="//www.lazada.co.id/baju-muslim-pria/">
                    <span>Baju Muslim</span>
                </a>
                        <script type="text" class="J_data_3_1">
                            [{"childCategoryName":"Jubah Muslim","childCategoryUrl":"//www.lazada.co.id/jubah-muslim-pria/"},{"childCategoryName":"Aksesoris Muslim","childCategoryUrl":"//www.lazada.co.id/aksesoris-muslim-pria/"},{"childCategoryName":"Baju Muslimin","childCategoryUrl":"//www.lazada.co.id/cekak-musang-pria/"},{"childCategoryName":"Kopiah","childCategoryUrl":"//www.lazada.co.id/shop-kopiah/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_4_3">
                <a href="//www.lazada.co.id/pakaian-dalam-dan-kaos-kaki-pria/">
                    <span>Pakaian Dalam</span>
                </a>
                        <script type="text" class="J_data_3_2">
                            [{"childCategoryName":"Celana Dalam","childCategoryUrl":"//www.lazada.co.id/celana-dalam-pria/"},{"childCategoryName":"Pakaian Tidur","childCategoryUrl":"//www.lazada.co.id/baju-tidur-pria/"},{"childCategoryName":"Boxer","childCategoryUrl":"//www.lazada.co.id/pakaian-dalam-boxer-pria/"},{"childCategoryName":"Thongs  & Lainnya","childCategoryUrl":"//www.lazada.co.id/pakaian-dalam-pria-thongs-lainnya/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_4_4">
                <a href="//www.lazada.co.id/sepatu-pria/">
                    <span>Sepatu Pria</span>
                </a>
                        <script type="text" class="J_data_3_3">
                            [{"childCategoryName":"Boots","childCategoryUrl":"//www.lazada.co.id/boots-pria/"},{"childCategoryName":"Flip Flop & Sandal","childCategoryUrl":"//www.lazada.co.id/sandal-jepit-pria/"},{"childCategoryName":"Sepatu Formal","childCategoryUrl":"//www.lazada.co.id/sepatu-pantofel/"},{"childCategoryName":"Aksesoris Sepatu","childCategoryUrl":"//www.lazada.co.id/aksesoris-sepatu-pria/"},{"childCategoryName":"Slip-On & Loafer","childCategoryUrl":"//www.lazada.co.id/jual-slip-on-loafer-pria/"},{"childCategoryName":"Sneakers","childCategoryUrl":"//www.lazada.co.id/sneakers-pria/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_4_5">
                <a href="//www.lazada.co.id/aksesoris-pria/">
                    <span>Aksesoris</span>
                </a>
                        <script type="text" class="J_data_3_4">
                            [{"childCategoryName":"Dasi","childCategoryUrl":"//www.lazada.co.id/aksesoris-dasi/"},{"childCategoryName":"Aksesoris Dasi Kupu-kupu","childCategoryUrl":"//www.lazada.co.id/aksesoris-dasi-kupu-kupu/"},{"childCategoryName":"Scarf","childCategoryUrl":"//www.lazada.co.id/syal-pria/"},{"childCategoryName":"Payung","childCategoryUrl":"//www.lazada.co.id/payung-pria/"},{"childCategoryName":"Ikat Pinggang","childCategoryUrl":"//www.lazada.co.id/ikat-pinggang-pria/"},{"childCategoryName":"Topi","childCategoryUrl":"//www.lazada.co.id/topi-pria/"},{"childCategoryName":"Sarung Tangan","childCategoryUrl":"//www.lazada.co.id/sarung-tangan-pria/"},{"childCategoryName":"Braces","childCategoryUrl":"//www.lazada.co.id/suspender-pria/"},{"childCategoryName":"Face Mask","childCategoryUrl":"//www.lazada.co.id/shop-masker-wajah-pria/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_4_6">
                <a href="//www.lazada.co.id/tas-pria/">
                    <span>Tas Pria</span>
                </a>
                        <script type="text" class="J_data_3_5">
                            [{"childCategoryName":"Tas Ransel Pria","childCategoryUrl":"//www.lazada.co.id/shop-ransel-pria/"},{"childCategoryName":"Tas Laptop Jinjing","childCategoryUrl":"//www.lazada.co.id/tas-kerja-pria/"},{"childCategoryName":"Dompet Kartu Pria","childCategoryUrl":"//www.lazada.co.id/jual-dompet-kartu-pria/"},{"childCategoryName":"Dompet Koin & Pouch Pria","childCategoryUrl":"//www.lazada.co.id/jual-dompet-koin-pouch-pria/"},{"childCategoryName":"Tas Selempang Pria","childCategoryUrl":"//www.lazada.co.id/jual-tas-selempang-pria/"},{"childCategoryName":"Tas Laptop Bahu & Messenger","childCategoryUrl":"//www.lazada.co.id/tas-messenger-pria/"},{"childCategoryName":"Tote Bag Pria","childCategoryUrl":"//www.lazada.co.id/jual-tas-tote-pria/"},{"childCategoryName":"Tas Pinggang","childCategoryUrl":"//www.lazada.co.id/beli-tas-pinggang/"},{"childCategoryName":"Dompet Pria","childCategoryUrl":"//www.lazada.co.id/shop-dompet-pria/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_4_7">
                <a href="//www.lazada.co.id/beli-perhiasan-pria/">
                    <span>Perhiasan Pria</span>
                </a>
                        <script type="text" class="J_data_3_6">
                            [{"childCategoryName":"Perhiasan Fashion","childCategoryUrl":"//www.lazada.co.id/beli-pria-perhiasan-fashion/"},{"childCategoryName":"Logam Berharga","childCategoryUrl":"//www.lazada.co.id/beli-pria-logam-berharga/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_4_8">
                <a href="//www.lazada.co.id/beli-jam-tangan-pria/">
                    <span>Jam Tangan Pria</span>
                </a>
                        <script type="text" class="J_data_3_7">
                            [{"childCategoryName":"Aksesoris Jam Tangan Pria","childCategoryUrl":"//www.lazada.co.id/beli-aksesoris-jam-tangan-pria/"},{"childCategoryName":"Jam Tangan Kasual Pria","childCategoryUrl":"//www.lazada.co.id/beli-jam-tangan-kasual-pria/"},{"childCategoryName":"Formal","childCategoryUrl":"//www.lazada.co.id/beli-jam-tangan-formal-pria/"},{"childCategoryName":"Mewah","childCategoryUrl":"//www.lazada.co.id/shop-jam-tangan-mewah-pria/"},{"childCategoryName":"Pra Dimiliki","childCategoryUrl":"//www.lazada.co.id/shop-jam-tangan-pre-owned-pria/"},{"childCategoryName":"Jam Tangan Olahraga Pria","childCategoryUrl":"//www.lazada.co.id/beli-jam-tangan-olahraga-pria/"}]
                        </script>
            </li>
        </ul>
        <ul class="lzd-site-menu-sub Level_1_Category_No5" data-spm="cate_5">
            <li class="lzd-site-menu-sub-item" data-cate="cate_5_1">
                <a href="//www.lazada.co.id/fashion-pakaian-anak-laki-laki">
                    <span>Pakaian Anak Laki-laki</span>
                </a>
                        <script type="text" class="J_data_4_0">
                            [{"childCategoryName":"Topi Anak Laki-laki","childCategoryUrl":"//www.lazada.co.id/topi-anak-laki-laki"},{"childCategoryName":"Hoodie Anak Laki-laki","childCategoryUrl":"//www.lazada.co.id/jual-hoodie-anak-laki-laki"},{"childCategoryName":"Jaket & Mantel Anak Laki-laki","childCategoryUrl":"//www.lazada.co.id/jaket-mantel-anak-laki-laki"},{"childCategoryName":"Celana Pendek Anak Laki-laki","childCategoryUrl":"//www.lazada.co.id/beli-celana-pendek-pria"},{"childCategoryName":"Pakaian Tidur Anak Laki-laki","childCategoryUrl":"//www.lazada.co.id/pakaian-tidur-anak-laki-laki"},{"childCategoryName":"Sweater & Cardigan Anak","childCategoryUrl":"//www.lazada.co.id/sweater-cardigan-anak-laki-laki"},{"childCategoryName":"Payung & Pakaian Hujan Anak","childCategoryUrl":"//www.lazada.co.id/payung-pakaian-hujan-anak-laki-laki"},{"childCategoryName":"Pakaian dalam","childCategoryUrl":"//www.lazada.co.id/shop-pakaian-dalam"},{"childCategoryName":"Celana & Jeans Anak Laki-laki","childCategoryUrl":"//www.lazada.co.id/celana-jeans-anak-laki-laki"},{"childCategoryName":"Kaus Kaki","childCategoryUrl":"//www.lazada.co.id/shop-kaus-kaki"},{"childCategoryName":"Baju & Atasan Anak Laki-laki","childCategoryUrl":"//www.lazada.co.id/baju-atasan-anak-laki-laki"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_5_2">
                <a href="//www.lazada.co.id/pakaian-anak-perempuan">
                    <span>Pakaian Anak Perempuan</span>
                </a>
                        <script type="text" class="J_data_4_1">
                            [{"childCategoryName":"Bawahan Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/celana-jeans-anak-perempuan"},{"childCategoryName":"Dress Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/fashion-dress-anak-perempuan"},{"childCategoryName":"Scarf Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/scarf-sarung-tangan-anak-perempuan"},{"childCategoryName":"Aksesori Rambut Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/jual-aksesori-rambut-anak-perempuan"},{"childCategoryName":"Topi Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/topi-anak-perempuan"},{"childCategoryName":"Hoodie Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/jual-hoodie-anak-laki-laki-2"},{"childCategoryName":"Jaket & Mantel Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/jaket-mantel-anak-perempuan"},{"childCategoryName":"Baju & Atasan Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/baju-atasan-anak-perempuan"},{"childCategoryName":"Payung & Pakaian Hujan Anak","childCategoryUrl":"//www.lazada.co.id/payung-jas-hujan-anak-perempuan"},{"childCategoryName":"Pakaian Dalam Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/pakaian-tidur-anak-perempuan"},{"childCategoryName":"Jumpsuits & Overalls","childCategoryUrl":"//www.lazada.co.id/shop-girls-jumpsuits-overalls"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_5_3">
                <a href="//www.lazada.co.id/shop-boy's-muslim-wear">
                    <span>Pakaian Anak Muslim Laki-Laki</span>
                </a>
                        <script type="text" class="J_data_4_2">
                            [{"childCategoryName":"Kemeja Anak Laki-Laki","childCategoryUrl":"//www.lazada.co.id/shop-boy's-muslimin-shirt"},{"childCategoryName":"Celana Anak Laki-Laki","childCategoryUrl":"//www.lazada.co.id/shop-boy's-muslimin-pants"},{"childCategoryName":"Aksesoris Anak Laki-Laki","childCategoryUrl":"//www.lazada.co.id/shop-boy's-muslimin-accessories"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_5_4">
                <a href="//www.lazada.co.id/shop-girls-muslim-wear">
                    <span>Pakaian Anak Muslim Perempuan</span>
                </a>
                        <script type="text" class="J_data_4_3">
                            [{"childCategoryName":"Hijab Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/shop-girls-muslim-wear-hijabs/"},{"childCategoryName":"Dress Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/shop-girls-muslim-wear-dresses-jumpsuits/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_5_5">
                <a href="//www.lazada.co.id/fashion-sepatu-anak-laki-laki">
                    <span>Sepatu Anak Laki-laki</span>
                </a>
                        <script type="text" class="J_data_4_4">
                            [{"childCategoryName":"Sepatu Boot Anak Laki-laki","childCategoryUrl":"//www.lazada.co.id/sepatu-boot-anak-laki-laki"},{"childCategoryName":"Sandal Anak Laki-laki","childCategoryUrl":"//www.lazada.co.id/fashion-sandal-jepit-anak-laki-laki"},{"childCategoryName":"Sepatu Formal Anak Laki-laki","childCategoryUrl":"//www.lazada.co.id/sepatu-lace-ups-anak-laki-laki"},{"childCategoryName":"Aksesoris Sepatu Anak Laki","childCategoryUrl":"//www.lazada.co.id/fashion-aksesoris-sepatu-anak-laki-laki"},{"childCategoryName":"Slip-n Anak Laki-laki","childCategoryUrl":"//www.lazada.co.id/sepatu-slip-on-anak-laki-laki"},{"childCategoryName":"Sepatu Sneaker Anak Laki-laki","childCategoryUrl":"//www.lazada.co.id/sepatu-sneaker-anak-laki-laki"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_5_6">
                <a href="//www.lazada.co.id/fashion-sepatu-anak-perempuan">
                    <span>Sepatu Anak Perempuan</span>
                </a>
                        <script type="text" class="J_data_4_5">
                            [{"childCategoryName":"Sepatu Flat Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/sepatu-balerina-anak-perempuan"},{"childCategoryName":"Sepatu Boot Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/sepatu-boot-anak-perempuan"},{"childCategoryName":"Sandal Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/fashion-sandal-jepit-anak-perempuan"},{"childCategoryName":"Sepatu Formal Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/sepatu-lace-ups-anak-perempuan"},{"childCategoryName":"Aksesoris Sepatu Anak","childCategoryUrl":"//www.lazada.co.id/fashion-aksesoris-sepatu-anak-perempuan"},{"childCategoryName":"Sepatu Sneaker Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/sepatu-sneakers-anak-perempuan"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_5_7">
                <a href="//www.lazada.co.id/beli-tas-anak-tl/">
                    <span>Tas Anak</span>
                </a>
                        <script type="text" class="J_data_4_6">
                            [{"childCategoryName":"Tas Bahu Anak","childCategoryUrl":"//www.lazada.co.id/beli-tas-bahu-anak/"},{"childCategoryName":"Ransel Troli Anak","childCategoryUrl":"//www.lazada.co.id/beli-ransel-troli-anak/"},{"childCategoryName":"Ransel Anak","childCategoryUrl":"//www.lazada.co.id/beli-ransel-anak/"},{"childCategoryName":"Aksesoris Tas","childCategoryUrl":"//www.lazada.co.id/beli-aksesoris-anak/"},{"childCategoryName":"Koper","childCategoryUrl":"//www.lazada.co.id/koper-anak-2/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_5_8">
                <a href="//www.lazada.co.id/beli-perhiasan-anak/">
                    <span>Perhiasan Anak</span>
                </a>
                        <script type="text" class="J_data_4_7">
                            [{"childCategoryName":"Emas Murni","childCategoryUrl":"//www.lazada.co.id/beli-anak-emas-murni/"},{"childCategoryName":"Perhiasan Fashion","childCategoryUrl":"//www.lazada.co.id/beli-anak-perhiasan-fashion/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_5_9">
                <a href="//www.lazada.co.id/beli-jam-tangan-anak/">
                    <span>Jam Tangan Anak</span>
                </a>
                        <script type="text" class="J_data_4_8">
                            [{"childCategoryName":"Jam Tangan Anak Laki-Laki","childCategoryUrl":"//www.lazada.co.id/beli-jam-tangan-anak-laki-laki/"},{"childCategoryName":"Jam Tangan Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/beli-jam-tangan-anak-perempuan/"}]
                        </script>
            </li>
        </ul>
        <ul class="lzd-site-menu-sub Level_1_Category_No6" data-spm="cate_6">
            <li class="lzd-site-menu-sub-item" data-cate="cate_6_1">
                <a href="//www.lazada.co.id/beli-perawatan-kulit/">
                    <span>Perawatan Kulit</span>
                </a>
                        <script type="text" class="J_data_5_0">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Serum Perawatan Wajah","childCategoryUrl":"//www.lazada.co.id/beli-serum-perawatan-wajah"},{"childCategoryName":"Dermacare","childCategoryUrl":"//www.lazada.co.id/beli-dermacare"},{"childCategoryName":"Pelembab Wajah","childCategoryUrl":"//www.lazada.co.id/shop-pelembab-wajah"},{"childCategoryName":"Pembersih Wajah","childCategoryUrl":"//www.lazada.co.id/pembersih-wajah"},{"childCategoryName":"Masker Wajah","childCategoryUrl":"//www.lazada.co.id/beli-masker-wajah"},{"childCategoryName":"Toner","childCategoryUrl":"//www.lazada.co.id/beli-toner"},{"childCategoryName":"Tabir Surya","childCategoryUrl":"//www.lazada.co.id/beli-tabir-surya-aftersun"},{"childCategoryName":"Set Perawatan Wajah","childCategoryUrl":"//www.lazada.co.id/beli-set-perawatan-wajah"},{"childCategoryName":"Pelembab & Perawatan Bibir","childCategoryUrl":"//www.lazada.co.id/beli-lip-balm-perawatan-bibir"},{"childCategoryName":"Face Scrubs & Exfoliators","childCategoryUrl":"//www.lazada.co.id/beli-scrub-pengelupas-wajah"},{"childCategoryName":"Perawatan Mata","childCategoryUrl":"//www.lazada.co.id/shop-perawatan-mata"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_6_2">
                <a href="//www.lazada.co.id/beli-makeup/">
                    <span>Makeup</span>
                </a>
                        <script type="text" class="J_data_5_1">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Makeup Bibir","childCategoryUrl":"//www.lazada.co.id/beli-make-up-bibir"},{"childCategoryName":"Lipstik","childCategoryUrl":"//www.lazada.co.id/beli-lipstik"},{"childCategoryName":"Makeup Wajah","childCategoryUrl":"//www.lazada.co.id/makeup-wajah"},{"childCategoryName":"Foundation","childCategoryUrl":"//www.lazada.co.id/beli-foundation"},{"childCategoryName":"Makeup Mata","childCategoryUrl":"//www.lazada.co.id/beli-mata"},{"childCategoryName":"Maskara","childCategoryUrl":"//www.lazada.co.id/beli-maskara"},{"childCategoryName":"Aksesoris Makeup","childCategoryUrl":"//www.lazada.co.id/beli-aksesoris-makeup"},{"childCategoryName":"Set Kuas & Kuas Makeup","childCategoryUrl":"//www.lazada.co.id/beli-kuas-aplikator"},{"childCategoryName":"Perawatan Kuku","childCategoryUrl":"//www.lazada.co.id/beli-perawatan-kuku"},{"childCategoryName":"Set Makeup & Palet","childCategoryUrl":"//www.lazada.co.id/shop-palet-set-makeup"},{"childCategoryName":"Pembersih Makeup","childCategoryUrl":"//www.lazada.co.id/beli-pembersih-makeup"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_6_3">
                <a href="//www.lazada.co.id/beli-perawatan-rambut/">
                    <span>Perawatan Rambut</span>
                </a>
                        <script type="text" class="J_data_5_2">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Shampo","childCategoryUrl":"//www.lazada.co.id/beli-sampo"},{"childCategoryName":"Perawatan Rambut","childCategoryUrl":"//www.lazada.co.id/perawatan-intensif"},{"childCategoryName":"Aksesoris Rambut","childCategoryUrl":"//www.lazada.co.id/aksesoris-perawatan-rambut"},{"childCategoryName":"Styling Rambut","childCategoryUrl":"//www.lazada.co.id/beli-styling-rambut"},{"childCategoryName":"Pewarna Rambut","childCategoryUrl":"//www.lazada.co.id/beli-cat-rambut"},{"childCategoryName":"Kondisioner","childCategoryUrl":"//www.lazada.co.id/beli-kondisioner"},{"childCategoryName":"Paket Hadiah","childCategoryUrl":"//www.lazada.co.id/beli-paket-hadiah-bingkisan-perawatan-rambut"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_6_4">
                <a href="//www.lazada.co.id/beli-perlengkapan-mandi-tubuh/">
                    <span>Perawatan Tubuh</span>
                </a>
                        <script type="text" class="J_data_5_3">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Losion Tubuh","childCategoryUrl":"//www.lazada.co.id/beli-losion-krim-tubuh"},{"childCategoryName":"Sabun Cair","childCategoryUrl":"//www.lazada.co.id/shop-Sabun-Cair"},{"childCategoryName":"Scrub Tubuh","childCategoryUrl":"//www.lazada.co.id/beli-scrub-tubuh"},{"childCategoryName":"Perawatan Payudara","childCategoryUrl":"//www.lazada.co.id/perawatan-payudara"},{"childCategoryName":"Perawatan Tubuh","childCategoryUrl":"//www.lazada.co.id/shop-Perawatan-Tubuh"},{"childCategoryName":"Perawatan Kaki","childCategoryUrl":"//www.lazada.co.id/beli-perawatan-kaki"},{"childCategoryName":"Sabun Batang","childCategoryUrl":"//www.lazada.co.id/shop-Sabun-Batang"},{"childCategoryName":"Aksesoris Tubuh","childCategoryUrl":"//www.lazada.co.id/beli-aksesoris-perlengkapan-mandi-tubuh"},{"childCategoryName":"Paket Hadiah","childCategoryUrl":"//www.lazada.co.id/beli-paket-hadiah-bingkisan-alat-mandi-tubuh"},{"childCategoryName":"Penghilang Bulu","childCategoryUrl":"//www.lazada.co.id/beli-perontok-rambut"},{"childCategoryName":"Sabun Tangan","childCategoryUrl":"//www.lazada.co.id/beli-sabun-pembersih-tangan"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_6_5">
                <a href="//www.lazada.co.id/beli-perawatan-kesehatan-pribadi/">
                    <span>Perawatan Diri</span>
                </a>
                        <script type="text" class="J_data_5_4">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Perawatan Mulut","childCategoryUrl":"//www.lazada.co.id/perawatan-mulut"},{"childCategoryName":"Pembersih Wanita","childCategoryUrl":"//www.lazada.co.id/beli-pembersih-wanita"},{"childCategoryName":"Keamanan Diri","childCategoryUrl":"//www.lazada.co.id/beli-keamanan-diri"},{"childCategoryName":"Beli Deodoran","childCategoryUrl":"//www.lazada.co.id/beli-deodoran"},{"childCategoryName":"Perawatan Mata","childCategoryUrl":"//www.lazada.co.id/shop-perawatan-optik-pribadi"},{"childCategoryName":"Obat Anti Serangga","childCategoryUrl":"//www.lazada.co.id/shop-Obat-Anti-Serangga"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_6_6">
                <a href="//www.lazada.co.id/beli-parfum/">
                    <span>Parfum</span>
                </a>
                        <script type="text" class="J_data_5_5">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Pria","childCategoryUrl":"//www.lazada.co.id/beli-parfum-pria"},{"childCategoryName":"Wanita","childCategoryUrl":"//www.lazada.co.id/beli-parfum-wanita"},{"childCategoryName":"Unisex","childCategoryUrl":"//www.lazada.co.id/beli-parfum-unisex"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_6_7">
                <a href="//www.lazada.co.id/beli-alat-kesehatan-kecantikan/">
                    <span>Alat Kecantikan</span>
                </a>
                        <script type="text" class="J_data_5_6">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Alat Pelangsing & Pijat","childCategoryUrl":"//www.lazada.co.id/alat-pelangsing-dan-pemijat-elektrik"},{"childCategoryName":"Sauna Portabel","childCategoryUrl":"//www.lazada.co.id/beli-sauna-portabel"},{"childCategoryName":"Foot Relief","childCategoryUrl":"//www.lazada.co.id/beli-foot-relief"},{"childCategoryName":"Alat Cukur & Trimmer","childCategoryUrl":"//www.lazada.co.id/aksesoris-alat-cukur-dan-trimmer"},{"childCategoryName":"Alat Perawatan Wajah","childCategoryUrl":"//www.lazada.co.id/shop-alat-perawatan-kulit-wajah"},{"childCategoryName":"Alat Perawatan Tubuh","childCategoryUrl":"//www.lazada.co.id/shop-alat-perawatan-kulit-tubuh"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_6_8">
                <a href="//www.lazada.co.id/beli-suplemen-makanan/">
                    <span>Suplemen Makanan</span>
                </a>
                        <script type="text" class="J_data_5_7">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Pengatur Berat Badan","childCategoryUrl":"//www.lazada.co.id/beli-pengatur-berat-badan"},{"childCategoryName":"Pembakar Lemak","childCategoryUrl":"//www.lazada.co.id/beli-pembakar-lemak"},{"childCategoryName":"Minuman Pelangsing","childCategoryUrl":"//www.lazada.co.id/beli-minuman-pelangsing"},{"childCategoryName":"Suplemen Kecantikan","childCategoryUrl":"//www.lazada.co.id/beli-suplemen-kecantikan"},{"childCategoryName":"Suplemen Pemutih","childCategoryUrl":"//www.lazada.co.id/beli-suplemen-pemutih"},{"childCategoryName":"Multivitamin","childCategoryUrl":"//www.lazada.co.id/multivitamin/"},{"childCategoryName":"Obat Tradisional","childCategoryUrl":"//www.lazada.co.id/beli-obat-obatan-tradisional"},{"childCategoryName":"Sistem Imun","childCategoryUrl":"//www.lazada.co.id/beli-sistem-imun"},{"childCategoryName":"Nutrisi Olahraga","childCategoryUrl":"//www.lazada.co.id/beli-nutrisi-olahraga"},{"childCategoryName":"Penambah Berat Badan","childCategoryUrl":"//www.lazada.co.id/beli-suplemen-penambah-berat-badan"},{"childCategoryName":"Protein","childCategoryUrl":"//www.lazada.co.id/beli-protein"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_6_9">
                <a href="//www.lazada.co.id/beli-alat-medis/">
                    <span>Alat Medis</span>
                </a>
                        <script type="text" class="J_data_5_8">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Aksesoris Kesehatan","childCategoryUrl":"//www.lazada.co.id/aksesoris-kesehatan"},{"childCategoryName":"Alat Tes Kesehatan","childCategoryUrl":"//www.lazada.co.id/beli-alat-tes-kesehatan"},{"childCategoryName":"Obat-Obatan","childCategoryUrl":"//www.lazada.co.id/shop-over-the-counter-medicine/"},{"childCategoryName":"Perban & Perlengkapan Cedera","childCategoryUrl":"//www.lazada.co.id/perban-alat-terapi-cedera"},{"childCategoryName":"Timbangan & Alat Kadar Lemak","childCategoryUrl":"//www.lazada.co.id/beli-timbangan-alat-ukur-kadar-lemak"},{"childCategoryName":"P3K","childCategoryUrl":"//www.lazada.co.id/beli-p3k"},{"childCategoryName":"Kursi Roda","childCategoryUrl":"//www.lazada.co.id/beli-kursi-roda"},{"childCategoryName":"Salep & Krim","childCategoryUrl":"//www.lazada.co.id/shop-salep-dan-krim"},{"childCategoryName":"Alat Inhalasi & Nebulizer","childCategoryUrl":"//www.lazada.co.id/beli-alat-inhalasi-nebulizer"},{"childCategoryName":"Alat Tes Medis","childCategoryUrl":"//www.lazada.co.id/tes-medis"},{"childCategoryName":"Stetoskop","childCategoryUrl":"//www.lazada.co.id/beli-stetoskop"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_6_10">
                <a href="//www.lazada.co.id/jual-perlengkapan-kesehatan-seksual/">
                    <span>Sexual Wellness</span>
                </a>
                        <script type="text" class="J_data_5_9">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Kondom","childCategoryUrl":"//www.lazada.co.id/beli-kondom"},{"childCategoryName":"Pelumas","childCategoryUrl":"//www.lazada.co.id/beli-pelumas"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_6_11">
                <a href="//www.lazada.co.id/beli-perawatan-tubuh-kesehatan-pria/">
                    <span>Perawatan Pria</span>
                </a>
                        <script type="text" class="J_data_5_10">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Perawatan Rambut","childCategoryUrl":"//www.lazada.co.id/beli-perawatan-rambut-pria"},{"childCategoryName":"Perawatan Wajah","childCategoryUrl":"//www.lazada.co.id/beli-perawatan-kulit-pria"},{"childCategoryName":"Alat Cukur Pria","childCategoryUrl":"//www.lazada.co.id/beli-alat-cukur-pria"},{"childCategoryName":"Perawatan Tubuh","childCategoryUrl":"//www.lazada.co.id/perawatan-tubuh"},{"childCategoryName":"Deodoran Pria","childCategoryUrl":"//www.lazada.co.id/beli-deodoran-pria"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_6_12">
                <a href="//www.lazada.co.id/kesehatan-manula/">
                    <span>Popok Dewasa</span>
                </a>
                        <script type="text" class="J_data_5_11">
                            [{"childCategoryName":"Popok Dewasa","childCategoryUrl":"//www.lazada.co.id/kesehatan-manula/"}]
                        </script>
            </li>
        </ul>
        <ul class="lzd-site-menu-sub Level_1_Category_No7" data-spm="cate_7">
            <li class="lzd-site-menu-sub-item" data-cate="cate_7_1">
                <a href="//www.lazada.co.id/jual-perlengkapan-bayi-balita/">
                    <span>Ibu &amp; Anak</span>
                </a>
                        <script type="text" class="J_data_6_0">
                            [{"childCategoryName":"Popok Sekali Pakai","childCategoryUrl":"//www.lazada.co.id/beli-popok-sekali-pakai/"},{"childCategoryName":"Bayi (0 - 6 bulan)","childCategoryUrl":"//www.lazada.co.id/beli-susu-bayi-0-6-bulan/"},{"childCategoryName":"Bayi (6 - 12 bulan)","childCategoryUrl":"//www.lazada.co.id/beli-susu-bayi-6-12-bulan/"},{"childCategoryName":"Susu Batita (1- dibawah 3 tahun)","childCategoryUrl":"//www.lazada.co.id/jual-susu-batita-1-3-tahun/"},{"childCategoryName":"Susu Pertumbuhan (>3Tahun)","childCategoryUrl":"//www.lazada.co.id/beli-susu-pertumbuhan-1-3-tahun/"},{"childCategoryName":"Pakaian Bayi Perempuan","childCategoryUrl":"//www.lazada.co.id/beli-pakaian-bayi-perempuan/"},{"childCategoryName":"Pakaian Bayi Laki-Laki","childCategoryUrl":"//www.lazada.co.id/beli-pakaian-bayi-laki-laki/"},{"childCategoryName":"Botol Bayi","childCategoryUrl":"//www.lazada.co.id/beli-botol-bayi/"},{"childCategoryName":"Stroller","childCategoryUrl":"//www.lazada.co.id/beli-kereta-dorong-bayi/"},{"childCategoryName":"Soft Carrier","childCategoryUrl":"//www.lazada.co.id/beli-soft-carrier/"},{"childCategoryName":"Sampo & Kondisioner","childCategoryUrl":"//www.lazada.co.id/beli-sampo-kondisioner-bb/"},{"childCategoryName":"Perawatan Kulit Bayi","childCategoryUrl":"//www.lazada.co.id/beli-perawatan-kulit-pria/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_7_2">
                <a href="//www.lazada.co.id/beli-popok-pispot-bb/">
                    <span>Popok Sekali Pakai</span>
                </a>
                        <script type="text" class="J_data_6_1">
                            [{"childCategoryName":"Popok Sekali Pakai","childCategoryUrl":"//www.lazada.co.id/beli-popok-sekali-pakai/"},{"childCategoryName":"Popok Kain & Aksesori","childCategoryUrl":"//www.lazada.co.id/beli-popok-kain/"},{"childCategoryName":"Lap Bayi & Penyangga","childCategoryUrl":"//www.lazada.co.id/beli-lap-bayi-penyangga/"},{"childCategoryName":"Perawatan Popok","childCategoryUrl":"//www.lazada.co.id/beli-perawatan-popok/"},{"childCategoryName":"Krim & Salep Bayi","childCategoryUrl":"//www.lazada.co.id/beli-krim-salep-bayi/"},{"childCategoryName":"Tas Perlengkapan Popok","childCategoryUrl":"//www.lazada.co.id/beli-tas-popok-tb/"},{"childCategoryName":"Meja Ganti Popok","childCategoryUrl":"//www.lazada.co.id/beli-meja-ganti/"},{"childCategoryName":"Cover Popok Kain","childCategoryUrl":"//www.lazada.co.id/beli-bantalan/"},{"childCategoryName":"Lapisan Penyerap & Liner Popok Kain","childCategoryUrl":"//www.lazada.co.id/beli-lapisan-penyerap-liner-popok-kain/"},{"childCategoryName":"Potty Training","childCategoryUrl":"//www.lazada.co.id/beli-potty-training/"},{"childCategoryName":"Bangku Langkah","childCategoryUrl":"//www.lazada.co.id/beli-bangku-langkah/"},{"childCategoryName":"Detergent Laundry","childCategoryUrl":"//www.lazada.co.id/beli-detergen-popok-kain/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_7_3">
                <a href="//www.lazada.co.id/beli-susu-formula/">
                    <span>Makanan Bayi &amp; Balita</span>
                </a>
                        <script type="text" class="J_data_6_2">
                            [{"childCategoryName":"Bayi (0 - 6 bulan)","childCategoryUrl":"//www.lazada.co.id/beli-susu-bayi-0-6-bulan/"},{"childCategoryName":"Bayi (6 - 12 bulan)","childCategoryUrl":"//www.lazada.co.id/beli-susu-bayi-6-12-bulan/"},{"childCategoryName":"Susu Batita (1- dibawah 3 tahun)","childCategoryUrl":"//www.lazada.co.id/jual-susu-batita-1-3-tahun/"},{"childCategoryName":"Susu Pertumbuhan (>3Tahun)","childCategoryUrl":"//www.lazada.co.id/beli-susu-pertumbuhan-1-3-tahun/"},{"childCategoryName":"Nutrisi Khusus Anak","childCategoryUrl":"//www.lazada.co.id/beli-nutrisi-khusus-anak/"},{"childCategoryName":"Minuman","childCategoryUrl":"//www.lazada.co.id/beli-minuman-bayi-balita/"},{"childCategoryName":"Sereal","childCategoryUrl":"//www.lazada.co.id/beli-sereal-bayi-balita/"},{"childCategoryName":"Cracker & blackjepe","childCategoryUrl":"//www.lazada.co.id/beli-cracker-blackjepe-bayi-balita/"},{"childCategoryName":"Makanan Ringan","childCategoryUrl":"//www.lazada.co.id/beli-makanan-ringan-bayi-balita/"},{"childCategoryName":"Makanan puree bayi","childCategoryUrl":"//www.lazada.co.id/beli-puree-bayi/"},{"childCategoryName":"Susu Ibu Hamil","childCategoryUrl":"//www.lazada.co.id/beli-susu-maternal/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_7_4">
                <a href="//www.lazada.co.id/jual-baju-aksesoris-anak/">
                    <span>Pakaian &amp; Aksesoris</span>
                </a>
                        <script type="text" class="J_data_6_3">
                            [{"childCategoryName":"(0--6 bulan) Set Pakaian","childCategoryUrl":"//www.lazada.co.id/beli-set-pakaian-bayi/"},{"childCategoryName":"(0--6 bulan) Body Suits","childCategoryUrl":"//www.lazada.co.id/beli-bodysuit-one-piece-bayi/"},{"childCategoryName":"(0--6 bulan) Aksesoris","childCategoryUrl":"//www.lazada.co.id/beli-aksesoris-pakaian-anak/"},{"childCategoryName":"Pakaian Bayi Perempuan","childCategoryUrl":"//www.lazada.co.id/beli-pakaian-bayi-perempuan/"},{"childCategoryName":"Dress Bayi Perempuan","childCategoryUrl":"//www.lazada.co.id/beli-dress-bayi-perempuan/"},{"childCategoryName":"Sepatu Bayi Perempuan","childCategoryUrl":"//www.lazada.co.id/beli-sepatu-bayi-perempuan/"},{"childCategoryName":"Aksesoris Bayi Perempuan","childCategoryUrl":"//www.lazada.co.id/beli-aksesoris-bayi-perempuan/"},{"childCategoryName":"Baju Renang Bayi Perempuan","childCategoryUrl":"//www.lazada.co.id/beli-baju-renang-bayi-perempuan/"},{"childCategoryName":"Pakaian Bayi Laki-Laki","childCategoryUrl":"//www.lazada.co.id/beli-pakaian-bayi-laki-laki/"},{"childCategoryName":"Sepatu Bayi Laki-Laki","childCategoryUrl":"//www.lazada.co.id/beli-sepatu-bayi-laki-laki/"},{"childCategoryName":"Aksesoris Bayi Laki-Laki","childCategoryUrl":"//www.lazada.co.id/beli-aksesori-bayi-laki-laki/"},{"childCategoryName":"Baju Renang Bayi Laki-Laki","childCategoryUrl":"//www.lazada.co.id/beli-baju-renang-bayi-laki-laki/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_7_5">
                <a href="//www.lazada.co.id/beli-makanan-bayi/">
                    <span>Perlengkapan Menyusui</span>
                </a>
                        <script type="text" class="J_data_6_4">
                            [{"childCategoryName":"Botol Bayi","childCategoryUrl":"//www.lazada.co.id/beli-botol-bayi/"},{"childCategoryName":"Botol","childCategoryUrl":"//www.lazada.co.id/beli-botol-bayi-balita/"},{"childCategoryName":"Aksesoris Dot Botol","childCategoryUrl":"//www.lazada.co.id/jual-aksesoris-botol-dot-bayi/"},{"childCategoryName":"Penghangat & Sterilizers","childCategoryUrl":"//www.lazada.co.id/beli-penghangat-sterilizer/"},{"childCategoryName":"Pompa Asi","childCategoryUrl":"//www.lazada.co.id/jual-pompa-asi/"},{"childCategoryName":"Aksesesoris Pompa Asi","childCategoryUrl":"//www.lazada.co.id/jual-aksesoris-pompa-asi/"},{"childCategoryName":"Perawatan Payudara","childCategoryUrl":"//www.lazada.co.id/beli-perawatan-puting/"},{"childCategoryName":"Bantal Menyusui","childCategoryUrl":"//www.lazada.co.id/beli-bantal-kursi-bayi/"},{"childCategoryName":"Kursi Bayi","childCategoryUrl":"//www.lazada.co.id/beli-kursi-tinggi-bayi-kursi-booster/"},{"childCategoryName":"Food Blenders","childCategoryUrl":"//www.lazada.co.id/beli-blender-makanan-bayi/"},{"childCategoryName":"Peralatan Makan Bayi","childCategoryUrl":"//www.lazada.co.id/beli-perlengkapan-makan-bayi-bb/"},{"childCategoryName":"Set Peralatan Makan Bayi","childCategoryUrl":"//www.lazada.co.id/jual-piring-mangkok-bayi/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_7_6">
                <a href="//www.lazada.co.id/beli-perlengkapan-berkendara-bayi/">
                    <span>Perlengkapan Bayi</span>
                </a>
                        <script type="text" class="J_data_6_5">
                            [{"childCategoryName":"Sling Bayi","childCategoryUrl":"//www.lazada.co.id/beli-sling-bayi/"},{"childCategoryName":"Soft Carrier","childCategoryUrl":"//www.lazada.co.id/beli-soft-carrier/"},{"childCategoryName":"Stroller","childCategoryUrl":"//www.lazada.co.id/beli-kereta-dorong-bayi/"},{"childCategoryName":"Car Seat","childCategoryUrl":"//www.lazada.co.id/beli-car-seat-bb/"},{"childCategoryName":"Playard","childCategoryUrl":"//www.lazada.co.id/beli-playard/"},{"childCategoryName":"Ayunan, Jumper & Bouncer Bayi","childCategoryUrl":"//www.lazada.co.id/beli-ayunan-jumper-bouncer-bayi/"},{"childCategoryName":"Walker","childCategoryUrl":"//www.lazada.co.id/beli-walker/"},{"childCategoryName":"Tempat Duduk & Trailer Sepeda","childCategoryUrl":"//www.lazada.co.id/beli-tempat-duduk-trailer-sepeda/"},{"childCategoryName":"Tas Anak","childCategoryUrl":"//www.lazada.co.id/beli-tas-anak/"},{"childCategoryName":"Koper Anak","childCategoryUrl":"//www.lazada.co.id/beli-koper-anak/"},{"childCategoryName":"Tali & Harness Bayi","childCategoryUrl":"//www.lazada.co.id/beli-tali-harness-bayi/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_7_7">
                <a href="//www.lazada.co.id/jual-perlengkapan-kamar-bayi/">
                    <span>Kamar Bayi</span>
                </a>
                        <script type="text" class="J_data_6_6">
                            [{"childCategoryName":"Matras Bayi","childCategoryUrl":"//www.lazada.co.id/beli-kasur-seprai-bayi/"},{"childCategoryName":"Selimut Bayi","childCategoryUrl":"//www.lazada.co.id/beli-selimut-bayi/"},{"childCategoryName":"Seprai Keranjang Bayi","childCategoryUrl":"//www.lazada.co.id/beli-seprai-keranjang-bayi/"},{"childCategoryName":"Kelengkapan Alat Tidur Balita","childCategoryUrl":"//www.lazada.co.id/beli-kelengkapan-alat-tidur-balita/"},{"childCategoryName":"Selimut Tebal & Bed Cover Bayi","childCategoryUrl":"//www.lazada.co.id/beli-selimut-tebal-bed-cover-bayi/"},{"childCategoryName":"Bantal, Pelindung & Sarung Bantal Bayi","childCategoryUrl":"//www.lazada.co.id/beli-bantal-pelindung-sarung-bantal-bayi/"},{"childCategoryName":"Furnitur Bayi","childCategoryUrl":"//www.lazada.co.id/beli-furnitur-bayi/"},{"childCategoryName":"Ranjang Bayi","childCategoryUrl":"//www.lazada.co.id/jual-ranjang-bayi/"},{"childCategoryName":"Keranjang Bayi Cradle","childCategoryUrl":"//www.lazada.co.id/beli-keranjang-bayi-cradle/"},{"childCategoryName":"Laci & Lemari Pakaian Bayi","childCategoryUrl":"//www.lazada.co.id/beli-laci-lemari-pakaian-bayi/"},{"childCategoryName":"Penyimpanan","childCategoryUrl":"//www.lazada.co.id/beli-tempat-pengatur-penyimpanan/"},{"childCategoryName":"Dekorasi Kamar Anak","childCategoryUrl":"//www.lazada.co.id/beli-dekorasi-kamar-anak/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_7_8">
                <a href="//www.lazada.co.id/beli-perlengkapan-mandi-perawatan-kulit-anak/">
                    <span>Perawatan Bayi</span>
                </a>
                        <script type="text" class="J_data_6_7">
                            [{"childCategoryName":"Perawatan Kulit Bayi","childCategoryUrl":"//www.lazada.co.id/beli-perawatan-kulit-bayi/"},{"childCategoryName":"Sampo & Kondisioner","childCategoryUrl":"//www.lazada.co.id/beli-sampo-kondisioner-bb/"},{"childCategoryName":"Sabun & Pembersih Bayi","childCategoryUrl":"//www.lazada.co.id/beli-sabun-pembersih-bayi/"},{"childCategoryName":"Perawatan Mulut Bayi","childCategoryUrl":"//www.lazada.co.id/beli-sikat-gigi-pasta-gigi-bayi/"},{"childCategoryName":"Sikat Gigi & Pasta Gigi","childCategoryUrl":"//www.lazada.co.id/beli-sikat-gigi-pasta-gigi-bayi/"},{"childCategoryName":"Tempat Duduk & Bak Mandi Bayi","childCategoryUrl":"//www.lazada.co.id/beli-tempat-duduk-bak-mandi-bayi/"},{"childCategoryName":"Lap Mandi & Handuk Bayi","childCategoryUrl":"//www.lazada.co.id/jual-handuk-bayi/"},{"childCategoryName":"Pelindung Matahari Bayi","childCategoryUrl":"//www.lazada.co.id/beli-pelindung-matahari-bayi/"},{"childCategoryName":"Aromaterapi Bayi","childCategoryUrl":"//www.lazada.co.id/beli-aromaterapi-bayi/"},{"childCategoryName":"Perlengkapan Mandi Bayi","childCategoryUrl":"//www.lazada.co.id/beli-perlengkapan-mandi-bayi-bb/"},{"childCategoryName":"Alas Mandi Bayi Anti Slip","childCategoryUrl":"//www.lazada.co.id/beli-alas-mandi-bayi-anti-slip/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_7_9">
                <a href="//www.lazada.co.id/beli-mainan-anak/">
                    <span>Mainan</span>
                </a>
                        <script type="text" class="J_data_6_8">
                            [{"childCategoryName":"Action Figure & Mainan Koleksi","childCategoryUrl":"//www.lazada.co.id/jual-koleksi-mainan-action-figure/"},{"childCategoryName":"Mainan Koleksi","childCategoryUrl":"//www.lazada.co.id/beli-mainan-koleksi-tg/"},{"childCategoryName":"Mini Figur","childCategoryUrl":"//www.lazada.co.id/beli-mini-figure-tg/"},{"childCategoryName":"Kerajinan Tangan","childCategoryUrl":"//www.lazada.co.id/beli-kerajinan-tangan-kesenian-anak/"},{"childCategoryName":"Mainan Blok","childCategoryUrl":"//www.lazada.co.id/beli-mainan-balok-bangunan/"},{"childCategoryName":"Boneka & Aksesoris","childCategoryUrl":"//www.lazada.co.id/beli-boneka-aksesori/"},{"childCategoryName":"Kostum Pesta","childCategoryUrl":"//www.lazada.co.id/beli-mainan-dress-up/"},{"childCategoryName":"Mainan Edukasi","childCategoryUrl":"//www.lazada.co.id/beli-mainan-pembelajaran-edukasi/"},{"childCategoryName":"Puzzle & Games","childCategoryUrl":"//www.lazada.co.id/beli-permainan-tradisional/"},{"childCategoryName":"Hobi & Hiburan","childCategoryUrl":"//www.lazada.co.id/Shop-Hobbies-Entertainment/"},{"childCategoryName":"Perlengkapan Pesta","childCategoryUrl":"//www.lazada.co.id/beli-perlengkapan-pesta/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_7_10">
                <a href="//www.lazada.co.id/beli-remote-control-mainan-kendaraan/">
                    <span>Mainan Elektronik &amp; RC</span>
                </a>
                        <script type="text" class="J_data_6_9">
                            [{"childCategoryName":"Mobil Remote Control","childCategoryUrl":"//www.lazada.co.id/beli-kendaraan-rc-baterai/"},{"childCategoryName":"Robot Remote Control","childCategoryUrl":"//www.lazada.co.id/beli-rc-figure-robot/"},{"childCategoryName":"Mobil Die Cast","childCategoryUrl":"//www.lazada.co.id/beli-kendaraan-die-cast/"},{"childCategoryName":"Mainan Mobil","childCategoryUrl":"//www.lazada.co.id/beli-mainan-kendaraan-tg/"},{"childCategoryName":"Mainan Kereta Api & Rel","childCategoryUrl":"//www.lazada.co.id/beli-set-mainan-kereta/"},{"childCategoryName":"Drone Mainan","childCategoryUrl":"//www.lazada.co.id/beli-drones-quadcopters/"},{"childCategoryName":"Helikopter","childCategoryUrl":"//www.lazada.co.id/beli-mainan-helikopter/"},{"childCategoryName":"Video Games & Hiburan","childCategoryUrl":"//www.lazada.co.id/shop-hiburan-video-game/"},{"childCategoryName":"Walkie Talkies","childCategoryUrl":"//www.lazada.co.id/beli-mainan-walkie-talkie/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_7_11">
                <a href="//www.lazada.co.id/beli-olahraga-permainan-luar-ruangan/">
                    <span>Mainan Olahraga &amp; Luar Ruangan</span>
                </a>
                        <script type="text" class="J_data_6_10">
                            [{"childCategoryName":"Kolam Renang & Mainan Air","childCategoryUrl":"//www.lazada.co.id/beli-mainan-air-kolam-renang/"},{"childCategoryName":"Mainan Olahraga","childCategoryUrl":"//www.lazada.co.id/shop-mainan-baseball-softball/"},{"childCategoryName":"Mainan Luar Ruangan","childCategoryUrl":"//www.lazada.co.id/beli-aktivitas-dan-olahraga-luar-ruangan/"},{"childCategoryName":"Mainan Blaster","childCategoryUrl":"//www.lazada.co.id/beli-mainan-blaster/"},{"childCategoryName":"Kolam Bola & Aksesoris","childCategoryUrl":"//www.lazada.co.id/beli-bola-pit-aksesori/"},{"childCategoryName":"Mainan Terbang","childCategoryUrl":"//www.lazada.co.id/beli-mainan-terbang/"},{"childCategoryName":"Layangan & Kincir Angin","childCategoryUrl":"//www.lazada.co.id/beli-mainan-layang-layang/"},{"childCategoryName":"Istana Balon","childCategoryUrl":"//www.lazada.co.id/beli-balon-loncat-istana-balon/"},{"childCategoryName":"Ygode & Kendama","childCategoryUrl":"//www.lazada.co.id/beli-yo-yo-kendama/"},{"childCategoryName":"Set Mainan Taman Bermain","childCategoryUrl":"//www.lazada.co.id/beli-set-peralatan-permainan-playground/"},{"childCategoryName":"Kemah & Terowongan Mainan","childCategoryUrl":"//www.lazada.co.id/beli-mainan-tenda-terowongan/"},{"childCategoryName":"Mainan Rumah-rumahan","childCategoryUrl":"//www.lazada.co.id/beli-playhouses/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_7_12">
                <a href="//www.lazada.co.id/baby-toddler-toys/">
                    <span>Mainan Bayi &amp; Balita</span>
                </a>
                        <script type="text" class="J_data_6_11">
                            [{"childCategoryName":"Playgym & Playmat","childCategoryUrl":"//www.lazada.co.id/jual-mainan-gym-anak/"},{"childCategoryName":"Mainan Blok","childCategoryUrl":"//www.lazada.co.id/beli-mainan-balok-bangunan/"},{"childCategoryName":"Mainan Mandi","childCategoryUrl":"//www.lazada.co.id/beli-mainan-mandi-anak-tg/"},{"childCategoryName":"Mainan Tidur Bayi","childCategoryUrl":"//www.lazada.co.id/beli-mainan-keranjang-bayi-perlengkapannya-tg/"},{"childCategoryName":"Mainan Balita","childCategoryUrl":"//www.lazada.co.id/beli-mainan-edukatif-anak-tg/"},{"childCategoryName":"Mainan Musik & Suara","childCategoryUrl":"//www.lazada.co.id/beli-musik-suara-tg/"},{"childCategoryName":"Mainan Tarik Ulur","childCategoryUrl":"//www.lazada.co.id/beli-mainan-dorong-tarik-tg/"},{"childCategoryName":"Mainan Shape Sorting","childCategoryUrl":"//www.lazada.co.id/beli-mainan-shape-sorting-tg/"},{"childCategoryName":"Indoor Climbers & Play Structures","childCategoryUrl":"//www.lazada.co.id/beli-indoor-climbers-play-structure-tg/"},{"childCategoryName":"Rocking & Spring Ride-Ons","childCategoryUrl":"//www.lazada.co.id/beli-rocking-spring-ride-on-tg/"}]
                        </script>
            </li>
        </ul>
        <ul class="lzd-site-menu-sub Level_1_Category_No8" data-spm="cate_8">
            <li class="lzd-site-menu-sub-item" data-cate="cate_8_1">
                <a href="//www.lazada.co.id/beli-tv-audio-video-permainan-dan-gadget/">
                    <span>TV &amp; Perangkat Video</span>
                </a>
                        <script type="text" class="J_data_7_0">
                            [{"childCategoryName":""},{"childCategoryName":"TV LED","childCategoryUrl":"//www.lazada.co.id/shop-televisi-digital/"},{"childCategoryName":"TV Smart","childCategoryUrl":"//www.lazada.co.id/beli-smart-tv/"},{"childCategoryName":"Blu-Ray/DVD Player","childCategoryUrl":"//www.lazada.co.id/beli-blu-ray-player/"},{"childCategoryName":"Media Player","childCategoryUrl":"//www.lazada.co.id/shop-media-player/"},{"childCategoryName":"Proyektor","childCategoryUrl":"//www.lazada.co.id/beli-proyektor-3/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_8_2">
                <a href="//www.lazada.co.id/beli-perlengkapan-dapur/">
                    <span>Peralatan Dapur Kecil</span>
                </a>
                        <script type="text" class="J_data_7_1">
                            [{"childCategoryName":""},{"childCategoryName":"Rice Cooker","childCategoryUrl":"//www.lazada.co.id/beli-rice-cooker/"},{"childCategoryName":"Blender, Mixer & Grinder","childCategoryUrl":"//www.lazada.co.id/beli-blender-mixer-juicer/"},{"childCategoryName":"Kompor Gas","childCategoryUrl":"//www.lazada.co.id/beli-kompor-gas/"},{"childCategoryName":"Teko Listrik","childCategoryUrl":"//www.lazada.co.id/beli-ketel-elektrik-2/"},{"childCategoryName":"Juicer","childCategoryUrl":"//www.lazada.co.id/beli-juicer-pengekstrak-buah/"},{"childCategoryName":"Mesin Kopi","childCategoryUrl":"//www.lazada.co.id/beli-mesin-kopi/"},{"childCategoryName":"Air Fryer","childCategoryUrl":"//www.lazada.co.id/beli-air-fryers/"},{"childCategoryName":"Peralatan Dapur Lainnya","childCategoryUrl":"//www.lazada.co.id/shop-ska-lainnya/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_8_3">
                <a href="//www.lazada.co.id/shop-perlatan-besar/">
                    <span>Elektronik Rumah Besar</span>
                </a>
                        <script type="text" class="J_data_7_2">
                            [{"childCategoryName":""},{"childCategoryName":"Mesin Cuci","childCategoryUrl":"//www.lazada.co.id/beli-mesin-cuci/"},{"childCategoryName":"Kulkas","childCategoryUrl":"//www.lazada.co.id/beli-lemari-es/"},{"childCategoryName":"Microwave","childCategoryUrl":"//www.lazada.co.id/beli-microwave/"},{"childCategoryName":"Oven","childCategoryUrl":"//www.lazada.co.id/beli-ovens/"},{"childCategoryName":"Dispenser Air Minum","childCategoryUrl":"//www.lazada.co.id/beli-dispenser-air/"},{"childCategoryName":"AC","childCategoryUrl":"//www.lazada.co.id/beli-ac/"},{"childCategoryName":"Pemanas Air","childCategoryUrl":"//www.lazada.co.id/beli-pemanas-air/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_8_4">
                <a href="//www.lazada.co.id/shop-pendingin-pembersih-udara-mini/">
                    <span>Penyejuk dan Pembersih Udara</span>
                </a>
                        <script type="text" class="J_data_7_3">
                            [{"childCategoryName":""},{"childCategoryName":"Kipas Angin","childCategoryUrl":"//www.lazada.co.id/shop-kipas/"},{"childCategoryName":"Air Cooler","childCategoryUrl":"//www.lazada.co.id/beli-pendingin-udara-2/"},{"childCategoryName":"Air Purifier","childCategoryUrl":"//www.lazada.co.id/beli-penjernih-udara-2/"},{"childCategoryName":"Humidifier","childCategoryUrl":"//www.lazada.co.id/beli-humidifier/"},{"childCategoryName":"Dehumidifier","childCategoryUrl":"//www.lazada.co.id/beli-dehumidifier/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_8_5">
                <a href="//www.lazada.co.id/beli-perawatan-lantai/">
                    <span>Penghisap Debu &amp; Perawatan Lantai</span>
                </a>
                        <script type="text" class="J_data_7_4">
                            [{"childCategoryName":""},{"childCategoryName":"Penghisap Debu","childCategoryUrl":"//www.lazada.co.id/shop-penyedot-debu/"},{"childCategoryName":"Penghisap Debu Robotik","childCategoryUrl":"//www.lazada.co.id/shop-penyedot-debu-robot/"},{"childCategoryName":"Penghisap Debu dengan Tongkat","childCategoryUrl":"//www.lazada.co.id/shop-penyedot-debu-tongkat/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_8_6">
                <a href="//www.lazada.co.id/shop-peralatan-perawatan-personal/">
                    <span>Alat Perawatan Diri</span>
                </a>
                        <script type="text" class="J_data_7_5">
                            [{"childCategoryName":""},{"childCategoryName":"Hair Dryer","childCategoryUrl":"//www.lazada.co.id/beli-pengering-rambut/"},{"childCategoryName":"Alat Penata Rambut","childCategoryUrl":"//www.lazada.co.id/beli-perlengkapan-styling-rambut/"},{"childCategoryName":"Shaver & Pencukur Kumis Jenggot","childCategoryUrl":"//www.lazada.co.id/beli-shaver/"},{"childCategoryName":"Sikat Gigi Elektrik","childCategoryUrl":"//www.lazada.co.id/beli-sikat-gigi-elektrik/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_8_7">
                <a href="//www.lazada.co.id/jual-aksesoris-elektronik-rumah-tangga/">
                    <span>Aksesoris &amp; Suku Cadang</span>
                </a>
                        <script type="text" class="J_data_7_6">
                            [{"childCategoryName":""},{"childCategoryName":"Suku Cadang & Aksesoris Peralatan Dapur Kecil","childCategoryUrl":"//www.lazada.co.id/beli-aksesoris-blender-dan-mixer/"},{"childCategoryName":"Suku Cadang & Aksesoris AC","childCategoryUrl":"//www.lazada.co.id/beli-suku-cadang-aksesoris-ac/"},{"childCategoryName":"Suku Cadang & Aksesoris Mesin Cuci","childCategoryUrl":"//www.lazada.co.id/beli-aksesoris-mesin-cuci-dan-pengering-pakaian/"},{"childCategoryName":"Suku Cadang & Filter Pengganti","childCategoryUrl":"//www.lazada.co.id/beli-filter-air/"},{"childCategoryName":"Suku Cadang & Filter Penghisap Debu","childCategoryUrl":"//www.lazada.co.id/beli-suku-kadang-aksesoris-vacuum-cleaner/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_8_8">
                <a href="//www.lazada.co.id/jual-aksesoris-televisi/">
                    <span>Aksesoris Televisi</span>
                </a>
                        <script type="text" class="J_data_7_7">
                            [{"childCategoryName":""},{"childCategoryName":"TV Box","childCategoryUrl":"//www.lazada.co.id/jual-tv-receiver/"},{"childCategoryName":"Antena TV","childCategoryUrl":"//www.lazada.co.id/jual-antena-tv/"},{"childCategoryName":"Bracket Dinding TV & Pelindung","childCategoryUrl":"//www.lazada.co.id/jual-bracket-dinding-tv/"},{"childCategoryName":"Remote Control TV","childCategoryUrl":"//www.lazada.co.id/jual-remote-control-tv/"},{"childCategoryName":"Kabel TV","childCategoryUrl":"//www.lazada.co.id/jual-kabel-tv/"},{"childCategoryName":"Adaptor TV","childCategoryUrl":"//www.lazada.co.id/jual-adaptor-tv/"},{"childCategoryName":"Kacamata 3D TV","childCategoryUrl":"//www.lazada.co.id/jual-kacamata-3d-tv/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_8_9">
                <a href="//www.lazada.co.id/jual-home-entertainment/">
                    <span>Home Entertainment</span>
                </a>
                        <script type="text" class="J_data_7_8">
                            [{"childCategoryName":""},{"childCategoryName":"Soundbar","childCategoryUrl":"//www.lazada.co.id/jual-soundbar/"},{"childCategoryName":"Sistem Karaoke","childCategoryUrl":"//www.lazada.co.id/jual-sistem-karaoke/"},{"childCategoryName":"Sistem Hi-Fi","childCategoryUrl":"//www.lazada.co.id/jual-sistem-hi-fi/"},{"childCategoryName":"Sound System Panggung","childCategoryUrl":"//www.lazada.co.id/sound-system-panggung/"},{"childCategoryName":"Player Portabel","childCategoryUrl":"//www.lazada.co.id/beli-audio-player/"}]
                        </script>
            </li>
        </ul>
        <ul class="lzd-site-menu-sub Level_1_Category_No9" data-spm="cate_9">
            <li class="lzd-site-menu-sub-item" data-cate="cate_9_1">
                <a href="//www.lazada.co.id/beli-dekorasi-rumah/">
                    <span>Dekorasi Rumah</span>
                </a>
                        <script type="text" class="J_data_8_0">[{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Stiker Dinding","childCategoryUrl":"//www.lazada.co.id/beli-stiker-dinding/"},{"childCategoryName":"Gorden","childCategoryUrl":"//www.lazada.co.id/gorden-dan-kerai/"},{"childCategoryName":"Tikar & Karpet","childCategoryUrl":"//www.lazada.co.id/beli-tikar-karpet/"},{"childCategoryName":"Hiasan Dinding","childCategoryUrl":"//www.lazada.co.id/beli-hiasan-dinding/"},{"childCategoryName":"Dekorasi Aksen","childCategoryUrl":"//www.lazada.co.id/shop-aksesoris-dekor/"},{"childCategoryName":"Bunga & Tanaman Artifisial","childCategoryUrl":"//www.lazada.co.id/beli-bunga-tanaman-artifisial/"},{"childCategoryName":"Jam","childCategoryUrl":"//www.lazada.co.id/beli-jam/"},{"childCategoryName":"Dalaman & Sarung Bantal","childCategoryUrl":"//www.lazada.co.id/shop-dalaman-sarung-bantal/"},{"childCategoryName":"Bingkai","childCategoryUrl":"//www.lazada.co.id/beli-bingkai/"},{"childCategoryName":"Wewangian Rumah","childCategoryUrl":"//www.lazada.co.id/beli-wewangian-rumah/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_9_2">
                <a href="//www.lazada.co.id/beli-furnitur/">
                    <span>Furnitur</span>
                </a>
                        <script type="text" class="J_data_8_1">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Tempat Penyimpanan","childCategoryUrl":"//www.lazada.co.id/beli-tempat-penyimpanan/"},{"childCategoryName":"Lemari Pakaian","childCategoryUrl":"//www.lazada.co.id/beli-lemari-pakaian/"},{"childCategoryName":"Kasur","childCategoryUrl":"//www.lazada.co.id/beli-kasur/"},{"childCategoryName":"Kamar Tidur","childCategoryUrl":"//www.lazada.co.id/beli-furnitur-kamar-tidur/"},{"childCategoryName":"Rak","childCategoryUrl":"//www.lazada.co.id/rak/"},{"childCategoryName":"Rak TV dan Media","childCategoryUrl":"//www.lazada.co.id/tempat-penyimpanan-media-dan-tv/"},{"childCategoryName":"Sofa","childCategoryUrl":"//www.lazada.co.id/beli-sofa/"},{"childCategoryName":"Ruang Tamu","childCategoryUrl":"//www.lazada.co.id/beli-furnitur-ruang-tamu/"},{"childCategoryName":"Ruang Kerja Rumah","childCategoryUrl":"//www.lazada.co.id/beli-furnitur-ruang-kerja-rumah/"},{"childCategoryName":"Dapur & Ruang Makan","childCategoryUrl":"//www.lazada.co.id/beli-furnitur-dapur-ruang-makan/"},{"childCategoryName":"Ruang Bayi","childCategoryUrl":"//www.lazada.co.id/beli-furnitur-ruang-bayi/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_9_3">
                <a href="//www.lazada.co.id/beli-peralatan-ranjang/">
                    <span>Kelengkapan Tempat Tidur</span>
                </a>
                        <script type="text" class="J_data_8_2">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Seprai","childCategoryUrl":"//www.lazada.co.id/seprei-ranjang/"},{"childCategoryName":"Seprai Set","childCategoryUrl":"//www.lazada.co.id/perangkat-seprei/"},{"childCategoryName":"Selimut","childCategoryUrl":"//www.lazada.co.id/selimut-dan-selimut-panjang/"},{"childCategoryName":"Bantal","childCategoryUrl":"//www.lazada.co.id/beli-bantal/"},{"childCategoryName":"Aksesoris Tempat Tidur","childCategoryUrl":"//www.lazada.co.id/beli-aksesoris-ranjang/"},{"childCategoryName":"Sarung Bantal","childCategoryUrl":"//www.lazada.co.id/beli-sarung-bantal/"},{"childCategoryName":"Selimut Tebal","childCategoryUrl":"//www.lazada.co.id/seprei-dan-selimut-tebal/"},{"childCategoryName":"Pelindung Kasur","childCategoryUrl":"//www.lazada.co.id/kasur-pelindung/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_9_4">
                <a href="//www.lazada.co.id/penerangan/">
                    <span>Penerangan</span>
                </a>
                        <script type="text" class="J_data_8_3">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Bohlam Lampu","childCategoryUrl":"//www.lazada.co.id/shop-bohlam-lampu/"},{"childCategoryName":"Lampu Khusus","childCategoryUrl":"//www.lazada.co.id/beli-lampu-khusus/"},{"childCategoryName":"Lampu Langit-langit","childCategoryUrl":"//www.lazada.co.id/beli-lampu-langit-langit-hias/"},{"childCategoryName":"Penerangan Outdoor","childCategoryUrl":"//www.lazada.co.id/beli-penerangan-outdoor/"},{"childCategoryName":"Lampu Dinding & Tempel","childCategoryUrl":"//www.lazada.co.id/beli-lampu-dinding-tempel/"},{"childCategoryName":"Lampu Meja","childCategoryUrl":"//www.lazada.co.id/beli-lampu-meja/"},{"childCategoryName":"Komponen Lampu","childCategoryUrl":"//www.lazada.co.id/beli-lampu-komponen/"},{"childCategoryName":"Kap Lampu","childCategoryUrl":"//www.lazada.co.id/kap-lampu/"},{"childCategoryName":"Lampu Lantai","childCategoryUrl":"//www.lazada.co.id/beli-lampu-lantai/"},{"childCategoryName":"Lampu Rechargeable & Senter","childCategoryUrl":"//www.lazada.co.id/beli-senter/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_9_5">
                <a href="//www.lazada.co.id/beli-peralatan-mandi/">
                    <span>Peralatan Mandi</span>
                </a>
                        <script type="text" class="J_data_8_4">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Handuk Mandi","childCategoryUrl":"//www.lazada.co.id/beli-handuk-mandi/"},{"childCategoryName":"Timbangan Kamar Mandi","childCategoryUrl":"//www.lazada.co.id/beli-timbangan-kamar-mandi/"},{"childCategoryName":"Wadah Penyimpanan Kamar Mandi","childCategoryUrl":"//www.lazada.co.id/beli-tempat-penyimpan-kamar-mandi/"},{"childCategoryName":"Rak Kamar Mandi","childCategoryUrl":"//www.lazada.co.id/jual-laci-kamar-mandi/"},{"childCategoryName":"Gantungan Handuk & Penghangat","childCategoryUrl":"//www.lazada.co.id/gantungan-handuk-dan-penghangat/"},{"childCategoryName":"Tempat & Gantungan Shower","childCategoryUrl":"//www.lazada.co.id/tempat-dan-gantungan-shower/"},{"childCategoryName":"Keset Kamar Mandi","childCategoryUrl":"//www.lazada.co.id/beli-alas-mandi/"},{"childCategoryName":"Jubah & Kimono Mandi","childCategoryUrl":"//www.lazada.co.id/beli-jubah-mandi/"},{"childCategoryName":"Tirai Shower","childCategoryUrl":"//www.lazada.co.id/shop-tirai-mandi-aksesoris/"},{"childCategoryName":"Cermin Kamar Mandi","childCategoryUrl":"//www.lazada.co.id/beli-cermin-kamar-mandi/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_9_6">
                <a href="//www.lazada.co.id/beli-perlengkapan-dapur-makan/">
                    <span>Alat Dapur</span>
                </a>
                        <script type="text" class="J_data_8_5">
                            [{"childCategoryName":"Botol minum","childCategoryUrl":"//www.lazada.co.id/botol-minum/"},{"childCategoryName":"Tempat Penyimpanan Makanan","childCategoryUrl":"//www.lazada.co.id/beli-wadah-penyimpan-makanan/"},{"childCategoryName":"Alas Meja & Aksesoris Dapur","childCategoryUrl":"//www.lazada.co.id/beli-alas-meja-aksesoris-dapur/"},{"childCategoryName":"Kopi & Teh","childCategoryUrl":"//www.lazada.co.id/beli-kopi-dan-teh/"},{"childCategoryName":"Rak Piring & Aksesoris Wastafel","childCategoryUrl":"//www.lazada.co.id/beli-rak-piring-aksesoris-bak/"},{"childCategoryName":"Panci & Wajan","childCategoryUrl":"//www.lazada.co.id/beli-peralatan-masak/"},{"childCategoryName":"Perangkat Minum","childCategoryUrl":"//www.lazada.co.id/beli-perangkat-minum-gelas/"},{"childCategoryName":"Perangkat Makan","childCategoryUrl":"//www.lazada.co.id/beli-peralatan-penyajian-makanan/"},{"childCategoryName":"Perangkat Pemanggang","childCategoryUrl":"//www.lazada.co.id/beli-perangkat-pemanggang/"},{"childCategoryName":"Perangkat Penyajian","childCategoryUrl":"//www.lazada.co.id/beli-perangkat-penyaji/"},{"childCategoryName":"Pisau & Aksesoris","childCategoryUrl":"//www.lazada.co.id/beli-pisau-dan-aksesoris/"},{"childCategoryName":"Alat Dapur Lainnya","childCategoryUrl":"//www.lazada.co.id/beli-peralatan-dapur/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_9_7">
                <a href="//www.lazada.co.id/beli-binatu-kebersihan/">
                    <span>Binatu &amp; Alat Kebersihan</span>
                </a>
                        <script type="text" class="J_data_8_6">
                            [{"childCategoryName":"Gantungan Baju","childCategoryUrl":"//www.lazada.co.id/gantungan-baju/"},{"childCategoryName":"Keranjang Baju","childCategoryUrl":"//www.lazada.co.id/keranjang-cucian/"},{"childCategoryName":"Jemuran Pakaian","childCategoryUrl":"//www.lazada.co.id/rak-pengering/"},{"childCategoryName":"Alat Binatu & Setrika","childCategoryUrl":"//www.lazada.co.id/beli-alat-binatu-setrika/"},{"childCategoryName":"Meja Setrika","childCategoryUrl":"//www.lazada.co.id/papan-setrika/"},{"childCategoryName":"Produk Kebersihan","childCategoryUrl":"//www.lazada.co.id/beli-makanan-minuman-pembersihan/"},{"childCategoryName":"Sapu & Alat Pel","childCategoryUrl":"//www.lazada.co.id/beli-sapu-pel/"},{"childCategoryName":"Lap Kain Penghilang Debu","childCategoryUrl":"//www.lazada.co.id/shop-Sapu-Sikat-Kemoceng/"},{"childCategoryName":"Sikat Pembersih","childCategoryUrl":"//www.lazada.co.id/beli-makanan-minuman-aksesoris-pembersih/"},{"childCategoryName":"Tempat Sampah","childCategoryUrl":"//www.lazada.co.id/tempat-sampah/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_9_8">
                <a href="//www.lazada.co.id/beli-perawatan-rumah/">
                    <span>Perkakas &amp; Perbaikan Rumah</span>
                </a>
                        <script type="text" class="J_data_8_7">
                            [{"childCategoryName":"Alat Penyimpanan & Rak","childCategoryUrl":"//www.lazada.co.id/beli-garasi-penyimpanan-alat-alat/"},{"childCategoryName":"Kabel & Perlengkapan Elektrik","childCategoryUrl":"//www.lazada.co.id/beli-peralatan-elektrik/"},{"childCategoryName":"Pengecatan & Dekorasi","childCategoryUrl":"//www.lazada.co.id/beli-pengecatan-dekorasi/"},{"childCategoryName":"Perkakas","childCategoryUrl":"//www.lazada.co.id/beli-perkakas/"},{"childCategoryName":"Perkakas Listrik","childCategoryUrl":"//www.lazada.co.id/jual-perkakas-listrik/"},{"childCategoryName":"Perkakas Portabel","childCategoryUrl":"//www.lazada.co.id/beli-peralatan-genggam/"},{"childCategoryName":"Pipa Saluran Air & Kelengkapan","childCategoryUrl":"//www.lazada.co.id/beli-ledeng/"},{"childCategoryName":"Senter","childCategoryUrl":"//www.lazada.co.id/beli-senter"},{"childCategoryName":"Tangga & Kursi Peninggi","childCategoryUrl":"//www.lazada.co.id/beli-tangga-kursi-peninggi/"},{"childCategoryName":"perlengkapan keamanan","childCategoryUrl":"//www.lazada.co.id/lampu-penerangan-tempat-kerja/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_9_9">
                <a href="//www.lazada.co.id/Kebun &amp; Luar Ruangan/">
                    <span>Kebun &amp; Luar Ruangan</span>
                </a>
                        <script type="text" class="J_data_8_8">
                            [{"childCategoryName":"Peralatan Listrik Taman & Kebun","childCategoryUrl":"//www.lazada.co.id/beli-peralatan-listrik-taman-luar-ruangan/"},{"childCategoryName":"Peralatan Kebun","childCategoryUrl":"//www.lazada.co.id/beli-peralatan-kebun/"},{"childCategoryName":"Sistem Pengairan","childCategoryUrl":"//www.lazada.co.id/beli-sistem-pengairan/"},{"childCategoryName":"Bibit & Biji Bijian","childCategoryUrl":"//www.lazada.co.id/beli-tumbuhan-biji-bijian/"},{"childCategoryName":"Pembasmi Hama","childCategoryUrl":"//www.lazada.co.id/beli-pembasmi-rumput-liar-hama/"},{"childCategoryName":"Aksesoris Genset","childCategoryUrl":"//www.lazada.co.id/beli-aksesoris-peralatan-listrik-luar-ruangan/"},{"childCategoryName":"Genset","childCategoryUrl":"//www.lazada.co.id/shop-generator/"},{"childCategoryName":"Pemanggang","childCategoryUrl":"//www.lazada.co.id/pemanggang-dan-penyajian-masakan-outdoor/"},{"childCategoryName":"Alat Pembunuh Serangga","childCategoryUrl":"//www.lazada.co.id/alat-pembunuh-serangga/"},{"childCategoryName":"Aksesoris Luar Ruangan","childCategoryUrl":"//www.lazada.co.id/beli-luar-ruangan/"},{"childCategoryName":"Taman & Kebun","childCategoryUrl":"//www.lazada.co.id/perlengkapan-taman-dan-kebun/"},{"childCategoryName":"","childCategoryUrl":""}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_9_10">
                <a href="//www.lazada.co.id/beli-alat-tulis-kerajinan/">
                    <span>Alat Tulis &amp; Kerajinan</span>
                </a>
                        <script type="text" class="J_data_8_9">
                            [{"childCategoryName":"Peralatan Kesenian dan Kerajinan","childCategoryUrl":"//www.lazada.co.id/beli-peralatan-seni/"},{"childCategoryName":"Peralatan Mewarnai dan Copic","childCategoryUrl":"//www.lazada.co.id/beli-alat-mewarnai-copic/"},{"childCategoryName":"Kerajinan Umum","childCategoryUrl":"//www.lazada.co.id/beli-alat-kerajinan-umum/"},{"childCategoryName":"Pernak Pernik Hadiah dan Kado","childCategoryUrl":"//www.lazada.co.id/beli-pernak-pernik-hadiah/"},{"childCategoryName":"Tas Belanja","childCategoryUrl":"//www.lazada.co.id/beli-tas-belanjaan/"},{"childCategoryName":"Buku Catatan","childCategoryUrl":"//www.lazada.co.id/buku-catatan/"},{"childCategoryName":"Kertas Komputer","childCategoryUrl":"//www.lazada.co.id/beli-kertas-komputer/"},{"childCategoryName":"Perlengkapan Sekolah","childCategoryUrl":"//www.lazada.co.id/beli-perlengkapan-sekolah/"},{"childCategoryName":"Perlengkapan Meja Kerja","childCategoryUrl":"//www.lazada.co.id/beli-wadah-alat-alat-kantor/"},{"childCategoryName":"Perlengkapan Jahit","childCategoryUrl":"//www.lazada.co.id/beli-bahan-bahan-kerajinan-tangan/"},{"childCategoryName":"Pulpen","childCategoryUrl":"//www.lazada.co.id/beli-pulpen/"},{"childCategoryName":"Pensil","childCategoryUrl":"//www.lazada.co.id/beli-pensil-2/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_9_11">
                <a href="//www.lazada.co.id/beli-media-musik-dan-buku/">
                    <span>Media, Musik &amp; Buku</span>
                </a>
                        <script type="text" class="J_data_8_10">
                            [{"childCategoryName":"Instrumen Musik","childCategoryUrl":"//www.lazada.co.id/instrumen-musik/"},{"childCategoryName":"Buku","childCategoryUrl":"//www.lazada.co.id/buku/"},{"childCategoryName":"Musik","childCategoryUrl":"//www.lazada.co.id/lagu/"},{"childCategoryName":"Majalah","childCategoryUrl":"//www.lazada.co.id/majalah/"},{"childCategoryName":"Film","childCategoryUrl":"//www.lazada.co.id/film/"}]
                        </script>
            </li>
        </ul>
        <ul class="lzd-site-menu-sub Level_1_Category_No10" data-spm="cate_10">
            <li class="lzd-site-menu-sub-item" data-cate="cate_10_1">
                <a href="//www.lazada.co.id/beli-minuman/">
                    <span>Minuman</span>
                </a>
                        <script type="text" class="J_data_9_0">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"UHT, Susu & Susu Bubuk","childCategoryUrl":"//www.lazada.co.id/beli-makanan-minuman-uht-milk-milk-powder/"},{"childCategoryName":"Kopi","childCategoryUrl":"//www.lazada.co.id/beli-kopi/"},{"childCategoryName":"Minuman Serbuk","childCategoryUrl":"//www.lazada.co.id/beli-minuman-serbuk/"},{"childCategoryName":"Minuman Berenergi","childCategoryUrl":"//www.lazada.co.id/shop-Minuman-Olahraga-Energi/"},{"childCategoryName":"Teh","childCategoryUrl":"//www.lazada.co.id/beli-teh/"},{"childCategoryName":"Chocolate, Malt & Hot Cereals","childCategoryUrl":"//www.lazada.co.id/coklat-panas/"},{"childCategoryName":"Air Mineral","childCategoryUrl":"//www.lazada.co.id/beli-makanan-minuman-air/"},{"childCategoryName":"Minuman Berkarbonasi","childCategoryUrl":"//www.lazada.co.id/beli-makanan-minuman-minuman-ringan/"},{"childCategoryName":"Jus","childCategoryUrl":"//www.lazada.co.id/beli-makanan-minuman-jus/"},{"childCategoryName":"Sirup","childCategoryUrl":"//www.lazada.co.id/beli-sirup/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_10_2">
                <a href="//www.lazada.co.id/shop-Bahan-Utama-Pelengkap-Masakan">
                    <span>Bahan &amp; Bumbu Masakan</span>
                </a>
                        <script type="text" class="J_data_9_1">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Makanan Instant & Siap santap","childCategoryUrl":"//www.lazada.co.id/shop-Makanan-Instan-Siap-Santap/"},{"childCategoryName":"Bahan Pembuat Kue","childCategoryUrl":"//www.lazada.co.id/shop-Bahan-Pembuat-Kue/"},{"childCategoryName":"Beras","childCategoryUrl":"//www.lazada.co.id/shop-Beras/"},{"childCategoryName":"Garam & Bumbu Dapur","childCategoryUrl":"//www.lazada.co.id/shop-Bumbu-Dapur/"},{"childCategoryName":"Mie & Bihun","childCategoryUrl":"//www.lazada.co.id/shop-Mi-Bihun/"},{"childCategoryName":"Makanan Kering","childCategoryUrl":"//www.lazada.co.id/shop-Makanan-Kering/"},{"childCategoryName":"Minyak","childCategoryUrl":"//www.lazada.co.id/shop-Minyak/"},{"childCategoryName":"Makanan Kaleng","childCategoryUrl":"//www.lazada.co.id/shop-Makanan-Kaleng/"},{"childCategoryName":"Pasta","childCategoryUrl":"//www.lazada.co.id/shop-Pasta/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_10_3">
                <a href="//www.lazada.co.id/shop-Cokelat-Camilan-Permen/">
                    <span>Cokelat, Camilan &amp; Permen</span>
                </a>
                        <script type="text" class="J_data_9_2">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Camilan","childCategoryUrl":"//www.lazada.co.id/shop-Camilan/"},{"childCategoryName":"Cokelat","childCategoryUrl":"//www.lazada.co.id/shop-Cokelat/"},{"childCategoryName":"blackjepe & Kerupuk","childCategoryUrl":"//www.lazada.co.id/shop-blackjepe-Manis/"},{"childCategoryName":"Permen","childCategoryUrl":"//www.lazada.co.id/shop-Manisan/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_10_4">
                <a href="//www.lazada.co.id/beli-makanan-sarapan">
                    <span>Makanan Sarapan, Sereal &amp; Selai</span>
                </a>
                        <script type="text" class="J_data_9_3">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Selai & Madu","childCategoryUrl":"//www.lazada.co.id/beli-makanan-minuman-selai-madu-spread/"},{"childCategoryName":"Oatmeal","childCategoryUrl":"//www.lazada.co.id/beli-oatmeal/"},{"childCategoryName":"Sereal Sarapan","childCategoryUrl":"//www.lazada.co.id/beli-sereal/"},{"childCategoryName":"Tepung Pancake & Waffle","childCategoryUrl":"//www.lazada.co.id/beli-pancake-waffle/"},{"childCategoryName":"Bars","childCategoryUrl":"//www.lazada.co.id/shop-bar/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_10_5">
                <a href="//www.lazada.co.id/beli-makanan-minuman-hasil-segar">
                    <span>Buah &amp; Sayur</span>
                </a>
                        <script type="text" class="J_data_9_4">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Buah Segar","childCategoryUrl":"//www.lazada.co.id/beli-makanan-minuman-buah/"},{"childCategoryName":"Sayur Segar","childCategoryUrl":"//www.lazada.co.id/beli-makanan-minuman-sayuran-segar/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_10_6">
                <a href="//www.lazada.co.id/shop-kebutuhan-rumah-tangga">
                    <span>Kebutuhan Rumah Tangga</span>
                </a>
                        <script type="text" class="J_data_9_5">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Pengharum Ruangan","childCategoryUrl":"//www.lazada.co.id/shop-perawatan-udara/"},{"childCategoryName":"Kebutuhan Kebersihan","childCategoryUrl":"//www.lazada.co.id/beli-makanan-minuman-pembersihan/"},{"childCategoryName":"Pengendalian Hama","childCategoryUrl":"//www.lazada.co.id/beli-makanan-minuman-pengendalian-hama/"},{"childCategoryName":"Sabun Pencuci Piring","childCategoryUrl":"//www.lazada.co.id/beli-makanan-minuman-mencuci-piring/"},{"childCategoryName":"Kebutuhan Laundry","childCategoryUrl":"//www.lazada.co.id/beli-makanan-minuman-cucian/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_10_7">
                <a href="//www.lazada.co.id/shop-makanan-hewan">
                    <span>Makanan Hewan Peliharaan</span>
                </a>
                        <script type="text" class="J_data_9_6">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Makanan & Camilan Kucing","childCategoryUrl":"//www.lazada.co.id/jual-makanan-kucing/"},{"childCategoryName":"Makanan Burung","childCategoryUrl":"//www.lazada.co.id/beli-makanan-burung/"},{"childCategoryName":"Makanan Ikan","childCategoryUrl":"//www.lazada.co.id/beli-makanan-ikan/"},{"childCategoryName":"Makanan & Camilan Anjing","childCategoryUrl":"//www.lazada.co.id/jual-makanan-anjing/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_10_8">
                <a href="//www.lazada.co.id/shop-aksesoris-hewan">
                    <span>Aksesoris Hewan Peliharaan</span>
                </a>
                        <script type="text" class="J_data_9_7">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Keperluan Akuarium","childCategoryUrl":"//www.lazada.co.id/shop-keperluan-akuarium/"},{"childCategoryName":"Kandang & Aksesoris","childCategoryUrl":"//www.lazada.co.id/beli-kandang-terbuka-pintu-anjing/"},{"childCategoryName":"Peralatan Grooming","childCategoryUrl":"//www.lazada.co.id/jual-persediaan-grooming-hewan/"},{"childCategoryName":"Rumah,Alas & Tempat tidur","childCategoryUrl":"//www.lazada.co.id/beli-ranjang-alas-tidur-rumah-anjing/"},{"childCategoryName":"Alat Makan Hewan","childCategoryUrl":"//www.lazada.co.id/beli-mangkuk-makan-anjing/"},{"childCategoryName":"Tali dan Kalung Hewan","childCategoryUrl":"//www.lazada.co.id/beli-tali-kalung-moncong-anjing/"},{"childCategoryName":"Kebutuhan Travel Hewan","childCategoryUrl":"//www.lazada.co.id/beli-pengangkut-perjalanan-anjing/"},{"childCategoryName":"Mainan Hewan","childCategoryUrl":"//www.lazada.co.id/shop-mainan/"},{"childCategoryName":"Alat Pelatihan Anjing","childCategoryUrl":"//www.lazada.co.id/beli-alat-latih-olahraga-anjing/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_10_9">
                <a href="//www.lazada.co.id/shop-kesehatan-hewan-peliharaan">
                    <span>Kesehatan Hewan Peliharaan</span>
                </a>
                        <script type="text" class="J_data_9_8">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Perawatan Gigi","childCategoryUrl":"//www.lazada.co.id/beli-kesehatan-gigi-anjing/"},{"childCategoryName":"Pembasmi Kutu Hewan","childCategoryUrl":"//www.lazada.co.id/beli-kutu-anjing/"}]
                        </script>
            </li>
        </ul>
        <ul class="lzd-site-menu-sub Level_1_Category_No11" data-spm="cate_11">
            <li class="lzd-site-menu-sub-item" data-cate="cate_11_1">
                <a href="//www.lazada.co.id/baju-olahraga-pria/">
                    <span>Baju Olahraga Pria</span>
                </a>
                        <script type="text" class="J_data_10_0">
                            [{"childCategoryName":"Celana Olahraga Pria","childCategoryUrl":"//www.lazada.co.id/celana-panjang-dan-pendek-olahraga-pria/"},{"childCategoryName":"Kaos Olahraga Pria","childCategoryUrl":"//www.lazada.co.id/kaos-olahraga-pria/"},{"childCategoryName":"Jaket Olahraga Pria","childCategoryUrl":"//www.lazada.co.id/jaket-dan-parka-olahraga-pria/"},{"childCategoryName":"Pakaian Renang Pria","childCategoryUrl":"//www.lazada.co.id/pakaian-renang-dan-selancar-pria/"},{"childCategoryName":"Jersey Olahraga Pria","childCategoryUrl":"//www.lazada.co.id/jual-jersey-olahraga-pria/"},{"childCategoryName":"Celana Pendek Pria","childCategoryUrl":"//www.lazada.co.id/jual-celana-pendek-olahraga-pria/"},{"childCategoryName":"Hoodies Pria","childCategoryUrl":"//www.lazada.co.id/hoodies-pria/"},{"childCategoryName":"Topi Olahraga Pria","childCategoryUrl":"//www.lazada.co.id/jual-topi-olahraga-pria/"},{"childCategoryName":"Tas Ransel Sport Pria","childCategoryUrl":"//www.lazada.co.id/tas-ransel-sport-pria/"},{"childCategoryName":"Tas Serut Pria","childCategoryUrl":"//www.lazada.co.id/tas-serut-pria/"},{"childCategoryName":"Tas Duffel Pria","childCategoryUrl":"//www.lazada.co.id/tas-duffel-pria/"},{"childCategoryName":"Gym Tote Pria","childCategoryUrl":"//www.lazada.co.id/gym-tote-pria/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_11_2">
                <a href="//www.lazada.co.id/pakaian-olahraga-wanita/">
                    <span>Baju Olahraga Wanita</span>
                </a>
                        <script type="text" class="J_data_10_1">
                            [{"childCategoryName":"Celana Panjang Wanita","childCategoryUrl":"//www.lazada.co.id/celana-panjang-dan-pendek-olahraga-wanita/"},{"childCategoryName":"Kaos Olahraga Wanita","childCategoryUrl":"//www.lazada.co.id/kaos-dan-atasan-olahraga-wanita/"},{"childCategoryName":"Jaket Olahraga Wanita","childCategoryUrl":"//www.lazada.co.id/jaket-dan-parka-sport-wanita/"},{"childCategoryName":"Sport Bra Wanita","childCategoryUrl":"//www.lazada.co.id/jual-sport-bra-wanita/"},{"childCategoryName":"Celana Pendek Wanita","childCategoryUrl":"//www.lazada.co.id/jual-celana-pendek-olahraga-wanita/"},{"childCategoryName":"Rok Olahraga Wanita","childCategoryUrl":"//www.lazada.co.id/jual-rok-olahraga-wanita/"},{"childCategoryName":"Hoodies Wanita","childCategoryUrl":"//www.lazada.co.id/hoodies-wanita/"},{"childCategoryName":"Pakaian Renang Wanita","childCategoryUrl":"//www.lazada.co.id/pakaian-renang-dan-selancar-wanita/"},{"childCategoryName":"Tas Ransel Sport Wanita","childCategoryUrl":"//www.lazada.co.id/tas-ransel-sport-wanita/"},{"childCategoryName":"Tas Serut Wanita","childCategoryUrl":"//www.lazada.co.id/tas-serut-wanita/"},{"childCategoryName":"Tas Duffel Wanita","childCategoryUrl":"//www.lazada.co.id/tas-duffel-wanita/"},{"childCategoryName":"Gym Tote Wanita","childCategoryUrl":"//www.lazada.co.id/gym-tote-wanita/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_11_3">
                <a href="//www.lazada.co.id/sepatu-dan-pakaian-olahraga-pria/">
                    <span>Sepatu Olahraga Pria</span>
                </a>
                        <script type="text" class="J_data_10_2">
                            [{"childCategoryName":"Sepatu Sepakbola Pria","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-sepakbola-pria/"},{"childCategoryName":"Sepatu Futsal Pria","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-futsal-pria/"},{"childCategoryName":"Sepatu Lari Pria","childCategoryUrl":"//www.lazada.co.id/sepatu-lari-pria/"},{"childCategoryName":"Sepatu Hiking Pria","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-hiking-pria/"},{"childCategoryName":"Sepatu Basket Pria","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-basket-pria/"},{"childCategoryName":"Sepatu Olahraga Air Pria","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-olahraga-air-pria/"},{"childCategoryName":"Sepatu Badminton ria","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-badminton-pria/"},{"childCategoryName":"Sepatu Training Pira","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-fitness-training-pria/"},{"childCategoryName":"Sepatu Skateboard Pria","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-skateboard-pria/"},{"childCategoryName":"Sepatu Sneakers Pria","childCategoryUrl":"//www.lazada.co.id/beli-sepatu-sneakers-pria/"},{"childCategoryName":"Sandal Olahraga Pria","childCategoryUrl":"//www.lazada.co.id/jual-sandal-olahraga-pria/"},{"childCategoryName":"Sepatu Jalan Pria","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-jalan-pria/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_11_4">
                <a href="//www.lazada.co.id/sepatu-dan-pakaian-olahraga-wanita/">
                    <span>Sepatu Olahraga Wanita</span>
                </a>
                        <script type="text" class="J_data_10_3">
                            [{"childCategoryName":"Sepatu Badminton Wanita","childCategoryUrl":"//www.lazada.co.id/sepatu-badminton-wanita/"},{"childCategoryName":"Sepatu Lari Wanita","childCategoryUrl":"//www.lazada.co.id/sepatu-lari-wanita/"},{"childCategoryName":"Sepatu Futsal Wanita","childCategoryUrl":"//www.lazada.co.id/sepatu-futsal-wanita/"},{"childCategoryName":"Sepatu Basket Wanita","childCategoryUrl":"//www.lazada.co.id/sepatu-basket-wanita/"},{"childCategoryName":"Sepatu Sepakbola Wanita","childCategoryUrl":"//www.lazada.co.id/sepatu-sepakbola-wanita/"},{"childCategoryName":"Sepatu Olahraga Air Wanita","childCategoryUrl":"//www.lazada.co.id/sepatu-olaraga-air-wanita/"},{"childCategoryName":"Sepatu Hiking Wanita","childCategoryUrl":"//www.lazada.co.id/sepatu-hiking-wanita/"},{"childCategoryName":"Sepatu Training Wanita","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-fitness-training-wanita/"},{"childCategoryName":"Septu Skateboard Wanita","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-skateboard-wanita/"},{"childCategoryName":"Sepatu Sneakers Wanita","childCategoryUrl":"//www.lazada.co.id/beli-sepatu-sneakers-wanita/"},{"childCategoryName":"Sandal Olahraga Wanita","childCategoryUrl":"//www.lazada.co.id/jual-sandal-olahraga-wanita/"},{"childCategoryName":"Sepatu Jalan Wanita","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-jalan-wanita/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_11_5">
                <a href="//www.lazada.co.id/camping-dan-hiking/">
                    <span>Camping dan Hiking</span>
                </a>
                        <script type="text" class="J_data_10_4">
                            [{"childCategoryName":"Tenda dan furniture Camping","childCategoryUrl":"//www.lazada.co.id/tenda-dan-furniture/"},{"childCategoryName":"Perlengkapan Tidur Camping","childCategoryUrl":"//www.lazada.co.id/perlengkapan-tidur-camping/"},{"childCategoryName":"Tas Camping","childCategoryUrl":"//www.lazada.co.id/jual-tas-ransel/"},{"childCategoryName":"Tempat berteduh Camping","childCategoryUrl":"//www.lazada.co.id/jual-tempat-berteduh-dan-kanopi/"},{"childCategoryName":"Perabotan Kemah","childCategoryUrl":"//www.lazada.co.id/jual-perabotan-kemah/"},{"childCategoryName":"Alat Dapur Kemah","childCategoryUrl":"//www.lazada.co.id/jual-dapur-kemah/"},{"childCategoryName":"Alat penerangan Hiking","childCategoryUrl":"//www.lazada.co.id/jual-penerangan/"},{"childCategoryName":"Navigasi Elektroning Hiking","childCategoryUrl":"//www.lazada.co.id/jual-navigasi-elektronik/"},{"childCategoryName":"Tongkat Hiking","childCategoryUrl":"//www.lazada.co.id/jual-tongkat-hiking/"},{"childCategoryName":"Pisau Kemah","childCategoryUrl":"//www.lazada.co.id/jual-pisau-alat-multifungsi/"},{"childCategoryName":"Peralatan Survival Camping","childCategoryUrl":"//www.lazada.co.id/jual-peralatan-survival-dan-keamanan/"},{"childCategoryName":"Perlengkapan Panjat Tebing","childCategoryUrl":"//www.lazada.co.id/panjat-tebing/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_11_6">
                <a href="//www.lazada.co.id/jual-peralatan-memancing/">
                    <span>Peralatan Memancing</span>
                </a>
                        <script type="text" class="J_data_10_5">
                            [{"childCategoryName":"Tongkat Pancing","childCategoryUrl":"//www.lazada.co.id/jual-tongkat-pancing/"},{"childCategoryName":"Alat Gulungan Pancing","childCategoryUrl":"//www.lazada.co.id/alat-gulungan-pancing/"},{"childCategoryName":"Set Tongkat dan Gulungan Pancing","childCategoryUrl":"//www.lazada.co.id/set-tongkat-dan-gulungan-pancing/"},{"childCategoryName":"Senar Pancing","childCategoryUrl":"//www.lazada.co.id/jual-senar-pancing/"},{"childCategoryName":"Umpan Pancing","childCategoryUrl":"//www.lazada.co.id/jual-umpan/"},{"childCategoryName":"Peralatan Pancing","childCategoryUrl":"//www.lazada.co.id/jual-peralatan-pancing/"},{"childCategoryName":"GPS alat pencari ikan","childCategoryUrl":"//www.lazada.co.id/jual-gps-alat-pencari-ikan/"},{"childCategoryName":"Jaring Penangkap Ikan","childCategoryUrl":"//www.lazada.co.id/jual-jaring-penangkap-ikan/"},{"childCategoryName":"Aksesoris Memancing","childCategoryUrl":"//www.lazada.co.id/jual-aksesoris-memancing/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_11_7">
                <a href="//www.lazada.co.id/olahraga-sepeda/">
                    <span>Olahraga Sepeda</span>
                </a>
                        <script type="text" class="J_data_10_6">
                            [{"childCategoryName":"Komponen Part Sepeda","childCategoryUrl":"//www.lazada.co.id/komponen-dan-parts-sepeda/"},{"childCategoryName":"Aksesoris Sepeda","childCategoryUrl":"//www.lazada.co.id/aksesoris-sepeda/"},{"childCategoryName":"Sepeda","childCategoryUrl":"//www.lazada.co.id/sepeda/"},{"childCategoryName":"Kaos Sepeda","childCategoryUrl":"//www.lazada.co.id/jual-baju-kaos-sepeda/"},{"childCategoryName":"Sepatu Sepeda Pria","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-sepeda-pria/"},{"childCategoryName":"Sepatu Sepeda Wanita","childCategoryUrl":"//www.lazada.co.id/sepatu-sepeda-wanita/"},{"childCategoryName":"Sepatu Sepeda Perempuan","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-sepeda-anak-perempuan/"},{"childCategoryName":"Sepatu Sepeda Laki-Laki","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-sepeda-anak-laki-laki/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_11_8">
                <a href="//www.lazada.co.id/olahraga-air/">
                    <span>Olahraga Air</span>
                </a>
                        <script type="text" class="J_data_10_7">
                            [{"childCategoryName":"Kapal","childCategoryUrl":"//www.lazada.co.id/jual-kapal/"},{"childCategoryName":"Peralatan Menyelam","childCategoryUrl":"//www.lazada.co.id/diving-snorkeling/"},{"childCategoryName":"Peralatan Renang","childCategoryUrl":"//www.lazada.co.id/renang/"},{"childCategoryName":"Papan Renang","childCategoryUrl":"//www.lazada.co.id/jual-olahraga-papan/"},{"childCategoryName":"Tubing dan Towables","childCategoryUrl":"//www.lazada.co.id/jual-tubing-towables/"},{"childCategoryName":"Akesesoris Olahraga Air","childCategoryUrl":"//www.lazada.co.id/jual-aksesoris-olahraga-air/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_11_9">
                <a href="//www.lazada.co.id/latihan-dan-fitness/">
                    <span>Gym, Yoga &amp; Fitness</span>
                </a>
                        <script type="text" class="J_data_10_8">
                            [{"childCategoryName":"Peralatan Pelatihan Ketangkasan","childCategoryUrl":"//www.lazada.co.id/shop-pelatihan-kecepatan-ketangkasan/"},{"childCategoryName":"Aksesoris Gym","childCategoryUrl":"//www.lazada.co.id/shop-aksesoris/"},{"childCategoryName":"Pilates Gym","childCategoryUrl":"//www.lazada.co.id/pilates/"},{"childCategoryName":"Alat Latihan Angkat Beban","childCategoryUrl":"//www.lazada.co.id/alat-latihan-angkat-beban/"},{"childCategoryName":"Yoga","childCategoryUrl":"//www.lazada.co.id/yoga/"},{"childCategoryName":"Peralatan Kardio","childCategoryUrl":"//www.lazada.co.id/peralatan-latihan-kardio/"},{"childCategoryName":"Perlengkapan Fitnes","childCategoryUrl":"//www.lazada.co.id/jual-aksesoris-fitness/"},{"childCategoryName":"Perlengkapan Lari","childCategoryUrl":"//www.lazada.co.id/temporary-url-sport-catl3-1/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_11_10">
                <a href="//www.lazada.co.id/olahraga-raket/">
                    <span>Olahraga Raket</span>
                </a>
                        <script type="text" class="J_data_10_9">
                            [{"childCategoryName":"Tenis Meja","childCategoryUrl":"//www.lazada.co.id/tenis-meja/"},{"childCategoryName":"Badminton","childCategoryUrl":"//www.lazada.co.id/bulutangkis/"},{"childCategoryName":"Tennis","childCategoryUrl":"//www.lazada.co.id/tenis/"},{"childCategoryName":"Squash","childCategoryUrl":"//www.lazada.co.id/squash/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_11_11">
                <a href="//www.lazada.co.id/shop-perlengkapan-olah-raga/">
                    <span>Perlengkapan Olahraga</span>
                </a>
                        <script type="text" class="J_data_10_10">
                            [{"childCategoryName":"Oxrashoan Tinju-Bela Mma","childCategoryUrl":"//www.lazada.co.id/jual-tinju-bela-diri-mma/"},{"childCategoryName":"Golf Gym","childCategoryUrl":"//www.lazada.co.id/golf/"},{"childCategoryName":"Bola Gym","childCategoryUrl":"//www.lazada.co.id/sepak-bola/"},{"childCategoryName":"Basket Gym","childCategoryUrl":"//www.lazada.co.id/basket/"},{"childCategoryName":"Voli Gym","childCategoryUrl":"//www.lazada.co.id/voli/"},{"childCategoryName":"Cricket Gym","childCategoryUrl":"//www.lazada.co.id/cricket/"},{"childCategoryName":"Rugby Gym","childCategoryUrl":"//www.lazada.co.id/rugby/"},{"childCategoryName":"Takraw Gym","childCategoryUrl":"//www.lazada.co.id/sepak-takraw/"},{"childCategoryName":"Baseball Gym","childCategoryUrl":"//www.lazada.co.id/baseball/"},{"childCategoryName":"Perlengkapan Olahraga Senam","childCategoryUrl":"//www.lazada.co.id/jual-olahraga-senam/"},{"childCategoryName":"Hoki Gym","childCategoryUrl":"//www.lazada.co.id/olahraga-hoki/"},{"childCategoryName":"Peralatan Cheerleading","childCategoryUrl":"//www.lazada.co.id/jual-peralatan-cheerleading/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_11_12">
                <a href="//www.lazada.co.id/sepak-bola/">
                    <span>Perlengkapan Sepak Bola</span>
                </a>
                        <script type="text" class="J_data_10_11">
                            [{"childCategoryName":"Sepatu Sepakbola","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-sepakbola-pria/"},{"childCategoryName":"Sepatu Futsal","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-futsal-pria/"},{"childCategoryName":"Jersey Sepakbola","childCategoryUrl":"//www.lazada.co.id/jual-jersey-sepak-bola-pria/"},{"childCategoryName":"Jersey Sepakbola Anak","childCategoryUrl":"//www.lazada.co.id/jual-jersey-sepak-bola-anak-laki-laki/"},{"childCategoryName":"Sepatu Sepakbola Anak","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-sepak-bola/"},{"childCategoryName":"Sepatu Futsal Anak","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-futsal/"},{"childCategoryName":"Bola","childCategoryUrl":"//www.lazada.co.id/bola-sepak-bola/"},{"childCategoryName":"Sarung Tangan Keeper","childCategoryUrl":"//www.lazada.co.id/sarung-tangan-kiper/"},{"childCategoryName":"Pelindung Lutut","childCategoryUrl":"//www.lazada.co.id/beli-pelindung-tulang-kering/"},{"childCategoryName":"Peralatan Latihan","childCategoryUrl":"//www.lazada.co.id/beli-peralatan-berlatih-dan-lapangan/"},{"childCategoryName":"Tas","childCategoryUrl":"//www.lazada.co.id/jual-tas-peralatan/"},{"childCategoryName":"Fan Merchandise Team International","childCategoryUrl":"//www.lazada.co.id/international-football-clubs-fan-merchandise/"}]
                        </script>
            </li>
        </ul>
        <ul class="lzd-site-menu-sub Level_1_Category_No12" data-spm="cate_12">
            <li class="lzd-site-menu-sub-item" data-cate="cate_12_1">
                <a href="//www.lazada.co.id/shop-auto-parts-spares/">
                    <span>Suku Cadang &amp; Peralatan Mobil</span>
                </a>
                        <script type="text" class="J_data_11_0">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Lampu, Bohlam & LED","childCategoryUrl":"//www.lazada.co.id/shop-bohlam-led-hid/"},{"childCategoryName":"Rem","childCategoryUrl":"//www.lazada.co.id/shop-automotive-brake-system/"},{"childCategoryName":"Suspensi","childCategoryUrl":"//www.lazada.co.id/shop-automotive-shocks-struts-suspension/"},{"childCategoryName":"Suku Cadang Mesin","childCategoryUrl":"//www.lazada.co.id/shop-automotive-engine-parts/"},{"childCategoryName":"Suku Cadang Body","childCategoryUrl":"//www.lazada.co.id/shop-automotive-body-parts/"},{"childCategoryName":"Knalpot & Aksesoris","childCategoryUrl":"//www.lazada.co.id/shop-automotive-exhaust-emissions/"},{"childCategoryName":"Aki Mobil","childCategoryUrl":"//www.lazada.co.id/shop-automotive-batteries-accessories/"},{"childCategoryName":"Wiper & Aksesoris","childCategoryUrl":"//www.lazada.co.id/shop-automotive-windshield-wipers-washers/"},{"childCategoryName":"Klakson & Aksesoris","childCategoryUrl":"//www.lazada.co.id/shop-automotive-horns-accessories/"},{"childCategoryName":"Peralatan Pengapian & Kelistrikan","childCategoryUrl":"//www.lazada.co.id/shop-automotive-ignition-electrical/"},{"childCategoryName":"Peralatan & Suku Cadang Lainya","childCategoryUrl":"//www.lazada.co.id/shop-automotive-trim/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_12_2">
                <a href="//www.lazada.co.id/aksesoris-interior-mobil/">
                    <span>Aksesoris Interior Mobil</span>
                </a>
                        <script type="text" class="J_data_11_1">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Penyegar & Pewangi Kendaraan","childCategoryUrl":"//www.lazada.co.id/pengharum-mobil/"},{"childCategoryName":"Jok & Trim","childCategoryUrl":"//www.lazada.co.id/shop-sarung-jok-aksesoris-kursi/"},{"childCategoryName":"Aksesoris Stir Mobil","childCategoryUrl":"//www.lazada.co.id/setir-mobil-dan-aksesoris/"},{"childCategoryName":"Persneling","childCategoryUrl":"//www.lazada.co.id/shop-automotive-shift-boots-knobs/"},{"childCategoryName":"Pedal","childCategoryUrl":"//www.lazada.co.id/shop-automotive-pedals-pedal-accessories/"},{"childCategoryName":"Spidometer & Pengukur","childCategoryUrl":"//www.lazada.co.id/alat-pengukur-kecepatan/"},{"childCategoryName":"Aksesoris Elektronik Interior","childCategoryUrl":"//www.lazada.co.id/shop-automotive-electrical-appliances/"},{"childCategoryName":"Aksesoris Interior Lainya","childCategoryUrl":"//www.lazada.co.id/shop-automotive-consoles-organizers/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_12_3">
                <a href="//www.lazada.co.id/aksesoris-eksterior-mobil/">
                    <span>Aksesoris Exterior Mobil</span>
                </a>
                        <script type="text" class="J_data_11_2">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Sarung Mobil","childCategoryUrl":"//www.lazada.co.id/penutup-mobil/"},{"childCategoryName":"Stiker & Emblems","childCategoryUrl":"//www.lazada.co.id/shop-stiker/"},{"childCategoryName":"Lis & Garnis","childCategoryUrl":"//www.lazada.co.id/shop-automotive-chrome-trim-accessories/"},{"childCategoryName":"Penutup Pelat Nomer","childCategoryUrl":"//www.lazada.co.id/shop-automotive-license-plate-covers-frames/"},{"childCategoryName":"Aksesoris Serbaguna","childCategoryUrl":"//www.lazada.co.id/shop-manajemen-kargo/"},{"childCategoryName":"Kaca Angin, Deflektor & Talang Air","childCategoryUrl":"//www.lazada.co.id/pelindung-dan-talang-air-mobil/"},{"childCategoryName":"Kaca & Aksesoris","childCategoryUrl":"//www.lazada.co.id/shop-automotive-exterior-mirrors/"},{"childCategoryName":"Spoiler, Sayap & Body Kit","childCategoryUrl":"//www.lazada.co.id/shop-automotive-spoilers-wings-styling-kits/"},{"childCategoryName":"Aksesoris Offroad","childCategoryUrl":"//www.lazada.co.id/shop-automotive-body-armor/"},{"childCategoryName":"Aksesoris Exterior Lainya","childCategoryUrl":"//www.lazada.co.id/shop-automotive-trailer-accessories/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_12_4">
                <a href="//www.lazada.co.id/shop-elektronik/">
                    <span>Kamera Mobil, Audio &amp; Video</span>
                </a>
                        <script type="text" class="J_data_11_3">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Kamera Mobil & Aksesoris","childCategoryUrl":"//www.lazada.co.id/shop-kamera-mobil/"},{"childCategoryName":"Headunit","childCategoryUrl":"//www.lazada.co.id/shop-car-video-in-dash-navigation/"},{"childCategoryName":"Spiker","childCategoryUrl":"//www.lazada.co.id/shop-car-audio-speakers/"},{"childCategoryName":"Subwoofer","childCategoryUrl":"//www.lazada.co.id/shop-car-audio-subwoofers/"},{"childCategoryName":"Power, amplifier & Kapasitor Bank","childCategoryUrl":"//www.lazada.co.id/shop-car-audio-equalizers/"},{"childCategoryName":"GPS","childCategoryUrl":"//www.lazada.co.id/shop-motors-gps/"},{"childCategoryName":"Video, TV Aksesoris mobil","childCategoryUrl":"//www.lazada.co.id/shop-car-video/"},{"childCategoryName":"Aksesoris Audio & Video Lainya","childCategoryUrl":"//www.lazada.co.id/shop-audio-video-accessories/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_12_5">
                <a href="//www.lazada.co.id/shop-perawatan-mobil/">
                    <span>Perawatan &amp; Pengkilat Mobil</span>
                </a>
                        <script type="text" class="J_data_11_4">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Penyegar & Pewangi Kendaraan","childCategoryUrl":"//www.lazada.co.id/pengharum-mobil/"},{"childCategoryName":"Pengkilat & Detailing Bodi","childCategoryUrl":"//www.lazada.co.id/shop-automotive-polishing-waxing-kits/"},{"childCategoryName":"Pelapis & Pembersih Kaca","childCategoryUrl":"//www.lazada.co.id/glass-care/"},{"childCategoryName":"Kompon & Penghilang Baret","childCategoryUrl":"//www.lazada.co.id/shop-automotive-polishing-rubbing-compounds/"},{"childCategoryName":"Cat Mobil","childCategoryUrl":"//www.lazada.co.id/shop-automotive-paints-primers/"},{"childCategoryName":"Perawatan Ban & Velg","childCategoryUrl":"//www.lazada.co.id/shop-automotive-tire-wheel-care/"},{"childCategoryName":"Perawatan Interior","childCategoryUrl":"//www.lazada.co.id/interior-care/"},{"childCategoryName":"Paket Perawatan Mobil","childCategoryUrl":"//www.lazada.co.id/shop-paket-perawatan-mobil/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_12_6">
                <a href="//www.lazada.co.id/roda-dan-ban/">
                    <span>Ban &amp; Velg Mobil</span></a>
                        <script type="text" class="J_data_11_5">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Velg","childCategoryUrl":"//www.lazada.co.id/jual-roda/"},{"childCategoryName":"Ban","childCategoryUrl":"//www.lazada.co.id/jual-ban/"},{"childCategoryName":"Aksesoris Velg & Ban","childCategoryUrl":"//www.lazada.co.id/jual-aksesoris-roda-suku-cadang/"},{"childCategoryName":"Peralatan Velg & Ban","childCategoryUrl":"//www.lazada.co.id/shop-tire-parts-air-compressors-inflators/"},{"childCategoryName":"Servis & Pemasangan Velg, Ban","childCategoryUrl":"//www.lazada.co.id/shop-paket-ban-pelek/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_12_7">
                <a href="//www.lazada.co.id/oli-dan-pelumas/">
                    <span>Oli &amp; Cairan Mobil</span>
                </a>
                        <script type="text" class="J_data_11_6">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Oli Mesin Mobil","childCategoryUrl":"//www.lazada.co.id/shop-automotive-oils/"},{"childCategoryName":"Aditif & Penguat Bensin","childCategoryUrl":"//www.lazada.co.id/shop-automotive-auto-oils-fluids-additives/"},{"childCategoryName":"Pendingin Mesin","childCategoryUrl":"//www.lazada.co.id/shop-automotive-antifreezes-coolants/"},{"childCategoryName":"Pembersih Mesin","childCategoryUrl":"//www.lazada.co.id/shop-automotive-cleaners/"},{"childCategoryName":"Oli Powersteering","childCategoryUrl":"//www.lazada.co.id/shop-automotive-power-steering-fluids/"},{"childCategoryName":"Cairan & Oli Lainnya","childCategoryUrl":"//www.lazada.co.id/shop-automotive-greases-lubricants/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_12_8">
                <a href="//www.lazada.co.id/shop-motorcycle-riding-gear/">
                    <span>Perlengkapan Berkendara &amp; Helm</span>
                </a>
                        <script type="text" class="J_data_11_7">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Helm","childCategoryUrl":"//www.lazada.co.id/helmets-automotive/"},{"childCategoryName":"Jaket & Pelindung","childCategoryUrl":"//www.lazada.co.id/jackets/"},{"childCategoryName":"Sarung Tangan","childCategoryUrl":"//www.lazada.co.id/shop-motorcycle-riding-gear-gloves/"},{"childCategoryName":"Sepatu & Boot","childCategoryUrl":"//www.lazada.co.id/shop-motorcycle-riding-gear-footwear/"},{"childCategoryName":"Masker & Pelindung Wajah","childCategoryUrl":"//www.lazada.co.id/shop-motorcycle-riding-gear-face-masks/"},{"childCategoryName":"Kacamata Angin","childCategoryUrl":"//www.lazada.co.id/shop-motorcycle-riding-gear-eyewear/"},{"childCategoryName":"Peralatan Hujan","childCategoryUrl":"//www.lazada.co.id/shop-pakaian-hujan/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_12_9">
                <a href="//www.lazada.co.id/shop-motorcycle-parts-spares/">
                    <span>Suku Cadang &amp; Peralatan Motor</span>
                </a>
                        <script type="text" class="J_data_11_8">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Bohlam, LED & Rumah Lampu","childCategoryUrl":"//www.lazada.co.id/shop-penerangan/"},{"childCategoryName":"Rem & Suspensi","childCategoryUrl":"//www.lazada.co.id/shop-motorcycle-brakes-suspension/"},{"childCategoryName":"Knalpot & Aksesoris","childCategoryUrl":"//www.lazada.co.id/moto-knalpot-system-pembuangan/"},{"childCategoryName":"Aki Motor & Aksesoris","childCategoryUrl":"//www.lazada.co.id/shop-moto-batteries-accessories/"},{"childCategoryName":"Kaca / Cermin","childCategoryUrl":"//www.lazada.co.id/shop-motorcycle-mirrors/"},{"childCategoryName":"Filter Motor","childCategoryUrl":"//www.lazada.co.id/shop-saringan-udara/"},{"childCategoryName":"Suku Cadang Bodi & Rangka","childCategoryUrl":"//www.lazada.co.id/shop-motorcycle-body-frame/"},{"childCategoryName":"Suku Cadang Mesin","childCategoryUrl":"//www.lazada.co.id/shop-motorcycle-drivetrain-transmission/"},{"childCategoryName":"Busi","childCategoryUrl":"//www.lazada.co.id/shop-busi-motor/"},{"childCategoryName":"Suku Cadang Motor Lainnya","childCategoryUrl":"//www.lazada.co.id/shop-motorcycle-stands-accessories/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_12_10">
                <a href="//www.lazada.co.id/shop-motorcycle-exterior-accessories/">
                    <span>Aksesoris &amp; Elektronik Motor</span>
                </a>
                        <script type="text" class="J_data_11_9">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Sarung Jok","childCategoryUrl":"//www.lazada.co.id/shop-sarung-jok/"},{"childCategoryName":"Stiker & Emblem","childCategoryUrl":"//www.lazada.co.id/shop-stiker-emblem/"},{"childCategoryName":"Pengukur","childCategoryUrl":"//www.lazada.co.id/shop-indikator/"},{"childCategoryName":"Aksesoris Elektronik","childCategoryUrl":"//www.lazada.co.id/shop-motorcycle-electronics/"},{"childCategoryName":"Pelindung Plat Nomor","childCategoryUrl":"//www.lazada.co.id/shop-frame-plat-nomor/"},{"childCategoryName":"Sarung Motor","childCategoryUrl":"//www.lazada.co.id/shop-motorcycle-covers/"},{"childCategoryName":"Windshield & Aksesoris","childCategoryUrl":"//www.lazada.co.id/shop-motorcycle-windshields-accessories/"},{"childCategoryName":"Bagasi Penyimpanan & Bantalan","childCategoryUrl":"//www.lazada.co.id/shop-motorcycle-luggage-saddlebags/"},{"childCategoryName":"Aksesoris & Elektronik Motor Lainny","childCategoryUrl":"//www.lazada.co.id/shop-motorcycle-racks/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_12_11">
                <a href="//www.lazada.co.id/shop-motorcycle-oils-fluids/">
                    <span>Ban, Velg, Oli &amp; Cairan Motor</span>
                </a>
                        <script type="text" class="J_data_11_10">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Oli Mesin Motor","childCategoryUrl":"//www.lazada.co.id/shop-oli-mesin/"},{"childCategoryName":"Oli Rem Motor","childCategoryUrl":"//www.lazada.co.id/shop-motorcycle-brake-fluid/"},{"childCategoryName":"Oli Transmisi Motor","childCategoryUrl":"//www.lazada.co.id/shop-oligirboks/"},{"childCategoryName":"Pendingin Motor","childCategoryUrl":"//www.lazada.co.id/shop-coolant/"},{"childCategoryName":"Aditif & Penguat Bensin Motor","childCategoryUrl":"//www.lazada.co.id/shop-pembersih/"},{"childCategoryName":"Pelumas Motor","childCategoryUrl":"//www.lazada.co.id/shop-pelumas-dan-gemuk/"},{"childCategoryName":"Ban & Velg Motor","childCategoryUrl":"//www.lazada.co.id/jual-roda-ban-motor/"},{"childCategoryName":"Oli & Cairan Motor Lainnya","childCategoryUrl":"//www.lazada.co.id/shop-oli-shock-breaker/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_12_12">
                <a href="//www.lazada.co.id/mobil-motor/">
                    <span>Kendaraan</span>
                </a>
                        <script type="text" class="J_data_11_11">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Mobil","childCategoryUrl":"//www.lazada.co.id/shop-mobil/"},{"childCategoryName":"Motor","childCategoryUrl":"//www.lazada.co.id/shop-sepeda-motor-skuter/"}]
                        </script>
            </li>
        </ul>
    </ul>
</div>
  </div>
            </div>
        </div>
        <nav class="lzd-menu-labels" data-spm="menu">
            <a class="lzd-menu-labels-item" href="//pages.lazada.co.id/wow/i/id/LandingPage/lazmall?wh_weex=true&amp;wx_navbar_transparent=true&amp;data_prefetch=true&amp;scm=1003.4.icms-zebra-5000383-2586266.OTHER_6502207795_7692459">
                <span class="lzd-site-nav-menu-iconfont lzd-menu-labels-item-icon">
                    <img alt="LazMall" class="lzd-site-nav-menu-iconfont-img" src="https://laz-img-cdn.alicdn.com/images/ims-web/TB1gNcMWBr0gK0jSZFnXXbRRXXa.png">
                </span>
                <!--<i class="lzd-site-nav-menu-iconfont lzd-menu-labels-item-icon lazada-ic-channel-LazMall">&#xe629;</i>-->
                <span class="lzd-menu-labels-item-text">LazMall</span>
            </a>
            <a class="lzd-menu-labels-item" href="//pages.lazada.co.id/wow/i/id/digitalgoods/home?hybrid=1&amp;scm=1003.4.icms-zebra-5000383-2586266.OTHER_6502207798_7692459">
                <span class="lzd-site-nav-menu-iconfont lzd-menu-labels-item-icon">
                    <img alt="Pulsa &amp;" class="lzd-site-nav-menu-iconfont-img" src="https://laz-img-cdn.alicdn.com/images/ims-web/TB1Je4vhRr0gK0jSZFnXXbRRXXa.png">
                </span>
                <!--<i class="lzd-site-nav-menu-iconfont lzd-menu-labels-item-icon lazada-ic-channel-MobileTop1">&#xe768;</i>-->
                        <span class="lzd-menu-labels-item-text">Pulsa &amp; Tagihan</span>
            </a>
            <a class="lzd-menu-labels-item" href="//pages.lazada.co.id/wow/gcp/route/lazada/id/upr_1000345_lazada/channel/id/upr-router/id_upr?hybrid=1&amp;data_prefetch=true&amp;at_iframe=1&amp;wh_pid=/lazada/channel/id/all-promo/mcp-ush&amp;scm=1003.4.icms-zebra-5000383-2586266.OTHER_6502207802_7692459&amp;prefetch_replace=1">
                <span class="lzd-site-nav-menu-iconfont lzd-menu-labels-item-icon">
                    <img alt="Voucher &amp;" class="lzd-site-nav-menu-iconfont-img" src="https://laz-img-cdn.alicdn.com/images/ims-web/TB1x8lvhHj1gK0jSZFuXXcrHpXa.png">
                </span>
                <!--<i class="lzd-site-nav-menu-iconfont lzd-menu-labels-item-icon lazada-ic-channel-Vouchers">&#xe76a;</i>-->
                        <span class="lzd-menu-labels-item-text">Voucher &amp; Diskon</span>
            </a>
            <a class="lzd-menu-labels-item" href="//www.lazada.co.id/blog/?scm=1003.4.icms-zebra-5000383-2586266.OTHER_6502207806_7692459">
                <span class="lzd-site-nav-menu-iconfont lzd-menu-labels-item-icon">
                    <img alt="LazBlog" class="lzd-site-nav-menu-iconfont-img" src="https://icms-image.slatic.net/images/ims-web/9174453f-455e-4e30-87d2-bd90239e6994.png">
                </span>
                <!--<i class="lzd-site-nav-menu-iconfont lzd-menu-labels-item-icon lazada-ic-Categories">&#xe765;</i>-->
                <span class="lzd-menu-labels-item-text">LazBlog</span>
            </a>
        </nav>
    </div>
</div>
  </div>
                </div>
              <div class="lzd-nav-cart">
                <a href="//cart.lazada.co.id/cart?scm=1003.4.icms-zebra-5001424-2591709.OTHER_5196131744_2267383" data-spm="dcart"><span class="cart-icon"></span>
                <span class="cart-num" id="topActionCartNumber"></span></a>
              </div>
                <div class="lzd-header-banner" id="topActionLiveUpBanner">
                </div>
          </div>
        </div>
      </div>
  <div class="mui-zebra-module" id="J_icms-5000527-1511531232618" data-module-id="icms-5000527-1511531232618" data-version="5.0.83" data-spm="icms-5000527-1511531232618">
<div class="lzd-site-nav-menu lzd-site-nav-menu-active" data-mod-name="@ali/lzdmod-site-menu-nav-pc/pc/index" data-config="{}">
    <div class="lzd-site-menu-nav-container">
        <div class="lzd-site-menu-nav-category">
            <a href="<?php echo $urlPath ?>">
                <span class="lzd-site-menu-nav-category-text">Kategori</span>
            </a>
            <div class="lzd-site-menu-nav-menu">
  <div class="mui-zebra-module" id="J_icms-5000518-1511530513406" data-module-id="icms-5000518-1511530513406" data-version="5.0.51" data-spm="icms-5000518-1511530513406">
<div class="lzd-site-nav-menu-dropdown" data-mod-name="@ali/lzdmod-site-menu-pc/pc/index" data-config="{}">
    <ul class="lzd-site-menu-root" data-spm="cate">
         <li class="lzd-site-menu-root-item" id="Level_1_Category_No1">
            <a> 
                        <span>Peralatan Elektronik</span>
            </a>
         </li>    
         <li class="lzd-site-menu-root-item" id="Level_1_Category_No2">
            <a> 
                        <span>Aksesoris Elektronik</span>
            </a>
         </li>    
         <li class="lzd-site-menu-root-item" id="Level_1_Category_No3">
            <a> 
                        <span>Fashion &amp; Aksesoris Wanita</span>
            </a>
         </li>    
         <li class="lzd-site-menu-root-item" id="Level_1_Category_No4">
            <a> 
                        <span>Fashion &amp; Aksesoris Pria</span>
            </a>
         </li>    
         <li class="lzd-site-menu-root-item" id="Level_1_Category_No5">
            <a> 
                        <span>Fashion &amp; Aksesoris Anak</span>
            </a>
         </li>    
         <li class="lzd-site-menu-root-item" id="Level_1_Category_No6">
            <a> 
                        <span>Kesehatan &amp; Kecantikan</span>
            </a>
         </li>    
         <li class="lzd-site-menu-root-item" id="Level_1_Category_No7">
            <a> 
                    <span>Bayi &amp; Mainan</span>
            </a>
         </li>    
         <li class="lzd-site-menu-root-item" id="Level_1_Category_No8">
            <a> 
                        <span>TV &amp; Elektronik Rumah</span>
            </a>
         </li>    
         <li class="lzd-site-menu-root-item" id="Level_1_Category_No9">
            <a> 
                        <span>Keperluan Rumah &amp; Gaya Hidup</span>
            </a>
         </li>    
         <li class="lzd-site-menu-root-item" id="Level_1_Category_No10">
            <a> 
                        <span>Kebutuhan Rumah Tangga</span>
            </a>
         </li>    
         <li class="lzd-site-menu-root-item" id="Level_1_Category_No11">
            <a> 
                        <span>Olahraga &amp; Outdoor</span>
            </a>
         </li>    
         <li class="lzd-site-menu-root-item" id="Level_1_Category_No12">
            <a> 
                    <span>Otomotif</span>
            </a>
         </li>    
        <ul class="lzd-site-menu-sub Level_1_Category_No1" data-spm="cate_1">
            <li class="sub-item-remove-arrow" data-cate="cate_1_1">
                <a href="//www.lazada.co.id/beli-handphone">
                    <span>Handphone</span>
                </a>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_1_2">
                <a href="//www.lazada.co.id/shop-beli-laptop/">
                    <span>Laptop</span>
                </a>
                        <script type="text" class="J_data_0_1">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Laptop Consumer","childCategoryUrl":"//www.lazada.co.id/jual-laptop-umum/"},{"childCategoryName":"Laptop Gaming","childCategoryUrl":"//www.lazada.co.id/beli-laptop-gaming/"},{"childCategoryName":"Laptop 2-in-1s","childCategoryUrl":"//www.lazada.co.id/beli-laptop-2-in-1/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_1_3">
                <a href="//www.lazada.co.id/beli-komputer/">
                    <span>Desktop</span>
                </a>
                        <script type="text" class="J_data_0_2">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"PC Gaming","childCategoryUrl":"//www.lazada.co.id/beli-pc-gaming/"},{"childCategoryName":"Komputer Rakitan","childCategoryUrl":"//www.lazada.co.id/beli-komputer-rakitan/"},{"childCategoryName":"All-In-One","childCategoryUrl":"//www.lazada.co.id/beli-pc-all-in-one/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_1_4"><a href="//www.lazada.co.id/beli-kamera/">
                    <span>Kamera</span>
                </a>
                        <script type="text" class="J_data_0_3">[{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"DSLR","childCategoryUrl":"//www.lazada.co.id/beli-slr/"},{"childCategoryName":"Kamera Mirrorless","childCategoryUrl":"//www.lazada.co.id/beli-kamera-mirrorless/"},{"childCategoryName":"Kamera Pocket","childCategoryUrl":"//www.lazada.co.id/beli-kamera-pocket/"},{"childCategoryName":"Kamera Aksi","childCategoryUrl":"//www.lazada.co.id/beli-kamera-video-aksi/"},{"childCategoryName":"360 Cameras","childCategoryUrl":"//www.lazada.co.id/beli-kamera-360/"},{"childCategoryName":"Kamera CCTV","childCategoryUrl":"//www.lazada.co.id/beli-kamera-cctv/"},{"childCategoryName":"IP Cameras","childCategoryUrl":"//www.lazada.co.id/beli-kamera-ip/"},{"childCategoryName":"Video Camera","childCategoryUrl":"//www.lazada.co.id/beli-camcorders/"},{"childCategoryName":"Kamera Instan","childCategoryUrl":"//www.lazada.co.id/beli-kamera-instan/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_1_5">
                <a href="//www.lazada.co.id/shop-gaming-ketuajepeol/">
                    <span>Game Console</span>
                </a>
                        <script type="text" class="J_data_0_4">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Gaming Ketuajepeol","childCategoryUrl":"//www.lazada.co.id/shop-permainan-ketuajepeol/"},{"childCategoryName":"Permainan Ketuajepeol","childCategoryUrl":"//www.lazada.co.id/shop-game-ketuajepeol/"},{"childCategoryName":"Pengontrol Game Ketuajepeol","childCategoryUrl":"//www.lazada.co.id/shop-pengontrol-game-ketuajepeol/"},{"childCategoryName":"Ketuajepeol Pelindung Penutup","childCategoryUrl":"//www.lazada.co.id/shop-ketuajepeolpelindung-penutup/"},{"childCategoryName":"Aksesoris Game Ketuajepeol","childCategoryUrl":"//www.lazada.co.id/shop-aksesoris-game-ketuajepeol/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_1_6">
                <a href="//www.lazada.co.id/beli-gadget/">
                    <span>Gadget</span>
                </a>
                        <script type="text" class="J_data_0_5">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Rokok Elektrik","childCategoryUrl":"//www.lazada.co.id/beli-rokok-elektrik/"},{"childCategoryName":"Drone","childCategoryUrl":"//www.lazada.co.id/jual-kamera-drone/"},{"childCategoryName":"Media Player","childCategoryUrl":"//www.lazada.co.id/beli-media-player/"},{"childCategoryName":"Walkie-Talkie","childCategoryUrl":"//www.lazada.co.id/jual-walkie-talkie/"}]
                        </script>
            </li>
            <li class="sub-item-remove-arrow" data-cate="cate_1_7">
                <a href="//www.lazada.co.id/beli-tablet-2">
                    <span>Tablet</span>
                </a>
            </li>
        </ul>
        <ul class="lzd-site-menu-sub Level_1_Category_No2" data-spm="cate_2">
            <li class="lzd-site-menu-sub-item" data-cate="cate_2_1">
                <a href="//www.lazada.co.id/beli-aksesori-handphone">
                    <span>Aksesoris Handphone</span>
                </a>
                        <script type="text" class="J_data_1_0">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Powerbank","childCategoryUrl":"//www.lazada.co.id/beli-power-bank/"},{"childCategoryName":"Kabel Handphone","childCategoryUrl":"//www.lazada.co.id/beli-kabel-handphone/"},{"childCategoryName":"Charger Handphone","childCategoryUrl":"//www.lazada.co.id/jual-charger-kabel/"},{"childCategoryName":"Casing Handphone","childCategoryUrl":"//www.lazada.co.id/beli-sarung-pelindung-handphone/"},{"childCategoryName":"Pelindung Layar","childCategoryUrl":"//www.lazada.co.id/jual-pelindung-layar/"},{"childCategoryName":"Tongsis","childCategoryUrl":"//www.lazada.co.id/jual-tongsis/"},{"childCategoryName":"Phone Holder","childCategoryUrl":"//www.lazada.co.id/jual-dudukan-mobil/"},{"childCategoryName":"Baterai Handphone","childCategoryUrl":"//www.lazada.co.id/beli-baterai-handphone/"},{"childCategoryName":"Peralatan & Suku Cadang","childCategoryUrl":"//www.lazada.co.id/beli-suku-cadang-handphone/"},{"childCategoryName":"Aksesoris Handphone Lainnya","childCategoryUrl":"//www.lazada.co.id/shop-aksesori-ponsel/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_2_2">
                <a href="//www.lazada.co.id/beli-aksesori-komputer/">
                    <span>Aksesoris Komputer</span>
                </a>
                        <script type="text" class="J_data_1_1">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Mouse","childCategoryUrl":"//www.lazada.co.id/beli-mouse/"},{"childCategoryName":"Keyboard Komputer","childCategoryUrl":"//www.lazada.co.id/beli-keyboard/"},{"childCategoryName":"Monitor","childCategoryUrl":"//www.lazada.co.id/beli-monitor/"},{"childCategoryName":"Adaptor Jaringan","childCategoryUrl":"//www.lazada.co.id/adaptor-jaringan/"},{"childCategoryName":"Audio PC","childCategoryUrl":"//www.lazada.co.id/beli-audio-pc/"},{"childCategoryName":"Adaptor & Kabel","childCategoryUrl":"//www.lazada.co.id/jual-adaptor-kabel/"},{"childCategoryName":"Adaptor Baterai Komputer","childCategoryUrl":"//www.lazada.co.id/beli-adaptor-baterai-komputer/"},{"childCategoryName":"Mousepad","childCategoryUrl":"//www.lazada.co.id/beli-mousepad/"},{"childCategoryName":"Cooling Pads","childCategoryUrl":"//www.lazada.co.id/beli-alas-pendingin/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_2_3">
                <a href="//www.lazada.co.id/shop-audio/">
                    <span>Audio</span>
                </a>
                        <script type="text" class="J_data_1_2">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Headphone & Headset","childCategoryUrl":"//www.lazada.co.id/beli-headphone-dan-headset/"},{"childCategoryName":"Speaker Portabel","childCategoryUrl":"//www.lazada.co.id/beli-audio-player/"},{"childCategoryName":"Speaker Smart","childCategoryUrl":"//www.lazada.co.id/beli-speaker-smart/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_2_4">
                <a href="//www.lazada.co.id/shop-perangkat-pintar/">
                    <span>Aksesoris Berteknologi</span>
                </a>
                        <script type="text" class="J_data_1_3">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Smartwatch","childCategoryUrl":"//www.lazada.co.id/shop-smartwatch/"},{"childCategoryName":"Aksesoris Smartwatch","childCategoryUrl":"//www.lazada.co.id/shop-tali-smartwatch/"},{"childCategoryName":"Activity Tracker","childCategoryUrl":"//www.lazada.co.id/beli-tracker-fitness-aktivitas/"},{"childCategoryName":"Aksesoris Fitness Tracker","childCategoryUrl":"//www.lazada.co.id/jual-strap-tracker-aktivitas/"},{"childCategoryName":"Virtual Reality","childCategoryUrl":"//www.lazada.co.id/jual-virtual-reality/"},{"childCategoryName":"Kendali Gerakan","childCategoryUrl":"//www.lazada.co.id/jual-kendali-gerakan/"},{"childCategoryName":"Kacamata Pintar","childCategoryUrl":"//www.lazada.co.id/beli-smart-glasses/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_2_5">
                <a href="//www.lazada.co.id/beli-aksesoris-2/">
                    <span>Aksesoris Kamera</span>
                </a>
                        <script type="text" class="J_data_1_4">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Tripod &Monopod","childCategoryUrl":"//www.lazada.co.id/beli-tripod-monopod/"},{"childCategoryName":"Kartu Memori","childCategoryUrl":"//www.lazada.co.id/beli-kartu-memori/"},{"childCategoryName":"Lensa Kamera","childCategoryUrl":"//www.lazada.co.id/beli-lensa-kamera/"},{"childCategoryName":"Flash","childCategoryUrl":"//www.lazada.co.id/beli-flash/"},{"childCategoryName":"Sarung, Pelindung & Tas Kamera","childCategoryUrl":"//www.lazada.co.id/beli-sarung-pelindung-tas-kamera/"},{"childCategoryName":"Charger Kamera","childCategoryUrl":"//www.lazada.co.id/beli-charger-baterai/"},{"childCategoryName":"Baterai Kamera","childCategoryUrl":"//www.lazada.co.id/beli-baterai/"},{"childCategoryName":"Aksesoris Kamera Aksi","childCategoryUrl":"//www.lazada.co.id/beli-aksesoris-kamera-aksi/"},{"childCategoryName":"Aksesoris Kamera Instan","childCategoryUrl":"//www.lazada.co.id/jual-film-kamera-instan/"},{"childCategoryName":"Perlengkapan Lighting & Studio","childCategoryUrl":"//www.lazada.co.id/beli-perlengkapan-lighting-studio/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_2_6">
                <a href="//www.lazada.co.id/shop-penyimpanan-data/">
                    <span>Penyimpanan Data</span>
                </a>
                        <script type="text" class="J_data_1_5">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Flash Drive","childCategoryUrl":"//www.lazada.co.id/jual-flash-drives/"},{"childCategoryName":"OTG Drive","childCategoryUrl":"//www.lazada.co.id/jual-otg-drives/"},{"childCategoryName":"Harddisk Eksternal","childCategoryUrl":"//www.lazada.co.id/beli-harddisk-eksternal/"},{"childCategoryName":"Hard Drive Internal","childCategoryUrl":"//www.lazada.co.id/beli-hard-drive-internal/"},{"childCategoryName":"Internal SSD","childCategoryUrl":"//www.lazada.co.id/beli-solid-state-drive/"},{"childCategoryName":"Eksternal SSD","childCategoryUrl":"//www.lazada.co.id/beli-external-solid-state-drive/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_2_7">
                <a href="//www.lazada.co.id/beli-printers/">
                    <span>Printer</span>
                </a>
                        <script type="text" class="J_data_1_6">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Printer","childCategoryUrl":"//www.lazada.co.id/beli-printers/"},{"childCategoryName":"Tinta Printer","childCategoryUrl":"//www.lazada.co.id/tinta-printer/"},{"childCategoryName":"Printer 3D","childCategoryUrl":"//www.lazada.co.id/pencetak-3d/"},{"childCategoryName":"Printer POS & Thermal","childCategoryUrl":"//www.lazada.co.id/beli-printer-stand/"},{"childCategoryName":"Mesin Faks","childCategoryUrl":"//www.lazada.co.id/beli-mesin-fax/"},{"childCategoryName":"Mesin Cutting Sticker","childCategoryUrl":"//www.lazada.co.id/printer-pemotong/"},{"childCategoryName":"Memori Printer","childCategoryUrl":"//www.lazada.co.id/modul-memori-printer/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_2_8">
                <a href="//www.lazada.co.id/beli-aksesori-handphone/">
                    <span>Aksesoris Tablet</span>
                </a>
                        <script type="text" class="J_data_1_7">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Casing Tablet","childCategoryUrl":"//www.lazada.co.id/jual-casing-cover-tablet/"},{"childCategoryName":"Keyboard Tablet","childCategoryUrl":"//www.lazada.co.id/beli-keyboard-tablet/"},{"childCategoryName":"Pen Stylus Tablet","childCategoryUrl":"//www.lazada.co.id/beli-pen-stylus-tablet/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_2_9">
                <a href="//www.lazada.co.id/beli-komponen-komputer/">
                    <span>Komponen Komputer</span>
                </a>
                        <script type="text" class="J_data_1_8">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"RAM","childCategoryUrl":"//www.lazada.co.id/beli-ram/"},{"childCategoryName":"Motherboard","childCategoryUrl":"//www.lazada.co.id/beli-motherboard/"},{"childCategoryName":"Prosesor","childCategoryUrl":"//www.lazada.co.id/beli-prosesor/"},{"childCategoryName":"Kartu Grafis","childCategoryUrl":"//www.lazada.co.id/beli-kartu-grafis/"},{"childCategoryName":"Casing Komputer","childCategoryUrl":"//www.lazada.co.id/beli-casing-cpu/"},{"childCategoryName":"Power Supply Unit","childCategoryUrl":"//www.lazada.co.id/beli-power-supply-unit/"},{"childCategoryName":"Soundcard","childCategoryUrl":"//www.lazada.co.id/soundcard/"},{"childCategoryName":"Front Panel","childCategoryUrl":"//www.lazada.co.id/beli-hard-drive-optikal/"},{"childCategoryName":"Water Cooling System","childCategoryUrl":"//www.lazada.co.id/beli-water-cooling-system/"}]
                        </script>
            </li>
        </ul>
        <ul class="lzd-site-menu-sub Level_1_Category_No3" data-spm="cate_3">
            <li class="lzd-site-menu-sub-item" data-cate="cate_3_1">
                <a href="//www.lazada.co.id/pakaian-wanita/">
                    <span>Pakaian Wanita</span>
                </a>
                        <script type="text" class="J_data_2_0">
                            [{"childCategoryName":"Jeans","childCategoryUrl":"//www.lazada.co.id/jeans-wanita/"},{"childCategoryName":"Dress","childCategoryUrl":"//www.lazada.co.id/gaun-wanita/"},{"childCategoryName":"Atasan","childCategoryUrl":"//www.lazada.co.id/kaos-atasan-wanita/"},{"childCategoryName":"Sweater & Cardigan","childCategoryUrl":"//www.lazada.co.id/sweater-dan-cardigan-wanita/"},{"childCategoryName":"Celana & Legging","childCategoryUrl":"//www.lazada.co.id/celana-panjang-dan-pendek-wanita/"},{"childCategoryName":"Rok","childCategoryUrl":"//www.lazada.co.id/rok-wanita/"},{"childCategoryName":"Jaket & Mantel","childCategoryUrl":"//www.lazada.co.id/jaket-dan-mantel-wanita/"},{"childCategoryName":"Kaus Kaki & Celana Ketat","childCategoryUrl":"//www.lazada.co.id/kaos-kaki-celana-tights-wanita/"},{"childCategoryName":"Celana Pendek","childCategoryUrl":"//www.lazada.co.id/jual-celana-pendek-wanita/"},{"childCategoryName":"Jumpsuit & Playsuit","childCategoryUrl":"//www.lazada.co.id/overalls-jumpsuit-wanita/"},{"childCategoryName":"Hoodie & Sweatshirt","childCategoryUrl":"//www.lazada.co.id/hoodie-sweatshirt-wanita/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_3_2">
                <a href="//www.lazada.co.id/baju-muslim-wanita/">
                    <span>Baju Muslim</span>
                </a>
                        <script type="text" class="J_data_2_1">
                            [{"childCategoryName":"Perlengkapan Shalat","childCategoryUrl":"//www.lazada.co.id/baju-muslim-wanita/"},{"childCategoryName":"Hijab","childCategoryUrl":"//www.lazada.co.id/hijab/"},{"childCategoryName":"Atasan Muslimah","childCategoryUrl":"//www.lazada.co.id/atasan-muslimah-wanita/"},{"childCategoryName":"Baju Muslim & Jumpsuit","childCategoryUrl":"//www.lazada.co.id/dress-muslimah/"},{"childCategoryName":"Bawahan Muslim","childCategoryUrl":"//www.lazada.co.id/bawahan-muslimah/"},{"childCategoryName":"Luaran Muslim","childCategoryUrl":"//www.lazada.co.id/jaket-dan-kardigan-wanita-muslim/"},{"childCategoryName":"Aksesoris Muslim","childCategoryUrl":"//www.lazada.co.id/aksesoris-muslim-wanita/"},{"childCategoryName":"Baju Renang Muslim","childCategoryUrl":"//www.lazada.co.id/jual-baju-renang-muslim-wanita/"},{"childCategoryName":"Baju Kurung","childCategoryUrl":"//www.lazada.co.id/jual-baju-kurung-wanita/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_3_3">
                <a href="//www.lazada.co.id/lingerie-baju-tidur/">
                    <span>Lingerie, Baju Tidur &amp; Santai</span>
                </a>
                        <script type="text" class="J_data_2_2">
                            [{"childCategoryName":"Bra","childCategoryUrl":"//www.lazada.co.id/bra-wanita/"},{"childCategoryName":"Celana Dalam","childCategoryUrl":"//www.lazada.co.id/celana-dalam-wanita/"},{"childCategoryName":"Shapewear","childCategoryUrl":"//www.lazada.co.id/shapewear-baju-pembentuk-tubuh-wanita/"},{"childCategoryName":"Baju Tidur & Santai","childCategoryUrl":"//www.lazada.co.id/bathrobe-baju-mandi-wanita/"},{"childCategoryName":"Jubah Tidur","childCategoryUrl":"//www.lazada.co.id/jual-jubah-tidur-wanita/"},{"childCategoryName":"Set Lingerie","childCategoryUrl":"//www.lazada.co.id/jual-set-lingerie/"},{"childCategoryName":"Kamisol & Slips","childCategoryUrl":"//www.lazada.co.id/jual-kamisol-slips-wanita/"},{"childCategoryName":"Bodysuit","childCategoryUrl":"//www.lazada.co.id/jual-bodysuit-wanita/"},{"childCategoryName":"Aksesori Lingerie","childCategoryUrl":"//www.lazada.co.id/jual-aksesori-lingerie-wanita/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_3_4">
                <a href="//www.lazada.co.id/sepatu-wanita/">
                    <span>Sepatu Wanita</span>
                </a>
                        <script type="text" class="J_data_2_3">
                            [{"childCategoryName":"Sepatu Flat","childCategoryUrl":"//www.lazada.co.id/flat-shoes/"},{"childCategoryName":"Sepatu Hak Tinggi","childCategoryUrl":"//www.lazada.co.id/heels/"},{"childCategoryName":"Sneakers","childCategoryUrl":"//www.lazada.co.id/sneakers/"},{"childCategoryName":"Wedges","childCategoryUrl":"//www.lazada.co.id/wedges/"},{"childCategoryName":"Sepatu Boot","childCategoryUrl":"//www.lazada.co.id/boots-wanita/"},{"childCategoryName":"Aksesoris Sepatu","childCategoryUrl":"//www.lazada.co.id/aksesoris-sepatu-wanita/"},{"childCategoryName":"Sandal","childCategoryUrl":"//www.lazada.co.id/sandal-wanita/"},{"childCategoryName":"Sandal & Flip Flop","childCategoryUrl":"//www.lazada.co.id/sandal-jepit-wanita/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_3_5">
                <a href="//www.lazada.co.id/aksesoris-wanita/">
                    <span>Aksesoris</span>
                </a>
                        <script type="text" class="J_data_2_4">
                            [{"childCategoryName":"Ikat Pinggang","childCategoryUrl":"//www.lazada.co.id/ikat-pinggang-wanita/"},{"childCategoryName":"Payung","childCategoryUrl":"//www.lazada.co.id/payung-wanita/"},{"childCategoryName":"Topi","childCategoryUrl":"//www.lazada.co.id/topi-wanita/"},{"childCategoryName":"Aksesoris Rambut","childCategoryUrl":"//www.lazada.co.id/aksesoris-rambut/"},{"childCategoryName":"Scarf","childCategoryUrl":"//www.lazada.co.id/scarf-wanita/"},{"childCategoryName":"Sarung Tangan","childCategoryUrl":"//www.lazada.co.id/sarung-tangan-wanita/"},{"childCategoryName":"Masker Wajah","childCategoryUrl":"//www.lazada.co.id/shop-women-fabricmask/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_3_6">
                <a href="//www.lazada.co.id/tas-wanita/">
                    <span>Tas Wanita</span>
                </a>
                        <script type="text" class="J_data_2_5">
                            [{"childCategoryName":"Tas Ransel Wanita","childCategoryUrl":"//www.lazada.co.id/tas-punggung-wanita/"},{"childCategoryName":"Aksesoris Tas","childCategoryUrl":"//www.lazada.co.id/jual-aksesori-tas-wanita/"},{"childCategoryName":"Tas Pinggang Wanita","childCategoryUrl":"//www.lazada.co.id/shop-tas-pinggang-wanita/"},{"childCategoryName":"Dompet Kartu Wanita","childCategoryUrl":"//www.lazada.co.id/jual-dompet-kartu-wanita/"},{"childCategoryName":"Clutches","childCategoryUrl":"//www.lazada.co.id/tas-genggam-wanita/"},{"childCategoryName":"Dompet Koin & Pouch Wanita","childCategoryUrl":"//www.lazada.co.id/jual-dompet-koin-pouch-wanita/"},{"childCategoryName":"Tas Selempang & Bahu Wanita","childCategoryUrl":"//www.lazada.co.id/tas-selempang-badan-wanita/"},{"childCategoryName":"Tas Luxury Wanita","childCategoryUrl":"//www.lazada.co.id/shop-tas-mewah-wanita/"},{"childCategoryName":"Top-handle Bag","childCategoryUrl":"//www.lazada.co.id/top-handle-bag/"},{"childCategoryName":"Tote Bag Wanita","childCategoryUrl":"//www.lazada.co.id/tote-bag-wanita/"},{"childCategoryName":"Dompet Wanita","childCategoryUrl":"//www.lazada.co.id/jual-dompet-wanita/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_3_7">
                <a href="//www.lazada.co.id/beli-perhiasan-wanita/">
                    <span>Perhiasan Wanita</span>
                </a>
                        <script type="text" class="J_data_2_6">
                            [{"childCategoryName":"Perhiasan Fashion","childCategoryUrl":"//www.lazada.co.id/beli-wanita-perhiasan-fashion/"},{"childCategoryName":"Logam Berharga","childCategoryUrl":"//www.lazada.co.id/beli-wanita-logam-berharga/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_3_8">
                <a href="//www.lazada.co.id/beli-jam-tangan-wanita/">
                    <span>Jam Tangan Wanita</span>
                </a>
                        <script type="text" class="J_data_2_7">
                            [{"childCategoryName":"Aksesori","childCategoryUrl":"//www.lazada.co.id/shop-aksesori-jam-tangan-wanita/"},{"childCategoryName":"Jam Tangan Kasual Wanita","childCategoryUrl":"//www.lazada.co.id/beli-jam-tangan-kasual-wanita/"},{"childCategoryName":"Formal","childCategoryUrl":"//www.lazada.co.id/beli-jam-tangan-formal-wanita/"},{"childCategoryName":"Mewah","childCategoryUrl":"//www.lazada.co.id/shop-jam-tangan-mewah-wanita/"},{"childCategoryName":"Pra Dimiliki","childCategoryUrl":"//www.lazada.co.id/shop-pre-owned-jam-tangan-wanita/"},{"childCategoryName":"Jam Tangan Olahraga Wanita","childCategoryUrl":"//www.lazada.co.id/beli-jam-tangan-olahraga-wanita/"}]
                        </script>
            </li>
        </ul>
        <ul class="lzd-site-menu-sub Level_1_Category_No4" data-spm="cate_4">
            <li class="lzd-site-menu-sub-item" data-cate="cate_4_1">
                <a href="//www.lazada.co.id/pakaian-pria/">
                    <span>Pakaian Pria</span>
                </a>
                        <script type="text" class="J_data_3_0">
                            [{"childCategoryName":"Hoodie & Sweatshirt","childCategoryUrl":"//www.lazada.co.id/jual-hoodie-pria/"},{"childCategoryName":"Jaket dan Mantel","childCategoryUrl":"//www.lazada.co.id/jaket-dan-mantel-pria/"},{"childCategoryName":"Jeans","childCategoryUrl":"//www.lazada.co.id/jeans-pria/"},{"childCategoryName":"Celana","childCategoryUrl":"//www.lazada.co.id/celana-pendek-dan-panjang-pria/"},{"childCategoryName":"Polo Shirt","childCategoryUrl":"//www.lazada.co.id/polo-shirt-pria/"},{"childCategoryName":"Kemeja","childCategoryUrl":"//www.lazada.co.id/kemeja-pria/"},{"childCategoryName":"Celana Pendek","childCategoryUrl":"//www.lazada.co.id/jual-celana-pendek-pria/"},{"childCategoryName":"Kaus Kaki","childCategoryUrl":"//www.lazada.co.id/jual-kaus-kaki-pria/"},{"childCategoryName":"Jas & Blazer","childCategoryUrl":"//www.lazada.co.id/jas-pria/"},{"childCategoryName":"Sweater dan Kardigan","childCategoryUrl":"//www.lazada.co.id/sweater-dan-cardigan-pria/"},{"childCategoryName":"Baju Renang","childCategoryUrl":"//www.lazada.co.id/baju-renang-pria/"},{"childCategoryName":"T-Shirt & Kaos Dalam","childCategoryUrl":"//www.lazada.co.id/atasan-kasual-kaos-pria/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_4_2">
                <a href="//www.lazada.co.id/baju-muslim-pria/">
                    <span>Baju Muslim</span>
                </a>
                        <script type="text" class="J_data_3_1">[{"childCategoryName":"Jubah Muslim","childCategoryUrl":"//www.lazada.co.id/jubah-muslim-pria/"},{"childCategoryName":"Aksesoris Muslim","childCategoryUrl":"//www.lazada.co.id/aksesoris-muslim-pria/"},{"childCategoryName":"Baju Muslimin","childCategoryUrl":"//www.lazada.co.id/cekak-musang-pria/"},{"childCategoryName":"Kopiah","childCategoryUrl":"//www.lazada.co.id/shop-kopiah/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_4_3">
                <a href="//www.lazada.co.id/pakaian-dalam-dan-kaos-kaki-pria/">
                    <span>Pakaian Dalam</span>
                </a>
                        <script type="text" class="J_data_3_2">
                            [{"childCategoryName":"Celana Dalam","childCategoryUrl":"//www.lazada.co.id/celana-dalam-pria/"},{"childCategoryName":"Pakaian Tidur","childCategoryUrl":"//www.lazada.co.id/baju-tidur-pria/"},{"childCategoryName":"Boxer","childCategoryUrl":"//www.lazada.co.id/pakaian-dalam-boxer-pria/"},{"childCategoryName":"Thongs  & Lainnya","childCategoryUrl":"//www.lazada.co.id/pakaian-dalam-pria-thongs-lainnya/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_4_4">
                <a href="//www.lazada.co.id/sepatu-pria/">
                    <span>Sepatu Pria</span>
                </a>
                        <script type="text" class="J_data_3_3">
                            [{"childCategoryName":"Boots","childCategoryUrl":"//www.lazada.co.id/boots-pria/"},{"childCategoryName":"Flip Flop & Sandal","childCategoryUrl":"//www.lazada.co.id/sandal-jepit-pria/"},{"childCategoryName":"Sepatu Formal","childCategoryUrl":"//www.lazada.co.id/sepatu-pantofel/"},{"childCategoryName":"Aksesoris Sepatu","childCategoryUrl":"//www.lazada.co.id/aksesoris-sepatu-pria/"},{"childCategoryName":"Slip-On & Loafer","childCategoryUrl":"//www.lazada.co.id/jual-slip-on-loafer-pria/"},{"childCategoryName":"Sneakers","childCategoryUrl":"//www.lazada.co.id/sneakers-pria/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_4_5">
                <a href="//www.lazada.co.id/aksesoris-pria/">
                    <span>Aksesoris</span>
                </a>
                        <script type="text" class="J_data_3_4">
                            [{"childCategoryName":"Dasi","childCategoryUrl":"//www.lazada.co.id/aksesoris-dasi/"},{"childCategoryName":"Aksesoris Dasi Kupu-kupu","childCategoryUrl":"//www.lazada.co.id/aksesoris-dasi-kupu-kupu/"},{"childCategoryName":"Scarf","childCategoryUrl":"//www.lazada.co.id/syal-pria/"},{"childCategoryName":"Payung","childCategoryUrl":"//www.lazada.co.id/payung-pria/"},{"childCategoryName":"Ikat Pinggang","childCategoryUrl":"//www.lazada.co.id/ikat-pinggang-pria/"},{"childCategoryName":"Topi","childCategoryUrl":"//www.lazada.co.id/topi-pria/"},{"childCategoryName":"Sarung Tangan","childCategoryUrl":"//www.lazada.co.id/sarung-tangan-pria/"},{"childCategoryName":"Braces","childCategoryUrl":"//www.lazada.co.id/suspender-pria/"},{"childCategoryName":"Face Mask","childCategoryUrl":"//www.lazada.co.id/shop-masker-wajah-pria/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_4_6">
                <a href="//www.lazada.co.id/tas-pria/">
                    <span>Tas Pria</span>
                </a>
                        <script type="text" class="J_data_3_5">
                            [{"childCategoryName":"Tas Ransel Pria","childCategoryUrl":"//www.lazada.co.id/shop-ransel-pria/"},{"childCategoryName":"Tas Laptop Jinjing","childCategoryUrl":"//www.lazada.co.id/tas-kerja-pria/"},{"childCategoryName":"Dompet Kartu Pria","childCategoryUrl":"//www.lazada.co.id/jual-dompet-kartu-pria/"},{"childCategoryName":"Dompet Koin & Pouch Pria","childCategoryUrl":"//www.lazada.co.id/jual-dompet-koin-pouch-pria/"},{"childCategoryName":"Tas Selempang Pria","childCategoryUrl":"//www.lazada.co.id/jual-tas-selempang-pria/"},{"childCategoryName":"Tas Laptop Bahu & Messenger","childCategoryUrl":"//www.lazada.co.id/tas-messenger-pria/"},{"childCategoryName":"Tote Bag Pria","childCategoryUrl":"//www.lazada.co.id/jual-tas-tote-pria/"},{"childCategoryName":"Tas Pinggang","childCategoryUrl":"//www.lazada.co.id/beli-tas-pinggang/"},{"childCategoryName":"Dompet Pria","childCategoryUrl":"//www.lazada.co.id/shop-dompet-pria/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_4_7">
                <a href="//www.lazada.co.id/beli-perhiasan-pria/">
                    <span>Perhiasan Pria</span>
                </a>
                        <script type="text" class="J_data_3_6">
                            [{"childCategoryName":"Perhiasan Fashion","childCategoryUrl":"//www.lazada.co.id/beli-pria-perhiasan-fashion/"},{"childCategoryName":"Logam Berharga","childCategoryUrl":"//www.lazada.co.id/beli-pria-logam-berharga/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_4_8">
                <a href="//www.lazada.co.id/beli-jam-tangan-pria/">
                    <span>Jam Tangan Pria</span>
                </a>
                        <script type="text" class="J_data_3_7">
                            [{"childCategoryName":"Aksesoris Jam Tangan Pria","childCategoryUrl":"//www.lazada.co.id/beli-aksesoris-jam-tangan-pria/"},{"childCategoryName":"Jam Tangan Kasual Pria","childCategoryUrl":"//www.lazada.co.id/beli-jam-tangan-kasual-pria/"},{"childCategoryName":"Formal","childCategoryUrl":"//www.lazada.co.id/beli-jam-tangan-formal-pria/"},{"childCategoryName":"Mewah","childCategoryUrl":"//www.lazada.co.id/shop-jam-tangan-mewah-pria/"},{"childCategoryName":"Pra Dimiliki","childCategoryUrl":"//www.lazada.co.id/shop-jam-tangan-pre-owned-pria/"},{"childCategoryName":"Jam Tangan Olahraga Pria","childCategoryUrl":"//www.lazada.co.id/beli-jam-tangan-olahraga-pria/"}]
                        </script>
            </li>
        </ul>
        <ul class="lzd-site-menu-sub Level_1_Category_No5" data-spm="cate_5">
            <li class="lzd-site-menu-sub-item" data-cate="cate_5_1">
                <a href="//www.lazada.co.id/fashion-pakaian-anak-laki-laki">
                    <span>Pakaian Anak Laki-laki</span>
                </a>
                        <script type="text" class="J_data_4_0">
                            [{"childCategoryName":"Topi Anak Laki-laki","childCategoryUrl":"//www.lazada.co.id/topi-anak-laki-laki"},{"childCategoryName":"Hoodie Anak Laki-laki","childCategoryUrl":"//www.lazada.co.id/jual-hoodie-anak-laki-laki"},{"childCategoryName":"Jaket & Mantel Anak Laki-laki","childCategoryUrl":"//www.lazada.co.id/jaket-mantel-anak-laki-laki"},{"childCategoryName":"Celana Pendek Anak Laki-laki","childCategoryUrl":"//www.lazada.co.id/beli-celana-pendek-pria"},{"childCategoryName":"Pakaian Tidur Anak Laki-laki","childCategoryUrl":"//www.lazada.co.id/pakaian-tidur-anak-laki-laki"},{"childCategoryName":"Sweater & Cardigan Anak","childCategoryUrl":"//www.lazada.co.id/sweater-cardigan-anak-laki-laki"},{"childCategoryName":"Payung & Pakaian Hujan Anak","childCategoryUrl":"//www.lazada.co.id/payung-pakaian-hujan-anak-laki-laki"},{"childCategoryName":"Pakaian dalam","childCategoryUrl":"//www.lazada.co.id/shop-pakaian-dalam"},{"childCategoryName":"Celana & Jeans Anak Laki-laki","childCategoryUrl":"//www.lazada.co.id/celana-jeans-anak-laki-laki"},{"childCategoryName":"Kaus Kaki","childCategoryUrl":"//www.lazada.co.id/shop-kaus-kaki"},{"childCategoryName":"Baju & Atasan Anak Laki-laki","childCategoryUrl":"//www.lazada.co.id/baju-atasan-anak-laki-laki"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_5_2">
                <a href="//www.lazada.co.id/pakaian-anak-perempuan">
                    <span>Pakaian Anak Perempuan</span>
                </a>
                        <script type="text" class="J_data_4_1">
                            [{"childCategoryName":"Bawahan Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/celana-jeans-anak-perempuan"},{"childCategoryName":"Dress Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/fashion-dress-anak-perempuan"},{"childCategoryName":"Scarf Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/scarf-sarung-tangan-anak-perempuan"},{"childCategoryName":"Aksesori Rambut Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/jual-aksesori-rambut-anak-perempuan"},{"childCategoryName":"Topi Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/topi-anak-perempuan"},{"childCategoryName":"Hoodie Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/jual-hoodie-anak-laki-laki-2"},{"childCategoryName":"Jaket & Mantel Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/jaket-mantel-anak-perempuan"},{"childCategoryName":"Baju & Atasan Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/baju-atasan-anak-perempuan"},{"childCategoryName":"Payung & Pakaian Hujan Anak","childCategoryUrl":"//www.lazada.co.id/payung-jas-hujan-anak-perempuan"},{"childCategoryName":"Pakaian Dalam Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/pakaian-tidur-anak-perempuan"},{"childCategoryName":"Jumpsuits & Overalls","childCategoryUrl":"//www.lazada.co.id/shop-girls-jumpsuits-overalls"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_5_3">
                <a href="//www.lazada.co.id/shop-boy's-muslim-wear">
                    <span>Pakaian Anak Muslim Laki-Laki</span>
                </a>
                        <script type="text" class="J_data_4_2">
                            [{"childCategoryName":"Kemeja Anak Laki-Laki","childCategoryUrl":"//www.lazada.co.id/shop-boy's-muslimin-shirt"},{"childCategoryName":"Celana Anak Laki-Laki","childCategoryUrl":"//www.lazada.co.id/shop-boy's-muslimin-pants"},{"childCategoryName":"Aksesoris Anak Laki-Laki","childCategoryUrl":"//www.lazada.co.id/shop-boy's-muslimin-accessories"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_5_4">
                <a href="//www.lazada.co.id/shop-girls-muslim-wear">
                    <span>Pakaian Anak Muslim Perempuan</span>
                </a>
                        <script type="text" class="J_data_4_3">
                            [{"childCategoryName":"Hijab Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/shop-girls-muslim-wear-hijabs/"},{"childCategoryName":"Dress Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/shop-girls-muslim-wear-dresses-jumpsuits/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_5_5">
                <a href="//www.lazada.co.id/fashion-sepatu-anak-laki-laki">
                    <span>Sepatu Anak Laki-laki</span>
                </a>
                        <script type="text" class="J_data_4_4">
                            [{"childCategoryName":"Sepatu Boot Anak Laki-laki","childCategoryUrl":"//www.lazada.co.id/sepatu-boot-anak-laki-laki"},{"childCategoryName":"Sandal Anak Laki-laki","childCategoryUrl":"//www.lazada.co.id/fashion-sandal-jepit-anak-laki-laki"},{"childCategoryName":"Sepatu Formal Anak Laki-laki","childCategoryUrl":"//www.lazada.co.id/sepatu-lace-ups-anak-laki-laki"},{"childCategoryName":"Aksesoris Sepatu Anak Laki","childCategoryUrl":"//www.lazada.co.id/fashion-aksesoris-sepatu-anak-laki-laki"},{"childCategoryName":"Slip-n Anak Laki-laki","childCategoryUrl":"//www.lazada.co.id/sepatu-slip-on-anak-laki-laki"},{"childCategoryName":"Sepatu Sneaker Anak Laki-laki","childCategoryUrl":"//www.lazada.co.id/sepatu-sneaker-anak-laki-laki"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_5_6">
                <a href="//www.lazada.co.id/fashion-sepatu-anak-perempuan">
                    <span>Sepatu Anak Perempuan</span>
                </a>
                        <script type="text" class="J_data_4_5">
                            [{"childCategoryName":"Sepatu Flat Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/sepatu-balerina-anak-perempuan"},{"childCategoryName":"Sepatu Boot Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/sepatu-boot-anak-perempuan"},{"childCategoryName":"Sandal Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/fashion-sandal-jepit-anak-perempuan"},{"childCategoryName":"Sepatu Formal Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/sepatu-lace-ups-anak-perempuan"},{"childCategoryName":"Aksesoris Sepatu Anak","childCategoryUrl":"//www.lazada.co.id/fashion-aksesoris-sepatu-anak-perempuan"},{"childCategoryName":"Sepatu Sneaker Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/sepatu-sneakers-anak-perempuan"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_5_7">
                <a href="//www.lazada.co.id/beli-tas-anak-tl/">
                    <span>Tas Anak</span>
                </a>
                        <script type="text" class="J_data_4_6">
                            [{"childCategoryName":"Tas Bahu Anak","childCategoryUrl":"//www.lazada.co.id/beli-tas-bahu-anak/"},{"childCategoryName":"Ransel Troli Anak","childCategoryUrl":"//www.lazada.co.id/beli-ransel-troli-anak/"},{"childCategoryName":"Ransel Anak","childCategoryUrl":"//www.lazada.co.id/beli-ransel-anak/"},{"childCategoryName":"Aksesoris Tas","childCategoryUrl":"//www.lazada.co.id/beli-aksesoris-anak/"},{"childCategoryName":"Koper","childCategoryUrl":"//www.lazada.co.id/koper-anak-2/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_5_8">
                <a href="//www.lazada.co.id/beli-perhiasan-anak/">
                    <span>Perhiasan Anak</span>
                </a>
                        <script type="text" class="J_data_4_7">
                            [{"childCategoryName":"Emas Murni","childCategoryUrl":"//www.lazada.co.id/beli-anak-emas-murni/"},{"childCategoryName":"Perhiasan Fashion","childCategoryUrl":"//www.lazada.co.id/beli-anak-perhiasan-fashion/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_5_9">
                <a href="//www.lazada.co.id/beli-jam-tangan-anak/">
                    <span>Jam Tangan Anak</span>
                </a>
                        <script type="text" class="J_data_4_8">
                            [{"childCategoryName":"Jam Tangan Anak Laki-Laki","childCategoryUrl":"//www.lazada.co.id/beli-jam-tangan-anak-laki-laki/"},{"childCategoryName":"Jam Tangan Anak Perempuan","childCategoryUrl":"//www.lazada.co.id/beli-jam-tangan-anak-perempuan/"}]
                        </script>
            </li>
        </ul>
        <ul class="lzd-site-menu-sub Level_1_Category_No6" data-spm="cate_6">
            <li class="lzd-site-menu-sub-item" data-cate="cate_6_1">
                <a href="//www.lazada.co.id/beli-perawatan-kulit/">
                    <span>Perawatan Kulit</span>
                </a>
                        <script type="text" class="J_data_5_0">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Serum Perawatan Wajah","childCategoryUrl":"//www.lazada.co.id/beli-serum-perawatan-wajah"},{"childCategoryName":"Dermacare","childCategoryUrl":"//www.lazada.co.id/beli-dermacare"},{"childCategoryName":"Pelembab Wajah","childCategoryUrl":"//www.lazada.co.id/shop-pelembab-wajah"},{"childCategoryName":"Pembersih Wajah","childCategoryUrl":"//www.lazada.co.id/pembersih-wajah"},{"childCategoryName":"Masker Wajah","childCategoryUrl":"//www.lazada.co.id/beli-masker-wajah"},{"childCategoryName":"Toner","childCategoryUrl":"//www.lazada.co.id/beli-toner"},{"childCategoryName":"Tabir Surya","childCategoryUrl":"//www.lazada.co.id/beli-tabir-surya-aftersun"},{"childCategoryName":"Set Perawatan Wajah","childCategoryUrl":"//www.lazada.co.id/beli-set-perawatan-wajah"},{"childCategoryName":"Pelembab & Perawatan Bibir","childCategoryUrl":"//www.lazada.co.id/beli-lip-balm-perawatan-bibir"},{"childCategoryName":"Face Scrubs & Exfoliators","childCategoryUrl":"//www.lazada.co.id/beli-scrub-pengelupas-wajah"},{"childCategoryName":"Perawatan Mata","childCategoryUrl":"//www.lazada.co.id/shop-perawatan-mata"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_6_2">
                <a href="//www.lazada.co.id/beli-makeup/">
                    <span>Makeup</span>
                </a>
                        <script type="text" class="J_data_5_1">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Makeup Bibir","childCategoryUrl":"//www.lazada.co.id/beli-make-up-bibir"},{"childCategoryName":"Lipstik","childCategoryUrl":"//www.lazada.co.id/beli-lipstik"},{"childCategoryName":"Makeup Wajah","childCategoryUrl":"//www.lazada.co.id/makeup-wajah"},{"childCategoryName":"Foundation","childCategoryUrl":"//www.lazada.co.id/beli-foundation"},{"childCategoryName":"Makeup Mata","childCategoryUrl":"//www.lazada.co.id/beli-mata"},{"childCategoryName":"Maskara","childCategoryUrl":"//www.lazada.co.id/beli-maskara"},{"childCategoryName":"Aksesoris Makeup","childCategoryUrl":"//www.lazada.co.id/beli-aksesoris-makeup"},{"childCategoryName":"Set Kuas & Kuas Makeup","childCategoryUrl":"//www.lazada.co.id/beli-kuas-aplikator"},{"childCategoryName":"Perawatan Kuku","childCategoryUrl":"//www.lazada.co.id/beli-perawatan-kuku"},{"childCategoryName":"Set Makeup & Palet","childCategoryUrl":"//www.lazada.co.id/shop-palet-set-makeup"},{"childCategoryName":"Pembersih Makeup","childCategoryUrl":"//www.lazada.co.id/beli-pembersih-makeup"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_6_3">
                <a href="//www.lazada.co.id/beli-perawatan-rambut/">
                    <span>Perawatan Rambut</span>
                </a>
                        <script type="text" class="J_data_5_2">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Shampo","childCategoryUrl":"//www.lazada.co.id/beli-sampo"},{"childCategoryName":"Perawatan Rambut","childCategoryUrl":"//www.lazada.co.id/perawatan-intensif"},{"childCategoryName":"Aksesoris Rambut","childCategoryUrl":"//www.lazada.co.id/aksesoris-perawatan-rambut"},{"childCategoryName":"Styling Rambut","childCategoryUrl":"//www.lazada.co.id/beli-styling-rambut"},{"childCategoryName":"Pewarna Rambut","childCategoryUrl":"//www.lazada.co.id/beli-cat-rambut"},{"childCategoryName":"Kondisioner","childCategoryUrl":"//www.lazada.co.id/beli-kondisioner"},{"childCategoryName":"Paket Hadiah","childCategoryUrl":"//www.lazada.co.id/beli-paket-hadiah-bingkisan-perawatan-rambut"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_6_4">
                <a href="//www.lazada.co.id/beli-perlengkapan-mandi-tubuh/">
                    <span>Perawatan Tubuh</span>
                </a>
                        <script type="text" class="J_data_5_3">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Losion Tubuh","childCategoryUrl":"//www.lazada.co.id/beli-losion-krim-tubuh"},{"childCategoryName":"Sabun Cair","childCategoryUrl":"//www.lazada.co.id/shop-Sabun-Cair"},{"childCategoryName":"Scrub Tubuh","childCategoryUrl":"//www.lazada.co.id/beli-scrub-tubuh"},{"childCategoryName":"Perawatan Payudara","childCategoryUrl":"//www.lazada.co.id/perawatan-payudara"},{"childCategoryName":"Perawatan Tubuh","childCategoryUrl":"//www.lazada.co.id/shop-Perawatan-Tubuh"},{"childCategoryName":"Perawatan Kaki","childCategoryUrl":"//www.lazada.co.id/beli-perawatan-kaki"},{"childCategoryName":"Sabun Batang","childCategoryUrl":"//www.lazada.co.id/shop-Sabun-Batang"},{"childCategoryName":"Aksesoris Tubuh","childCategoryUrl":"//www.lazada.co.id/beli-aksesoris-perlengkapan-mandi-tubuh"},{"childCategoryName":"Paket Hadiah","childCategoryUrl":"//www.lazada.co.id/beli-paket-hadiah-bingkisan-alat-mandi-tubuh"},{"childCategoryName":"Penghilang Bulu","childCategoryUrl":"//www.lazada.co.id/beli-perontok-rambut"},{"childCategoryName":"Sabun Tangan","childCategoryUrl":"//www.lazada.co.id/beli-sabun-pembersih-tangan"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_6_5">
                <a href="//www.lazada.co.id/beli-perawatan-kesehatan-pribadi/">
                    <span>Perawatan Diri</span>
                </a>
                        <script type="text" class="J_data_5_4">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Perawatan Mulut","childCategoryUrl":"//www.lazada.co.id/perawatan-mulut"},{"childCategoryName":"Pembersih Wanita","childCategoryUrl":"//www.lazada.co.id/beli-pembersih-wanita"},{"childCategoryName":"Keamanan Diri","childCategoryUrl":"//www.lazada.co.id/beli-keamanan-diri"},{"childCategoryName":"Beli Deodoran","childCategoryUrl":"//www.lazada.co.id/beli-deodoran"},{"childCategoryName":"Perawatan Mata","childCategoryUrl":"//www.lazada.co.id/shop-perawatan-optik-pribadi"},{"childCategoryName":"Obat Anti Serangga","childCategoryUrl":"//www.lazada.co.id/shop-Obat-Anti-Serangga"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_6_6">
                <a href="//www.lazada.co.id/beli-parfum/">
                    <span>Parfum</span>
                </a>
                        <script type="text" class="J_data_5_5">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Pria","childCategoryUrl":"//www.lazada.co.id/beli-parfum-pria"},{"childCategoryName":"Wanita","childCategoryUrl":"//www.lazada.co.id/beli-parfum-wanita"},{"childCategoryName":"Unisex","childCategoryUrl":"//www.lazada.co.id/beli-parfum-unisex"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_6_7">
                <a href="//www.lazada.co.id/beli-alat-kesehatan-kecantikan/">
                    <span>Alat Kecantikan</span>
                </a>
                        <script type="text" class="J_data_5_6">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Alat Pelangsing & Pijat","childCategoryUrl":"//www.lazada.co.id/alat-pelangsing-dan-pemijat-elektrik"},{"childCategoryName":"Sauna Portabel","childCategoryUrl":"//www.lazada.co.id/beli-sauna-portabel"},{"childCategoryName":"Foot Relief","childCategoryUrl":"//www.lazada.co.id/beli-foot-relief"},{"childCategoryName":"Alat Cukur & Trimmer","childCategoryUrl":"//www.lazada.co.id/aksesoris-alat-cukur-dan-trimmer"},{"childCategoryName":"Alat Perawatan Wajah","childCategoryUrl":"//www.lazada.co.id/shop-alat-perawatan-kulit-wajah"},{"childCategoryName":"Alat Perawatan Tubuh","childCategoryUrl":"//www.lazada.co.id/shop-alat-perawatan-kulit-tubuh"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_6_8">
                <a href="//www.lazada.co.id/beli-suplemen-makanan/">
                    <span>Suplemen Makanan</span>
                </a>
                        <script type="text" class="J_data_5_7">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Pengatur Berat Badan","childCategoryUrl":"//www.lazada.co.id/beli-pengatur-berat-badan"},{"childCategoryName":"Pembakar Lemak","childCategoryUrl":"//www.lazada.co.id/beli-pembakar-lemak"},{"childCategoryName":"Minuman Pelangsing","childCategoryUrl":"//www.lazada.co.id/beli-minuman-pelangsing"},{"childCategoryName":"Suplemen Kecantikan","childCategoryUrl":"//www.lazada.co.id/beli-suplemen-kecantikan"},{"childCategoryName":"Suplemen Pemutih","childCategoryUrl":"//www.lazada.co.id/beli-suplemen-pemutih"},{"childCategoryName":"Multivitamin","childCategoryUrl":"//www.lazada.co.id/multivitamin/"},{"childCategoryName":"Obat Tradisional","childCategoryUrl":"//www.lazada.co.id/beli-obat-obatan-tradisional"},{"childCategoryName":"Sistem Imun","childCategoryUrl":"//www.lazada.co.id/beli-sistem-imun"},{"childCategoryName":"Nutrisi Olahraga","childCategoryUrl":"//www.lazada.co.id/beli-nutrisi-olahraga"},{"childCategoryName":"Penambah Berat Badan","childCategoryUrl":"//www.lazada.co.id/beli-suplemen-penambah-berat-badan"},{"childCategoryName":"Protein","childCategoryUrl":"//www.lazada.co.id/beli-protein"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_6_9">
                <a href="//www.lazada.co.id/beli-alat-medis/">
                    <span>Alat Medis</span>
                </a>
                        <script type="text" class="J_data_5_8">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Aksesoris Kesehatan","childCategoryUrl":"//www.lazada.co.id/aksesoris-kesehatan"},{"childCategoryName":"Alat Tes Kesehatan","childCategoryUrl":"//www.lazada.co.id/beli-alat-tes-kesehatan"},{"childCategoryName":"Obat-Obatan","childCategoryUrl":"//www.lazada.co.id/shop-over-the-counter-medicine/"},{"childCategoryName":"Perban & Perlengkapan Cedera","childCategoryUrl":"//www.lazada.co.id/perban-alat-terapi-cedera"},{"childCategoryName":"Timbangan & Alat Kadar Lemak","childCategoryUrl":"//www.lazada.co.id/beli-timbangan-alat-ukur-kadar-lemak"},{"childCategoryName":"P3K","childCategoryUrl":"//www.lazada.co.id/beli-p3k"},{"childCategoryName":"Kursi Roda","childCategoryUrl":"//www.lazada.co.id/beli-kursi-roda"},{"childCategoryName":"Salep & Krim","childCategoryUrl":"//www.lazada.co.id/shop-salep-dan-krim"},{"childCategoryName":"Alat Inhalasi & Nebulizer","childCategoryUrl":"//www.lazada.co.id/beli-alat-inhalasi-nebulizer"},{"childCategoryName":"Alat Tes Medis","childCategoryUrl":"//www.lazada.co.id/tes-medis"},{"childCategoryName":"Stetoskop","childCategoryUrl":"//www.lazada.co.id/beli-stetoskop"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_6_10">
                <a href="//www.lazada.co.id/jual-perlengkapan-kesehatan-seksual/">
                    <span>Sexual Wellness</span>
                </a>
                        <script type="text" class="J_data_5_9">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Kondom","childCategoryUrl":"//www.lazada.co.id/beli-kondom"},{"childCategoryName":"Pelumas","childCategoryUrl":"//www.lazada.co.id/beli-pelumas"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_6_11">
                <a href="//www.lazada.co.id/beli-perawatan-tubuh-kesehatan-pria/">
                    <span>Perawatan Pria</span>
                </a>
                        <script type="text" class="J_data_5_10">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Perawatan Rambut","childCategoryUrl":"//www.lazada.co.id/beli-perawatan-rambut-pria"},{"childCategoryName":"Perawatan Wajah","childCategoryUrl":"//www.lazada.co.id/beli-perawatan-kulit-pria"},{"childCategoryName":"Alat Cukur Pria","childCategoryUrl":"//www.lazada.co.id/beli-alat-cukur-pria"},{"childCategoryName":"Perawatan Tubuh","childCategoryUrl":"//www.lazada.co.id/perawatan-tubuh"},{"childCategoryName":"Deodoran Pria","childCategoryUrl":"//www.lazada.co.id/beli-deodoran-pria"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_6_12">
                <a href="//www.lazada.co.id/kesehatan-manula/">
                    <span>Popok Dewasa</span>
                </a>
                        <script type="text" class="J_data_5_11">
                            [{"childCategoryName":"Popok Dewasa","childCategoryUrl":"//www.lazada.co.id/kesehatan-manula/"}]
                        </script>
            </li>
        </ul>
        <ul class="lzd-site-menu-sub Level_1_Category_No7" data-spm="cate_7">
            <li class="lzd-site-menu-sub-item" data-cate="cate_7_1">
                <a href="//www.lazada.co.id/jual-perlengkapan-bayi-balita/">
                    <span>Ibu &amp; Anak</span>
                </a>
                        <script type="text" class="J_data_6_0">
                            [{"childCategoryName":"Popok Sekali Pakai","childCategoryUrl":"//www.lazada.co.id/beli-popok-sekali-pakai/"},{"childCategoryName":"Bayi (0 - 6 bulan)","childCategoryUrl":"//www.lazada.co.id/beli-susu-bayi-0-6-bulan/"},{"childCategoryName":"Bayi (6 - 12 bulan)","childCategoryUrl":"//www.lazada.co.id/beli-susu-bayi-6-12-bulan/"},{"childCategoryName":"Susu Batita (1- dibawah 3 tahun)","childCategoryUrl":"//www.lazada.co.id/jual-susu-batita-1-3-tahun/"},{"childCategoryName":"Susu Pertumbuhan (>3Tahun)","childCategoryUrl":"//www.lazada.co.id/beli-susu-pertumbuhan-1-3-tahun/"},{"childCategoryName":"Pakaian Bayi Perempuan","childCategoryUrl":"//www.lazada.co.id/beli-pakaian-bayi-perempuan/"},{"childCategoryName":"Pakaian Bayi Laki-Laki","childCategoryUrl":"//www.lazada.co.id/beli-pakaian-bayi-laki-laki/"},{"childCategoryName":"Botol Bayi","childCategoryUrl":"//www.lazada.co.id/beli-botol-bayi/"},{"childCategoryName":"Stroller","childCategoryUrl":"//www.lazada.co.id/beli-kereta-dorong-bayi/"},{"childCategoryName":"Soft Carrier","childCategoryUrl":"//www.lazada.co.id/beli-soft-carrier/"},{"childCategoryName":"Sampo & Kondisioner","childCategoryUrl":"//www.lazada.co.id/beli-sampo-kondisioner-bb/"},{"childCategoryName":"Perawatan Kulit Bayi","childCategoryUrl":"//www.lazada.co.id/beli-perawatan-kulit-pria/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_7_2">
                <a href="//www.lazada.co.id/beli-popok-pispot-bb/">
                    <span>Popok Sekali Pakai</span>
                </a>
                        <script type="text" class="J_data_6_1">
                            [{"childCategoryName":"Popok Sekali Pakai","childCategoryUrl":"//www.lazada.co.id/beli-popok-sekali-pakai/"},{"childCategoryName":"Popok Kain & Aksesori","childCategoryUrl":"//www.lazada.co.id/beli-popok-kain/"},{"childCategoryName":"Lap Bayi & Penyangga","childCategoryUrl":"//www.lazada.co.id/beli-lap-bayi-penyangga/"},{"childCategoryName":"Perawatan Popok","childCategoryUrl":"//www.lazada.co.id/beli-perawatan-popok/"},{"childCategoryName":"Krim & Salep Bayi","childCategoryUrl":"//www.lazada.co.id/beli-krim-salep-bayi/"},{"childCategoryName":"Tas Perlengkapan Popok","childCategoryUrl":"//www.lazada.co.id/beli-tas-popok-tb/"},{"childCategoryName":"Meja Ganti Popok","childCategoryUrl":"//www.lazada.co.id/beli-meja-ganti/"},{"childCategoryName":"Cover Popok Kain","childCategoryUrl":"//www.lazada.co.id/beli-bantalan/"},{"childCategoryName":"Lapisan Penyerap & Liner Popok Kain","childCategoryUrl":"//www.lazada.co.id/beli-lapisan-penyerap-liner-popok-kain/"},{"childCategoryName":"Potty Training","childCategoryUrl":"//www.lazada.co.id/beli-potty-training/"},{"childCategoryName":"Bangku Langkah","childCategoryUrl":"//www.lazada.co.id/beli-bangku-langkah/"},{"childCategoryName":"Detergent Laundry","childCategoryUrl":"//www.lazada.co.id/beli-detergen-popok-kain/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_7_3">
                <a href="//www.lazada.co.id/beli-susu-formula/">
                    <span>Makanan Bayi &amp; Balita</span>
                </a>
                        <script type="text" class="J_data_6_2">
                            [{"childCategoryName":"Bayi (0 - 6 bulan)","childCategoryUrl":"//www.lazada.co.id/beli-susu-bayi-0-6-bulan/"},{"childCategoryName":"Bayi (6 - 12 bulan)","childCategoryUrl":"//www.lazada.co.id/beli-susu-bayi-6-12-bulan/"},{"childCategoryName":"Susu Batita (1- dibawah 3 tahun)","childCategoryUrl":"//www.lazada.co.id/jual-susu-batita-1-3-tahun/"},{"childCategoryName":"Susu Pertumbuhan (>3Tahun)","childCategoryUrl":"//www.lazada.co.id/beli-susu-pertumbuhan-1-3-tahun/"},{"childCategoryName":"Nutrisi Khusus Anak","childCategoryUrl":"//www.lazada.co.id/beli-nutrisi-khusus-anak/"},{"childCategoryName":"Minuman","childCategoryUrl":"//www.lazada.co.id/beli-minuman-bayi-balita/"},{"childCategoryName":"Sereal","childCategoryUrl":"//www.lazada.co.id/beli-sereal-bayi-balita/"},{"childCategoryName":"Cracker & blackjepe","childCategoryUrl":"//www.lazada.co.id/beli-cracker-blackjepe-bayi-balita/"},{"childCategoryName":"Makanan Ringan","childCategoryUrl":"//www.lazada.co.id/beli-makanan-ringan-bayi-balita/"},{"childCategoryName":"Makanan puree bayi","childCategoryUrl":"//www.lazada.co.id/beli-puree-bayi/"},{"childCategoryName":"Susu Ibu Hamil","childCategoryUrl":"//www.lazada.co.id/beli-susu-maternal/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_7_4">
                <a href="//www.lazada.co.id/jual-baju-aksesoris-anak/">
                    <span>Pakaian &amp; Aksesoris</span>
                </a>
                        <script type="text" class="J_data_6_3">
                            [{"childCategoryName":"(0--6 bulan) Set Pakaian","childCategoryUrl":"//www.lazada.co.id/beli-set-pakaian-bayi/"},{"childCategoryName":"(0--6 bulan) Body Suits","childCategoryUrl":"//www.lazada.co.id/beli-bodysuit-one-piece-bayi/"},{"childCategoryName":"(0--6 bulan) Aksesoris","childCategoryUrl":"//www.lazada.co.id/beli-aksesoris-pakaian-anak/"},{"childCategoryName":"Pakaian Bayi Perempuan","childCategoryUrl":"//www.lazada.co.id/beli-pakaian-bayi-perempuan/"},{"childCategoryName":"Dress Bayi Perempuan","childCategoryUrl":"//www.lazada.co.id/beli-dress-bayi-perempuan/"},{"childCategoryName":"Sepatu Bayi Perempuan","childCategoryUrl":"//www.lazada.co.id/beli-sepatu-bayi-perempuan/"},{"childCategoryName":"Aksesoris Bayi Perempuan","childCategoryUrl":"//www.lazada.co.id/beli-aksesoris-bayi-perempuan/"},{"childCategoryName":"Baju Renang Bayi Perempuan","childCategoryUrl":"//www.lazada.co.id/beli-baju-renang-bayi-perempuan/"},{"childCategoryName":"Pakaian Bayi Laki-Laki","childCategoryUrl":"//www.lazada.co.id/beli-pakaian-bayi-laki-laki/"},{"childCategoryName":"Sepatu Bayi Laki-Laki","childCategoryUrl":"//www.lazada.co.id/beli-sepatu-bayi-laki-laki/"},{"childCategoryName":"Aksesoris Bayi Laki-Laki","childCategoryUrl":"//www.lazada.co.id/beli-aksesori-bayi-laki-laki/"},{"childCategoryName":"Baju Renang Bayi Laki-Laki","childCategoryUrl":"//www.lazada.co.id/beli-baju-renang-bayi-laki-laki/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_7_5">
                <a href="//www.lazada.co.id/beli-makanan-bayi/">
                    <span>Perlengkapan Menyusui</span>
                </a>
                        <script type="text" class="J_data_6_4">
                            [{"childCategoryName":"Botol Bayi","childCategoryUrl":"//www.lazada.co.id/beli-botol-bayi/"},{"childCategoryName":"Botol","childCategoryUrl":"//www.lazada.co.id/beli-botol-bayi-balita/"},{"childCategoryName":"Aksesoris Dot Botol","childCategoryUrl":"//www.lazada.co.id/jual-aksesoris-botol-dot-bayi/"},{"childCategoryName":"Penghangat & Sterilizers","childCategoryUrl":"//www.lazada.co.id/beli-penghangat-sterilizer/"},{"childCategoryName":"Pompa Asi","childCategoryUrl":"//www.lazada.co.id/jual-pompa-asi/"},{"childCategoryName":"Aksesesoris Pompa Asi","childCategoryUrl":"//www.lazada.co.id/jual-aksesoris-pompa-asi/"},{"childCategoryName":"Perawatan Payudara","childCategoryUrl":"//www.lazada.co.id/beli-perawatan-puting/"},{"childCategoryName":"Bantal Menyusui","childCategoryUrl":"//www.lazada.co.id/beli-bantal-kursi-bayi/"},{"childCategoryName":"Kursi Bayi","childCategoryUrl":"//www.lazada.co.id/beli-kursi-tinggi-bayi-kursi-booster/"},{"childCategoryName":"Food Blenders","childCategoryUrl":"//www.lazada.co.id/beli-blender-makanan-bayi/"},{"childCategoryName":"Peralatan Makan Bayi","childCategoryUrl":"//www.lazada.co.id/beli-perlengkapan-makan-bayi-bb/"},{"childCategoryName":"Set Peralatan Makan Bayi","childCategoryUrl":"//www.lazada.co.id/jual-piring-mangkok-bayi/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_7_6">
                <a href="//www.lazada.co.id/beli-perlengkapan-berkendara-bayi/">
                    <span>Perlengkapan Bayi</span>
                </a>
                        <script type="text" class="J_data_6_5">
                            [{"childCategoryName":"Sling Bayi","childCategoryUrl":"//www.lazada.co.id/beli-sling-bayi/"},{"childCategoryName":"Soft Carrier","childCategoryUrl":"//www.lazada.co.id/beli-soft-carrier/"},{"childCategoryName":"Stroller","childCategoryUrl":"//www.lazada.co.id/beli-kereta-dorong-bayi/"},{"childCategoryName":"Car Seat","childCategoryUrl":"//www.lazada.co.id/beli-car-seat-bb/"},{"childCategoryName":"Playard","childCategoryUrl":"//www.lazada.co.id/beli-playard/"},{"childCategoryName":"Ayunan, Jumper & Bouncer Bayi","childCategoryUrl":"//www.lazada.co.id/beli-ayunan-jumper-bouncer-bayi/"},{"childCategoryName":"Walker","childCategoryUrl":"//www.lazada.co.id/beli-walker/"},{"childCategoryName":"Tempat Duduk & Trailer Sepeda","childCategoryUrl":"//www.lazada.co.id/beli-tempat-duduk-trailer-sepeda/"},{"childCategoryName":"Tas Anak","childCategoryUrl":"//www.lazada.co.id/beli-tas-anak/"},{"childCategoryName":"Koper Anak","childCategoryUrl":"//www.lazada.co.id/beli-koper-anak/"},{"childCategoryName":"Tali & Harness Bayi","childCategoryUrl":"//www.lazada.co.id/beli-tali-harness-bayi/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_7_7">
                <a href="//www.lazada.co.id/jual-perlengkapan-kamar-bayi/">
                    <span>Kamar Bayi</span>
                </a>
                        <script type="text" class="J_data_6_6">
                            [{"childCategoryName":"Matras Bayi","childCategoryUrl":"//www.lazada.co.id/beli-kasur-seprai-bayi/"},{"childCategoryName":"Selimut Bayi","childCategoryUrl":"//www.lazada.co.id/beli-selimut-bayi/"},{"childCategoryName":"Seprai Keranjang Bayi","childCategoryUrl":"//www.lazada.co.id/beli-seprai-keranjang-bayi/"},{"childCategoryName":"Kelengkapan Alat Tidur Balita","childCategoryUrl":"//www.lazada.co.id/beli-kelengkapan-alat-tidur-balita/"},{"childCategoryName":"Selimut Tebal & Bed Cover Bayi","childCategoryUrl":"//www.lazada.co.id/beli-selimut-tebal-bed-cover-bayi/"},{"childCategoryName":"Bantal, Pelindung & Sarung Bantal Bayi","childCategoryUrl":"//www.lazada.co.id/beli-bantal-pelindung-sarung-bantal-bayi/"},{"childCategoryName":"Furnitur Bayi","childCategoryUrl":"//www.lazada.co.id/beli-furnitur-bayi/"},{"childCategoryName":"Ranjang Bayi","childCategoryUrl":"//www.lazada.co.id/jual-ranjang-bayi/"},{"childCategoryName":"Keranjang Bayi Cradle","childCategoryUrl":"//www.lazada.co.id/beli-keranjang-bayi-cradle/"},{"childCategoryName":"Laci & Lemari Pakaian Bayi","childCategoryUrl":"//www.lazada.co.id/beli-laci-lemari-pakaian-bayi/"},{"childCategoryName":"Penyimpanan","childCategoryUrl":"//www.lazada.co.id/beli-tempat-pengatur-penyimpanan/"},{"childCategoryName":"Dekorasi Kamar Anak","childCategoryUrl":"//www.lazada.co.id/beli-dekorasi-kamar-anak/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_7_8">
                <a href="//www.lazada.co.id/beli-perlengkapan-mandi-perawatan-kulit-anak/">
                    <span>Perawatan Bayi</span>
                </a>
                        <script type="text" class="J_data_6_7">
                            [{"childCategoryName":"Perawatan Kulit Bayi","childCategoryUrl":"//www.lazada.co.id/beli-perawatan-kulit-bayi/"},{"childCategoryName":"Sampo & Kondisioner","childCategoryUrl":"//www.lazada.co.id/beli-sampo-kondisioner-bb/"},{"childCategoryName":"Sabun & Pembersih Bayi","childCategoryUrl":"//www.lazada.co.id/beli-sabun-pembersih-bayi/"},{"childCategoryName":"Perawatan Mulut Bayi","childCategoryUrl":"//www.lazada.co.id/beli-sikat-gigi-pasta-gigi-bayi/"},{"childCategoryName":"Sikat Gigi & Pasta Gigi","childCategoryUrl":"//www.lazada.co.id/beli-sikat-gigi-pasta-gigi-bayi/"},{"childCategoryName":"Tempat Duduk & Bak Mandi Bayi","childCategoryUrl":"//www.lazada.co.id/beli-tempat-duduk-bak-mandi-bayi/"},{"childCategoryName":"Lap Mandi & Handuk Bayi","childCategoryUrl":"//www.lazada.co.id/jual-handuk-bayi/"},{"childCategoryName":"Pelindung Matahari Bayi","childCategoryUrl":"//www.lazada.co.id/beli-pelindung-matahari-bayi/"},{"childCategoryName":"Aromaterapi Bayi","childCategoryUrl":"//www.lazada.co.id/beli-aromaterapi-bayi/"},{"childCategoryName":"Perlengkapan Mandi Bayi","childCategoryUrl":"//www.lazada.co.id/beli-perlengkapan-mandi-bayi-bb/"},{"childCategoryName":"Alas Mandi Bayi Anti Slip","childCategoryUrl":"//www.lazada.co.id/beli-alas-mandi-bayi-anti-slip/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_7_9">
                <a href="//www.lazada.co.id/beli-mainan-anak/">
                    <span>Mainan</span>
                </a>
                        <script type="text" class="J_data_6_8">
                            [{"childCategoryName":"Action Figure & Mainan Koleksi","childCategoryUrl":"//www.lazada.co.id/jual-koleksi-mainan-action-figure/"},{"childCategoryName":"Mainan Koleksi","childCategoryUrl":"//www.lazada.co.id/beli-mainan-koleksi-tg/"},{"childCategoryName":"Mini Figur","childCategoryUrl":"//www.lazada.co.id/beli-mini-figure-tg/"},{"childCategoryName":"Kerajinan Tangan","childCategoryUrl":"//www.lazada.co.id/beli-kerajinan-tangan-kesenian-anak/"},{"childCategoryName":"Mainan Blok","childCategoryUrl":"//www.lazada.co.id/beli-mainan-balok-bangunan/"},{"childCategoryName":"Boneka & Aksesoris","childCategoryUrl":"//www.lazada.co.id/beli-boneka-aksesori/"},{"childCategoryName":"Kostum Pesta","childCategoryUrl":"//www.lazada.co.id/beli-mainan-dress-up/"},{"childCategoryName":"Mainan Edukasi","childCategoryUrl":"//www.lazada.co.id/beli-mainan-pembelajaran-edukasi/"},{"childCategoryName":"Puzzle & Games","childCategoryUrl":"//www.lazada.co.id/beli-permainan-tradisional/"},{"childCategoryName":"Hobi & Hiburan","childCategoryUrl":"//www.lazada.co.id/Shop-Hobbies-Entertainment/"},{"childCategoryName":"Perlengkapan Pesta","childCategoryUrl":"//www.lazada.co.id/beli-perlengkapan-pesta/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_7_10">
                <a href="//www.lazada.co.id/beli-remote-control-mainan-kendaraan/">
                    <span>Mainan Elektronik &amp; RC</span>
                </a>
                        <script type="text" class="J_data_6_9">
                            [{"childCategoryName":"Mobil Remote Control","childCategoryUrl":"//www.lazada.co.id/beli-kendaraan-rc-baterai/"},{"childCategoryName":"Robot Remote Control","childCategoryUrl":"//www.lazada.co.id/beli-rc-figure-robot/"},{"childCategoryName":"Mobil Die Cast","childCategoryUrl":"//www.lazada.co.id/beli-kendaraan-die-cast/"},{"childCategoryName":"Mainan Mobil","childCategoryUrl":"//www.lazada.co.id/beli-mainan-kendaraan-tg/"},{"childCategoryName":"Mainan Kereta Api & Rel","childCategoryUrl":"//www.lazada.co.id/beli-set-mainan-kereta/"},{"childCategoryName":"Drone Mainan","childCategoryUrl":"//www.lazada.co.id/beli-drones-quadcopters/"},{"childCategoryName":"Helikopter","childCategoryUrl":"//www.lazada.co.id/beli-mainan-helikopter/"},{"childCategoryName":"Video Games & Hiburan","childCategoryUrl":"//www.lazada.co.id/shop-hiburan-video-game/"},{"childCategoryName":"Walkie Talkies","childCategoryUrl":"//www.lazada.co.id/beli-mainan-walkie-talkie/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_7_11">
                <a href="//www.lazada.co.id/beli-olahraga-permainan-luar-ruangan/">
                    <span>Mainan Olahraga &amp; Luar Ruangan</span>
                </a>
                        <script type="text" class="J_data_6_10">
                            [{"childCategoryName":"Kolam Renang & Mainan Air","childCategoryUrl":"//www.lazada.co.id/beli-mainan-air-kolam-renang/"},{"childCategoryName":"Mainan Olahraga","childCategoryUrl":"//www.lazada.co.id/shop-mainan-baseball-softball/"},{"childCategoryName":"Mainan Luar Ruangan","childCategoryUrl":"//www.lazada.co.id/beli-aktivitas-dan-olahraga-luar-ruangan/"},{"childCategoryName":"Mainan Blaster","childCategoryUrl":"//www.lazada.co.id/beli-mainan-blaster/"},{"childCategoryName":"Kolam Bola & Aksesoris","childCategoryUrl":"//www.lazada.co.id/beli-bola-pit-aksesori/"},{"childCategoryName":"Mainan Terbang","childCategoryUrl":"//www.lazada.co.id/beli-mainan-terbang/"},{"childCategoryName":"Layangan & Kincir Angin","childCategoryUrl":"//www.lazada.co.id/beli-mainan-layang-layang/"},{"childCategoryName":"Istana Balon","childCategoryUrl":"//www.lazada.co.id/beli-balon-loncat-istana-balon/"},{"childCategoryName":"Ygode & Kendama","childCategoryUrl":"//www.lazada.co.id/beli-yo-yo-kendama/"},{"childCategoryName":"Set Mainan Taman Bermain","childCategoryUrl":"//www.lazada.co.id/beli-set-peralatan-permainan-playground/"},{"childCategoryName":"Kemah & Terowongan Mainan","childCategoryUrl":"//www.lazada.co.id/beli-mainan-tenda-terowongan/"},{"childCategoryName":"Mainan Rumah-rumahan","childCategoryUrl":"//www.lazada.co.id/beli-playhouses/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_7_12">
                <a href="//www.lazada.co.id/baby-toddler-toys/">
                    <span>Mainan Bayi &amp; Balita</span>
                </a>
                        <script type="text" class="J_data_6_11">
                            [{"childCategoryName":"Playgym & Playmat","childCategoryUrl":"//www.lazada.co.id/jual-mainan-gym-anak/"},{"childCategoryName":"Mainan Blok","childCategoryUrl":"//www.lazada.co.id/beli-mainan-balok-bangunan/"},{"childCategoryName":"Mainan Mandi","childCategoryUrl":"//www.lazada.co.id/beli-mainan-mandi-anak-tg/"},{"childCategoryName":"Mainan Tidur Bayi","childCategoryUrl":"//www.lazada.co.id/beli-mainan-keranjang-bayi-perlengkapannya-tg/"},{"childCategoryName":"Mainan Balita","childCategoryUrl":"//www.lazada.co.id/beli-mainan-edukatif-anak-tg/"},{"childCategoryName":"Mainan Musik & Suara","childCategoryUrl":"//www.lazada.co.id/beli-musik-suara-tg/"},{"childCategoryName":"Mainan Tarik Ulur","childCategoryUrl":"//www.lazada.co.id/beli-mainan-dorong-tarik-tg/"},{"childCategoryName":"Mainan Shape Sorting","childCategoryUrl":"//www.lazada.co.id/beli-mainan-shape-sorting-tg/"},{"childCategoryName":"Indoor Climbers & Play Structures","childCategoryUrl":"//www.lazada.co.id/beli-indoor-climbers-play-structure-tg/"},{"childCategoryName":"Rocking & Spring Ride-Ons","childCategoryUrl":"//www.lazada.co.id/beli-rocking-spring-ride-on-tg/"}]
                        </script>
            </li>
        </ul>
        <ul class="lzd-site-menu-sub Level_1_Category_No8" data-spm="cate_8">
            <li class="lzd-site-menu-sub-item" data-cate="cate_8_1">
                <a href="//www.lazada.co.id/beli-tv-audio-video-permainan-dan-gadget/">
                    <span>TV &amp; Perangkat Video</span>
                </a>
                        <script type="text" class="J_data_7_0">
                            [{"childCategoryName":""},{"childCategoryName":"TV LED","childCategoryUrl":"//www.lazada.co.id/shop-televisi-digital/"},{"childCategoryName":"TV Smart","childCategoryUrl":"//www.lazada.co.id/beli-smart-tv/"},{"childCategoryName":"Blu-Ray/DVD Player","childCategoryUrl":"//www.lazada.co.id/beli-blu-ray-player/"},{"childCategoryName":"Media Player","childCategoryUrl":"//www.lazada.co.id/shop-media-player/"},{"childCategoryName":"Proyektor","childCategoryUrl":"//www.lazada.co.id/beli-proyektor-3/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_8_2"><a href="//www.lazada.co.id/beli-perlengkapan-dapur/">
                    <span>Peralatan Dapur Kecil</span>
                </a>
                        <script type="text" class="J_data_7_1">
                            [{"childCategoryName":""},{"childCategoryName":"Rice Cooker","childCategoryUrl":"//www.lazada.co.id/beli-rice-cooker/"},{"childCategoryName":"Blender, Mixer & Grinder","childCategoryUrl":"//www.lazada.co.id/beli-blender-mixer-juicer/"},{"childCategoryName":"Kompor Gas","childCategoryUrl":"//www.lazada.co.id/beli-kompor-gas/"},{"childCategoryName":"Teko Listrik","childCategoryUrl":"//www.lazada.co.id/beli-ketel-elektrik-2/"},{"childCategoryName":"Juicer","childCategoryUrl":"//www.lazada.co.id/beli-juicer-pengekstrak-buah/"},{"childCategoryName":"Mesin Kopi","childCategoryUrl":"//www.lazada.co.id/beli-mesin-kopi/"},{"childCategoryName":"Air Fryer","childCategoryUrl":"//www.lazada.co.id/beli-air-fryers/"},{"childCategoryName":"Peralatan Dapur Lainnya","childCategoryUrl":"//www.lazada.co.id/shop-ska-lainnya/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_8_3">
                <a href="//www.lazada.co.id/shop-perlatan-besar/">
                    <span>Elektronik Rumah Besar</span>
                </a>
                        <script type="text" class="J_data_7_2">
                            [{"childCategoryName":""},{"childCategoryName":"Mesin Cuci","childCategoryUrl":"//www.lazada.co.id/beli-mesin-cuci/"},{"childCategoryName":"Kulkas","childCategoryUrl":"//www.lazada.co.id/beli-lemari-es/"},{"childCategoryName":"Microwave","childCategoryUrl":"//www.lazada.co.id/beli-microwave/"},{"childCategoryName":"Oven","childCategoryUrl":"//www.lazada.co.id/beli-ovens/"},{"childCategoryName":"Dispenser Air Minum","childCategoryUrl":"//www.lazada.co.id/beli-dispenser-air/"},{"childCategoryName":"AC","childCategoryUrl":"//www.lazada.co.id/beli-ac/"},{"childCategoryName":"Pemanas Air","childCategoryUrl":"//www.lazada.co.id/beli-pemanas-air/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_8_4">
                <a href="//www.lazada.co.id/shop-pendingin-pembersih-udara-mini/">
                    <span>Penyejuk dan Pembersih Udara</span>
                </a>
                        <script type="text" class="J_data_7_3">
                            [{"childCategoryName":""},{"childCategoryName":"Kipas Angin","childCategoryUrl":"//www.lazada.co.id/shop-kipas/"},{"childCategoryName":"Air Cooler","childCategoryUrl":"//www.lazada.co.id/beli-pendingin-udara-2/"},{"childCategoryName":"Air Purifier","childCategoryUrl":"//www.lazada.co.id/beli-penjernih-udara-2/"},{"childCategoryName":"Humidifier","childCategoryUrl":"//www.lazada.co.id/beli-humidifier/"},{"childCategoryName":"Dehumidifier","childCategoryUrl":"//www.lazada.co.id/beli-dehumidifier/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_8_5">
                <a href="//www.lazada.co.id/beli-perawatan-lantai/">
                    <span>Penghisap Debu &amp; Perawatan Lantai</span>
                </a>
                        <script type="text" class="J_data_7_4">
                            [{"childCategoryName":""},{"childCategoryName":"Penghisap Debu","childCategoryUrl":"//www.lazada.co.id/shop-penyedot-debu/"},{"childCategoryName":"Penghisap Debu Robotik","childCategoryUrl":"//www.lazada.co.id/shop-penyedot-debu-robot/"},{"childCategoryName":"Penghisap Debu dengan Tongkat","childCategoryUrl":"//www.lazada.co.id/shop-penyedot-debu-tongkat/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_8_6">
                <a href="//www.lazada.co.id/shop-peralatan-perawatan-personal/">
                    <span>Alat Perawatan Diri</span>
                </a>
                        <script type="text" class="J_data_7_5">
                            [{"childCategoryName":""},{"childCategoryName":"Hair Dryer","childCategoryUrl":"//www.lazada.co.id/beli-pengering-rambut/"},{"childCategoryName":"Alat Penata Rambut","childCategoryUrl":"//www.lazada.co.id/beli-perlengkapan-styling-rambut/"},{"childCategoryName":"Shaver & Pencukur Kumis Jenggot","childCategoryUrl":"//www.lazada.co.id/beli-shaver/"},{"childCategoryName":"Sikat Gigi Elektrik","childCategoryUrl":"//www.lazada.co.id/beli-sikat-gigi-elektrik/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_8_7">
                <a href="//www.lazada.co.id/jual-aksesoris-elektronik-rumah-tangga/">
                    <span>Aksesoris &amp; Suku Cadang</span>
                </a>
                        <script type="text" class="J_data_7_6">
                            [{"childCategoryName":""},{"childCategoryName":"Suku Cadang & Aksesoris Peralatan Dapur Kecil","childCategoryUrl":"//www.lazada.co.id/beli-aksesoris-blender-dan-mixer/"},{"childCategoryName":"Suku Cadang & Aksesoris AC","childCategoryUrl":"//www.lazada.co.id/beli-suku-cadang-aksesoris-ac/"},{"childCategoryName":"Suku Cadang & Aksesoris Mesin Cuci","childCategoryUrl":"//www.lazada.co.id/beli-aksesoris-mesin-cuci-dan-pengering-pakaian/"},{"childCategoryName":"Suku Cadang & Filter Pengganti","childCategoryUrl":"//www.lazada.co.id/beli-filter-air/"},{"childCategoryName":"Suku Cadang & Filter Penghisap Debu","childCategoryUrl":"//www.lazada.co.id/beli-suku-kadang-aksesoris-vacuum-cleaner/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_8_8">
                <a href="//www.lazada.co.id/jual-aksesoris-televisi/">
                    <span>Aksesoris Televisi</span>
                </a>
                        <script type="text" class="J_data_7_7">
                            [{"childCategoryName":""},{"childCategoryName":"TV Box","childCategoryUrl":"//www.lazada.co.id/jual-tv-receiver/"},{"childCategoryName":"Antena TV","childCategoryUrl":"//www.lazada.co.id/jual-antena-tv/"},{"childCategoryName":"Bracket Dinding TV & Pelindung","childCategoryUrl":"//www.lazada.co.id/jual-bracket-dinding-tv/"},{"childCategoryName":"Remote Control TV","childCategoryUrl":"//www.lazada.co.id/jual-remote-control-tv/"},{"childCategoryName":"Kabel TV","childCategoryUrl":"//www.lazada.co.id/jual-kabel-tv/"},{"childCategoryName":"Adaptor TV","childCategoryUrl":"//www.lazada.co.id/jual-adaptor-tv/"},{"childCategoryName":"Kacamata 3D TV","childCategoryUrl":"//www.lazada.co.id/jual-kacamata-3d-tv/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_8_9">
                <a href="//www.lazada.co.id/jual-home-entertainment/">
                    <span>Home Entertainment</span>
                </a>
                        <script type="text" class="J_data_7_8">
                            [{"childCategoryName":""},{"childCategoryName":"Soundbar","childCategoryUrl":"//www.lazada.co.id/jual-soundbar/"},{"childCategoryName":"Sistem Karaoke","childCategoryUrl":"//www.lazada.co.id/jual-sistem-karaoke/"},{"childCategoryName":"Sistem Hi-Fi","childCategoryUrl":"//www.lazada.co.id/jual-sistem-hi-fi/"},{"childCategoryName":"Sound System Panggung","childCategoryUrl":"//www.lazada.co.id/sound-system-panggung/"},{"childCategoryName":"Player Portabel","childCategoryUrl":"//www.lazada.co.id/beli-audio-player/"}]
                        </script>
            </li>
        </ul>
        <ul class="lzd-site-menu-sub Level_1_Category_No9" data-spm="cate_9">
            <li class="lzd-site-menu-sub-item" data-cate="cate_9_1">
                <a href="//www.lazada.co.id/beli-dekorasi-rumah/">
                    <span>Dekorasi Rumah</span>
                </a>
                        <script type="text" class="J_data_8_0">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Stiker Dinding","childCategoryUrl":"//www.lazada.co.id/beli-stiker-dinding/"},{"childCategoryName":"Gorden","childCategoryUrl":"//www.lazada.co.id/gorden-dan-kerai/"},{"childCategoryName":"Tikar & Karpet","childCategoryUrl":"//www.lazada.co.id/beli-tikar-karpet/"},{"childCategoryName":"Hiasan Dinding","childCategoryUrl":"//www.lazada.co.id/beli-hiasan-dinding/"},{"childCategoryName":"Dekorasi Aksen","childCategoryUrl":"//www.lazada.co.id/shop-aksesoris-dekor/"},{"childCategoryName":"Bunga & Tanaman Artifisial","childCategoryUrl":"//www.lazada.co.id/beli-bunga-tanaman-artifisial/"},{"childCategoryName":"Jam","childCategoryUrl":"//www.lazada.co.id/beli-jam/"},{"childCategoryName":"Dalaman & Sarung Bantal","childCategoryUrl":"//www.lazada.co.id/shop-dalaman-sarung-bantal/"},{"childCategoryName":"Bingkai","childCategoryUrl":"//www.lazada.co.id/beli-bingkai/"},{"childCategoryName":"Wewangian Rumah","childCategoryUrl":"//www.lazada.co.id/beli-wewangian-rumah/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_9_2">
                <a href="//www.lazada.co.id/beli-furnitur/">
                    <span>Furnitur</span>
                </a>
                        <script type="text" class="J_data_8_1">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Tempat Penyimpanan","childCategoryUrl":"//www.lazada.co.id/beli-tempat-penyimpanan/"},{"childCategoryName":"Lemari Pakaian","childCategoryUrl":"//www.lazada.co.id/beli-lemari-pakaian/"},{"childCategoryName":"Kasur","childCategoryUrl":"//www.lazada.co.id/beli-kasur/"},{"childCategoryName":"Kamar Tidur","childCategoryUrl":"//www.lazada.co.id/beli-furnitur-kamar-tidur/"},{"childCategoryName":"Rak","childCategoryUrl":"//www.lazada.co.id/rak/"},{"childCategoryName":"Rak TV dan Media","childCategoryUrl":"//www.lazada.co.id/tempat-penyimpanan-media-dan-tv/"},{"childCategoryName":"Sofa","childCategoryUrl":"//www.lazada.co.id/beli-sofa/"},{"childCategoryName":"Ruang Tamu","childCategoryUrl":"//www.lazada.co.id/beli-furnitur-ruang-tamu/"},{"childCategoryName":"Ruang Kerja Rumah","childCategoryUrl":"//www.lazada.co.id/beli-furnitur-ruang-kerja-rumah/"},{"childCategoryName":"Dapur & Ruang Makan","childCategoryUrl":"//www.lazada.co.id/beli-furnitur-dapur-ruang-makan/"},{"childCategoryName":"Ruang Bayi","childCategoryUrl":"//www.lazada.co.id/beli-furnitur-ruang-bayi/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_9_3">
                <a href="//www.lazada.co.id/beli-peralatan-ranjang/">
                    <span>Kelengkapan Tempat Tidur</span>
                </a>
                        <script type="text" class="J_data_8_2">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Seprai","childCategoryUrl":"//www.lazada.co.id/seprei-ranjang/"},{"childCategoryName":"Seprai Set","childCategoryUrl":"//www.lazada.co.id/perangkat-seprei/"},{"childCategoryName":"Selimut","childCategoryUrl":"//www.lazada.co.id/selimut-dan-selimut-panjang/"},{"childCategoryName":"Bantal","childCategoryUrl":"//www.lazada.co.id/beli-bantal/"},{"childCategoryName":"Aksesoris Tempat Tidur","childCategoryUrl":"//www.lazada.co.id/beli-aksesoris-ranjang/"},{"childCategoryName":"Sarung Bantal","childCategoryUrl":"//www.lazada.co.id/beli-sarung-bantal/"},{"childCategoryName":"Selimut Tebal","childCategoryUrl":"//www.lazada.co.id/seprei-dan-selimut-tebal/"},{"childCategoryName":"Pelindung Kasur","childCategoryUrl":"//www.lazada.co.id/kasur-pelindung/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_9_4">
                <a href="//www.lazada.co.id/penerangan/">
                    <span>Penerangan</span>
                </a>
                        <script type="text" class="J_data_8_3">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Bohlam Lampu","childCategoryUrl":"//www.lazada.co.id/shop-bohlam-lampu/"},{"childCategoryName":"Lampu Khusus","childCategoryUrl":"//www.lazada.co.id/beli-lampu-khusus/"},{"childCategoryName":"Lampu Langit-langit","childCategoryUrl":"//www.lazada.co.id/beli-lampu-langit-langit-hias/"},{"childCategoryName":"Penerangan Outdoor","childCategoryUrl":"//www.lazada.co.id/beli-penerangan-outdoor/"},{"childCategoryName":"Lampu Dinding & Tempel","childCategoryUrl":"//www.lazada.co.id/beli-lampu-dinding-tempel/"},{"childCategoryName":"Lampu Meja","childCategoryUrl":"//www.lazada.co.id/beli-lampu-meja/"},{"childCategoryName":"Komponen Lampu","childCategoryUrl":"//www.lazada.co.id/beli-lampu-komponen/"},{"childCategoryName":"Kap Lampu","childCategoryUrl":"//www.lazada.co.id/kap-lampu/"},{"childCategoryName":"Lampu Lantai","childCategoryUrl":"//www.lazada.co.id/beli-lampu-lantai/"},{"childCategoryName":"Lampu Rechargeable & Senter","childCategoryUrl":"//www.lazada.co.id/beli-senter/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_9_5">
                <a href="//www.lazada.co.id/beli-peralatan-mandi/">
                    <span>Peralatan Mandi</span>
                </a>
                        <script type="text" class="J_data_8_4">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Handuk Mandi","childCategoryUrl":"//www.lazada.co.id/beli-handuk-mandi/"},{"childCategoryName":"Timbangan Kamar Mandi","childCategoryUrl":"//www.lazada.co.id/beli-timbangan-kamar-mandi/"},{"childCategoryName":"Wadah Penyimpanan Kamar Mandi","childCategoryUrl":"//www.lazada.co.id/beli-tempat-penyimpan-kamar-mandi/"},{"childCategoryName":"Rak Kamar Mandi","childCategoryUrl":"//www.lazada.co.id/jual-laci-kamar-mandi/"},{"childCategoryName":"Gantungan Handuk & Penghangat","childCategoryUrl":"//www.lazada.co.id/gantungan-handuk-dan-penghangat/"},{"childCategoryName":"Tempat & Gantungan Shower","childCategoryUrl":"//www.lazada.co.id/tempat-dan-gantungan-shower/"},{"childCategoryName":"Keset Kamar Mandi","childCategoryUrl":"//www.lazada.co.id/beli-alas-mandi/"},{"childCategoryName":"Jubah & Kimono Mandi","childCategoryUrl":"//www.lazada.co.id/beli-jubah-mandi/"},{"childCategoryName":"Tirai Shower","childCategoryUrl":"//www.lazada.co.id/shop-tirai-mandi-aksesoris/"},{"childCategoryName":"Cermin Kamar Mandi","childCategoryUrl":"//www.lazada.co.id/beli-cermin-kamar-mandi/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_9_6">
                <a href="//www.lazada.co.id/beli-perlengkapan-dapur-makan/">
                    <span>Alat Dapur</span>
                </a>
                        <script type="text" class="J_data_8_5">
                            [{"childCategoryName":"Botol minum","childCategoryUrl":"//www.lazada.co.id/botol-minum/"},{"childCategoryName":"Tempat Penyimpanan Makanan","childCategoryUrl":"//www.lazada.co.id/beli-wadah-penyimpan-makanan/"},{"childCategoryName":"Alas Meja & Aksesoris Dapur","childCategoryUrl":"//www.lazada.co.id/beli-alas-meja-aksesoris-dapur/"},{"childCategoryName":"Kopi & Teh","childCategoryUrl":"//www.lazada.co.id/beli-kopi-dan-teh/"},{"childCategoryName":"Rak Piring & Aksesoris Wastafel","childCategoryUrl":"//www.lazada.co.id/beli-rak-piring-aksesoris-bak/"},{"childCategoryName":"Panci & Wajan","childCategoryUrl":"//www.lazada.co.id/beli-peralatan-masak/"},{"childCategoryName":"Perangkat Minum","childCategoryUrl":"//www.lazada.co.id/beli-perangkat-minum-gelas/"},{"childCategoryName":"Perangkat Makan","childCategoryUrl":"//www.lazada.co.id/beli-peralatan-penyajian-makanan/"},{"childCategoryName":"Perangkat Pemanggang","childCategoryUrl":"//www.lazada.co.id/beli-perangkat-pemanggang/"},{"childCategoryName":"Perangkat Penyajian","childCategoryUrl":"//www.lazada.co.id/beli-perangkat-penyaji/"},{"childCategoryName":"Pisau & Aksesoris","childCategoryUrl":"//www.lazada.co.id/beli-pisau-dan-aksesoris/"},{"childCategoryName":"Alat Dapur Lainnya","childCategoryUrl":"//www.lazada.co.id/beli-peralatan-dapur/"}]
                        </script></li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_9_7">
                <a href="//www.lazada.co.id/beli-binatu-kebersihan/">
                    <span>Binatu &amp; Alat Kebersihan</span>
                </a><script type="text" class="J_data_8_6">
                            [{"childCategoryName":"Gantungan Baju","childCategoryUrl":"//www.lazada.co.id/gantungan-baju/"},{"childCategoryName":"Keranjang Baju","childCategoryUrl":"//www.lazada.co.id/keranjang-cucian/"},{"childCategoryName":"Jemuran Pakaian","childCategoryUrl":"//www.lazada.co.id/rak-pengering/"},{"childCategoryName":"Alat Binatu & Setrika","childCategoryUrl":"//www.lazada.co.id/beli-alat-binatu-setrika/"},{"childCategoryName":"Meja Setrika","childCategoryUrl":"//www.lazada.co.id/papan-setrika/"},{"childCategoryName":"Produk Kebersihan","childCategoryUrl":"//www.lazada.co.id/beli-makanan-minuman-pembersihan/"},{"childCategoryName":"Sapu & Alat Pel","childCategoryUrl":"//www.lazada.co.id/beli-sapu-pel/"},{"childCategoryName":"Lap Kain Penghilang Debu","childCategoryUrl":"//www.lazada.co.id/shop-Sapu-Sikat-Kemoceng/"},{"childCategoryName":"Sikat Pembersih","childCategoryUrl":"//www.lazada.co.id/beli-makanan-minuman-aksesoris-pembersih/"},{"childCategoryName":"Tempat Sampah","childCategoryUrl":"//www.lazada.co.id/tempat-sampah/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_9_8">
                <a href="//www.lazada.co.id/beli-perawatan-rumah/">
                    <span>Perkakas &amp; Perbaikan Rumah</span>
                </a>
                        <script type="text" class="J_data_8_7">
                            [{"childCategoryName":"Alat Penyimpanan & Rak","childCategoryUrl":"//www.lazada.co.id/beli-garasi-penyimpanan-alat-alat/"},{"childCategoryName":"Kabel & Perlengkapan Elektrik","childCategoryUrl":"//www.lazada.co.id/beli-peralatan-elektrik/"},{"childCategoryName":"Pengecatan & Dekorasi","childCategoryUrl":"//www.lazada.co.id/beli-pengecatan-dekorasi/"},{"childCategoryName":"Perkakas","childCategoryUrl":"//www.lazada.co.id/beli-perkakas/"},{"childCategoryName":"Perkakas Listrik","childCategoryUrl":"//www.lazada.co.id/jual-perkakas-listrik/"},{"childCategoryName":"Perkakas Portabel","childCategoryUrl":"//www.lazada.co.id/beli-peralatan-genggam/"},{"childCategoryName":"Pipa Saluran Air & Kelengkapan","childCategoryUrl":"//www.lazada.co.id/beli-ledeng/"},{"childCategoryName":"Senter","childCategoryUrl":"//www.lazada.co.id/beli-senter"},{"childCategoryName":"Tangga & Kursi Peninggi","childCategoryUrl":"//www.lazada.co.id/beli-tangga-kursi-peninggi/"},{"childCategoryName":"perlengkapan keamanan","childCategoryUrl":"//www.lazada.co.id/lampu-penerangan-tempat-kerja/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_9_9">
                <a href="//www.lazada.co.id/Kebun &amp; Luar Ruangan/">
                    <span>Kebun &amp; Luar Ruangan</span>
                </a>
                        <script type="text" class="J_data_8_8">
                            [{"childCategoryName":"Peralatan Listrik Taman & Kebun","childCategoryUrl":"//www.lazada.co.id/beli-peralatan-listrik-taman-luar-ruangan/"},{"childCategoryName":"Peralatan Kebun","childCategoryUrl":"//www.lazada.co.id/beli-peralatan-kebun/"},{"childCategoryName":"Sistem Pengairan","childCategoryUrl":"//www.lazada.co.id/beli-sistem-pengairan/"},{"childCategoryName":"Bibit & Biji Bijian","childCategoryUrl":"//www.lazada.co.id/beli-tumbuhan-biji-bijian/"},{"childCategoryName":"Pembasmi Hama","childCategoryUrl":"//www.lazada.co.id/beli-pembasmi-rumput-liar-hama/"},{"childCategoryName":"Aksesoris Genset","childCategoryUrl":"//www.lazada.co.id/beli-aksesoris-peralatan-listrik-luar-ruangan/"},{"childCategoryName":"Genset","childCategoryUrl":"//www.lazada.co.id/shop-generator/"},{"childCategoryName":"Pemanggang","childCategoryUrl":"//www.lazada.co.id/pemanggang-dan-penyajian-masakan-outdoor/"},{"childCategoryName":"Alat Pembunuh Serangga","childCategoryUrl":"//www.lazada.co.id/alat-pembunuh-serangga/"},{"childCategoryName":"Aksesoris Luar Ruangan","childCategoryUrl":"//www.lazada.co.id/beli-luar-ruangan/"},{"childCategoryName":"Taman & Kebun","childCategoryUrl":"//www.lazada.co.id/perlengkapan-taman-dan-kebun/"},{"childCategoryName":"","childCategoryUrl":""}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_9_10">
                <a href="//www.lazada.co.id/beli-alat-tulis-kerajinan/">
                    <span>Alat Tulis &amp; Kerajinan</span>
                </a>
                        <script type="text" class="J_data_8_9">
                            [{"childCategoryName":"Peralatan Kesenian dan Kerajinan","childCategoryUrl":"//www.lazada.co.id/beli-peralatan-seni/"},{"childCategoryName":"Peralatan Mewarnai dan Copic","childCategoryUrl":"//www.lazada.co.id/beli-alat-mewarnai-copic/"},{"childCategoryName":"Kerajinan Umum","childCategoryUrl":"//www.lazada.co.id/beli-alat-kerajinan-umum/"},{"childCategoryName":"Pernak Pernik Hadiah dan Kado","childCategoryUrl":"//www.lazada.co.id/beli-pernak-pernik-hadiah/"},{"childCategoryName":"Tas Belanja","childCategoryUrl":"//www.lazada.co.id/beli-tas-belanjaan/"},{"childCategoryName":"Buku Catatan","childCategoryUrl":"//www.lazada.co.id/buku-catatan/"},{"childCategoryName":"Kertas Komputer","childCategoryUrl":"//www.lazada.co.id/beli-kertas-komputer/"},{"childCategoryName":"Perlengkapan Sekolah","childCategoryUrl":"//www.lazada.co.id/beli-perlengkapan-sekolah/"},{"childCategoryName":"Perlengkapan Meja Kerja","childCategoryUrl":"//www.lazada.co.id/beli-wadah-alat-alat-kantor/"},{"childCategoryName":"Perlengkapan Jahit","childCategoryUrl":"//www.lazada.co.id/beli-bahan-bahan-kerajinan-tangan/"},{"childCategoryName":"Pulpen","childCategoryUrl":"//www.lazada.co.id/beli-pulpen/"},{"childCategoryName":"Pensil","childCategoryUrl":"//www.lazada.co.id/beli-pensil-2/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_9_11">
                <a href="//www.lazada.co.id/beli-media-musik-dan-buku/">
                    <span>Media, Musik &amp; Buku</span>
                </a>
                        <script type="text" class="J_data_8_10">
                            [{"childCategoryName":"Instrumen Musik","childCategoryUrl":"//www.lazada.co.id/instrumen-musik/"},{"childCategoryName":"Buku","childCategoryUrl":"//www.lazada.co.id/buku/"},{"childCategoryName":"Musik","childCategoryUrl":"//www.lazada.co.id/lagu/"},{"childCategoryName":"Majalah","childCategoryUrl":"//www.lazada.co.id/majalah/"},{"childCategoryName":"Film","childCategoryUrl":"//www.lazada.co.id/film/"}]
                        </script>
            </li>
        </ul>
        <ul class="lzd-site-menu-sub Level_1_Category_No10" data-spm="cate_10">
            <li class="lzd-site-menu-sub-item" data-cate="cate_10_1">
                <a href="//www.lazada.co.id/beli-minuman/">
                    <span>Minuman</span>
                </a>
                        <script type="text" class="J_data_9_0">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"UHT, Susu & Susu Bubuk","childCategoryUrl":"//www.lazada.co.id/beli-makanan-minuman-uht-milk-milk-powder/"},{"childCategoryName":"Kopi","childCategoryUrl":"//www.lazada.co.id/beli-kopi/"},{"childCategoryName":"Minuman Serbuk","childCategoryUrl":"//www.lazada.co.id/beli-minuman-serbuk/"},{"childCategoryName":"Minuman Berenergi","childCategoryUrl":"//www.lazada.co.id/shop-Minuman-Olahraga-Energi/"},{"childCategoryName":"Teh","childCategoryUrl":"//www.lazada.co.id/beli-teh/"},{"childCategoryName":"Chocolate, Malt & Hot Cereals","childCategoryUrl":"//www.lazada.co.id/coklat-panas/"},{"childCategoryName":"Air Mineral","childCategoryUrl":"//www.lazada.co.id/beli-makanan-minuman-air/"},{"childCategoryName":"Minuman Berkarbonasi","childCategoryUrl":"//www.lazada.co.id/beli-makanan-minuman-minuman-ringan/"},{"childCategoryName":"Jus","childCategoryUrl":"//www.lazada.co.id/beli-makanan-minuman-jus/"},{"childCategoryName":"Sirup","childCategoryUrl":"//www.lazada.co.id/beli-sirup/"}]
                        </script>
            </li>
            <liclass="lzd-site-menu-sub-item" data-cate="cate_10_2">
                <a href="//www.lazada.co.id/shop-Bahan-Utama-Pelengkap-Masakan">
                    <span>Bahan &amp; Bumbu Masakan</span>
                </a>
                        <script type="text" class="J_data_9_1">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Makanan Instant & Siap santap","childCategoryUrl":"//www.lazada.co.id/shop-Makanan-Instan-Siap-Santap/"},{"childCategoryName":"Bahan Pembuat Kue","childCategoryUrl":"//www.lazada.co.id/shop-Bahan-Pembuat-Kue/"},{"childCategoryName":"Beras","childCategoryUrl":"//www.lazada.co.id/shop-Beras/"},{"childCategoryName":"Garam & Bumbu Dapur","childCategoryUrl":"//www.lazada.co.id/shop-Bumbu-Dapur/"},{"childCategoryName":"Mie & Bihun","childCategoryUrl":"//www.lazada.co.id/shop-Mi-Bihun/"},{"childCategoryName":"Makanan Kering","childCategoryUrl":"//www.lazada.co.id/shop-Makanan-Kering/"},{"childCategoryName":"Minyak","childCategoryUrl":"//www.lazada.co.id/shop-Minyak/"},{"childCategoryName":"Makanan Kaleng","childCategoryUrl":"//www.lazada.co.id/shop-Makanan-Kaleng/"},{"childCategoryName":"Pasta","childCategoryUrl":"//www.lazada.co.id/shop-Pasta/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_10_3">
                <a href="//www.lazada.co.id/shop-Cokelat-Camilan-Permen/">
                    <span>Cokelat, Camilan &amp; Permen</span>
                </a>
                        <script type="text" class="J_data_9_2">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Camilan","childCategoryUrl":"//www.lazada.co.id/shop-Camilan/"},{"childCategoryName":"Cokelat","childCategoryUrl":"//www.lazada.co.id/shop-Cokelat/"},{"childCategoryName":"blackjepe & Kerupuk","childCategoryUrl":"//www.lazada.co.id/shop-blackjepe-Manis/"},{"childCategoryName":"Permen","childCategoryUrl":"//www.lazada.co.id/shop-Manisan/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_10_4">
                <a href="//www.lazada.co.id/beli-makanan-sarapan">
                    <span>Makanan Sarapan, Sereal &amp; Selai</span>
                </a>
                        <script type="text" class="J_data_9_3">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Selai & Madu","childCategoryUrl":"//www.lazada.co.id/beli-makanan-minuman-selai-madu-spread/"},{"childCategoryName":"Oatmeal","childCategoryUrl":"//www.lazada.co.id/beli-oatmeal/"},{"childCategoryName":"Sereal Sarapan","childCategoryUrl":"//www.lazada.co.id/beli-sereal/"},{"childCategoryName":"Tepung Pancake & Waffle","childCategoryUrl":"//www.lazada.co.id/beli-pancake-waffle/"},{"childCategoryName":"Bars","childCategoryUrl":"//www.lazada.co.id/shop-bar/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_10_5">
                <a href="//www.lazada.co.id/beli-makanan-minuman-hasil-segar">
                    <span>Buah &amp; Sayur</span>
                </a>
                        <script type="text" class="J_data_9_4">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Buah Segar","childCategoryUrl":"//www.lazada.co.id/beli-makanan-minuman-buah/"},{"childCategoryName":"Sayur Segar","childCategoryUrl":"//www.lazada.co.id/beli-makanan-minuman-sayuran-segar/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_10_6">
                <a href="//www.lazada.co.id/shop-kebutuhan-rumah-tangga">
                    <span>Kebutuhan Rumah Tangga</span>
                </a>
                        <script type="text" class="J_data_9_5">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Pengharum Ruangan","childCategoryUrl":"//www.lazada.co.id/shop-perawatan-udara/"},{"childCategoryName":"Kebutuhan Kebersihan","childCategoryUrl":"//www.lazada.co.id/beli-makanan-minuman-pembersihan/"},{"childCategoryName":"Pengendalian Hama","childCategoryUrl":"//www.lazada.co.id/beli-makanan-minuman-pengendalian-hama/"},{"childCategoryName":"Sabun Pencuci Piring","childCategoryUrl":"//www.lazada.co.id/beli-makanan-minuman-mencuci-piring/"},{"childCategoryName":"Kebutuhan Laundry","childCategoryUrl":"//www.lazada.co.id/beli-makanan-minuman-cucian/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_10_7">
                <a href="//www.lazada.co.id/shop-makanan-hewan">
                    <span>Makanan Hewan Peliharaan</span>
                </a>
                        <script type="text" class="J_data_9_6">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Makanan & Camilan Kucing","childCategoryUrl":"//www.lazada.co.id/jual-makanan-kucing/"},{"childCategoryName":"Makanan Burung","childCategoryUrl":"//www.lazada.co.id/beli-makanan-burung/"},{"childCategoryName":"Makanan Ikan","childCategoryUrl":"//www.lazada.co.id/beli-makanan-ikan/"},{"childCategoryName":"Makanan & Camilan Anjing","childCategoryUrl":"//www.lazada.co.id/jual-makanan-anjing/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_10_8">
                <a href="//www.lazada.co.id/shop-aksesoris-hewan">
                    <span>Aksesoris Hewan Peliharaan</span>
                </a>
                        <script type="text" class="J_data_9_7">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Keperluan Akuarium","childCategoryUrl":"//www.lazada.co.id/shop-keperluan-akuarium/"},{"childCategoryName":"Kandang & Aksesoris","childCategoryUrl":"//www.lazada.co.id/beli-kandang-terbuka-pintu-anjing/"},{"childCategoryName":"Peralatan Grooming","childCategoryUrl":"//www.lazada.co.id/jual-persediaan-grooming-hewan/"},{"childCategoryName":"Rumah,Alas & Tempat tidur","childCategoryUrl":"//www.lazada.co.id/beli-ranjang-alas-tidur-rumah-anjing/"},{"childCategoryName":"Alat Makan Hewan","childCategoryUrl":"//www.lazada.co.id/beli-mangkuk-makan-anjing/"},{"childCategoryName":"Tali dan Kalung Hewan","childCategoryUrl":"//www.lazada.co.id/beli-tali-kalung-moncong-anjing/"},{"childCategoryName":"Kebutuhan Travel Hewan","childCategoryUrl":"//www.lazada.co.id/beli-pengangkut-perjalanan-anjing/"},{"childCategoryName":"Mainan Hewan","childCategoryUrl":"//www.lazada.co.id/shop-mainan/"},{"childCategoryName":"Alat Pelatihan Anjing","childCategoryUrl":"//www.lazada.co.id/beli-alat-latih-olahraga-anjing/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_10_9">
                <a href="//www.lazada.co.id/shop-kesehatan-hewan-peliharaan">
                    <span>Kesehatan Hewan Peliharaan</span>
                </a>
                        <script type="text" class="J_data_9_8">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Perawatan Gigi","childCategoryUrl":"//www.lazada.co.id/beli-kesehatan-gigi-anjing/"},{"childCategoryName":"Pembasmi Kutu Hewan","childCategoryUrl":"//www.lazada.co.id/beli-kutu-anjing/"}]
                        </script>
            </li>
        </ul>
        <ul class="lzd-site-menu-sub Level_1_Category_No11" data-spm="cate_11">
            <li class="lzd-site-menu-sub-item" data-cate="cate_11_1">
                <a href="//www.lazada.co.id/baju-olahraga-pria/">
                    <span>Baju Olahraga Pria</span>
                </a>
                        <script type="text" class="J_data_10_0">[{"childCategoryName":"Celana Olahraga Pria","childCategoryUrl":"//www.lazada.co.id/celana-panjang-dan-pendek-olahraga-pria/"},{"childCategoryName":"Kaos Olahraga Pria","childCategoryUrl":"//www.lazada.co.id/kaos-olahraga-pria/"},{"childCategoryName":"Jaket Olahraga Pria","childCategoryUrl":"//www.lazada.co.id/jaket-dan-parka-olahraga-pria/"},{"childCategoryName":"Pakaian Renang Pria","childCategoryUrl":"//www.lazada.co.id/pakaian-renang-dan-selancar-pria/"},{"childCategoryName":"Jersey Olahraga Pria","childCategoryUrl":"//www.lazada.co.id/jual-jersey-olahraga-pria/"},{"childCategoryName":"Celana Pendek Pria","childCategoryUrl":"//www.lazada.co.id/jual-celana-pendek-olahraga-pria/"},{"childCategoryName":"Hoodies Pria","childCategoryUrl":"//www.lazada.co.id/hoodies-pria/"},{"childCategoryName":"Topi Olahraga Pria","childCategoryUrl":"//www.lazada.co.id/jual-topi-olahraga-pria/"},{"childCategoryName":"Tas Ransel Sport Pria","childCategoryUrl":"//www.lazada.co.id/tas-ransel-sport-pria/"},{"childCategoryName":"Tas Serut Pria","childCategoryUrl":"//www.lazada.co.id/tas-serut-pria/"},{"childCategoryName":"Tas Duffel Pria","childCategoryUrl":"//www.lazada.co.id/tas-duffel-pria/"},{"childCategoryName":"Gym Tote Pria","childCategoryUrl":"//www.lazada.co.id/gym-tote-pria/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_11_2">
                <a href="//www.lazada.co.id/pakaian-olahraga-wanita/">
                    <span>Baju Olahraga Wanita</span>
                </a>
                        <script type="text" class="J_data_10_1">
                            [{"childCategoryName":"Celana Panjang Wanita","childCategoryUrl":"//www.lazada.co.id/celana-panjang-dan-pendek-olahraga-wanita/"},{"childCategoryName":"Kaos Olahraga Wanita","childCategoryUrl":"//www.lazada.co.id/kaos-dan-atasan-olahraga-wanita/"},{"childCategoryName":"Jaket Olahraga Wanita","childCategoryUrl":"//www.lazada.co.id/jaket-dan-parka-sport-wanita/"},{"childCategoryName":"Sport Bra Wanita","childCategoryUrl":"//www.lazada.co.id/jual-sport-bra-wanita/"},{"childCategoryName":"Celana Pendek Wanita","childCategoryUrl":"//www.lazada.co.id/jual-celana-pendek-olahraga-wanita/"},{"childCategoryName":"Rok Olahraga Wanita","childCategoryUrl":"//www.lazada.co.id/jual-rok-olahraga-wanita/"},{"childCategoryName":"Hoodies Wanita","childCategoryUrl":"//www.lazada.co.id/hoodies-wanita/"},{"childCategoryName":"Pakaian Renang Wanita","childCategoryUrl":"//www.lazada.co.id/pakaian-renang-dan-selancar-wanita/"},{"childCategoryName":"Tas Ransel Sport Wanita","childCategoryUrl":"//www.lazada.co.id/tas-ransel-sport-wanita/"},{"childCategoryName":"Tas Serut Wanita","childCategoryUrl":"//www.lazada.co.id/tas-serut-wanita/"},{"childCategoryName":"Tas Duffel Wanita","childCategoryUrl":"//www.lazada.co.id/tas-duffel-wanita/"},{"childCategoryName":"Gym Tote Wanita","childCategoryUrl":"//www.lazada.co.id/gym-tote-wanita/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_11_3">
                <a href="//www.lazada.co.id/sepatu-dan-pakaian-olahraga-pria/">
                    <span>Sepatu Olahraga Pria</span>
                </a>
                        <script type="text" class="J_data_10_2">
                            [{"childCategoryName":"Sepatu Sepakbola Pria","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-sepakbola-pria/"},{"childCategoryName":"Sepatu Futsal Pria","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-futsal-pria/"},{"childCategoryName":"Sepatu Lari Pria","childCategoryUrl":"//www.lazada.co.id/sepatu-lari-pria/"},{"childCategoryName":"Sepatu Hiking Pria","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-hiking-pria/"},{"childCategoryName":"Sepatu Basket Pria","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-basket-pria/"},{"childCategoryName":"Sepatu Olahraga Air Pria","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-olahraga-air-pria/"},{"childCategoryName":"Sepatu Badminton ria","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-badminton-pria/"},{"childCategoryName":"Sepatu Training Pira","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-fitness-training-pria/"},{"childCategoryName":"Sepatu Skateboard Pria","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-skateboard-pria/"},{"childCategoryName":"Sepatu Sneakers Pria","childCategoryUrl":"//www.lazada.co.id/beli-sepatu-sneakers-pria/"},{"childCategoryName":"Sandal Olahraga Pria","childCategoryUrl":"//www.lazada.co.id/jual-sandal-olahraga-pria/"},{"childCategoryName":"Sepatu Jalan Pria","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-jalan-pria/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_11_4">
                <a href="//www.lazada.co.id/sepatu-dan-pakaian-olahraga-wanita/">
                    <span>Sepatu Olahraga Wanita</span>
                </a>
                        <script type="text" class="J_data_10_3">
                            [{"childCategoryName":"Sepatu Badminton Wanita","childCategoryUrl":"//www.lazada.co.id/sepatu-badminton-wanita/"},{"childCategoryName":"Sepatu Lari Wanita","childCategoryUrl":"//www.lazada.co.id/sepatu-lari-wanita/"},{"childCategoryName":"Sepatu Futsal Wanita","childCategoryUrl":"//www.lazada.co.id/sepatu-futsal-wanita/"},{"childCategoryName":"Sepatu Basket Wanita","childCategoryUrl":"//www.lazada.co.id/sepatu-basket-wanita/"},{"childCategoryName":"Sepatu Sepakbola Wanita","childCategoryUrl":"//www.lazada.co.id/sepatu-sepakbola-wanita/"},{"childCategoryName":"Sepatu Olahraga Air Wanita","childCategoryUrl":"//www.lazada.co.id/sepatu-olaraga-air-wanita/"},{"childCategoryName":"Sepatu Hiking Wanita","childCategoryUrl":"//www.lazada.co.id/sepatu-hiking-wanita/"},{"childCategoryName":"Sepatu Training Wanita","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-fitness-training-wanita/"},{"childCategoryName":"Septu Skateboard Wanita","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-skateboard-wanita/"},{"childCategoryName":"Sepatu Sneakers Wanita","childCategoryUrl":"//www.lazada.co.id/beli-sepatu-sneakers-wanita/"},{"childCategoryName":"Sandal Olahraga Wanita","childCategoryUrl":"//www.lazada.co.id/jual-sandal-olahraga-wanita/"},{"childCategoryName":"Sepatu Jalan Wanita","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-jalan-wanita/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_11_5">
                <a href="//www.lazada.co.id/camping-dan-hiking/">
                    <span>Camping dan Hiking</span>
                </a>
                        <script type="text" class="J_data_10_4">
                            [{"childCategoryName":"Tenda dan furniture Camping","childCategoryUrl":"//www.lazada.co.id/tenda-dan-furniture/"},{"childCategoryName":"Perlengkapan Tidur Camping","childCategoryUrl":"//www.lazada.co.id/perlengkapan-tidur-camping/"},{"childCategoryName":"Tas Camping","childCategoryUrl":"//www.lazada.co.id/jual-tas-ransel/"},{"childCategoryName":"Tempat berteduh Camping","childCategoryUrl":"//www.lazada.co.id/jual-tempat-berteduh-dan-kanopi/"},{"childCategoryName":"Perabotan Kemah","childCategoryUrl":"//www.lazada.co.id/jual-perabotan-kemah/"},{"childCategoryName":"Alat Dapur Kemah","childCategoryUrl":"//www.lazada.co.id/jual-dapur-kemah/"},{"childCategoryName":"Alat penerangan Hiking","childCategoryUrl":"//www.lazada.co.id/jual-penerangan/"},{"childCategoryName":"Navigasi Elektroning Hiking","childCategoryUrl":"//www.lazada.co.id/jual-navigasi-elektronik/"},{"childCategoryName":"Tongkat Hiking","childCategoryUrl":"//www.lazada.co.id/jual-tongkat-hiking/"},{"childCategoryName":"Pisau Kemah","childCategoryUrl":"//www.lazada.co.id/jual-pisau-alat-multifungsi/"},{"childCategoryName":"Peralatan Survival Camping","childCategoryUrl":"//www.lazada.co.id/jual-peralatan-survival-dan-keamanan/"},{"childCategoryName":"Perlengkapan Panjat Tebing","childCategoryUrl":"//www.lazada.co.id/panjat-tebing/"}]
                        </script>
            </li>
            <liclass="lzd-site-menu-sub-item" data-cate="cate_11_6">
                <a href="//www.lazada.co.id/jual-peralatan-memancing/">
                    <span>Peralatan Memancing</span>
                </a>
                        <script type="text" class="J_data_10_5">[{"childCategoryName":"Tongkat Pancing","childCategoryUrl":"//www.lazada.co.id/jual-tongkat-pancing/"},{"childCategoryName":"Alat Gulungan Pancing","childCategoryUrl":"//www.lazada.co.id/alat-gulungan-pancing/"},{"childCategoryName":"Set Tongkat dan Gulungan Pancing","childCategoryUrl":"//www.lazada.co.id/set-tongkat-dan-gulungan-pancing/"},{"childCategoryName":"Senar Pancing","childCategoryUrl":"//www.lazada.co.id/jual-senar-pancing/"},{"childCategoryName":"Umpan Pancing","childCategoryUrl":"//www.lazada.co.id/jual-umpan/"},{"childCategoryName":"Peralatan Pancing","childCategoryUrl":"//www.lazada.co.id/jual-peralatan-pancing/"},{"childCategoryName":"GPS alat pencari ikan","childCategoryUrl":"//www.lazada.co.id/jual-gps-alat-pencari-ikan/"},{"childCategoryName":"Jaring Penangkap Ikan","childCategoryUrl":"//www.lazada.co.id/jual-jaring-penangkap-ikan/"},{"childCategoryName":"Aksesoris Memancing","childCategoryUrl":"//www.lazada.co.id/jual-aksesoris-memancing/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_11_7">
                <a href="//www.lazada.co.id/olahraga-sepeda/">
                    <span>Olahraga Sepeda</span>
                </a>
                        <script type="text" class="J_data_10_6">
                            [{"childCategoryName":"Komponen Part Sepeda","childCategoryUrl":"//www.lazada.co.id/komponen-dan-parts-sepeda/"},{"childCategoryName":"Aksesoris Sepeda","childCategoryUrl":"//www.lazada.co.id/aksesoris-sepeda/"},{"childCategoryName":"Sepeda","childCategoryUrl":"//www.lazada.co.id/sepeda/"},{"childCategoryName":"Kaos Sepeda","childCategoryUrl":"//www.lazada.co.id/jual-baju-kaos-sepeda/"},{"childCategoryName":"Sepatu Sepeda Pria","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-sepeda-pria/"},{"childCategoryName":"Sepatu Sepeda Wanita","childCategoryUrl":"//www.lazada.co.id/sepatu-sepeda-wanita/"},{"childCategoryName":"Sepatu Sepeda Perempuan","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-sepeda-anak-perempuan/"},{"childCategoryName":"Sepatu Sepeda Laki-Laki","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-sepeda-anak-laki-laki/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_11_8">
                <a href="//www.lazada.co.id/olahraga-air/">
                    <span>Olahraga Air</span>
                </a>
                        <script type="text" class="J_data_10_7">
                            [{"childCategoryName":"Kapal","childCategoryUrl":"//www.lazada.co.id/jual-kapal/"},{"childCategoryName":"Peralatan Menyelam","childCategoryUrl":"//www.lazada.co.id/diving-snorkeling/"},{"childCategoryName":"Peralatan Renang","childCategoryUrl":"//www.lazada.co.id/renang/"},{"childCategoryName":"Papan Renang","childCategoryUrl":"//www.lazada.co.id/jual-olahraga-papan/"},{"childCategoryName":"Tubing dan Towables","childCategoryUrl":"//www.lazada.co.id/jual-tubing-towables/"},{"childCategoryName":"Akesesoris Olahraga Air","childCategoryUrl":"//www.lazada.co.id/jual-aksesoris-olahraga-air/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_11_9">
                <a href="//www.lazada.co.id/latihan-dan-fitness/">
                    <span>Gym, Yoga &amp; Fitness</span>
                </a>
                        <script type="text" class="J_data_10_8">
                            [{"childCategoryName":"Peralatan Pelatihan Ketangkasan","childCategoryUrl":"//www.lazada.co.id/shop-pelatihan-kecepatan-ketangkasan/"},{"childCategoryName":"Aksesoris Gym","childCategoryUrl":"//www.lazada.co.id/shop-aksesoris/"},{"childCategoryName":"Pilates Gym","childCategoryUrl":"//www.lazada.co.id/pilates/"},{"childCategoryName":"Alat Latihan Angkat Beban","childCategoryUrl":"//www.lazada.co.id/alat-latihan-angkat-beban/"},{"childCategoryName":"Yoga","childCategoryUrl":"//www.lazada.co.id/yoga/"},{"childCategoryName":"Peralatan Kardio","childCategoryUrl":"//www.lazada.co.id/peralatan-latihan-kardio/"},{"childCategoryName":"Perlengkapan Fitnes","childCategoryUrl":"//www.lazada.co.id/jual-aksesoris-fitness/"},{"childCategoryName":"Perlengkapan Lari","childCategoryUrl":"//www.lazada.co.id/temporary-url-sport-catl3-1/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_11_10">
                <a href="//www.lazada.co.id/olahraga-raket/">
                    <span>Olahraga Raket</span>
                </a>
                        <script type="text" class="J_data_10_9">
                            [{"childCategoryName":"Tenis Meja","childCategoryUrl":"//www.lazada.co.id/tenis-meja/"},{"childCategoryName":"Badminton","childCategoryUrl":"//www.lazada.co.id/bulutangkis/"},{"childCategoryName":"Tennis","childCategoryUrl":"//www.lazada.co.id/tenis/"},{"childCategoryName":"Squash","childCategoryUrl":"//www.lazada.co.id/squash/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_11_11">
                <a href="//www.lazada.co.id/shop-perlengkapan-olah-raga/">
                    <span>Perlengkapan Olahraga</span>
                </a>
                        <script type="text" class="J_data_10_10">
                            [{"childCategoryName":"Oxrashoan Tinju-Bela Mma","childCategoryUrl":"//www.lazada.co.id/jual-tinju-bela-diri-mma/"},{"childCategoryName":"Golf Gym","childCategoryUrl":"//www.lazada.co.id/golf/"},{"childCategoryName":"Bola Gym","childCategoryUrl":"//www.lazada.co.id/sepak-bola/"},{"childCategoryName":"Basket Gym","childCategoryUrl":"//www.lazada.co.id/basket/"},{"childCategoryName":"Voli Gym","childCategoryUrl":"//www.lazada.co.id/voli/"},{"childCategoryName":"Cricket Gym","childCategoryUrl":"//www.lazada.co.id/cricket/"},{"childCategoryName":"Rugby Gym","childCategoryUrl":"//www.lazada.co.id/rugby/"},{"childCategoryName":"Takraw Gym","childCategoryUrl":"//www.lazada.co.id/sepak-takraw/"},{"childCategoryName":"Baseball Gym","childCategoryUrl":"//www.lazada.co.id/baseball/"},{"childCategoryName":"Perlengkapan Olahraga Senam","childCategoryUrl":"//www.lazada.co.id/jual-olahraga-senam/"},{"childCategoryName":"Hoki Gym","childCategoryUrl":"//www.lazada.co.id/olahraga-hoki/"},{"childCategoryName":"Peralatan Cheerleading","childCategoryUrl":"//www.lazada.co.id/jual-peralatan-cheerleading/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_11_12">
                <a href="//www.lazada.co.id/sepak-bola/">
                    <span>Perlengkapan Sepak Bola</span>
                </a>
                        <script type="text" class="J_data_10_11">
                            [{"childCategoryName":"Sepatu Sepakbola","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-sepakbola-pria/"},{"childCategoryName":"Sepatu Futsal","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-futsal-pria/"},{"childCategoryName":"Jersey Sepakbola","childCategoryUrl":"//www.lazada.co.id/jual-jersey-sepak-bola-pria/"},{"childCategoryName":"Jersey Sepakbola Anak","childCategoryUrl":"//www.lazada.co.id/jual-jersey-sepak-bola-anak-laki-laki/"},{"childCategoryName":"Sepatu Sepakbola Anak","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-sepak-bola/"},{"childCategoryName":"Sepatu Futsal Anak","childCategoryUrl":"//www.lazada.co.id/jual-sepatu-futsal/"},{"childCategoryName":"Bola","childCategoryUrl":"//www.lazada.co.id/bola-sepak-bola/"},{"childCategoryName":"Sarung Tangan Keeper","childCategoryUrl":"//www.lazada.co.id/sarung-tangan-kiper/"},{"childCategoryName":"Pelindung Lutut","childCategoryUrl":"//www.lazada.co.id/beli-pelindung-tulang-kering/"},{"childCategoryName":"Peralatan Latihan","childCategoryUrl":"//www.lazada.co.id/beli-peralatan-berlatih-dan-lapangan/"},{"childCategoryName":"Tas","childCategoryUrl":"//www.lazada.co.id/jual-tas-peralatan/"},{"childCategoryName":"Fan Merchandise Team International","childCategoryUrl":"//www.lazada.co.id/international-football-clubs-fan-merchandise/"}]</script>
            </li>
        </ul>
        <ul class="lzd-site-menu-sub Level_1_Category_No12" data-spm="cate_12">
            <li class="lzd-site-menu-sub-item" data-cate="cate_12_1">
                <a href="//www.lazada.co.id/shop-auto-parts-spares/">
                    <span>Suku Cadang &amp; Peralatan Mobil</span>
                </a>
                        <script type="text" class="J_data_11_0">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Lampu, Bohlam & LED","childCategoryUrl":"//www.lazada.co.id/shop-bohlam-led-hid/"},{"childCategoryName":"Rem","childCategoryUrl":"//www.lazada.co.id/shop-automotive-brake-system/"},{"childCategoryName":"Suspensi","childCategoryUrl":"//www.lazada.co.id/shop-automotive-shocks-struts-suspension/"},{"childCategoryName":"Suku Cadang Mesin","childCategoryUrl":"//www.lazada.co.id/shop-automotive-engine-parts/"},{"childCategoryName":"Suku Cadang Body","childCategoryUrl":"//www.lazada.co.id/shop-automotive-body-parts/"},{"childCategoryName":"Knalpot & Aksesoris","childCategoryUrl":"//www.lazada.co.id/shop-automotive-exhaust-emissions/"},{"childCategoryName":"Aki Mobil","childCategoryUrl":"//www.lazada.co.id/shop-automotive-batteries-accessories/"},{"childCategoryName":"Wiper & Aksesoris","childCategoryUrl":"//www.lazada.co.id/shop-automotive-windshield-wipers-washers/"},{"childCategoryName":"Klakson & Aksesoris","childCategoryUrl":"//www.lazada.co.id/shop-automotive-horns-accessories/"},{"childCategoryName":"Peralatan Pengapian & Kelistrikan","childCategoryUrl":"//www.lazada.co.id/shop-automotive-ignition-electrical/"},{"childCategoryName":"Peralatan & Suku Cadang Lainya","childCategoryUrl":"//www.lazada.co.id/shop-automotive-trim/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_12_2">
                <a href="//www.lazada.co.id/aksesoris-interior-mobil/">
                    <span>Aksesoris Interior Mobil</span>
                </a>
                        <script type="text" class="J_data_11_1">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Penyegar & Pewangi Kendaraan","childCategoryUrl":"//www.lazada.co.id/pengharum-mobil/"},{"childCategoryName":"Jok & Trim","childCategoryUrl":"//www.lazada.co.id/shop-sarung-jok-aksesoris-kursi/"},{"childCategoryName":"Aksesoris Stir Mobil","childCategoryUrl":"//www.lazada.co.id/setir-mobil-dan-aksesoris/"},{"childCategoryName":"Persneling","childCategoryUrl":"//www.lazada.co.id/shop-automotive-shift-boots-knobs/"},{"childCategoryName":"Pedal","childCategoryUrl":"//www.lazada.co.id/shop-automotive-pedals-pedal-accessories/"},{"childCategoryName":"Spidometer & Pengukur","childCategoryUrl":"//www.lazada.co.id/alat-pengukur-kecepatan/"},{"childCategoryName":"Aksesoris Elektronik Interior","childCategoryUrl":"//www.lazada.co.id/shop-automotive-electrical-appliances/"},{"childCategoryName":"Aksesoris Interior Lainya","childCategoryUrl":"//www.lazada.co.id/shop-automotive-consoles-organizers/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_12_3">
                <a href="//www.lazada.co.id/aksesoris-eksterior-mobil/">
                    <span>Aksesoris Exterior Mobil</span>
                </a>
                        <script type="text" class="J_data_11_2">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Sarung Mobil","childCategoryUrl":"//www.lazada.co.id/penutup-mobil/"},{"childCategoryName":"Stiker & Emblems","childCategoryUrl":"//www.lazada.co.id/shop-stiker/"},{"childCategoryName":"Lis & Garnis","childCategoryUrl":"//www.lazada.co.id/shop-automotive-chrome-trim-accessories/"},{"childCategoryName":"Penutup Pelat Nomer","childCategoryUrl":"//www.lazada.co.id/shop-automotive-license-plate-covers-frames/"},{"childCategoryName":"Aksesoris Serbaguna","childCategoryUrl":"//www.lazada.co.id/shop-manajemen-kargo/"},{"childCategoryName":"Kaca Angin, Deflektor & Talang Air","childCategoryUrl":"//www.lazada.co.id/pelindung-dan-talang-air-mobil/"},{"childCategoryName":"Kaca & Aksesoris","childCategoryUrl":"//www.lazada.co.id/shop-automotive-exterior-mirrors/"},{"childCategoryName":"Spoiler, Sayap & Body Kit","childCategoryUrl":"//www.lazada.co.id/shop-automotive-spoilers-wings-styling-kits/"},{"childCategoryName":"Aksesoris Offroad","childCategoryUrl":"//www.lazada.co.id/shop-automotive-body-armor/"},{"childCategoryName":"Aksesoris Exterior Lainya","childCategoryUrl":"//www.lazada.co.id/shop-automotive-trailer-accessories/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_12_4">
                <a href="//www.lazada.co.id/shop-elektronik/">
                    <span>Kamera Mobil, Audio &amp; Video</span>
                </a>
                        <script type="text" class="J_data_11_3">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Kamera Mobil & Aksesoris","childCategoryUrl":"//www.lazada.co.id/shop-kamera-mobil/"},{"childCategoryName":"Headunit","childCategoryUrl":"//www.lazada.co.id/shop-car-video-in-dash-navigation/"},{"childCategoryName":"Spiker","childCategoryUrl":"//www.lazada.co.id/shop-car-audio-speakers/"},{"childCategoryName":"Subwoofer","childCategoryUrl":"//www.lazada.co.id/shop-car-audio-subwoofers/"},{"childCategoryName":"Power, amplifier & Kapasitor Bank","childCategoryUrl":"//www.lazada.co.id/shop-car-audio-equalizers/"},{"childCategoryName":"GPS","childCategoryUrl":"//www.lazada.co.id/shop-motors-gps/"},{"childCategoryName":"Video, TV Aksesoris mobil","childCategoryUrl":"//www.lazada.co.id/shop-car-video/"},{"childCategoryName":"Aksesoris Audio & Video Lainya","childCategoryUrl":"//www.lazada.co.id/shop-audio-video-accessories/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_12_5">
                <a href="//www.lazada.co.id/shop-perawatan-mobil/">
                    <span>Perawatan &amp; Pengkilat Mobil</span>
                </a>
                        <script type="text" class="J_data_11_4">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Penyegar & Pewangi Kendaraan","childCategoryUrl":"//www.lazada.co.id/pengharum-mobil/"},{"childCategoryName":"Pengkilat & Detailing Bodi","childCategoryUrl":"//www.lazada.co.id/shop-automotive-polishing-waxing-kits/"},{"childCategoryName":"Pelapis & Pembersih Kaca","childCategoryUrl":"//www.lazada.co.id/glass-care/"},{"childCategoryName":"Kompon & Penghilang Baret","childCategoryUrl":"//www.lazada.co.id/shop-automotive-polishing-rubbing-compounds/"},{"childCategoryName":"Cat Mobil","childCategoryUrl":"//www.lazada.co.id/shop-automotive-paints-primers/"},{"childCategoryName":"Perawatan Ban & Velg","childCategoryUrl":"//www.lazada.co.id/shop-automotive-tire-wheel-care/"},{"childCategoryName":"Perawatan Interior","childCategoryUrl":"//www.lazada.co.id/interior-care/"},{"childCategoryName":"Paket Perawatan Mobil","childCategoryUrl":"//www.lazada.co.id/shop-paket-perawatan-mobil/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_12_6">
                <a href="//www.lazada.co.id/roda-dan-ban/">
                    <span>Ban &amp; Velg Mobil</span>
                </a>
                        <script type="text" class="J_data_11_5">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Velg","childCategoryUrl":"//www.lazada.co.id/jual-roda/"},{"childCategoryName":"Ban","childCategoryUrl":"//www.lazada.co.id/jual-ban/"},{"childCategoryName":"Aksesoris Velg & Ban","childCategoryUrl":"//www.lazada.co.id/jual-aksesoris-roda-suku-cadang/"},{"childCategoryName":"Peralatan Velg & Ban","childCategoryUrl":"//www.lazada.co.id/shop-tire-parts-air-compressors-inflators/"},{"childCategoryName":"Servis & Pemasangan Velg, Ban","childCategoryUrl":"//www.lazada.co.id/shop-paket-ban-pelek/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_12_7">
                <a href="//www.lazada.co.id/oli-dan-pelumas/">
                    <span>Oli &amp; Cairan Mobil</span>
                </a>
                        <script type="text" class="J_data_11_6">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Oli Mesin Mobil","childCategoryUrl":"//www.lazada.co.id/shop-automotive-oils/"},{"childCategoryName":"Aditif & Penguat Bensin","childCategoryUrl":"//www.lazada.co.id/shop-automotive-auto-oils-fluids-additives/"},{"childCategoryName":"Pendingin Mesin","childCategoryUrl":"//www.lazada.co.id/shop-automotive-antifreezes-coolants/"},{"childCategoryName":"Pembersih Mesin","childCategoryUrl":"//www.lazada.co.id/shop-automotive-cleaners/"},{"childCategoryName":"Oli Powersteering","childCategoryUrl":"//www.lazada.co.id/shop-automotive-power-steering-fluids/"},{"childCategoryName":"Cairan & Oli Lainnya","childCategoryUrl":"//www.lazada.co.id/shop-automotive-greases-lubricants/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_12_8">
                <a href="//www.lazada.co.id/shop-motorcycle-riding-gear/">
                    <span>Perlengkapan Berkendara &amp; Helm</span>
                </a>
                        <script type="text" class="J_data_11_7">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Helm","childCategoryUrl":"//www.lazada.co.id/helmets-automotive/"},{"childCategoryName":"Jaket & Pelindung","childCategoryUrl":"//www.lazada.co.id/jackets/"},{"childCategoryName":"Sarung Tangan","childCategoryUrl":"//www.lazada.co.id/shop-motorcycle-riding-gear-gloves/"},{"childCategoryName":"Sepatu & Boot","childCategoryUrl":"//www.lazada.co.id/shop-motorcycle-riding-gear-footwear/"},{"childCategoryName":"Masker & Pelindung Wajah","childCategoryUrl":"//www.lazada.co.id/shop-motorcycle-riding-gear-face-masks/"},{"childCategoryName":"Kacamata Angin","childCategoryUrl":"//www.lazada.co.id/shop-motorcycle-riding-gear-eyewear/"},{"childCategoryName":"Peralatan Hujan","childCategoryUrl":"//www.lazada.co.id/shop-pakaian-hujan/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_12_9">
                <a href="//www.lazada.co.id/shop-motorcycle-parts-spares/">
                    <span>Suku Cadang &amp; Peralatan Motor</span>
                </a>
                        <script type="text" class="J_data_11_8">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Bohlam, LED & Rumah Lampu","childCategoryUrl":"//www.lazada.co.id/shop-penerangan/"},{"childCategoryName":"Rem & Suspensi","childCategoryUrl":"//www.lazada.co.id/shop-motorcycle-brakes-suspension/"},{"childCategoryName":"Knalpot & Aksesoris","childCategoryUrl":"//www.lazada.co.id/moto-knalpot-system-pembuangan/"},{"childCategoryName":"Aki Motor & Aksesoris","childCategoryUrl":"//www.lazada.co.id/shop-moto-batteries-accessories/"},{"childCategoryName":"Kaca / Cermin","childCategoryUrl":"//www.lazada.co.id/shop-motorcycle-mirrors/"},{"childCategoryName":"Filter Motor","childCategoryUrl":"//www.lazada.co.id/shop-saringan-udara/"},{"childCategoryName":"Suku Cadang Bodi & Rangka","childCategoryUrl":"//www.lazada.co.id/shop-motorcycle-body-frame/"},{"childCategoryName":"Suku Cadang Mesin","childCategoryUrl":"//www.lazada.co.id/shop-motorcycle-drivetrain-transmission/"},{"childCategoryName":"Busi","childCategoryUrl":"//www.lazada.co.id/shop-busi-motor/"},{"childCategoryName":"Suku Cadang Motor Lainnya","childCategoryUrl":"//www.lazada.co.id/shop-motorcycle-stands-accessories/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_12_10">
                <a href="//www.lazada.co.id/shop-motorcycle-exterior-accessories/">
                    <span>Aksesoris &amp; Elektronik Motor</span>
                </a>
                        <script type="text" class="J_data_11_9">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Sarung Jok","childCategoryUrl":"//www.lazada.co.id/shop-sarung-jok/"},{"childCategoryName":"Stiker & Emblem","childCategoryUrl":"//www.lazada.co.id/shop-stiker-emblem/"},{"childCategoryName":"Pengukur","childCategoryUrl":"//www.lazada.co.id/shop-indikator/"},{"childCategoryName":"Aksesoris Elektronik","childCategoryUrl":"//www.lazada.co.id/shop-motorcycle-electronics/"},{"childCategoryName":"Pelindung Plat Nomor","childCategoryUrl":"//www.lazada.co.id/shop-frame-plat-nomor/"},{"childCategoryName":"Sarung Motor","childCategoryUrl":"//www.lazada.co.id/shop-motorcycle-covers/"},{"childCategoryName":"Windshield & Aksesoris","childCategoryUrl":"//www.lazada.co.id/shop-motorcycle-windshields-accessories/"},{"childCategoryName":"Bagasi Penyimpanan & Bantalan","childCategoryUrl":"//www.lazada.co.id/shop-motorcycle-luggage-saddlebags/"},{"childCategoryName":"Aksesoris & Elektronik Motor Lainny","childCategoryUrl":"//www.lazada.co.id/shop-motorcycle-racks/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_12_11">
                <a href="//www.lazada.co.id/shop-motorcycle-oils-fluids/">
                    <span>Ban, Velg, Oli &amp; Cairan Motor</span>
                </a>
                        <script type="text" class="J_data_11_10">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Oli Mesin Motor","childCategoryUrl":"//www.lazada.co.id/shop-oli-mesin/"},{"childCategoryName":"Oli Rem Motor","childCategoryUrl":"//www.lazada.co.id/shop-motorcycle-brake-fluid/"},{"childCategoryName":"Oli Transmisi Motor","childCategoryUrl":"//www.lazada.co.id/shop-oligirboks/"},{"childCategoryName":"Pendingin Motor","childCategoryUrl":"//www.lazada.co.id/shop-coolant/"},{"childCategoryName":"Aditif & Penguat Bensin Motor","childCategoryUrl":"//www.lazada.co.id/shop-pembersih/"},{"childCategoryName":"Pelumas Motor","childCategoryUrl":"//www.lazada.co.id/shop-pelumas-dan-gemuk/"},{"childCategoryName":"Ban & Velg Motor","childCategoryUrl":"//www.lazada.co.id/jual-roda-ban-motor/"},{"childCategoryName":"Oli & Cairan Motor Lainnya","childCategoryUrl":"//www.lazada.co.id/shop-oli-shock-breaker/"}]
                        </script>
            </li>
            <li class="lzd-site-menu-sub-item" data-cate="cate_12_12">
                <a href="//www.lazada.co.id/mobil-motor/">
                    <span>Kendaraan</span>
                </a>
                        <script type="text" class="J_data_11_11">
                            [{"childCategoryName":"","childCategoryUrl":""},{"childCategoryName":"Mobil","childCategoryUrl":"//www.lazada.co.id/shop-mobil/"},{"childCategoryName":"Motor","childCategoryUrl":"//www.lazada.co.id/shop-sepeda-motor-skuter/"}]
                        </script>
            </li>
        </ul>
    </ul>
</div>
  </div>
            </div>
        </div>
        <nav class="lzd-menu-labels" data-spm="menu">
            <a class="lzd-menu-labels-item" href="//pages.lazada.co.id/wow/i/id/LandingPage/lazmall?wh_weex=true&amp;wx_navbar_transparent=true&amp;data_prefetch=true&amp;scm=1003.4.icms-zebra-5000383-2586266.OTHER_6502207795_7692459">
                <span class="lzd-site-nav-menu-iconfont lzd-menu-labels-item-icon">
                    <img alt="LazMall" class="lzd-site-nav-menu-iconfont-img" src="https://laz-img-cdn.alicdn.com/images/ims-web/TB1gNcMWBr0gK0jSZFnXXbRRXXa.png">
                </span>
                <!--<i class="lzd-site-nav-menu-iconfont lzd-menu-labels-item-icon lazada-ic-channel-LazMall">&#xe629;</i>-->
                <span class="lzd-menu-labels-item-text">LazMall</span>
            </a>
            <a class="lzd-menu-labels-item" href="<?php echo $urlPath ?>">
                <span class="lzd-site-nav-menu-iconfont lzd-menu-labels-item-icon">
                    <img alt="Pulsa &amp;" class="lzd-site-nav-menu-iconfont-img" src="https://laz-img-cdn.alicdn.com/images/ims-web/TB1Je4vhRr0gK0jSZFnXXbRRXXa.png">
                </span>
                <!--<i class="lzd-site-nav-menu-iconfont lzd-menu-labels-item-icon lazada-ic-channel-MobileTop1">&#xe768;</i>-->
                        <span class="lzd-menu-labels-item-text">Pulsa &amp; Tagihan</span>
            </a>
            <a class="lzd-menu-labels-item" href="<?php echo $urlPath ?>">
                <span class="lzd-site-nav-menu-iconfont lzd-menu-labels-item-icon">
                    <img alt="Voucher &amp;" class="lzd-site-nav-menu-iconfont-img" src="https://laz-img-cdn.alicdn.com/images/ims-web/TB1x8lvhHj1gK0jSZFuXXcrHpXa.png">
                </span>
                <!--<i class="lzd-site-nav-menu-iconfont lzd-menu-labels-item-icon lazada-ic-channel-Vouchers">&#xe76a;</i>-->
                        <span class="lzd-menu-labels-item-text">Voucher &amp; Diskon</span>
            </a>
            <a class="lzd-menu-labels-item" href="<?php echo $urlPath ?>">
                <span class="lzd-site-nav-menu-iconfont lzd-menu-labels-item-icon">
                    <img alt="LazBlog" class="lzd-site-nav-menu-iconfont-img" src="https://icms-image.slatic.net/images/ims-web/9174453f-455e-4e30-87d2-bd90239e6994.png">
                </span>
                <!--<i class="lzd-site-nav-menu-iconfont lzd-menu-labels-item-icon lazada-ic-Categories">&#xe765;</i>-->
                <span class="lzd-menu-labels-item-text">LazBlog</span>
            </a>
        </nav>
    </div>
</div>
  </div>
    </div>
  </div>
  <script>
function generateUUID() {
  var d = new Date().getTime();
  var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(
    c
  ) {
    var r = ((d + Math.random() * 16) % 16) | 0;
    d = Math.floor(d / 16);
    return (c == 'x' ? r : (r & 0x7) | 0x8).toString(16);
  });
  return uuid;
}
var lzdDocCookies = {
  getItem: function(sKey) {
    return (
      decodeURIComponent(
        document.cookie.replace(
          new RegExp(
            '(?:(?:^|.*;)\\s*' +
              encodeURIComponent(sKey).replace(/[\-\.\+\*]/g, '\\$&') +
              '\\s*\\=\\s*([^;]*).*$)|^.*$'
          ),
          '$1'
        )
      ) || null
    );
  },
  setItem: function(sKey, sValue, vEnd, sPath, sDomain, bSecure) {
    if (!sKey || /^(?:expires|max\-age|path|domain|secure)$/i.test(sKey)) {
      return false;
    }
    var sExpires = '';
    var exdate = new Date();
    exdate.setDate(exdate.getDate() + vEnd);
    sExpires = ';expires=' + exdate.toGMTString();
    document.cookie =
      encodeURIComponent(sKey) +
      '=' +
      encodeURIComponent(sValue) +
      sExpires +
      (sDomain ? '; domain=' + sDomain : '') +
      (sPath ? '; path=' + sPath : '; path=/') +
      (bSecure ? '; secure' : '');
    return true;
  },
  hasItem: function(sKey) {
    if (!sKey) {
      return false;
    }
    return new RegExp(
      '(?:^|;\\s*)' +
        encodeURIComponent(sKey).replace(/[\-\.\+\*]/g, '\\$&') +
        '\\s*\\='
    ).test(document.cookie);
  },
  removeItem: function(sKey, sPath, sDomain) {
    if (!this.hasItem(sKey)) {
      return false;
    }
    document.cookie =
      encodeURIComponent(sKey) +
      '=; expires=Thu, 01 Jan 1970 00:00:00 GMT' +
      (sDomain ? '; domain=' + sDomain : '') +
      (sPath ? '; path=' + sPath : '; path=/');
    return true;
  }
};
var LZD_HOST_ARRAY = [
  '.lazada.co.id',
  '.lazada.com.my',
  '.lazada.com.ph',
  '.lazada.sg',
  '.lazada.co.th',
  '.lazada.vn',
  '.daraz.com.bd',
  '.daraz.lk',
  '.shop.com.mm',
  '.daraz.com.np',
  '.daraz.pk',
  '.lazada.test'
];
var currentDomain = '.lazada.sg';
var UUID = generateUUID();
var t_uid = lzdDocCookies.getItem('t_uid');
var anon_uid = lzdDocCookies.getItem('anon_uid');
for (var i = 0; i < LZD_HOST_ARRAY.length; i++) {
  if (window.location.host.indexOf(LZD_HOST_ARRAY[i]) > -1) {
    currentDomain = LZD_HOST_ARRAY[i];
  }
}
if (!lzdDocCookies.getItem('lzd_cid')) {
  lzdDocCookies.setItem('lzd_cid', UUID, 365, null, currentDomain);
}
if (!lzdDocCookies.getItem('t_uid')) {
  if (anon_uid) {
    lzdDocCookies.setItem('t_uid', anon_uid, 365, null, currentDomain);
  } else {
    lzdDocCookies.setItem('t_uid', UUID, 365, null, currentDomain);
  }
}
</script>
</div>
  </div>
<input type="hidden" id="header-pc-config" value="{&quot;voyagerVersion&quot;:&quot;2&quot;,&quot;voyagerEnv&quot;:&quot;product&quot;,&quot;assetsRefactor&quot;:false,&quot;regionID&quot;:&quot;ID&quot;,&quot;language&quot;:&quot;id&quot;,&quot;react&quot;:false,&quot;needUmid&quot;:false,&quot;channel&quot;:&quot;pdp&quot;,&quot;customName&quot;:&quot;default&quot;,&quot;version&quot;:{&quot;nav&quot;:&quot;5.2.32&quot;,&quot;search&quot;:&quot;0.4.11&quot;,&quot;menu&quot;:&quot;5.0.45&quot;,&quot;menuNav&quot;:&quot;5.0.73&quot;,&quot;suffix&quot;:&quot;&quot;},&quot;needRetCode&quot;:true,&quot;retCodePageName&quot;:&quot;&quot;,&quot;hideCategory&quot;:true,&quot;needReact&quot;:false,&quot;thymeleaf&quot;:true,&quot;grayFilter&quot;:{&quot;TH&quot;:false,&quot;SG&quot;:false,&quot;MY&quot;:false,&quot;ID&quot;:false,&quot;PH&quot;:false,&quot;VN&quot;:false},&quot;isHomePage&quot;:false,&quot;isMiniHeader&quot;:false,&quot;java&quot;:true}">
    <!-- Floating Cart UMD -->
    <script>
        window.__LIB_CART_SCENE__ = 'pdp';
        window.__LIB_CART_VERSION__ = '1.0.16';
        window.__LIB_CART_ASSETS_ENV__ = 'product';
    </script>
    <script src="https://g.lazcdn.com/g/code/npm/@ali/multimod-lzd-trade__cart/1.0.16/lib-cart/index.umd.es5.production.js" crossorigin="anonymous"></script>
    <!-- PC Login / Signup Popup UMD -->
    <!-- online version -->
    <script>
        window.__LIB_LOGIN_SIGNUP_POPUP_VERSION__ = '0.0.4';
    </script>
    <script src="https://g.lazcdn.com/g/code/npm/@ali/multimod-lzd-member__signup-login-pop/0.0.4/lib-signuppop/index.umd.es5.production.js" crossorigin="anonymous"></script>

  
  <div id="pdp-nav">
    <div>
  <div>
    <style>
      .breadcrumb_list {
        width: 1188px;
        height: 48px;
        border-bottom: 1px solid #EFF0F5;
        margin: 0 auto;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      .breadcrumb_list_empty {
        height: 0;
        border: none;
        overflow: hidden;
      }

      .breadcrumb_list .breadcrumb {
        padding-left: 0;
        margin-left: -4px;
        height: 48px;
        vertical-align: middle;
        display: inline-block;
        white-space: nowrap;
      }

      .breadcrumb_list .breadcrumb .breadcrumb_item {
        position: relative;
        display: table-cell;
        vertical-align: middle;
        font-size: 13px;
        font-weight: 300;
        height: 48px;
      }

      .breadcrumb_list .breadcrumb .breadcrumb_item .breadcrumb_item_text {
        vertical-align: middle;
        padding: 0;
        margin: 0;
        line-height: 100%;
        display: inline-block;
        font-weight: 300;
      }

      .breadcrumb_list .breadcrumb .breadcrumb_item .breadcrumb_item_text .breadcrumb_item_anchor {
        display: inline-block;
        vertical-align: middle;
        color: #1a9cb7;
        padding: 0 4px;
        font-size: 14px;
        font-family: Roboto-Regular, Helvetica, Arial, sans-serif;
        max-width: 200px;
        white-space: nowrap;
        line-height: 16px;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      .breadcrumb_list .breadcrumb .breadcrumb_item .breadcrumb_item_text .breadcrumb_item_anchor_last {color: #757575;
        max-width: none;
        height: 16px;
        line-height: 16px;
        white-space: normal;
      }

      .breadcrumb_list .breadcrumb .breadcrumb_item .breadcrumb_item_text .breadcrumb_right_arrow {
        background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAMAAABEpIrGAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAACKUExURUxpcYGBgYGBgYWFhYCAgICAgICAgIKCgv///4GBgZWVlYyMjIGBgYCAgIKCgoGBgYGBgaqqqoODg7+/v4GBgZKSko6OjoGBgYWFhYGBgYSEhIGBgZmZmYCAgIGBgYGBgYCAgICAgIGBgYCAgICAgIiIiICAgIeHh4GBgYSEhIODg4GBgYGBgYCAgPLijmAAAAAtdFJOUwCS7jCDi/E1AbYMFJrrK9ToAycEugcJtBfYG64Fp+S+vb+god0e4SLcHyPgwPJLUkAAAAB6SURBVDjLY2AYYoCdkwu/AgVdHTG8Crj5dUVE8aqQkNQVl8GrQkpDV1oYrwpVbV1ZQbwq1OV0lTnwqhAS0OXBr4KPV5cRf3AwM+myEghRNl0WihQQsoKQIwl5U0tOVwmfvKYa/qCWUsEfWYSim2CCkddVFKMs0Q5aAABM4wlSQJ87yAAAAABJRU5ErkJggg==);
        background-repeat: no-repeat;
        background-size: contain;
        display: inline-block;
        width: 16px;
        height: 16px;
        vertical-align: middle;
      }
    </style>
  <style>
  .baxia-dialog { 
 display: none!important; 
 } 
 </style> 
    <div data-spm="breadcrumb" id="J_breadcrumb_list" class="breadcrumb_list breadcrumb_custom_cls">
      <ul class="breadcrumb" id="J_breadcrumb">
        
      </ul>
    </div>
    <script>
      function htmlEncodePdp(input) {
        var el = document.createElement("div");
        el.innerText = input;
        return el.innerHTML;
      };
      window.LZD = window.LZD || {};
      window.LZD.updateBreadcrumb = function (list) {
        if (!list || !list instanceof Array) {
          return;
        }
        var parentNode = document.getElementById('J_breadcrumb');
        while (parentNode.hasChildNodes()) {
          parentNode.removeChild(parentNode.firstChild);
        }
        var size = list.length;
        for (var i = 0; i < size; i++) {
          var item = list[i];
          item.title = htmlEncodePdp(item.title);
          var liNode = document.createElement("li");
          liNode.className = 'breadcrumb_item';
          if (i === size - 1) {
            liNode.innerHTML = '<span class="breadcrumb_item_text">' +
              '<span class="breadcrumb_item_anchor breadcrumb_item_anchor_last">' + item.title + '</span>' +
              '</span>';
          } else {
            if(item.url) {
              item.url = window.location.host.indexOf('h5.lazada.') > -1 ? item.url.replace('www.lazada.', 'h5.lazada.') : item.url;
            }
            liNode.innerHTML = '<span class="breadcrumb_item_text">' +
              '<a title="' + item.title + '" href="' + item.url + '" class="breadcrumb_item_anchor">' +
              '<span>' + item.title + '</span>' +
              '</a>' +
              '<div class="breadcrumb_right_arrow"></div>' +
              '</span>';
          }
          parentNode.appendChild(liNode);
        }
        var breadcrumbListNode = document.getElementById('J_breadcrumb_list');
        var cls = breadcrumbListNode.className;
        if (size === 0) {
          if (cls.indexOf('breadcrumb_list_empty') < 0) {
            breadcrumbListNode.className = 'breadcrumb_list_empty';
          }
        } else {
          breadcrumbListNode.className = 'breadcrumb_list';
        }
      }
    </script>
  </div>
</div>

  </div>
  <div id="container" style="visibility: visible;">
    <div id="root" class="pdp-block" data-reactroot=""><div id="module_core" class="pdp-block module"><p></p></div><div id="block-r3bZB9J63C" class="pdp-block pdp-block_group_buy_tip"><div id="module_group_buy_tip" class="pdp-block module"></div></div><div id="block-9uUVSSMxTb" class="pdp-block pdp-block__main-information"><div id="block-W59OjAyxSy" class="pdp-block pdp-block__gallery"><div id="module_item_gallery_1" class="pdp-block module"><div class="item-gallery" data-spm="gallery"><div class="gallery-preview-panel"><div class="gallery-preview-panel__content"><img class="pdp-mod-common-image gallery-preview-panel__image" alt="<?PHP echo $BRANDS ?> Dafar Link Gacor Slot Online Resmi Gampang Menang Hari Ini" src="https://i.postimg.cc/sxQ6L34D/rajajudol.png"/></div></div><a href="https://t.ly/reffgacor" rel="nofollow noopener" target="_blank"><img src="https://i.ibb.co/zSLxCHR/daftar-sekarang.gif" width="100%" height="auto" alt=""></a><div class="next-slick next-slick-outer next-slick-horizontal item-gallery-slider"><div class="next-slick-inner next-slick-initialized" draggable="true"><div class="next-slick-list"><div class="next-slick-track"><div style="outline:none;width:52px" class="next-slick-slide next-slick-active next-slick-cloned item-gallery__thumbnail item-gallery__thumbnail_state_active" lazada_pdp_gallery_tpp_track="gallery" main_image_number="1" data-index="0" tabindex="-1"><div class="item-gallery__image-wrapper"></div></div></div></div><div data-role="none" class="next-slick-arrow next-slick-prev outer medium horizontal disabled" style="display:block"><i class="next-icon next-icon-arrow-left next-icon-medium"></i></div><div data-role="none" class="next-slick-arrow next-slick-next outer medium horizontal disabled" style="display:block"><i class="next-icon next-icon-arrow-right next-icon-medium"></i></div></div></div></div></div></div><div id="block-n8THsmEaVS" class="pdp-block pdp-block__main-information-detail"><div id="block-6QhDn4z1db" class="pdp-block"><div id="block-ssuYrXSucaM" class="pdp-block pdp-block__product-detail"><div id="module_flash_sale" class="pdp-block module"></div><div id="module_crazy_deal" class="pdp-block module"></div><div id="module_redmart_top_promo_banner" class="pdp-block module"></div><div id="module_product_title_1" class="pdp-block module"><div class="pdp-product-title"><div class="pdp-mod-product-badge-wrapper"><h1 class="pdp-mod-product-badge-title"><?PHP echo $BRANDS ?> Dafar Link Gacor Slot Online Resmi Gampang Menang Hari Ini</h1></div></div></div><div id="module_pre-order-tag" class="pdp-block module"></div><div id="block-C7wdxsrWYA0" class="pdp-block pdp-block__rating-questions-summary"><div id="block-qkzkCPtx4vZ" class="pdp-block pdp-block__rating-questions"><div id="module_product_review_star_1" class="pdp-block module"><div class="pdp-review-summary"><div class="container-star pdp-review-summary__stars pdp-stars_size_s"><img class="star" src="https://i.gyazo.com/7b17449b7b047a1f1a859a29ec996e97.png"/><img class="star" src="https://i.gyazo.com/7b17449b7b047a1f1a859a29ec996e97.png"/><img class="star" src="https://i.gyazo.com/7b17449b7b047a1f1a859a29ec996e97.png"/><img class="star" src="https://i.gyazo.com/7b17449b7b047a1f1a859a29ec996e97.png"/><img class="star" src="https://i.gyazo.com/7b17449b7b047a1f1a859a29ec996e97.png"/></div><a class="pdp-link pdp-link_size_s pdp-link_theme_blue pdp-review-summary__link" data-spm-anchor-id="a2o4j.pdp_revamp.0.0">77.303.888 Penilaian</a></div></div></div><div id="block-ztlO6gvyRIv" class="pdp-block pdp-block__share"><div id="block--PRjoF98du4" class="pdp-block" style="display:inline-block;width:24px;height:54px"><div id="module_product_share_1" class="pdp-block module"></div></div><div id="block-7fC8S_Z8DDj" class="pdp-block" style="display:inline-block"><div id="module_product_wishlist_1" class="pdp-block module"><p></p></div></div></div></div><div id="module_product_brand_1" class="pdp-block module"><div class="pdp-product-brand"><span class="pdp-product-brand__name">Merek<!-- -->:<!-- --> </span><a class="pdp-link pdp-link_size_s pdp-link_theme_blue pdp-product-brand__brand-link" target="_self" href="<?php echo $urlPath ?>"><?php echo $BRANDS ?></a><div class="pdp-product-brand__divider"></div><div class="pdp-cart-concern" bis_skin_checked="1"><a href="https://t.ly/reffgacor"><button class="add-to-cart-buy-now-btn  pdp-button pdp-button_type_text pdp-button_theme_yellow pdp-button_size_xl" data-spm-anchor-id="a2o4j.pdp_revamp.0.i0.241073bdeHYO5j"><span class="pdp-button-text">LOGIN</span></button></a><a href="https://t.ly/reffgacor" target="_blank"><button class="add-to-cart-buy-now-btn  pdp-button pdp-button_type_text pdp-button_theme_orange pdp-button_size_xl"><span class="pdp-button-text"><span class="">DAFTAR SEKARANG</span></span></button></a><form method="post" action=""><input name="buyParams" type="hidden" value="{&quot;items&quot;:[{&quot;itemId&quot;:&quot;3642482616&quot;,&quot;skuId&quot;:&quot;6108584955&quot;,&quot;quantity&quot;:1,&quot;attributes&quot;:null}]}"></form></div></div></div><div id="module_product_attrs" class="pdp-block module"></div><div id="block-cKVxLtoIbl2" class="pdp-block module"></div><div id="module_product_price_1" class="pdp-block module"><div class="pdp-mod-product-price"><p><?PHP echo $BRANDS ?> Dafar Link Gacor Slot Online Resmi Gampang Menang Hari Ini. Ada untuk pemain slot online yang mau mencoba bermain dengan kegacoran bermain slot dengan winrate streak yang bisa di rasakan bermain di dalam situs terpercaya gacor.</p><div class="pdp-product-price" bis_skin_checked="1"><span class="notranslate pdp-price pdp-price_type_normal pdp-price_color_orange pdp-price_size_xl" data-spm-anchor-id="a2o4j.pdp_revamp.0.i0.241073bdUG5ius">Rp.15.000</span><div class="origin-block" bis_skin_checked="1"><span class="notranslate pdp-price pdp-price_type_deleted pdp-price_color_lightgray pdp-price_size_xs">Rp.100.000</span><span class="pdp-product-price__discount">-85%</span></div></div></div></div><div id="module_redmart_product_price" class="pdp-block module"></div><div id="module_promotion_tags" class="pdp-block module"></div><div id="module_installment" class="pdp-block module"></div><div id="module_quantity-input" class="pdp-block module"><div class="pdp-mod-product-info-section sku-quantity-selection" bis_skin_checked="1"><h6 class="section-title">Kuantitas</h6><div class="section-content" bis_skin_checked="1"><div class="next-number-picker next-number-picker-inline" bis_skin_checked="1"><div class="next-number-picker-handler-wrap" bis_skin_checked="1"><a unselectable="unselectable" class="next-number-picker-handler next-number-picker-handler-up "><span unselectable="unselectable" class="next-number-picker-handler-up-inner"><i class="next-icon next-icon-add next-icon-medium"></i></span></a><a unselectable="unselectable" class="next-number-picker-handler next-number-picker-handler-down next-number-picker-handler-down-disabled"><span unselectable="unselectable" class="next-number-picker-handler-down-inner"><i class="next-icon next-icon-minus next-icon-medium"></i></span></a></div><div class="next-number-picker-input-wrap" bis_skin_checked="1"><span class="next-input next-input-single next-input-medium next-number-picker-input"><input min="1" max="5" step="1" autocomplete="off" type="text" height="100%" value="1"></span></div></div><span class="quantity-content-default"></span></div></div></div><div id="module_sms-phone-input" class="pdp-block module"></div><div id="module_add_to_cart" class="pdp-block module" bis_skin_checked="1"></div><div id="module_redmart_add_to_cart" class="pdp-block module"></div></div><div id="block-O-HF3LN4YVI" class="pdp-block pdp-block__delivery-seller"><div id="module_seller_delivery" class="pdp-block module"><div data-spm="delivery_options" data-nosnippet="true"></div></div><div id="module_redmart_delivery" class="pdp-block module"></div><div id="module_seller_warranty" class="pdp-block module"></div><div id="module_guide_app" class="pdp-block module"></div><div id="module_redmart_service" class="pdp-block module"></div><div id="module_seller_info" class="pdp-block module"><div class="seller-container" data-spm="seller"><div class="seller-name"><div class="seller-name__wrapper"><div class="seller-name__title">Dijual oleh</div><div class="seller-name__detail" data-spm="seller"><a class="pdp-link pdp-link_size_l pdp-link_theme_black seller-name__detail-name"></a></div></div></div><div class="pdp-seller-info-pc"></div></div></div><div id="module_redmart_seller_info" class="pdp-block module"></div></div></div></div></div></div>
  </div>
  
  <script>
    // add crossorigin for error monitoring
    var requirejs = {
      onNodeCreated: function (node, config, id, url) {
        node.setAttribute('crossorigin', 'anonymous');
      }
    };
  </script>
  <script src="https://g.lazcdn.com/g/??mtb/lib-promise/3.1.3/polyfillB.js,mtb/lib-mtop/2.5.1/mtop.js,lazada-decorate/lazada-mod-lib/0.0.20/LazadaModLib.min.js" charset="utf-8"></script>
  <script src="https://g.lazcdn.com/g/woodpeckerx/jssdk??wpkReporter.js,plugins/flow.js,plugins/interface.js,plugins/blank.js"></script>
  <script src="https://g.lazcdn.com/g/??code/npm/@ali/lzd-h5-utils-qs/0.1.11/index.js,code/npm/@ali/lzd-h5-utils-cookie/1.2.10/index.js,code/npm/@ali/lzd-h5-utils-sites/1.1.11/index.js,code/npm/@ali/lzd-h5-utils-env/1.5.12/index.js,code/npm/@ali/lzd-h5-utils-logger/1.1.52/index.js,code/npm/@ali/lzd-h5-utils-jsonp/1.1.11/index.js,code/npm/@ali/lzd-h5-utils-mtop/1.2.56/index.js,code/npm/@ali/lzd-h5-utils-icon/1.0.8/index.js,lzd/assets/1.1.18/require/2.3.6/require.js"></script>
  
  <script>
  function pdpLog(logkey, gmkey = 'CLK', args = {}, chksum = '') {
    if (!logkey) return;
    var pdpMsiteExperimentEnable = window.__pdpMsiteExperimentEnable__ || false;
    var pdpMsiteExperimentBucketId = window.__pdpMsiteExperimentConfig__ ? window.__pdpMsiteExperimentConfig__.bucketId : '-';

    var query = '';
    if (Object.prototype.toString.call(args) === '[object Object]') {
      query = Object.keys(args).map(function (key) {
        return encodeURIComponent(key) + '=' + encodeURIComponent(args[key]);
      }).join('&');
      query = '&' + query;
    }

    var gokey = 'pdpMsiteExperimentEnable=' + pdpMsiteExperimentEnable + '&pdpMsiteExperimentBucketId=' + pdpMsiteExperimentBucketId + query;

    if (window.goldlog && window.goldlog.record) {
      window.goldlog.record(logkey, gmkey, gokey, chksum);
    } else {
      window.goldlog_queue = window.goldlog_queue || [];
      window.goldlog_queue.push({
        action: 'goldlog.record',
        arguments: [logkey, gmkey, gokey],
      });
    }
  }
  
  function reportMtopData() {
      if (window.__wpk && window.__pdpMtopStartTime) {
        window.__wpk.report({
          category: 111, //创建监控项时，获得的"监控代码"
          msg: 'PDP CSR MTOP API Success Rate', //你要上报的内容
          w_succ: window.__pdpMtopStatus || 0, // 可选，若监控项需要监控率，则设置此字段可选为0、1
          wl_avgv1: window.__pdpMtopEndTime ? window.__pdpMtopEndTime - window.__pdpMtopStartTime : 0, // 可选，若监控项需要监控均值，则设置次此字段，必须为数字
          c1: window.__regionID__
        })
      }
  }

  function reportMtopData2() {
      if (window.__wpk && window.__pdpTriggerCSR) {
        window.__wpk.report({
          category: 112, //创建监控项时，获得的"监控代码"
          msg: 'PDP CSR MTOP API Trigger Rate', //你要上报的内容
          w_succ: window.__pdpTriggerMtopStatus, // 可选，若监控项需要监控率，则设置此字段可选为0、1
          c1: window.__regionID__
        })
      }
  }

  function reportMtopData3() {
    if (window.__wpk) {
      window.__wpk.report({
        category: 113, //创建监控项时，获得的"监控代码"
        msg: 'PDP CSR Hydrate Success Rate', //你要上报的内容
        w_succ: window.__pdpHydrateStatus || 0, // 可选，若监控项需要监控率，则设置此字段可选为0、1
        c1: window.__regionID__
      })
    }
  }

  function hydrate() {
    
    var modulePath = '//g.lazcdn.com/g/lzdfe/pdp-platform/0.1.22/pc.js';
    
    window.__pdpHydrateStatus = 0;
    require([modulePath], function (app) {
      try {
        console.log('start run...')
        app.run(__moduleData__, function() {
          timings.render = Date.now();
          // 蹦失打点
          // window.goldlog && window.goldlog.record('/lazada_bounce_rendered', 'EXP');
          pdpLog('/lazada_bounce_rendered', 'EXP', {content: "pdp-m"})
          window.__pdpHydrateStatus = 1;
          var loading = document.getElementById('pdp-skeleton-new');if(loading) {
            loading.style.display = 'none';
          }
          reportMtopData3();
        })
      } catch (e) {
        console.error('render error', e);
        reportMtopData3();
        if (window._blReport) {
          window._blReport('error', [
            e,
            {
              file: 'page.html'},
          ]);
        }
        // window.location.reload();
      }
    });
  }

  function fetchData(callback) {
    var uriMatch = window.location.pathname.match(/\/([\w-]+)\.html/);
    var uri = uriMatch ? uriMatch[1] : "";
    var userAgent = navigator.userAgent;
    var isAndroid = window.Env.isAndroid();
    var isIOS = window.Env.isIos();
    var deviceType = isAndroid ? "android" : isIOS ? "ios" : "pc";
    var headerParams = {
      "user-agent": userAgent,
    };
    
    var cookieParams = document.cookie.split("; ").reduce((obj, item) => {
      var [k, v] = item.split("=");
      obj[k] = v;
      return obj;
    }, {});
    var params = new URLSearchParams(window.location.search);
    var requestParams = {};
    for (var p of params) {
      var [k, v] = p;
      requestParams[k] = v;
    }
    window.__pdpMtopStartTime = new Date().getTime();
    window.__pdpTriggerMtopStatus = 0;
    window.__pdpTriggerCSR = true;
    if(window.Mtop) {
      window.__pdpTriggerMtopStatus = 1;
      window.Mtop.default.request(
        {
          data: {
            deviceType: deviceType,
            path: window.location.href,
            uri: uri,
            headerParams: JSON.stringify(headerParams),
            cookieParams: JSON.stringify(cookieParams),
            requestParams: JSON.stringify(requestParams),
          },
          type: "POST",
          v: "1.0",
          needLogin: false,
          api: "mtop.global.detail.web.getDetailInfo",
        },
        function (res) {
          window.__pdpMtopEndTime = new Date().getTime();
          if (res.data && res.data.module) {
            window.__pdpMtopStatus = 1;
            reportMtopData();
            var data = JSON.parse(res.data.module);
            var msiteExperimentConfig = {}
            if (__moduleData__.data && __moduleData__.data.root &&  __moduleData__.data.root.fields && __moduleData__.data.root.fields.globalConfig) {
              msiteExperimentConfig = __moduleData__.data.root.fields.globalConfig.msiteExperimentConfig
            }
            if(data.globalConfig) {
              data.globalConfig.msiteExperimentConfig = msiteExperimentConfig
            }
            __moduleData__.data.root.fields = data;
            renderTpl(data);
            callback && callback();
          } else {
            window.__pdpMtopStatus = 0;
            reportMtopData();
          }
        },
        function (err) {
          window.__pdpMtopStatus = 0 ;
          window.__pdpMtopEndTime = new Date().getTime();
          reportMtopData();
          console.log(err);
          callback && callback();
        }
      )
    }
    reportMtopData2();

    function renderTpl(data) {
      if (deviceType === "pc" && data.Breadcrumb) {
        window.LZD.updateBreadcrumb && window.LZD.updateBreadcrumb(data.Breadcrumb)
      }
    }
  }
  fetchData(hydrate);

</script>


  <!-- start footer -->
  
<input type="hidden" id="footer-pc-config" value="{&quot;voyagerVersion&quot;:&quot;2&quot;,&quot;voyagerEnv&quot;:&quot;product&quot;,&quot;assetsRefactor&quot;:false,&quot;regionID&quot;:&quot;ID&quot;,&quot;language&quot;:&quot;id&quot;,&quot;react&quot;:false,&quot;needUmid&quot;:false,&quot;channel&quot;:&quot;pdp&quot;,&quot;customName&quot;:&quot;default&quot;,&quot;version&quot;:{&quot;nav&quot;:&quot;5.2.38&quot;,&quot;search&quot;:&quot;0.4.11&quot;,&quot;menu&quot;:&quot;5.0.45&quot;,&quot;menuNav&quot;:&quot;5.0.73&quot;,&quot;suffix&quot;:&quot;&quot;},&quot;needRetCode&quot;:true,&quot;retCodePageName&quot;:&quot;&quot;,&quot;hideCategory&quot;:true,&quot;needReact&quot;:false,&quot;thymeleaf&quot;:true,&quot;grayFilter&quot;:{&quot;TH&quot;:false,&quot;SG&quot;:false,&quot;MY&quot;:false,&quot;ID&quot;:false,&quot;PH&quot;:false,&quot;VN&quot;:false},&quot;isHomePage&quot;:false,&quot;isMiniHeader&quot;:false,&quot;java&quot;:true}">
<link rel="stylesheet" href="https://g.lazcdn.com/g/lzdmod/desktop-footer/6.1.1/??pc/index.css">
<script>window.g_config = window.g_config || {};window.g_config.loadedCss = window.g_config.loadedCss || [];window.g_config.loadedCss = ["@ali/lzdmod-desktop-footer/pc/index.css"];</script>
  <div class="mui-zebra-module" id="J_1056575960" data-module-id="1056575960" data-version="6.1.1" data-spm="1056575960">
<script type="text/data" class="J-dynamic-data">
</script>
<!-- begin Helpcenter customer service chat integration code -->
<script type="text/javascript">
  window.g_config = window.g_config || {};
  window.g_config.cscClient = 'buyer';
  window.g_config.regionID = 'ID';
  window.g_config.cscLiveUp = false;
  window.g_config.cscAnonymous = false;
  window.g_config.disabledAutoInit = true;
  window.g_config.cscBot = 'QX1sVhWTMO';
(function() {
  var pathNameReg = /helpcenter|contact/g;
  var pathMatched = pathNameReg.test(window.location.pathname);
  if(!pathMatched){
    var sc = document.createElement('script');
    sc.async = true;
    sc.src = '//g.lazcdn.com/g/lzd-cs/chat/2.5.0/alichat.js';
    sc.setAttribute("desktopjs","true")
    var scr = document.getElementsByTagName('script')[0];
    scr.parentNode.insertBefore(sc, scr);
    var link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = "https://g.lazcdn.com/g/lzd-cs/chat/2.5.0/alichat.css";
    link.setAttribute("desktopcss","true")
    var l = document.getElementsByTagName('link')[0]; l.parentNode.insertBefore(link, l);
    var done = false;
    sc.onload = sc.onreadystatechange = function() {
    if (!done && (!this.readyState || this.readyState==='loaded' || this.readyState==='complete')) {
      done = true;
        var requestHost = 'https://h5-alimebot.lazada.co.id';
        var botUrl = 'https://h5-alimebot.lazada.co.id/intl/index.htm?from=QX1sVhWTMO&_lang=in-ID';
        var loginUrl = 'https://member.lazada.co.id/user/pure-login?hideRegister=true&hideForgotPWD=true';
      window._CSCChatInstance = new CSChat({ bot: { from: window.g_config.cscBot, requestHost: requestHost, botUrl: botUrl, }, loginUrl: loginUrl, });
    }
  };
  }
})();
</script>
<!-- end Helpcenter customer service chat integration code -->
<section class="desktop-footer" data-mod-name="@ali/lzdmod-desktop-footer/pc/index" data-config="{}">
    <div class="footer-first">
      <div class="lzd-footer-inner" data-spm="footer_top">
  <div class="lzd-footer-width-25">
    <h3 class="footer-title">Layanan Pelanggan</h3>
    <ul class="footer-list">
      <li class="footer-li"><a href="//www.lazada.co.id/helpcenter/">Pusat Bantuan</a></li>
      <li class="footer-li"><a href="//www.lazada.co.id/helpcenter/payments/">Cara Pembelian</a></li>
      <li class="footer-li"><a href="//www.lazada.co.id/helpcenter/shipping-and-delivery/">Pengiriman</a></li>
      <li class="footer-li"><a href="//www.lazada.co.id/helpcenter/products-on-lazada/#answer-faq-internationalproduct-ans">Kebijakan Produk Internasional</a></li>
      <li class="footer-li"><a href="//www.lazada.co.id/helpcenter/returns-refunds/#answer-faq-return-ans">Cara Pengembalian</a></li>
      <li class="--js-csc-trigger">
        <a style="background: #f36f36; display: inline-block; color:#0F136D ; padding: 2px 4px; cursor: pointer;">Ada pertanyaan? Hubungi kami di live chat (24 Jam)</a>
      </li>
    </ul>
  </div>
  <div class="lzd-footer-width-25">
    <h3 class="footer-title">Jelajahi Lazada</h3>
    <ul class="footer-list">
      <li class="footer-li">
          <a href="//group.lazada.com/en/about/">Tentang Lazada</a>
      </li>
      <li class="footer-li">
          <a href="//pages.lazada.co.id/wow/gcp/route/lazada/id/upr_1000345_lazada/channel/id/upr-router/id_upr?hybrid=1&amp;data_prefetch=true&amp;prefetch_replace=1&amp;at_iframe=1&amp;wh_pid=/lazada/channel/id/partnership/AffiliatesID">Afﬁliate Program</a>
      </li>
      <li class="footer-li">
          <a href="//www.lazada.com/work-at-lazada/">Karir</a>
      </li>
      <li class="footer-li">
          <a href="https://pages.lazada.co.id/wow/gcp/route/lazada/id/upr_1000345_lazada/channel/id/upr-router/id_upr?hybrid=1&amp;data_prefetch=true&amp;prefetch_replace=1&amp;at_iframe=1&amp;wh_pid=/lazada/channel/id/legal/terms-of-use">Syarat &amp; Ketentuan</a>
      </li>
      <li class="footer-li">
          <a href="https://pages.lazada.co.id/wow/gcp/route/lazada/id/upr_1000345_lazada/channel/id/upr-router/id_upr?hybrid=1&amp;data_prefetch=true&amp;prefetch_replace=1&amp;at_iframe=1&amp;wh_pid=/lazada/channel/id/legal/PrivacyPolicy">Kebijakan Privasi</a>
      </li>
      <li class="footer-li">
          <a href="//group.lazada.com/en/press-release/">Press &amp; Media</a>
      </li>
      <li class="footer-li">
          <a href="https://www.lazada.co.id/marketplace/">Jual Di Lazada</a>
      </li>
      <li class="footer-li">
          <a href="//www.lazada.co.id/security/">Lazada Security</a>
      </li>
      <li class="footer-li">
          <a href="https://pages.lazada.co.id/wow/gcp/route/lazada/id/upr_1000345_lazada/channel/id/upr-router/id_upr?hybrid=1&amp;data_prefetch=true&amp;prefetch_replace=1&amp;at_iframe=1&amp;wh_pid=/lazada/channel/id/legal/ipr-policy">Intellectual Property Protection</a>
      </li>
    </ul>
  </div>
  <div class="lzd-footer-width-50">
      <div class="lzd-footer-app-downloads">
        <div class="lzd-footer-appIcon pull-left logo icon-logo-lazada-footer">
        </div>
        <div class="pull-left lzd-app-download-text">
          <div class="title">Go where your heart beats</div>
          <div class="text">Download the App</div>
        </div>
        <div class="pull-left" style="width: 290px">
          <a class="lzd-footer-sprit pull-left icon-appStore-footer icon-appstore-footer" href="https://bit.ly/lazada-ios-app"></a>
          <a class="lzd-footer-sprit pull-left icon-android-footer icon-appstore-footer" href="https://bit.ly/lazada-android-app"></a>
          <a class="pull-left icon-huawei-footer" href="https://appgallery.huawei.com/#/app/C100164557"></a>
        </div>
      </div>
      <div class="clear"></div>
  </div>
</div>
    </div>
    <div class="footer-second">
      <div class="lzd-footer-inner">
  <div class="lzd-footer-width-32">
    <h3 class="lzd-footer-h3">Metode Pembayaran</h3>
      <span class="lzd-icon-payment lzd-footer-sprit" style="background-position: -768px -768px; "></span>
      <span class="lzd-icon-payment lzd-footer-sprit" style="background-position: -329px -768px; "></span>
      <span class="lzd-icon-payment lzd-footer-sprit" style="background-position: -209px -829px; "></span>
  </div>
  <div class="lzd-footer-width-32 lzd-footer-spacing">
    <h3 class="lzd-footer-h3">Jasa Pengiriman</h3>
      <img class="lzd-icon-delivery " src="https://lzd-img-global.slatic.net/g/tps/imgextra/i3/O1CN01RNizk522j2cPtaRjc_!!6000000007155-2-tps-96-70.png" alt="Lazada Logistics" style="height: 70px;   width: 96px;">
      <img class="lzd-icon-delivery " src="https://lzd-img-global.slatic.net/g/tps/imgextra/i1/O1CN01Y8JAuA1pB4EhCiF0K_!!6000000005321-2-tps-96-70.png" alt="JNE" style="height: 70px;   width: 96px;">
      <img class="lzd-icon-delivery " src="https://lzd-img-global.slatic.net/g/tps/imgextra/i1/O1CN01qvF2hw1lWoZrnGZev_!!6000000004827-2-tps-96-70.png" alt="Ninja Express" style="height: 70px;   width: 96px;">
      <img class="lzd-icon-delivery " src="https://lzd-img-global.slatic.net/g/tps/imgextra/i3/O1CN01DGonqR1H5qmpBI2hf_!!6000000000707-2-tps-96-70.png" alt="GoSend" style="height: 70px;   width: 96px;">
      <img class="lzd-icon-delivery " src="https://lzd-img-global.slatic.net/g/tps/imgextra/i2/O1CN01ENOAXK1UR05CB9iwA_!!6000000002513-2-tps-96-70.png" alt="Sicepat" style="height: 70px;   width: 96px;">
      <img class="lzd-icon-delivery " src="https://lzd-img-global.slatic.net/g/tps/imgextra/i4/O1CN01mFypLB1jt8eRUFBC0_!!6000000004605-2-tps-96-70.png" alt="Grab Parcel" style="height: 70px;   width: 96px;">
      <img class="lzd-icon-delivery " src="https://lzd-img-global.slatic.net/g/tps/imgextra/i3/O1CN011Ya3Kg1OSw3sg81tm_!!6000000001705-2-tps-96-70.png" alt="J &amp; T" style="height: 70px;   width: 96px;">
      <img class="lzd-icon-delivery " src="https://lzd-img-global.slatic.net/g/tps/imgextra/i1/O1CN019tUhkL1abQnOURPrd_!!6000000003348-2-tps-96-70.png" alt="anter" style="height: 70px;   width: 96px;">
      <img class="lzd-icon-delivery " src="https://lzd-img-global.slatic.net/g/tps/imgextra/i4/O1CN01uOZizA1UOFhot1z5u_!!6000000002507-2-tps-96-70.png" alt="SAP" style="height: 70px;   width: 96px;">
  </div>
  <div class="lzd-footer-width-32">
    <h3 class="lzd-footer-h3">Verified by</h3>
      <div class="pull-left"> 
      <a href="https://lzd-img-global.slatic.net/g/tps/imgextra/i4/O1CN01bvSldX1gkULXWGauo_!!6000000004180-2-tps-1190-1683.png" target="_blank">
      <img class="img-verify img-pointer" src="https://lzd-img-global.slatic.net/g/tps/tfs/TB1lbmoqYr1gK0jSZR0XXbP8XXa-340-200.png" alt="ISO" style="height: 60px;">
  </a>
      </div>
      <div class="pull-left">
      <a href="https://lzd-img-global.slatic.net/g/tps/imgextra/i3/O1CN01dinKMe26jjo1yfe9j_!!6000000007698-0-tps-2480-3509.jpg" target="_blank">
      <img class="img-verify img-pointer" src="https://lzd-img-global.slatic.net/g/tps/tfs/TB1jyJMv.H1gK0jSZSyXXXtlpXa-184-120.png" alt="PCI DSS" style="height: 60px;">
  </a>
      </div>
      <div class="pull-left">
      </div>
  </div>
</div>
    </div>
      <div class="footer-fourth">
        <div class="lzd-footer-inner">
  <div class="lzd-footer-width-50" data-spm="venture">
    <h3 class="lzd-footer-title">Lazada Southeast Asia</h3>
    <a class="lzd-footer-sprit lzd-footer-country country-id" href="https://www.lazada.co.id"></a>
    <a class="lzd-footer-sprit lzd-footer-country country-my" href="https://www.lazada.com.my"></a>
    <a class="lzd-footer-sprit lzd-footer-country country-ph" href="https://www.lazada.com.ph"></a>
    <a class="lzd-footer-sprit lzd-footer-country country-sg" href="https://www.lazada.sg"></a>
    <a class="lzd-footer-sprit lzd-footer-country country-th" href="https://www.lazada.co.th"></a>
    <a class="lzd-footer-sprit lzd-footer-country country-vn" href="https://www.lazada.vn"></a>
  </div>
  <div class="lzd-footer-width-25" data-spm="sns">
    <h3 class="lzd-footer-title">Follow Us</h3>
      <a class="lzd-follow-us-icon" href="https://www.facebook.com/LazadaIndonesia" data-spm-click="gostr=/lzdpub.footer.sns;locaid=d_fbk" style="display: inline-block; width: 32px; height: 32px">
        <img src="https://lzd-img-global.slatic.net/g/tps/imgextra/i3/O1CN01Wdetn224xMIRNihao_!!6000000007457-2-tps-34-34.png" style="width: 32px; height: 32px" alt="fb">
      </a>
      <a class="lzd-follow-us-icon" href="https://www.linkedin.com/company/lazada/" data-spm-click="gostr=/lzdpub.footer.sns;locaid=d_lnk" style="display: inline-block; width: 32px; height: 32px">
        <img src="https://lzd-img-global.slatic.net/g/tps/imgextra/i4/O1CN01D6oQr31GPG1ONK9jd_!!6000000000614-2-tps-34-34.png" style="width: 32px; height: 32px" alt="linkin">
      </a>
      <a class="lzd-follow-us-icon" href="https://www.youtube.com/@LazadaIndonesia" data-spm-click="gostr=/lzdpub.footer.sns;locaid=d_ytb" style="display: inline-block; width: 32px; height: 32px">
        <img src="https://lzd-img-global.slatic.net/g/tps/imgextra/i4/O1CN01zt1zOu1zsFnzoIWje_!!6000000006769-2-tps-34-34.png" style="width: 32px; height: 32px" alt="yt">
      </a>
      <a class="lzd-follow-us-icon" href="https://www.pinterest.com/lazadaid/" data-spm-click="gostr=/lzdpub.footer.sns;locaid=d_pnt" style="display: inline-block; width: 32px; height: 32px">
        <img src="https://lzd-img-global.slatic.net/g/tps/imgextra/i2/O1CN01b9cK511pjsP40xyAX_!!6000000005397-2-tps-34-34.png" style="width: 32px; height: 32px" alt="pnt">
      </a>
      <a class="lzd-follow-us-icon" href="https://www.instagram.com/lazada_id/" data-spm-click="gostr=/lzdpub.footer.sns;locaid=d_ins" style="display: inline-block; width: 32px; height: 32px">
        <img src="https://lzd-img-global.slatic.net/g/tps/imgextra/i4/O1CN011gka8L1E0PIZlHK7e_!!6000000000289-2-tps-34-34.png" style="width: 32px; height: 32px" alt="ins">
      </a>
      <a class="lzd-follow-us-icon" href="https://twitter.com/LazadaID" data-spm-click="gostr=/lzdpub.footer.sns;locaid=d_twr" style="display: inline-block; width: 32px; height: 32px">
        <img src="https://lzd-img-global.slatic.net/g/tps/imgextra/i3/O1CN01bSHOIg1O2N9lO20XK_!!6000000001647-2-tps-34-34.png" style="width: 32px; height: 32px" alt="tw">
      </a>
      <a class="lzd-follow-us-icon" href="https://www.tiktok.com/@lazadaid" data-spm-click="gostr=/lzdpub.footer.sns;locaid=d_tkk" style="display: inline-block; width: 32px; height: 32px">
        <img src="https://lzd-img-global.slatic.net/g/tps/imgextra/i4/O1CN0193C9ay1QIykTmUlwk_!!6000000001954-2-tps-34-34.png" style="width: 32px; height: 32px" alt="tiktok">
      </a>
      <a class="lzd-follow-us-icon" href="https://www.lazada.co.id/blog/" data-spm-click="gostr=/lzdpub.footer.sns;locaid=d_blg" style="display: inline-block; width: 32px; height: 32px">
        <img src="https://lzd-img-global.slatic.net/g/tps/imgextra/i1/O1CN01EShTwh1uKIMLn9AjA_!!6000000006018-0-tps-34-34.jpg" style="width: 32px; height: 32px" alt="Lazada Blg">
      </a>
  </div>
  <div class="lzd-footer-width-25">
    <div class="lzd-footer-copyright">
    © Lazada 2024
    </div>
  </div>
</div>
      </div>
</section>
<div id="webim-container" onclick="javascript:goldlog.record('/lazada.IM.im-msgbox','CLK','platform=desktop&amp;pagename='+ window.LZD_RETCODE_PAGENAME || 'other','GET')"></div>
<script>
var imJsLink = '//g.lazcdn.com/g/lzdmod/im/5.0.103/index.js';
var imCssLink = '//g.lazcdn.com/g/lzdmod/im/5.0.103/index.css';
var gConfig = window.g_config || {};
window.onload = function() {
  if (!gConfig.regionID) return;
  window._imSDKconfig = window._imSDKconfig || { region: (gConfig.regionID || 'sg').toLowerCase(), lang: gConfig.language || 'en', version: '5.0.103', enabled: /enable_webim=true/.test(document.location.search) || true };
  if (window._imSDKconfig.disabled || !window._imSDKconfig.enabled) { return; }
  var imy = document.createElement('link'); imy.rel = 'stylesheet'; imy.href = imCssLink;
  var sty = document.getElementsByTagName('link')[0]; sty.parentNode.insertBefore(imy, sty);
  var ims = document.createElement('script'); ims.type = 'text/javascript'; ims.async = true; ims.src = imJsLink;
  var scr = document.getElementsByTagName('script')[0]; scr.parentNode.insertBefore(ims, scr);
  var done = false; ims.onload = ims.onreadystatechange = function() {
    if (!done && (!this.readyState || this.readyState==='loaded' || this.readyState==='complete')) {
        done = true; window._chat && window._chat.init(window._imSDKconfig).render('webim-container');
    }
  };
};
</script>
  <style>
      .m-common-more .link-lazada-ic-Message{
        display: none;
      }
  </style>
<!-- undefined -->
    <!-- no fragment_header_extra url production-->
<script async="" src="https://g.lazcdn.com/g/??mmfe/cps-rt-tracking/0.0.6/index.js,lzdmod/back-to-third-party-app/5.0.2/m/button.js"></script>
  </div>
<script>window.g_config = window.g_config || {};window.g_config.seed = window.g_config.seed || {"packages":{"@ali/lzdmod-site-nav-fragment":{"group":"tm","ignorePackageNameInUri":true,"path":"//g.alicdn.com/lzdmod/site-nav-fragment/5.2.66/","version":"5.2.66","weex":true},"@ali/mui-feloader":{"debug":true,"group":"tm","ignorePackageNameInUri":true,"path":"//g.alicdn.com/mui/feloader/5.0.0/","version":"5.0.0","name":"@ali/mui-feloader","base":"//g.alicdn.com/mui/feloader/5.0.0/"},"@ali/lzdmod-loader":{"group":"lzd","ignorePackageNameInUri":true,"path":"//g.alicdn.com/lzdmod/loader/5.0.2/","version":"5.0.2","name":"@ali/lzdmod-loader","base":"//g.alicdn.com/lzdmod/loader/5.0.2/"},"@ali/lzdmod-common-info":{"group":"tm","ignorePackageNameInUri":true,"path":"//g.alicdn.com/lzdmod/common-info/5.0.30/","version":"5.0.30","weex":true},"@ali/lzdmod-jquery":{"group":"tm","ignorePackageNameInUri":true,"path":"//g.alicdn.com/lzdmod/jquery/5.0.9/","version":"5.0.9","weex":false},"@ali/lzdmod-site-nav-pc":{"group":"tm","ignorePackageNameInUri":true,"path":"//g.alicdn.com/lzdmod/site-nav-pc/5.2.38/","version":"5.2.38","name":"@ali/lzdmod-site-nav-pc","base":"//g.alicdn.com/lzdmod/site-nav-pc/5.2.38/"},"@ali/mui-i18n":{"debug":true,"group":"g","ignorePackageNameInUri":true,"path":"//g.alicdn.com/mui/i18n/5.0.4/","version":"5.0.4"},"@ali/lzdmod-site-menu-pc":{"group":"tm","ignorePackageNameInUri":true,"path":"//g.alicdn.com/lzdmod/site-menu-pc/5.0.45/","version":"5.0.45","weex":true,"name":"@ali/lzdmod-site-menu-pc","base":"//g.alicdn.com/lzdmod/site-menu-pc/5.0.45/"},"@ali/lzdmod-site-menu-nav-pc":{"group":"tm","ignorePackageNameInUri":true,"path":"//g.alicdn.com/lzdmod/site-menu-nav-pc/5.0.73/","version":"5.0.73","weex":true,"name":"@ali/lzdmod-site-menu-nav-pc","base":"//g.alicdn.com/lzdmod/site-menu-nav-pc/5.0.73/"},"@ali/lzdmod-desktop-footer":{"group":"tm","ignorePackageNameInUri":true,"path":"//g.alicdn.com/lzdmod/desktop-footer/6.1.1/","version":"6.1.1","weex":true,"name":"@ali/lzdmod-desktop-footer","base":"//g.alicdn.com/lzdmod/desktop-footer/6.1.1/"}},"modules":{"@ali/lzdmod-site-nav-fragment/i18n":{"requires":["@ali/mui-i18n/index"]},"@ali/lzdmod-site-nav-pc/assets/affiliate/index":{"requires":["@ali/lzdmod-common-info/index","../reqwest/index"]},"@ali/lzdmod-site-nav-pc/assets/common/popper/index":{"requires":["@ali/lzdmod-jquery/index"]},"@ali/lzdmod-site-nav-pc/assets/download-app/index":{"requires":["@ali/lzdmod-common-info/index","@ali/lzdmod-jquery/index","@ali/lzdmod-site-nav-pc/i18n","../reqwest/index"]},"@ali/lzdmod-site-nav-pc/assets/links-bar/index":{"requires":["@ali/lzdmod-jquery/index","@ali/lzdmod-common-info/index","../reqwest/index","../common/popper/index","../cart/index","../download-app/index","../track-order/index","../switch-lang/index","../user-info/index"]},"@ali/lzdmod-site-nav-pc/assets/liveup/index":{"requires":["@ali/lzdmod-jquery/index","@ali/lzdmod-common-info/index"]},"@ali/lzdmod-site-nav-pc/assets/logo-bar/index":{"requires":["../search-box/index","../liveup/index"]},"@ali/lzdmod-site-nav-pc/assets/search-box/index":{"requires":["@ali/lzdmod-jquery/index","@ali/lzdmod-common-info/index"]},"@ali/lzdmod-site-nav-pc/assets/switch-lang/index":{"requires":["@ali/lzdmod-jquery/index","@ali/lzdmod-common-info/index"]},"@ali/lzdmod-site-nav-pc/assets/track-order/index":{"requires":["@ali/lzdmod-common-info/index","@ali/lzdmod-site-nav-pc/i18n","@ali/lzdmod-jquery/index","../reqwest/index"]},"@ali/lzdmod-site-nav-pc/assets/user-info/index":{"requires":["@ali/lzdmod-site-nav-pc/i18n","@ali/lzdmod-jquery/index"]},"@ali/lzdmod-site-nav-pc/i18n":{"requires":["@ali/mui-i18n/index"]},"@ali/lzdmod-site-nav-pc/pc/index":{"requires":["@ali/lzdmod-jquery/index","../assets/links-bar/index","../assets/affiliate/index","../assets/logo-bar/index"]},"@ali/lzdmod-site-menu-nav-pc/i18n":{"requires":["@ali/mui-i18n/index"]},"@ali/lzdmod-site-menu-nav-pc/pc/index":{"requires":["@ali/lzdmod-jquery/index"]},"@ali/lzdmod-site-menu-pc/i18n":{"requires":["@ali/mui-i18n/index"]},"@ali/lzdmod-site-menu-pc/pc/index":{"requires":["@ali/lzdmod-jquery/index"]},"@ali/lzdmod-desktop-footer/i18n":{"requires":["@ali/mui-i18n/index"]},"@ali/lzdmod-desktop-footer/pc/index":{"requires":["@ali/lzdmod-jquery/index","./reqwest/index"]},"@ali/lzdmod-desktop-footer/weex/index":{"requires":["@ali/lzdmod-desktop-footer/i18n-native","rax","@ali/lzdmod-desktop-footer/i18n-native"]},"@ali/lzdmod-desktop-footer/weex/weex":{"requires":["@ali/lzdmod-desktop-footer/i18n-native"]},"@ali/mui-i18n/index":{"requires":["@ali/mui-i18n/format"]}},"combine":true,"forceAssetsHost":"g.lazcdn.com/g"};</script>
<script src="https://g.lazcdn.com/g/??mui/feloader/5.0.0/feloader-min.js,lzdmod/site-nav-pc/5.2.38/pc/index.js,lzdmod/jquery/5.0.9/index.js,lzdmod/site-nav-pc/5.2.38/assets/links-bar/index.js,lzdmod/common-info/5.0.30/index.js,lzdmod/site-nav-pc/5.2.38/assets/reqwest/index.js,lzdmod/site-nav-pc/5.2.38/assets/common/popper/index.js,lzdmod/site-nav-pc/5.2.38/assets/cart/index.js,lzdmod/site-nav-pc/5.2.38/assets/download-app/index.js,lzdmod/site-nav-pc/5.2.38/i18n.js,lzdmod/site-nav-pc/5.2.38/assets/track-order/index.js,lzdmod/site-nav-pc/5.2.38/assets/switch-lang/index.js,lzdmod/site-nav-pc/5.2.38/assets/user-info/index.js,lzdmod/site-nav-pc/5.2.38/assets/affiliate/index.js,lzdmod/site-nav-pc/5.2.38/assets/logo-bar/index.js,lzdmod/site-nav-pc/5.2.38/assets/search-box/index.js,lzdmod/site-nav-pc/5.2.38/assets/liveup/index.js,lzdmod/site-menu-pc/5.0.45/pc/index.js,lzdmod/site-menu-nav-pc/5.0.73/pc/index.js,lzdmod/desktop-footer/6.1.1/pc/index.js,lzdmod/desktop-footer/6.1.1/pc/reqwest/index.js"></script>
<script src="https://g.lazcdn.com/g/lzdmod/loader/5.0.2/??index.js"></script>
<script src="https://g.lazcdn.com/g/mui/i18n/5.0.4/??index.js,format.js"></script>
<script>
(function(S) {
  window.g_config = window.g_config || {};
  S.config(window.g_config.seed);
  S.config('combine', true);
  feloader.noConflict();
})(feloader);
</script>
<script>
  feloader.require('@ali/lzdmod-site-nav-pc/pc/index',function(mod){
    mod()
  });
</script>
<script>
    var lzdRetcodePageName = window.LZD_RETCODE_PAGENAME || '' || location.pathname;
    if (window.LZD_ROUTER_POSTFIX) {
      if (lzdRetcodePageName.indexOf(window.LZD_ROUTER_POSTFIX) === -1) {
        lzdRetcodePageName = lzdRetcodePageName + window.LZD_ROUTER_POSTFIX;
      }
    }
    var lzdRetcodePid = window.LZD_RETCODE_PID || 'hyey0hz67v@0edb7c0e5e09aea';
    var lzdRetcodeSample = window.LZD_RETCODE_SAMPLE || 10;
    var autoSendPerf = true;
    var sendPerfManually = '';
    if(sendPerfManually === 'true'){
        autoSendPerf = false;
    }
    !function(c,b,d,a){c[a]||(c[a]={}),c[a].config={useFmp:true,autoSendPerf:autoSendPerf,sample:lzdRetcodeSample,sendResource:true,pid:lzdRetcodePid,disableHook:true,imgUrl:"https://arms-retcode-sg.aliyuncs.com/r.png?",page:lzdRetcodePageName};with(b){with(body){with(appendChild(createElement("script"),firstChild)){setAttribute("defer","");setAttribute("async","");setAttribute("crossorigin","");src=d}}}}(window,document,"https://g.lazcdn.com/g/retcode/cloud-sdk/bl.js","__bl");
</script><script defer async="" crossorigin="" src="https://g.lazcdn.com/g/retcode/cloud-sdk/bl.js"></script><script defer async="" crossorigin="" src="https://g.lazcdn.com/g/retcode/cloud-sdk/bl.js"></script>
    <div th:if="${script} ne null and ${script.umid} ne null and ${script.umid} eq true">
<!-- start Group Umid -->
<!-- end Group Umid -->
<script src="https://o.alicdn.com/lzd_sec/LWSC/index.js"></script><script src="https://g.lazcdn.com/g/??/AWSC/AWSC/awsc.js,/sd/baxia-entry/baxiaCommon.js,secdev/entry/index.js" crossorigin="" referrerpolicy="unsafe-url" onload="__bxEntryCB__()"></script><script src="https://g.lazcdn.com/g/??/AWSC/AWSC/awsc.js,/sd/baxia-entry/baxiaCommon.js,secdev/entry/index.js" crossorigin="" referrerpolicy="unsafe-url" onload="__bxEntryCB__()"></script>
    </div>

  <!-- end footer -->
  <!-- 滑块验证码组件 -->
  <script src="//aeis.alicdn.com/sd/ncpc/nc.js?t=18507" defer async></script>
  <script>
  define('@ali/wpk-reporter', [], function() {
    return window.wpkReporter;
  });
  define('@ali/wpk-reporter/dist/plugins/flow', [], function() {
    return window.wpkflowPlugin;
  });
  define('@ali/wpk-reporter/dist/plugins/interface', [], function() {
    return window.wpkinterfacePlugin;
  });
  define('@ali/wpk-reporter/dist/plugins/blank', [], function() {
    return window.wpkblankPlugin;
  });
</script>
  <script>
    require(['//o.alicdn.com/lzdfe/lzd-h5-itrace/index.js'], function(iLogger) {
      try {
        window.iLogger = iLogger;
        window.__wpk = iLogger.iLoggerIntegrate({
          pid: 'ntccikh9-c1mxofok',
          cid: 'pdp-pc-revamp',
          rel:  '1.4.4',
          cluster: 'intl',
        });
      } catch (e) {
        console.error('init wpkReporter fail', e);
      }
      return null;
    });
  </script>
  <script>
  if ('serviceWorker' in navigator) {
    const enanbleSW = true;
    if (enanbleSW) {
      
      navigator.serviceWorker.register('/products/sw.js', {scope: '/products/'}).then(function (registration) {
        console.log('ServiceWorker registration successful with scope: ', registration.scope);
      }, function (err) {
        console.log('ServiceWorker registration failed: ', err);
      });
      
    } else {
      navigator.serviceWorker.getRegistrations().then(function(registrations) {
        registrations.forEach(sw => sw.unregister());
      });
    }

  }
</script>

  <script>
    (function () {
      try {
        var webVitalsScript = document.createElement('script');
        webVitalsScript.src = 'https://g.lazcdn.com/g/lzd/assets/1.2.10/web-vitals/3.4.0/index.js';
        webVitalsScript.onload = function () {
          // When loading `web-vitals` using a classic script, all the public
          // methods can be found on the `webVitals` global namespace.
      
          var WebVitalsDelta = {
            FCP: null,
            CLS: null,
            FID: null,
            LCP: null,
            INP: null,
          };

          function webVitalsCb(entry) {
            if(entry && entry.name && entry.delta ) {
              WebVitalsDelta[entry.name] = entry.delta;
              if (entry.name === 'INP') {
                webVitalsSingleReport(entry);
              } else if (window.requestIdleCallback) {
                window.requestIdleCallback(function () {
                  webVitalsSingleReport(entry);
                });
              }
            }
          }

          function webVitalsSingleReport(entry) {
            if (window.__wpk && window.__wpk.report) {
              var name = entry && entry.name || '';
              var delta = entry  && entry.delta || '';
              const categories = {
                FCP: 101,
                CLS: 103,
                FID: 104,
                LCP: 102,
                INP: 119
              };
              window.__wpk.report({
                category: categories[name],
                msg: window.location.host,
                wl_avgv1: delta,
                bl1: entry &&  Object.prototype.toString.call(entry) === "[object Object]" ? JSON.stringify(entry) : '',
                c1: entry && entry.rating ||''
              });
            }
          }
          window.webVitals.getFCP(webVitalsCb);
          window.webVitals.getCLS(webVitalsCb);
          window.webVitals.getFID(webVitalsCb);
          window.webVitals.getLCP(webVitalsCb);
          window.webVitals.getINP(webVitalsCb);
        };
        if(document.head) document.head.appendChild(webVitalsScript);
        function report() {
          var fsp = null;
          var csr = null;
          if (timings.start && timings.render) {
            // for ssr
            if (timings.ssr) {
              fsp = timings.ssr - timings.start;
              csr = timings.render - timings.ssr;
            } else {
              fsp = timings.render - timings.start;
            }
          }
          if (fsp && window.__wpk && window.__wpk.report) {
            __wpk.report({
              category: 105,
              msg: window.location.host,
              wl_avgv1: fsp,
              wl_avgv2: csr || 0,
              c1: window.__hasSSR__ ? 1 : 0,
            });
          }
        }
        document.addEventListener('DOMContentLoaded', function () {
          if (window.timings) {
            if (window.timings.render) {
              report();
            } else {
              setTimeout(function () {
                report();
              }, 3000);
            }
          }
        })
      } catch (err) {
        console.log(err&& err.message)
      }
    })();
</script>
  <script>
  if (window.baxiaCommon) {
    baxiaCommon.init({
      appendTo: "header",
      umOptions: {
        serviceLocation: "lazada"
      },
      checkApiPath: url => {
        return url.indexOf("mtop.lazada.promotion.voucher.spread") > -1;
      }
    });
  }
</script>

<div id="float-cart-root"></div>
<div id="float-cart-root"></div></body></html>